# Bảo hiểm tai nạn chuyến đi Green SM Care: Bảo vệ hành khách lên tới 500 triệu đồng chỉ từ 1.000 VNĐ

- **Ngày đăng:** 2026-06-10
- **Chuyên mục:** Công ty
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tong-quan-bao-hiem-tai-nan-chuyen-di-green-sm-care](https://www.greensm.com/vn-vi/news/tong-quan-bao-hiem-tai-nan-chuyen-di-green-sm-care)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Khi di chuyển bằng xe công nghệ, rất ít hành khách để ý rằng mình có thể được bảo vệ trước những rủi ro tai nạn bất ngờ trên đường – chỉ với một khoản phí rất nhỏ. Đó chính là lý doGreen SM giới thiệu Green SM Care, gói bảo hiểm tai nạn dành riêng cho khách hàng sử dụng dịch vụ di chuyển của Green SM.

## Green SM Care là gì?

Green SM Carelà chương trìnhbảo hiểm tai nạn chuyến đigiúp hành khách an tâm hơn khi di chuyển, với mức phí chỉ từ1.000 VNĐ/chuyến xenhưng quyền lợi bảo hiểm có thể lên tới500.000.000 VNĐ. Đây là loại bảo hiểmkhông bắt buộc– hành khách hoàn toàn có thể lựa chọn đăng ký thêm hoặc không trước mỗi chuyến đi, tùy theo nhu cầu cá nhân.

![green sm care decorative illustration with mobile interface](https://cdn.xanhsm.com/2026/06/14dd7640-an-tam-di-chuyen.png)

> **[Nội dung trích xuất từ ảnh]:**
> # AN NHIÊN ĐẶT CHUYẾN AN TÂM DI CHUYỂN
> 
> **Phí bảo hiểm chỉ từ 1.000VND/Chuyến**
> 
> ## Ứng dụng đặt xe Green SM:
> 
> *   **Thời gian:** 15:01
> *   **Điểm đến:** Starbucks - Ecopark, R... (6 phút - 3.1 km)
> *   **Điểm đón:** Tòa S02 - Chung Cư S... / Phụng Công
> *   **Tùy chọn dịch vụ:**
>     *   **Green Premium:** 46.000₫
>         *   2 chỗ
>         *   Đón trong 4 phút
>         *   Tiện nghi, rộng rãi
>     *   **Green Limo - 6 khách:** 55.000₫
>         *   6 chỗ
>         *   Đón trong 3 phút
>     *   **Green Car:** 42.000₫
>         *   4 chỗ
>         *   Đón trong 3 phút
> *   **Phương thức thanh toán:** Visa Card
> *   **Các tùy chọn khác:** Ưu đãi, Hẹn giờ, GreenNow, Đặt xe
> *   **Thêm:** BẬT GREEN SM CARE NGAY

## Quyền lợi bảo hiểm chuyến đi chi tiết

Khi tham gia Green SM Care, hành khách được hưởng các quyền lợi sau nếu xảy ra tai nạn trong chuyến đi:

| Quyền lợi bảo hiểm | Số tiền bảo hiểm |
| --- | --- |
| Tử vong do tai nạn trong chuyến đi | 500.000.000 VNĐ/vụ |
| Thương tật toàn bộ vĩnh viễn do tai nạn trong chuyến đi | 500.000.000 VNĐ/vụ |
| Thương tật bộ phận vĩnh viễn do tai nạn trong chuyến đi | Theo bảng tỷ lệ thương tật, tính trên số tiền bảo hiểm 500.000.000 VNĐ |
| Trợ cấp nằm viện do tai nạn trong chuyến đi | Lên tới 300.000 VNĐ/ngày/người, tối đa 30 ngày/người |
| Trợ cấp khi mất giấy tờ tùy thân trong chuyến đi | 300.000 VNĐ/vụ/người |
| Hỗ trợ chi phí vận chuyển cấp cứu do tai nạn trong chuyến đi | Lên tới 300.000 VNĐ/chuyến |

Có thể thấy, ngoài quyền lợi tử vong và thương tật, Green SM Care còn hỗ trợ những tình huống phát sinh khác trong chuyến đi như mất giấy tờ tùy thân hay chi phí cấp cứu – những khoản chi phí nhỏ nhưng dễ gây phiền toái khi xảy ra bất ngờ.

![green sm care with green sm's driver and mobile interface](https://cdn.xanhsm.com/2026/06/f9ffb9bf-thumb-green-sm-care-1-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là nội dung được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> ```markdown
> **GREEN SM**
> **AN NHIÊN ĐẶT CHUYẾN**
> **AN TÂM DI CHUYỂN**
> 
> (Hình ảnh minh họa giao diện ứng dụng trên điện thoại)
> **14:59**
> **<** Tùy chọn
> 
> **Yêu cầu xuất hoá đơn**
> **Xuất hóa đơn cho doanh nghiệp**
> *TU 01.06.2025, theo Nghị định 10-CP, khách hàng cần ... không thể chỉnh sửa sau đó. Quý khách vui lòng chịu trách nhiệm với thông tin đã cung cấp*
> 
> **Ghi chú**
> *Ghi chú cho bác tài*
> 
> **Tùy chọn chuyến đi**
> *Tài xế sẽ nhận được thông tin và điều chỉnh theo yêu cầu của bạn.*
> 
> **Bảo hiểm**
> **1.000đ**
> *Green SM và OPES được quyền sử dụng dữ liệu cá nhân của khách hàng để cung cấp Giấy Chứng nhận bảo hiểm.* [Chi tiết]
> 
> **Phí bảo hiểm chỉ từ 1.000VND/Chuyến**
> 
> **Áp dụng cho chuyến tiếp theo (tùy chọn).**
> 
> **Chuyến xe im lặng**
> *Tài xế sẽ không bắt chuyện với bạn nếu không thật sự cần thiết.*
> 
> **Chuyến xe giới hạn tốc độ**
> *Lưu ý: Tài xế sẽ vẫn tuân thủ giới hạn tốc độ theo luật.*
> 
> **Cập nhật**
> ```

## Mức phí bảo hiểm

Phí tham gia Green SM Care được cộng trực tiếp vào giá cước mỗi chuyến xe hợp lệ, cụ thể:

- 1.000 VNĐ/chuyếnđối với di chuyển bằng xe máy.

- 2.000 VNĐ/chuyếnđối với dịch vụ di chuyển bằng ô tô.

Mức phí này sẽ tiếp tục được áp dụng cho mỗi chuyến đi kể từ khi hành khách đăng ký tham gia, cho đến khi hành khách chủ động hủy đăng ký trên ứng dụng.

## Ai có thể tham gia Green SM Care?

Đối tượng tham gia bảo hiểm là hành khách người Việt Nam và người nước ngoài di chuyển trong lãnh thổ Việt Nam bằng phương tiện vận chuyển hành khách đường bộ. Chương trình không áp dụng cho lái xe, phụ xe hoặc nhân viên áp tải, nhân viên của đơn vị vận chuyển đang làm nhiệm vụ trên phương tiện đó.

Đáng chú ý, người được bảo hiểm theo Green SM Care vẫn được hưởng quyền lợi của các loại hình bảo hiểm khác mà mình đang tham gia (nếu có), không bị loại trừ lẫn nhau.

## Vì sao nên chọn Green SM Care?

- Chi phí hợp lý:thêm chỉ từ 1.000 VNĐ/chuyến, hành trình trọn vẹn.

- Quyền lợi cao:bảo vệ tài chính lên tới 500 triệu đồng trước các rủi ro tai nạn.

- Linh hoạt:đăng ký hoặc hủy đăng ký bất cứ lúc nào ngay trên ứng dụng Green SM.

## Đối tác cung cấp bảo hiểm

Hợp đồng bảo hiểm tai nạn cá nhân trong chương trình Green SM Care được phân phối bởi một trong các đối tác bảo hiểm uy tín:PVI Digital, OPES, BIC, TCGI, MIC, tương ứng với thông tin trên giấy chứng nhận bảo hiểm được phát hành trên app Green SM.

Chỉ với vài nghìn đồng mỗi chuyến đi,Green SM Caremang đến cho hành khách một lớp bảo vệ tài chính đáng kể trước những rủi ro không mong muốn trên đường. Đây là một lựa chọn đáng cân nhắc cho bất kỳ ai thường xuyên di chuyển bằng dịch vụ của Green SM.
