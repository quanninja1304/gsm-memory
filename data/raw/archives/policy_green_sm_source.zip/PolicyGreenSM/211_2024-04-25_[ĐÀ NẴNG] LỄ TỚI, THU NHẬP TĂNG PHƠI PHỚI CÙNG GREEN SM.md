# [ĐÀ NẴNG] LỄ TỚI, THU NHẬP TĂNG PHƠI PHỚI CÙNG GREEN SM

- **Ngày đăng:** 2024-04-25
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/da-nang-le-toi-thu-nhap-tang-phoi-phoi-cung-xanh-sm](https://www.greensm.com/vn-vi/news/da-nang-le-toi-thu-nhap-tang-phoi-phoi-cung-xanh-sm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Quý Đối tác Tài xế thân mến,

Đồng hành với Quý Đối tác Tài xế vào dịp lễ lớn 30/04 – 01/05, Green SM xin thông tin đến Quý Đối tác Tài xế 02 chương trình thưởng hấp dẫn như sau:

1. Nhân điểm thưởng – áp dụng với chính sách Thưởng điểm tuần:

- Thời gian diễn ra: 27-28/4/2024.

- Nội dung chi tiết: Điểm thưởng của Quý Đối tác Tài xế được nhân 1,5 giá trị trong giai đoạn này.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/04/7056eb4a-2404_chinh-sach-nhan-diem-thuong-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # BẢNG QUY ĐỔI ĐIỂM THƯỞNG DỊP LỄ 30/4 - 1/5
> 
> **Thời gian áp dụng:** 27-28/4/2024
> **Khu vực áp dụng:** Toàn quốc
> 
> ## T7 - CN
> 
> | Khung giờ/ngày | DỊCH VỤ BIKE (Điểm thưởng/1 chuyến xe hoàn thành) | DỊCH VỤ EXPRESS (Điểm thưởng/1 điểm giao hoàn thành) |
> | :------------- | :--------------------------------------------- | :----------------------------------------------- |
> | 00:00 - 04:59  | 1.5                                            | 1.5                                              |
> | 05:00 - 08:59  | 1.5                                            | 1.5                                              |
> | 09:00 - 11:59  | 2.25                                           | 2.25                                             |
> | 12:00 - 15:59  | 1.5                                            | 3                                                |
> | 16:00 - 19:59  | 3                                              | 3                                                |
> | 20:00 - 23:59  | 3                                              | 3                                                |

2. Tăng thưởng vượt mốc – áp dụng với chính sách Thưởng vượt mốc chuyến/ngày:

- Thời gian diễn ra: 29/4 đến hết 1/5/2024.

- Nội dung chi tiết: Thưởng vượt mốc được nhân 1,5 lần dựa theo chính sách thu nhập hiện hành.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/04/4ddf6484-2404_da-nang_cs-nhan-diem-thuong-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # BẢNG ĐIỂM THƯỞNG DỊP LỄ 30/4 - 1/5
> 
> **Thời gian áp dụng:** 29/04 - 01/05/2024
> **Khu vực áp dụng:** ĐÀ NẴNG
> 
> ## Cấp Đại sứ
> 
> | Đại sứ Xanh Bike 5h      | Đại sứ Xanh Bike 8h       | Đại sứ Xanh Bike 10h       |
> | :----------------------- | :------------------------ | :------------------------- |
> | Từ 8 - 12 chuyến: 4.500 VNĐ | Từ 12 - 14 chuyến: 7.500 VNĐ | Từ 14 - 16 chuyến: 9.000 VNĐ |
> | Trên 12 chuyến: 7.500 VNĐ | Trên 14 chuyến: 9.000 VNĐ  | Trên 16 chuyến: 12.000 VNĐ |

- 

Lưu ý:

- 02 chương trình trên áp dụng đối với cả dịch vụ Green SM Bike và Green SM Express.

- Các điều kiện nhận thưởng khác không thay đổi.

Kính chúc Quý Đối tác Tài xế một mùa lễ an lành, thu nhập tăng nhanh cùng Green SM Bike!

Trân trọng,Đội ngũ Green SM Bike.
