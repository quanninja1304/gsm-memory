# [Quan trọng] Chính sách mới: Chạy hăng say, thưởng về tay!

- **Ngày đăng:** 2025-08-08
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-tai-xe-bike-tai-da-nang-va-cac-thi-truong-moi](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-tai-xe-bike-tai-da-nang-va-cac-thi-truong-moi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Đối tác Tài xế thân mến,

Với mong muốn luôn đồng hành cùng Đối tác Tài xế trên hành trình phát triển bền vững, vận doanh hiệu quả trong giai đoạn ra mắt dịch vụ mới,Green SM Bikethông báo cập nhật chính sách thu nhập, áp dụng từ ngày11/8/2025như sau.

✅  Nội dung cập nhật:Điều chỉnh các mốc điểm nhận thưởng tuần (các nội dung còn lại không thay đổi)

Khu vực áp dụng:Quảng Ninh, Hải Phòng, Nghệ An, Huế, Đà Nẵng, Khánh Hòa, Hồ Chí Minh (khu vực Bà Rịa – Vũng Tàu cũ).

Trong thời gian tới, Green SM sẽ tiếp tục theo dõi, đánh giá hiệu quả chính sách để có điều chỉnh phù hợp với nhu cầu thực tiễn và cam kết đồng hành cùng Đối tác trên hành trình tăng trưởng bền vững.

Một số giải đáp liên quan đến chính sách, vui lòng tham khảotại đây.

Xin cảm ơn và chúc Đối tác Tài xế vận doanh an toàn – hiệu quả – thu nhập vượt trội!

Trân trọng,

Đội ngũ Green SM Bike

Toàn bộ nội dung chi tiết, Quý Đối tác vui lòng tham khảo trong ảnh bên dưới.

![(1) Chính sách thu nhập](https://cdn.xanhsm.com/2025/07/e9ea2090-1-chinh-sach-thu-nhap-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THU NHẬP DÀNH CHO TÀI XẾ XANH SM BIKE
> 
> Áp dụng từ ngày 11/08/2025
> 
> | TỔNG THU NHẬP GỘP | | Chia sẻ doanh số (1) | | Thưởng tuần (2) | | Thưởng khác (nếu có) (3) |
> |---|---|---|---|---|---|---|
> | | = | | + | | + | |
> 
> ## (1) Chia sẻ doanh số
> 
> CHIA SẺ DOANH SỐ = 70% x DOANH SỐ
> 
> ### GHI CHÚ:
> 
> *   Doanh số bao gồm cả các phí yêu cầu đặc biệt của dịch vụ Xanh Express (giao tận tay, phí giao hàng cồng kềnh...)
> *   Mức chia sẻ doanh số chưa bao gồm khoản khấu trừ Thuế Thu nhập cá nhân (PIT) & thuế GTGT (VAT)
> ```

![1108_Thuong tuan DN](https://cdn.xanhsm.com/2025/08/3da7472a-1108_thuong-tuan-dn-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP DÀNH CHO TÀI XẾ XANH SM BIKE
> Áp dụng từ ngày 11/08/2025
> 
> ## (2) THƯỞNG TUẦN
> **Khu vực áp dụng:** Quảng Ninh, Hải Phòng, Nghệ An, Huế, Đà Nẵng, Khánh Hòa, Hồ Chí Minh (khu vực Bà Rịa - Vũng Tàu cũ)
> 
> | MỨC ĐIỂM THƯỞNG/TUẦN | MỨC THƯỞNG/TUẦN |
> |---------------------|-----------------|
> | 500 - dưới 800 điểm | 200.000 VNĐ     |
> | 800 - dưới 1200 điểm | 400.000 VNĐ     |
> | 1200 - dưới 1500 điểm| 800.000 VNĐ     |
> | Từ 1500 điểm trở lên | 1.200.000 VNĐ   |

![(3) Bảng quy đổi điểm](https://cdn.xanhsm.com/2025/07/6ee1de3b-3-bang-quy-doi-diem-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là nội dung được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> # XANH SM
> ## CHÍNH SÁCH THU NHẬP
> ## DÀNH CHO TÀI XẾ XANH SM BIKE
> Áp dụng từ ngày 11/08/2025
> 
> ## (2) THƯỞNG TUẦN
> ### BẢNG QUY ĐỔI ĐIỂM THƯỞNG
> 
> | Dịch vụ             | Sáng (6h00-8h59) | Trưa (11h00-13h59) | Chiều (16h00-18h59) | Còn lại (9h00-10h59, 14h00-15h59, 19h00-21h59) |
> | :------------------ | :--------------- | :----------------- | :------------------ | :--------------------------------------------- |
> | Xanh SM Bike        | 10               | 5                  | 10                  | 5                                              |
> | Xanh Express siêu tốc | 5                | 10                 | 5                   | 5                                              |
> | Xanh Express 2h     | 10               | 20                 | 10                  | 10                                             |
> | Xanh SM Ngon        | 15               | 30                 | 30                  | 15                                             |
> 
> ⚠️ Các cuốc hoàn thành trong khung 22h00 – 23h59 và 0h00 – 05h59 không áp dụng tính điểm thưởng

![(4) Điều kiện nhận thưởng](https://cdn.xanhsm.com/2025/07/f8f81959-4-dieu-kien-nhan-thuong-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP DÀNH CHO TÀI XẾ XANH SM BIKE
> 
> ## (2) THƯỞNG TUẦN
> 
> ### ĐIỀU KIỆN NHẬN THƯỞNG
> 
> | STT | TIÊU CHÍ                       | ĐIỀU KIỆN        |
> |-----|--------------------------------|------------------|
> | 1   | Số ngày hoạt động tối thiểu(*)/tuần | >= 5 ngày/tuần   |
> | 2   | Tỷ lệ nhận chuyến/tuần         | >=90%            |
> | 3   | Tỷ lệ hoàn thành chuyến/tuần   | >=90%            |
> 
> (*) Ngày hoạt động là ngày có phát sinh doanh số

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/08/a9ec10f0-image-11-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # XANH SM
> 
> # CHÍNH SÁCH QUẢN LÝ VẬN DOANH DÀNH CHO TÀI XẾ XANH SM BIKE
> 
> ## CHÍNH SÁCH DOANH SỐ TỐI THIỂU
> 
> | Khu vực | Mức khoán doanh số tối thiểu | Mức xử phạt |
> |---|---|---|
> | Hà Nội | 280.000 VNĐ /ngày vận doanh/tài xế (*) | Trong trường hợp **không đạt** mức khoán doanh số tối thiểu ngày, Tài xế Xanh Bike sẽ bị truy thu **20%** phần Doanh số khoán chưa đạt bằng hình thức Trừ Ví tài xế |
> | Đà Nẵng, Hội An, TPHCM, Bình Dương, Đồng Nai | 200.000 VNĐ /ngày vận doanh/tài xế (*) | |
> | Quảng Ninh, Hải Phòng, Nghệ An, Thành phố Huế, Khánh Hòa, Hồ Chí Minh (khu vực Bà Rịa - Vũng Tàu cũ) | 50.000 VNĐ /ngày vận doanh/tài xế (*) | |
> 
> (*) Ngày vận doanh là ngày Đối tác Tài xế phát sinh doanh số
> ```

![Green SM Bike chính thức thông báo cập nhật chính sách thu nhập dành cho Đối tác Tài xế](https://cdn.xanhsm.com/2025/07/e757bc47-anh-6_chinh-sach-qdvd-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH QUẢN LÝ VẬN DOANH DÀNH CHO TÀI XẾ XANH SM BIKE
> 
> ## QUY ĐỊNH TRỰC TUYẾN & TỶ LỆ VẬN HÀNH
> 
> | Tiêu chí                  | Nội dung                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
> | :------------------------ | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Quy định trực tuyến**   | - Cảnh báo nếu Đối tác không trực tuyến/không phát sinh chuyến xe trong **02** ngày liên tiếp. <br> - Công ty sẽ tiến hành **thu hồi xe** và **chấm dứt hợp đồng** nếu **03** ngày liên tiếp Đối tác **không trực tuyến/ không phát sinh chuyến xe** mà không có lý do hợp lệ. Đồng thời, Xanh SM Bike sẽ tiến hành **thu phí sử dụng xe 50.000VND/ngày**, hình thức thu: trừ ví tài xế.                                                                                                                                                                                                                                                                                                                                               |
> | **Quy định tỷ lệ vận hành** | 1. Trường hợp Đối tác Tài xế có **tỷ lệ chấp nhận chuyến dưới 50%**: Hệ thống sẽ mặc định bật tính năng “Nhận chuyến tự động" tới 23h59 của ngày vận doanh đó. <br> 2. Trường hợp Đối tác Tài xế có **tỷ lệ hoàn thành chuyến và/hoặc tỷ lệ chấp nhận chuyến <70%** sẽ bị xử phạt như sau:<br> &nbsp;&nbsp;&nbsp;&nbsp; - Đối với tệp tài xế đạt trung bình **5 đơn/ngày (*)** trở lên: Áp dụng mức phạt **100.000 VNĐ/tuần** nếu vi phạm **03** ngày/tuần.<br> &nbsp;&nbsp;&nbsp;&nbsp; - Đối với tệp tài xế đạt trung bình **dưới 5 đơn/ngày (*)**: Áp dụng mức phạt **200.000 VNĐ/tuần** nếu vi phạm **03** ngày/tuần. Trường hợp vi phạm **03 lần (tuần) liên tiếp**, Công ty sẽ tiến hành **khóa tài khoản & thu hồi xe**. |
> 
> (*) Số đơn trung bình được tính trên ngày vận doanh/tuần
