# [Cập nhật mới] Chính sách đảm bảo thu nhập dành cho Bác Tài Xanh GF-VIP mới gia nhập

- **Ngày đăng:** 2026-08-29
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-moi-chinh-sach-dam-bao-thu-nhap-danh-cho-bac-tai-xanh-gf-vip-moi-gia-nhap](https://www.greensm.com/vn-vi/news/cap-nhat-moi-chinh-sach-dam-bao-thu-nhap-danh-cho-bac-tai-xanh-gf-vip-moi-gia-nhap)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm giúp Bác Tài Xanh an tâm vận doanh và vững tin gắn bó, Green SM cập nhật chính sách đảm bảo thu nhập dành riêng cho Bác Tài Xanh đang vận doanh dịch vụ GF-VIP, được áp dụng từ ngày 31/08/2026.

Với chính sách mới, Green SM tiếp tục khẳng định cam kết đồng hành cùng Bác Tài Xanh trong mọi điều kiện vận doanh, mang đến thêm sự an tâm, ổn định và động lực để Bác Tài Xanh vững vàng trên mọi hành trình. Cùng Green SM tìm hiểu chi tiết chính sách dưới đây:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/08/33c2258a-04.-upd-chinh-sach-dam-bao-thu-nhap-cho-tai-xe-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> DRIVER
> GREEN SM
> BÁC TÀI XANH TAXI
> Cập nhật chính sách
> Đảm bảo thu nhập
> GF VIP
> GF VIP

THÔNG TIN CHUNG

- Đối tượng áp dụng: Bác Tài Xanh mới đăng ký vận doanh dịch vụ GF-VIP trong 03 tháng đầu tiên

- Thời gian áp dụng: Kể từ 31/08/2026 tới khi có thông báo mới nhất

- Khu vực áp dụng: Hà Nội & TP. Hồ Chí Minh (theo địa giới hành chính cũ)

CHI TIẾT CẬP NHẬT

| Mức đảm bảo thu nhập: 650.000đ/ngày |
| --- |
| Số cuốc đảm bảo phát tối thiểu: 06 cuốc/ngàyTrong trường hợp Bác Tài Xanh không được nhận đủ số cuốc đảm bảo, Green SM sẽ bù thu nhập theo mức90.000đ/cuốc |
| Số giờ làm việc tối thiểu: 08 giờ/ngàyGreen SM sẽ tiến hành kiểm tra nghi ngờ gian lận hàng ngày, nếu phát hiện gian lận sẽ áp dụng chế tài xử lý theo quy định chung của Bộ Quy định Nội bộ chung dành cho Tài xế 4 bánh của Công ty |
| Tỷ lệ nhận chuyến trung bình≥ 90% | Tỷ lệ hoàn thành chuyến trung bình≥ 95% |
| Thời gian hoạt động:6h – 22h hàng ngày(Được yêu cầu hoạt động tối thiểu03 tiếng trong khung giờ cao điểm/ngày) (*) |
| Khu vực hoạt động:Trung tâm thành phố (**) |

(*) Khung giờ cao điểm tại được xác định như sau:

| Tỉnh/thành phố | Khung cao điểm | Từ thứ 2 đến thứ 6 | Thứ 7 & Chủ nhật |
| --- | --- | --- | --- |
| Hà Nội & TP. HCM (theo địa giới hành chính cũ) | Sáng | 06:00 – 08:59 | 09:00 – 11:59 |
| Chiều | 16:00 – 21:59 | 17:00 – 23:59 |

(**) Chi tiết các khu vực áp dụng (theo địa giới hành chính cũ) bao gồm:

| Khu vực | Chi tiết |
| --- | --- |
| Thành phố Hà Nội | Quận Ba Đình, Quận Hoàn Kiếm, Quận Tây Hồ, Quận Long Biên, Quận Cầu Giấy, Quận Đống Đa, Quận Hai Bà Trưng, Quận Hoàng Mai, Quận Thạnh Xuân, Quận Nam Từ Liêm, Quận Bắc Từ Liêm, Quận Hà Đông |
| Thành phố Hồ Chí Minh | Quận 1, Quận 12, Quận Gò Vấp, Quận Bình Thạnh, Quận Tân Bình, Quận Tân Phú, Quận Phú Nhuận, TP Thủ Đức, Quận 3, Quận 10, Quận 11, Quận 4, Quận 5, Quận 6, Quận 8, Quận 7, Quận Bình Tân |

Green SM mong mỗi Bác Tài Xanh có thể vững tâm hơn trên từng hành trình, tập trung trọn vẹn vào việc mang đến trải nghiệm tốt nhất cho Khách hàng. Green SM luôn đồng hành cùng Bác Tài Xanh trên mọi chặng đường, để mỗi ngày vận doanh đều là một ngày an tâm và trọn vẹn.

Mọi thắc mắc về chính sách, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Mến chúc Bác Tài Xanh hoạt động an toàn và hiệu quả!

Trân trọng,Green SM.
