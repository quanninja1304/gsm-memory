# Quyền lợi tài xế taxi Green SM hấp dẫn như thế nào?

- **Ngày đăng:** 2023-06-22
- **Chuyên mục:** Cộng đồng
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/quyen-loi-tai-xe-taxi-xanh-sm](https://www.greensm.com/vn-vi/news/quyen-loi-tai-xe-taxi-xanh-sm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bên cạnh mức lương cạnh tranh so với thị trường, đối tác tài xế của Taxi Green SM còn được hưởng những chế độ đãi ngộ riêng biệt. Quyền lợi khi trở thành tài xế Taxi Green SM đã thu hút nhiều sự quan tâm, đặc biệt với những người đang có nhu cầu tìm kiếm cơ hội việc làm tốt. Trở thành một phần của đội ngũ lái xe ngay hôm nay để được hưởng nhữngquyền lợi tài xế Taxi Green SMhấp dẫn.

Tháng 4/2023, GSM chính thức triển khai dịch vụ taxi thuần điện đầu tiên tại Việt Nam. Dịch vụ Taxi Green SM ra mắt với mục tiêu mang đến những trải nghiệm cao cấp như xe không mùi, không tiếng ồn cho khách hàng.

Hiện nay, Taxi Green SM đã có mặt tại thủ đô Hà Nội, TP. Hồ Chí Minh, TP. Huế, TP. Nha Trang, TP. Đà Nẵng. Trong thời gian tới, Taxi Green SM dự kiến mở rộng quy mô hoạt động ra khắp các tỉnh/thành phố trên cả nước.

Với tốc độ phủ sóng nhanh, Taxi Green SM có nhu cầu tuyển dụng số lượng lớn các đối tác lái xe. Đây là cơ hội việc làm tốt với nhữngquyền lợi tài xế Taxi Green SMhấp dẫn dành cho lái xe tại các tỉnh/thành phố.

![Quyền lợi tài xế taxi xanh sm](https://cdn.xanhsm.com/2023/06/612a575f-quyen-loi-tai-xe-taxi-xanh-sm.jpg)

Quyền lợi tài xế Taxi Green SM hấp dẫn bên cạnh mức lương cạnh tranh

## 1. Quyền lợi tài xế taxi Green SM

### 1.1. Chế độ phúc lợi chung

Trở thành tài xế taxi của Taxi Green SM, người làm sẽ nhận được nhiều quyền lợi hấp dẫn. Một sốquyền lợi của tài xế taxi Green SMsẽ được hưởng như sau:

- Tài xế taxi Green SM có thể nhận mức lương cứng lên tới 11 triệu đồng, trong đó: lương cứng cố định từ 7 triệu đồng trở lên (bao gồm bảo hiểm xã hội, bảo hiểm y tế, bảo hiểm thất nghiệp theo quy định pháp luật về quyền của người lao động).

- Các tài xế Taxi Green SM còn được hưởng các khoản thưởng và hỗ trợ chi phí khác như thưởng theo mức đánh giá của khách hàng (2 triệu đồng), hỗ trợ chi phí thuộc đường (2 triệu đồng, tối đa 6 tháng và sẽ thay đổi theo tình hình kinh doanh). Tuy nhiên, mức lương cứng cụ thể sẽ thay đổi tùy theo tỉnh thành.

- Mức lương tài xế nhận được sẽ được cộng thêm hoa hồng 25 – 35% trên tổng doanh thu tháng cũng như hoa hồng từ việc bán chéo các sản phẩm của Vinwonders, VinFast. Đây là một chính sách hấp dẫn, giúp tài xế Taxi Green SM gia tăng thu nhập trong bối cảnh kinh tế còn nhiều khó khăn.

- Taxi Green SM tổ chức các chương trình tham quan du lịch và thưởng lương tháng thứ 13, dựa trên hiệu quả kinh doanh của công ty. Lương và các chế độ chính sách sẽ được tính khi tài xế chính thức làm việc.

![quyền lợi của tài xế taxi](https://cdn.xanhsm.com/2023/06/60fd6daa-lai-xe-taxi.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> **Văn bản:**
> * tổng đài toàn quốc
> * XANH SM
> * TAXI
> * 1900 2088
> 
> **Số liệu:**
> * 1900 2088 (số điện thoại)
> 
> **Tiêu đề:**
> Không có tiêu đề rõ ràng trong hình ảnh.
> 
> **Bảng biểu:**
> Không có bảng biểu trong hình ảnh.
> ```

Quyền lợi tài xế Taxi Green SM thu hút những ứng viên tìm kiếm công việc lái xe taxi

### 1.2. Chế độ phúc lợi riêng cho tài xế LuxuryCar – VF 8

Trở thành tài xế LuxuryCar – VF 8,lái xe taxisẽ có cơ hội được hưởng các chế độ đãi ngộ riêng biệt, cùng với lộ trình phát triển bài bản và chuyên nghiệp, cụ thể như sau:

- Tài xế LuxuryCar sẽ nhận được thu nhập cạnh tranh so với thị trường, bao gồm lương cứng 9.000.000 VNĐ, thưởng 2.000.000 VNĐ dựa trên chất lượng công việc và cộng thêm hỗ trợ tối đa 6 tháng với mức 2.000.000 VNĐ. Mức lương còn được cộng thêm hoa hồng 35% tổng doanh thu tháng và phụ cấp tiếng Anh 500.000 VNĐ.

- Bên cạnh đó, tài xế LuxuryCar – VF 8 còn được hưởng các chế độ phúc lợi như tham gia BHXH, đào tạo tiếng Anh giao tiếp cơ bản, khám sức khỏe định kỳ hàng năm, đào tạo bài bản về ngành dịch vụ vận tải và tư vấn lộ trình phát triển nghề nghiệp rõ ràng.

![quyền lợi của tài xế taxi vinfast](https://cdn.xanhsm.com/2023/06/fd3bd150-quyen-loi-tai-xe-taxi-xanh-sm-luxurycar.jpg)

Các chế độ phúc lợi riêng dành cho tài xế LuxuryCar – VinFast VF 8

## 2. Yêu cầu với đối tác tài xế taxi Green SM

Để trở thành một phần của cộng đồng tài xế Taxi Green SM, ứng viên cần đáp ứng những yêu cầu cụ thể. Đây là những điều kiện cần và đủ để ứng tuyển vị trí tài xế Taxi Green SM.

- Ứng viên cần sở hữu bằng lái xe B2 trở lên.

- Ứng viên có độ tuổi 21 – 55 tuổi.

- Cần thông thạo địa lý tại khu vực làm việc.

- Có lý lịch tư pháp rõ ràng, không có tiền sử gây án.

- Ứng viên có trên 6 tháng kinh nghiệm làm việc tại các hãng taxi loại hình khác như taxi công nghệ, truyền thống, lái xe hợp đồng… là một lợi thế.

- Có sức khỏe tốt, đạt tiêu chuẩn được yêu cầu bởi Bộ Y Tế dành cho nghề Taxi.

- Ứng viên có thể sẵn sàng làm việc luôn.

- Tài xế có tinh thần dịch vụ và mong muốn được làm việc trong môi trường chuyên nghiệp.

## 3. Các bước đăng ký ứng tuyển tài xế taxi Green SM

Với quy trình 3 bước đơn giản, tài xế có thể nhanh chóng trở thành những tiên phong trong sứ mệnh phổ cập trải nghiệm di chuyển điện và lan tỏa lối sống xanh đến cộng đồng.

- Bước 1:Ứng viên điền các thông tin cần thiết vào form đăng kýTẠI ĐÂY

- Bước 2:Ứng viên phỏng vấn theo lịch hẹn và thực hành lái xe trực tiếp tại mỗi tỉnh/thành.

- Bước 3:Sau khi qua vòng phỏng vấn và sát hạch, ứng viên được tham gia chương trình đào tạo tài xế Taxi Green SM.

- Bước 4:Ứng viên thực hiện khám sức khỏe tổng quát

![quyền lợi tài xế taxi điện](https://cdn.xanhsm.com/2023/06/0f4cd614-lam-tai-xe-taxi-xanh-sm.jpg)

Các bước đơn giản để trở thành tài xế Taxi Green SM

Nếu ứng viên đang tìm kiếm một cơ hội việc làm với môi trường làm việc cạnh tranh và lộ trình phát triển rõ ràng, hãy đăng ký ngay để trở thành một phần của cộng đồng tài xế Taxi Green SM.

Là tài xế Taxi Green SM – hãng taxi thuần điện, lái xe sẽ trở thành đội ngũ tiên phong lan tỏa lối sống xanh và phổ cập trải nghiệm phương tiện điện đến với cộng đồng. Vớiquyền lợi tài xế Taxi Green SMhấp dẫn, đây là cơ hội việc làm tốt dành cho những ứng viên có nhu cầu tìm kiếm công việc lái xe.

Nếu quý khách có quan tâm đến dịch vụ Taxi Green SM, xin vui lòng theo dõi các thông tin mới nhất vềCông ty GSM – Taxi Green SMtại Fanpage chính thức vàCộng đồng Tài Xế Green SM – GSMđể cập nhật thêm thông tin.
