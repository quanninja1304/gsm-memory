# Đắk Lắk | Tổng hợp các chính sách thưởng đặc biệt dành cho Bác Tài Xanh

- **Ngày đăng:** 2026-08-19
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/dak-lak-tong-hop-cac-chinh-sach-thuong-dac-biet-danh-cho-bac-tai-xanh](https://www.greensm.com/vn-vi/news/dak-lak-tong-hop-cac-chinh-sach-thuong-dac-biet-danh-cho-bac-tai-xanh)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm đồng hành cùng Bác Tài Xanh để gia tăng thu nhập và phát triển vận doanh tại khu vực Đắk Lắk, Green SM triển khai chuỗi chính sách thưởng đặc biệt dành cho Bác Tài Xanh với nhiều cơ hội nhận thưởng hấp dẫn. Cụ thể như sau:

| Thời gian áp dụng | Từ 20/07/2026 đến hết 30/09/2026 |
| --- | --- |
| Đối tượng áp dụng | Bác Tài Xanh thuộc đối tác Việt Đức nhận được thông báo từ Green SM tại ứng dụng Green SM Driver |
| Khu vực áp dụng | Tỉnh Đắk Lắk |
| Dịch vụ áp dụng | Green Car, Green Limo |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/08/31e3a41b-thumb-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> DRIVER
> GREEN SM
> THÔNG BÁO
> CHƯƠNG TRÌNH THƯỞNG MỚI
> VẬN DOANH
> NGAY
> VOREN
> G
> GREEN SM
> GREEN SM
> ```

🔰Chương trình 1: Thưởng thêm 10.000đ khi hoàn thành chuyến xe GreenNow

Khi hoàn thành mỗi chuyến xe được Khách hàng đặt thông qua tính năng GreenNow, Bác Tài Xanh sẽ nhận thưởng thêm 10.000đ/chuyến xe.

| Điều kiện xác định chuyến xe thỏa mãn chương trình | Phương thức trả thưởng |
| --- | --- |
| Chỉ áp dụng với các chuyến xe Green Now được Khách hàng đặt thông qua Tổng đài Đối tác hoặc Cuốc vẫy | Green SM sẽ tiến hành đối soát và chi trả cho những chuyến xe hợp lệ trong đợt đối soát mỗi tháng. Tiền thưởng sẽ được chi trả khi kết thúc chương trình và hoàn thành đối soát. Lưu ý: Green SM sẽ không tiến hành thu phí nền tảng đối với các chuyến xe Green Now đạt điều kiện trong thời gian diễn ra chương trình. |

🔰Chương trình 2: Thưởng nóng thêm đến 200.000đ/ngày khi hoàn thành đủ số chuyến xe

Bác Tài Xanh hãy sẵn sàng tăng tốc vận doanh để đón đầu nhu cầu di chuyển tăng cao và bứt phá thu nhập cùng chương trình thưởng nóng lên đến 200.000đ/ngày khi hoàn thành đủ số chuyến xe yêu cầu, cụ thể như sau:

💙 Chương trình thưởng:

✅Thưởng thêm 100.000đ/ngày khi hoàn thành 10 chuyến xe/ngày

✅Thưởng thêm 200.000đ/ngày khi hoàn thành thành từ 15 chuyến xe/ngày trở lên

💙Điều kiện áp dụng:

❇️ Tỷ lệ hoàn thành chuyến trung bình ngày ≥ 85%

❇️ Tỷ lệ nhận chuyến trung bình ngày ≥ 80%

🔰Chương trình 3: Thưởng chuyên cần 500.000đ/tháng

Chuyên cần là có thưởng – mà nay thưởng còn “xịn” hơn nữa! 💙💙💙

Mỗi chuyến xe lăn bánh không chỉ mang lại thu nhập hằng ngày mà còn thể hiện sự siêng năng, tinh thần trách nhiệm và nỗ lực bền bỉ của Bác Tài Xanh trên từng cung đường.

Để ghi nhận và tiếp thêm động lực cho những Bác Tài luôn duy trì hoạt động ổn định, Bác Tài Xanh tại khu vực Đắk Lắk sẽ có cơ hội nhận thưởng 500.000đ từ chương trình Thưởng Chuyên Cần! 🏆

Hãy duy trì online đều đặn, nhận cuốc tích cực và chinh phục ngay phần thưởng hấp dẫn từ chương trình. Cụ thể như sau:

NHẬN NGAY MỨC THƯỞNG CHUYÊN CẦN 500.000Đ/THÁNG

Khi Bác Tài Xanh đạt đủ điều kiện:

❇️ Tài xế đạt tối thiểu 26 ngày vận doanh trên nền tảng Green SM

❇️ Tỷ lệ hoàn thành chuyến trung bình ngày ≥ 85%

❇️ Tỷ lệ nhận chuyến trung bình ngày ≥ 80%

Lưu ý: Các điều kiện trên được tính từ ngày đầu tiên đến ngày cuối cùng của tháng

Vui lòng liên hệ với Đội xe để được hỗ trợ giải đáp mọi thắc mắc!

Green SM khuyến khích Bác Tài Xanh hãy tối đa hóa thời gian vận doanh, giữ vững tỷ lệ đẹp và không hủy chuyến để đáp ứng các điều kiện từ chương trình thưởng. Từ đó, tối ưu cơ hội đạt thêm thưởng hấp dẫn!

Mến chúc Bác Tài Xanh hoạt động an toàn và hiệu quả!

Trân trọng,Phòng Phát triển cộng đồng Bác Tài Xanh.
