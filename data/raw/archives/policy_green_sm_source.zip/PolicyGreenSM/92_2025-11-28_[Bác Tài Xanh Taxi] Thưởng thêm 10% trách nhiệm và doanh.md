# [Bác Tài Xanh Taxi] Thưởng thêm 10% trách nhiệm và doanh số khi vận doanh tại sân bay Tân Sơn Nhất

- **Ngày đăng:** 2025-11-28
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-don-khach-san-bay-tan-son-nhat](https://www.greensm.com/vn-vi/news/thuong-don-khach-san-bay-tan-son-nhat)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm khuyến khích Bác Tài Xanh tăng cường vận doanh và gia tăng thu nhập, Green SM triển khai chính sách thưởngthêm 10% doanh sốkhi Bác Tài Xanh  đón khách tại Sân bay Tân Sơn Nhất.

Bác Tài Xanh hãy tận dụng cơ hội vàng và hoạt động tích cực trong khung giờ quy định để bứt phá doanh thu nhé!

Chi tiết chương trình thưởng như sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/11/d51b3c02-thuong-vd-tai-san-bay-tan-son-nhat-4.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG THÊM 10% TRÁCH NHIỆM VÀ DOANH SỐ KHI VẬN DOANH TẠI SÂN BAY TÂN SƠN NHẤT
> 
> | Tiêu đề | Nội dung |
> |---|---|
> | **Đối tượng áp dụng** | Bác Tài Xanh Taxi/Green Limo/Green Premium và GF VIP tại các Depot Hồ Chí Minh 1, 6, 7 |
> | **Thời gian áp dụng** | 16h00 - 01:59 sáng hôm sau \| 28/11/2025 đến khi có thông báo mới nhất |
> | **Mức thưởng** | Thưởng thêm 10% doanh số cho mỗi chuyến xe hoàn thành trong khung giờ, khu vực áp dụng |
> | **Điều kiện áp dụng** | Hoàn thành các chuyến xe phát sinh tại nhà ga T1, T2, T3 |
> 
> TÂN SƠN NHẤT

Mọi thắc mắc Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành và Phát triển Bác Tài Xanh
