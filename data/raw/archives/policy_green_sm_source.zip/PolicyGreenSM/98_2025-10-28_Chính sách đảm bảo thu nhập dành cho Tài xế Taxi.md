# Chính sách đảm bảo thu nhập dành cho Tài xế Taxi

- **Ngày đăng:** 2025-10-28
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-dam-bao-thu-nhap](https://www.greensm.com/vn-vi/news/chinh-sach-dam-bao-thu-nhap)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Tin vui dành cho các Bác tài đến rồi đây. Nhằm đảm bảo thu nhập ổn định và ghi nhận nỗ lực của các Bác tài, Công ty triển khai Chính sách Đảm bảo thu nhập tối thiểu600.000đ mỗi ngày.

Chính sách này giúp Bác tài yên tâm vận doanh, duy trì hiệu suất làm việc và nâng cao chất lượng dịch vụ.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/45f6f805-251028_chinhsach-02-818x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH ĐẢM BẢO THU NHẬP DÀNH CHO TÀI XẾ TAXI
> 
> **Đối tượng áp dụng**
> *   Bác tài mới (chưa có kinh nghiệm vận doanh tại Xanh SM)
> *   Bác tài tái tuyển
> 
> **Phạm vi áp dụng**
> 
> | Dịch vụ áp dụng       | Khu vực áp dụng                                                                  | Thời gian Đảm bảo thu nhập                                                                                             |
> | :-------------------- | :------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------- |
> | Xanh SM Car, Xanh SM Premium | Hà Nội và TP.HCM (không bao gồm khu vực Bình Dương và Bà Rịa - Vũng Tàu) | Trong thời gian tập nghề                                                                                               |
> | Xanh SM Limo          | Toàn quốc                                                                        | Trong thời gian tập nghề hoặc trong 02 tháng kể từ ngày Bác tài chuyển sang dịch vụ Xanh SM Limo                      |
> 
> **Thời gian áp dụng**
> Kể từ ngày 06/10/2025
> 
> **Mức đảm bảo thu nhập**
> Tối thiểu **600.000 VNĐ/ngày**
> 
> **Điều kiện áp dụng**
> *   Hoạt động tuân thủ 100% phân công và quy định phân ca của Đội xe
> *   Online tối thiểu 8 giờ/ngày
> *   Duy trì tỷ lệ nhận và hoàn thành chuyến ≥ 90% mỗi ngày
> *   Đảm bảo quãng đường di chuyển tối thiểu 70 km/ngày

Lưu ý:

- Các mức đảm bảo thu nhập bao gồm: Lương cơ bản và các khoản thưởng theo Chính sách thu nhập của Tài xế Taxi khi Bác tài đạt đủ các Điều kiện của chương trình. Mức đảm bảo thu nhập được áp dụng theo ngày, số ngày đạt trong tháng không quá 26 ngày. Từ ngày thứ 27 trở đi, áp dụng thưởng theo chính sách hiện hành.

- Các khoản thưởng theo Chính sách thu nhập bao gồm: Thưởng Trách nhiệm & Doanh số, Thưởng YTCLCV, Thưởng chuyên cần, Thưởng thâm niên, Thưởng vượt công chuẩn, Thưởng KOC, Thưởng số cuốc và số khách Xanh liên tỉnh, Hoàn sạc Tài xế tập nghề.

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác tài vận doanh an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
