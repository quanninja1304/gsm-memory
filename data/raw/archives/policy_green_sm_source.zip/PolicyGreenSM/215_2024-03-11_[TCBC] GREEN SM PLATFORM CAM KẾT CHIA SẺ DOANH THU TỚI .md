# [TCBC] GREEN SM PLATFORM CAM KẾT CHIA SẺ DOANH THU TỚI 80% TRONG 3 NĂM ĐẦU, HỖ TRỢ ĐỐI TÁC TÀI XẾ AN TÂM SỞ HỮU Ô TÔ ĐIỆN VINFAST

- **Ngày đăng:** 2024-03-11
- **Chuyên mục:** Báo chí, Công ty
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tcbc-xanh-sm-platform-cam-ket-chia-se-doanh-thu-toi-80-trong-3-nam-dau](https://www.greensm.com/vn-vi/news/tcbc-xanh-sm-platform-cam-ket-chia-se-doanh-thu-toi-80-trong-3-nam-dau)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

Hà Nội, ngày 08/03/2024 – Công ty Cổ phần Di chuyển Xanh và Thông minh (GSM) công bố chính sách hỗ trợ đối tác tài xế vay mua ô tô điện VinFast trả góp qua ngân hàng bằng việc cam kết duy trì mức chia sẻ doanh thu lên tới 80% trong 3 năm đầu tiên. Đây là mức chia sẻ doanh thu tốt nhất thị trường hiện nay, đảm bảo cho các đối tác tài xế có nguồn thu nhập ổn định và dễ dàng sở hữu ô tô điện VinFast.

Sau khi chính thức ra mắt nền tảng Green SM Platform, tạo cơ hội cho các chủ sở hữu xe ô tô điện VinFast gia nhập hệ sinh thái Green SM để cung cấp dịch vụ vận chuyển 5 sao bằng xe điện tới đông đảo người dân, công ty GSM tiếp tục công bố chính sách hỗ trợ các đối tác tài xế mua mới ô tô điện VinFast.

Cụ thể, với các đối tác tài xế mua mới xe VinFast bằng hình thức trả góp hoặc trả thẳng theo chính sách VinFast đang triển khai, khi tham gia vào Green SM Platform sẽ được cam kết mức chia sẻ doanh thu tối thiểu 78% (nếu đạt hạn mức và chỉ tiêu tối thiểu), có thể lên tới 80% (nếu vượt hạn mức và được thưởng). Các mức này được GSM cam kết duy trì trong vòng 3 năm đầu tiên, đảm bảo cho các đối tác tài xế có nguồn thu nhập ổn định và an tâm, chủ động với các phương án tài chính và kế hoạch cá nhân.

Ông Nguyễn Văn Thanh – Tổng giám đốc Công ty GSM toàn cầu cho biết:“Cam kết chia sẻ doanh thu lên tới 80% trong vòng 3 năm liên tục cho các đối tác tài xế là chính sách chưa từng có tiền lệ trên thị trường gọi xe công nghệ, cho thấy quyết tâm của GSM trong việc thúc đẩy chuyển đổi xanh và kiến tạo giao thông xanh tại Việt Nam. Tôi tin tưởng chính sách đặc biệt hấp dẫn này sẽ nhận được sự hưởng ứng của các đối tác tài xế trên toàn quốc, qua đó nhanh chóng phổ cập thói quen di chuyển xanh bằng xe điện tới đông đảo người dân, góp phần giảm thiểu ô nhiễm môi trường”.

Green SM Platform là nền tảng công nghệ đa dịch vụ thuần điện đầu tiên tại Việt Nam do GSM phát triển, nhằm kết nối các chủ xe VinFast có nhu cầu cung cấp dịch vụ vận tải với khách hàng, qua đó lan tỏa xu hướng sống xanh trong cộng đồng và tạo ra nguồn thu nhập hấp dẫn cho các chủ xe điện VinFast.

Green SM Platform dự kiến sẽ chính thức đi vào hoạt động từ ngày 20/03/2024. Các chủ sở hữu xe điện VinFast trên toàn quốc có thể đăng ký trở thành đối tác tài xế của Green SM Platform ngay từ hôm nay tại địa chỉ:https://www.xanhsm.com/platform/.

ĐĂNG KÝ NGAY
