# Vì sao nhiều hãng vận tải đồng loạt muốn đẩy nhanh chuyển đổi sang xe điện?

- **Ngày đăng:** 2024-08-16
- **Chuyên mục:** Báo chí
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/vi-sao-nhieu-hang-van-tai-dong-loat-muon-day-nhanh-chuyen-doi-sang-xe-dien](https://www.greensm.com/vn-vi/news/vi-sao-nhieu-hang-van-tai-dong-loat-muon-day-nhanh-chuyen-doi-sang-xe-dien)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Với nhiều doanh nghiệp vận tải, việc chuyển đổi sang xe điện là bước ngoặt giúp cải thiện doanh thu, chất lượng dịch vụ, thậm chí là vực dậy trong lúc khó khăn nhất. Cùng với những chính sách “chơi lớn” vừa được Green SM công bố, nhiều doanh nghiệp mong muốn đẩy nhanh quá trình “phủ xanh” 100% đội xe.

“Xe điện đã cứu chúng tôi”

Góp mặt trong hội thảo “Mãnh liệt tinh thần Việt Nam – Vì tương lai xanh” tổ chức mới đây tại Hà Nội, ông Nguyễn Ngọc Đồng – Tổng Giám đốc Công ty TNHH Đồng Thúy (đơn vị vận hành hãng Lado Taxi) nhớ lại quãng thời gian khó khăn vì ảnh hưởng bởi dịch bệnh Covid-19. Lado Taxi khoảng thời gian cuối năm 2021, đầu năm 2022 rơi vào cảnh phải cơ cấu lại nợ và loay hoay chưa tìm thấy lối ra.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/08/b1b438dd-nhan0375-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Tiêu đề: VÌ TƯƠNG LAI XANH
> 
> **Thời gian và địa điểm:** Hồ Chí Minh, 02.08.2024
> 
> **Hình ảnh mô tả:** Một nhóm người đàn ông đang ngồi trên sân khấu, có vẻ như đang tham gia một buổi tọa đàm hoặc hội nghị. Phía sau họ là một màn hình lớn hiển thị hình ảnh có chữ "VÌ TƯƠNG LAI XANH" và "Hồ Chí Minh, 02.08.2024", cùng với hình ảnh các tòa nhà cao tầng, cây xanh và ô tô điện.
> 
> **Các đối tượng trong hình:**
> *   Năm người đàn ông mặc vest hoặc áo sơ mi lịch sự, ngồi trên ghế bọc nệm.
> *   Người đàn ông ở giữa bên trái đang cầm micro và nói.
> *   Trên bàn giữa họ có đặt các chai nước, ly thủy tinh và bình hoa nhỏ.
> *   Phía sau là màn hình lớn với các chi tiết đã nêu ở trên, bao gồm cả một chiếc ô tô điện màu xanh lá cây nhạt và màu vàng.
> *   Có chữ "XANH" màu vàng trên một bảng nhỏ phía trước chiếc ô tô điện.
> ```

Tình cờ, đó cũng là khoảng thời gian VinFast VF e34 đang nhận được sự quan tâm lớn của cộng đồng. Ông Đồng bắt đầu tìm hiểu về xe điện và ngay lập tức quyết định mua những chiếc xe xanh đầu tiên. “Những ngày đầu, nhiều người kêu tôi… khùng nhưng tới hôm nay tôi khẳng định với mọi người: Chính xe điện đã cứu Lado và 1.500 con người”.

Trong thời gian khó khăn ấy, theo ông Đồng, việc chuyển đổi sang taxi điện đã giúp doanh nghiệp ông tiết kiệm tới 37% tổng chi phí, từ đó tối ưu lợi nhuận. Theo ông, giá xăng thay đổi liên tục trong khi giá điện ổn định đã giúp người làm kinh doanh tối ưu chi phí hơn. Đây cũng là một trong những yếu tố giúp doanh nghiệp vượt qua những thời khắc khó khăn nhất.

Điều ông Đồng cảm nhận rõ rệt là doanh thu tăng trưởng bền vững, không chỉ trong thời gian cao điểm du lịch. “Trước đây doanh thu chỉ tăng vào mua hè nhưng bây giờ thì tăng trưởng đều đặng vì người dân, du khách tới Lâm Đồng đều muốn trải nghiệm xe điện”, ông Đồng nói.

Nói thêm về chi phí, ông Nguyễn Văn Định, Chủ tịch HĐQT kiêm Tổng Giám đốc Công ty Én vàng (công ty ra mắt dịch vụ taxi điện đầu tiên tại Hải Phòng) cho rằng, khoản tiết kiệm còn đến từ chi phí bảo dưỡng, sửa chữa. Trong khi xe xăng phải thường xuyên bảo dưỡng, doanh nghiệp phải gánh chi phí lớn, đặc biệt là khi xe xuống cấp thì ngược lại, xe điện ít linh kiện, chi tiết, nên hoàn toàn không đáng lo. Riêng với chi phí năng lượng, ngoài ưu điểm về giá điện ổn định, theo ông, doanh nghiệp như ông còn có thể sử dụng nguồn điện mặt trời giúp tiết giảm thêm chi phí.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/08/d8f7f7a2-dqt02872-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Hình ảnh hàng xe taxi điện VinFast màu vàng
> 
> Đây là một hình ảnh chụp một hàng dài xe taxi điện VinFast màu vàng đang đỗ trên một con đường nhựa.
> 
> ## Các chi tiết đáng chú ý:
> 
> *   **Loại xe:** Xe taxi điện VinFast, có thể là mẫu VF e34 hoặc một mẫu xe điện tương tự, với logo chữ V đặc trưng của VinFast ở mặt trước.
> *   **Màu sắc:** Toàn bộ các xe đều có màu vàng tươi sáng.
> *   **Biển số xe:** Biển số xe của chiếc xe đầu tiên có thể nhìn thấy rõ là **15E 012.04**.
> *   **Đèn nóc taxi:** Trên nóc của mỗi xe có một biển hiệu nhỏ màu xanh lam với chữ "TAXI ĐIỆN" màu trắng.
> *   **Bối cảnh:** Các xe đỗ dọc theo một con đường giữa hai hàng cây xanh rậm rạp, tạo cảm giác về một không gian xanh mát. Con đường có vẻ như là đường nội bộ hoặc đường trong khuôn viên một khu vực nào đó.
> *   **Số lượng xe:** Có ít nhất 7 chiếc xe taxi điện màu vàng có thể nhìn thấy trong hàng.
> 
> Hình ảnh gợi lên sự hiện đại, thân thiện với môi trường của dịch vụ taxi điện tại Việt Nam.
> ```

Đồng tình với những ý kiến trên, ông Nguyễn Duy Hưng, Chủ tịch HĐQT kiêm TGĐ Công Ty CP Đầu tư và Dịch vụ Cảng Hàng Không Việt Nam (ASV) tổng kết, sự hài lòng của khách hàng cũng như khả năng tiết kiệm chi phí đã giúp cải thiện thu nhập của doanh nghiệp cũng như người lao động. “Tài xế ban đầu có lo lắng nhưng chỉ sau 3 tháng, mọi việc hoàn toàn khác. Khách hàng hoàn toàn hài lòng, chúng tôi được khách hàng yêu quý nhiều hơn, tài xế cũng vui hơn, có thêm nguồn doanh thu”, ông Hưng nói.

Thêm nhiều chính sách khủng, doanh nghiệp muốn sớm chuyển đổi 100% sang xe điện

Lắng nghe những câu chuyện thực tế từ chính những doanh nghiệp đã chuyển đổi sang phương tiện xanh, ông Nguyễn Văn Thanh, Tổng giám đốc GSM toàn cầu (GSM là đơn vị chủ quản của Green SM-PV) bày tỏ mong muốn sẽ có thêm nhiều doanh nghiệp khác đồng hành cùng Green SM thông qua hàng loạt các chính sách ưu đãi mà GSM và VinFast cam kết đồng hành cùng các đơn vị.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/08/021cfcd4-blk_3921-1024x683.jpg)

Với những cam kết mạnh mẽ từ Green SM, ông Hưng cũng bày tỏ mong muốn sớm mở rộng đội ngũ xe điện của công ty. Ngoài ra, công ty cũng dự tính sẽ dần chuyển từ hình thức thuê sang mua xe.

Ông Nguyễn Ngọc Đồng, Tổng Giám đốc Công ty TNHH Đồng Thúy cũng thừa nhận, những chương trình trên sẽ giúp giải quyết được nhiều vấn đề của doanh nghiệp. “Cam kết sau 5 năm mua lại, giới thiệu ngân hàng cho vay, app độc quyền. Sướng như vậy thì không còn gì phải nghĩ”, ông Đồng nhận xét.

Giống như lãnh đạo ASV, vị TGĐ của Công ty Đồng Thúy cũng dự kiến tới hết năm nay, 100% xe 4 chỗ của đơn vị này sẽ chuyển đổi sang xe điện VinFast. Ngoài ra, với thực tế những gì công ty ông đã trải qua, ông cũng kêu gọi các doanh nghiệp cùng chung tay với Green SM để vừa kinh doanh hiệu quả hơn vừa ủng hộ tinh thần mãnh liệt của người Việt, vì thương hiệu Việt.
