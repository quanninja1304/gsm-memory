# Chính sách thưởng cuốc tại Hà Nội ngày 27/04

- **Ngày đăng:** 2025-04-27
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-cuoc-ngay-27-04-tai-ha-noi](https://www.greensm.com/vn-vi/news/thuong-cuoc-ngay-27-04-tai-ha-noi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Đáp ứng nhu cầu di chuyển tăng cao tại Hà Nội dịp cuối tuần trước thềm Lễ Giải phóng miền Nam 30/04 và Quốc tế Lao động 01/05/2025, Green SM triển khaichương trình thưởng cuốc đặc biệtvào ngày27/04/2025!

👥Đối tượng áp dụng:Tài xế Taxi, Tài xế Car Platform, Tài xế Đối tác Green Car trực thuộc các Depot tại Hà Nội

📅Thời gian áp dụng:duy nhất ngày 27/04/2025

⭐Nội dung chính sách:Hoàn thành từ15 cuốc(doanh số trung bình≥ 60.000đ/cuốc) sẽ được thưởng thêm8.000đ/cuốc; từ17 cuốctrở lên thưởng10.000đ/cuốc.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/6f7654de-20250427_chinhsachhn-1024x852.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THƯỞNG CUỐC TẠI HÀ NỘI NGÀY 27/04
> 
> **Đối tượng áp dụng:** Tài xế Taxi, Tài xế Car Platform, Tài xế Đối tác Green Car trực thuộc các Depot tại Hà Nội
> **Thời gian áp dụng:** duy nhất ngày 27/04/2025
> 
> | Điều kiện                                             | Mức thưởng             |
> | :---------------------------------------------------- | :--------------------- |
> | Hoàn thành ≥ 15 cuốc xe trở lên (doanh số trung bình ≥ 60.000đ/cuốc) | Thưởng 8.000đ/cuốc     |
> | Hoàn thành ≥ 17 cuốc xe (doanh số trung bình ≥ 60.000đ/cuốc)        | Thưởng 10.000đ/cuốc    |
> 
> **Ví dụ:**
> * Hoàn thành 15 cuốc, doanh số trung bình ≥ 60.000đ/cuốc → thưởng 120.000đ (15 cuốc x 8.000đ)
> * Hoàn thành 17 cuốc, doanh số trung bình ≥ 60.000đ/cuốc → thưởng 170.000đ (17 cuốc x 10.000đ)
> 
> **Lưu ý:** Đối với Tài xế Car Platform chỉ áp dụng chính sách thưởng cuốc này vào ngày 27/04, không áp dụng đồng thời các chương trình thưởng hiện hữu khác.

Vận doanh càng nhiều – thưởng thêm càng cao!

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được giải đáp.

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM
