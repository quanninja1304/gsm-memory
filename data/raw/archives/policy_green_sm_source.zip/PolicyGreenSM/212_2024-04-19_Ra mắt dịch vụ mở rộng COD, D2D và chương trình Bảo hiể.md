# Ra mắt dịch vụ mở rộng COD, D2D và chương trình Bảo hiểm hàng hóa Xanh Express dành riêng cho chủ shop

- **Ngày đăng:** 2024-04-19
- **Chuyên mục:** Cộng đồng, Công ty
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/ra-mat-dich-vu-mo-rong-cod-d2d-va-chuong-trinh-bao-hiem-hang-hoa-xanh-express-danh-rieng-cho-chu-shop](https://www.greensm.com/vn-vi/news/ra-mat-dich-vu-mo-rong-cod-d2d-va-chuong-trinh-bao-hiem-hang-hoa-xanh-express-danh-rieng-cho-chu-shop)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Với mong muốn đáp ứng nhu cầu đa dạng của Khách hàng và gia tăng thu nhập của Đối tác tài xế, từ ngày 04/04/2024, Green SM ra mắt dịch vụ cộng thêm COD – Thu tiền hộ, D2D – Giao hàng tận tay và chương trình Bảo hiểm hàng hóa Xanh Express.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/04/2e7dda1d-jtran0039-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất từ hình ảnh:
> 
> **Văn bản:**
> * XANHSM (trên mũ bảo hiểm của người giao hàng)
> * XANHSM (trên tay áo của người giao hàng)
> * XANHSM (trên túi của người giao hàng)
> 
> **Ghi chú:**
> * Logo chữ 'V' cũng xuất hiện trên mũ bảo hiểm, áo khoác và túi của người giao hàng.
> 
> Nếu bạn cần bất kỳ thông tin nào khác, xin vui lòng cho tôi biết.

1.Tính năng Thanh toán khi nhận hàng (COD)

Thu tiền hộ (COD – là viết tắt của Cash on Delivery – thanh toán khi nhận hàng)là dịch vụ mở rộng của sản phẩm giao hàng Xanh Express nhằm cung cấp cho người dùng, đặc biệt là các cá nhân, doanh nghiệp kinh doanh online, bán hàng qua mạng xã hội giải pháp giao hàng thu tiền hộ tiện lợi và linh hoạt.

Dịch vụ này cho phép tài xế tạm ứng trước số tiền cần thu cho người gửi và sẽ thu lại số tiền đó từ người nhận khi hoàn thành giao hàng.

Các bước sử dụng dịch vụ Thu tiền hộ (COD)

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/04/ad0e880d-express1-1024x726.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # TÍNH NĂNG THANH TOÁN KHI NHẬN HÀNG
> 
> ## Các bước thực hiện:
> 
> ### Bước 1: Chọn "Giao hàng"
> *   **Màn hình ứng dụng Xanh SM:**
>     *   **Tiêu đề:** Xin chào, Quang
>     *   **Lựa chọn dịch vụ:**
>         *   Ô tô
>         *   Xe máy
>         *   Giao hàng
>         *   Thuê xe
> 
> ### Bước 2: Chọn dịch vụ mở rộng "Thu tiền hộ"
> *   **Màn hình "Giao hàng":**
>     *   **Điểm đón:** Công Lý Tự Trọng - Vincom Cent
>     *   **Điểm đến:** 92 Nam Kỳ Khởi Nghĩa, Quận 1, Th
>     *   **Dịch vụ mở rộng:**
>         *   Thu tiền hộ
>         *   Giao hàng tận tay
>         *   Có hóa đơn cho 1 điểm giao
>     *   **Chi phí dự kiến:** 21.000₫
>     *   **Nút:** Đặt giao hàng
> 
> *   **Màn hình "Thông tin người nhận":**
>     *   **Tiêu đề:** Thông tin người nhận
>     *   **Địa chỉ:** 92 Nam Kỳ Khởi Nghĩa, Quận 1, Th
>     *   **Thông tin người nhận:**
>         *   Tên người nhận: Thái
>         *   Số điện thoại:
>         *   Ghi chú cho tài xế:
>     *   **Dịch vụ mở rộng:**
>         *   Thu tiền hộ
> 
> ### Bước 3: Nhập số tiền thu hộ
> *   **Màn hình "Thu tiền hộ":**
>     *   **Số tiền thu hộ:** 200.000 VND
>     *   **Bàn phím số:**
>         *   1 2 3
>         *   4 5 6
>         *   7 8 9
>         *   0
>     *   **Nút:** Lưu
> 
> ### Bước 4: Chọn "Đặt giao hàng"
> *   **Màn hình "Giao hàng":**
>     *   **Điểm đón:** Công Lý Tự Trọng - Vincom Cent
>     *   **Điểm đến:** 92 Nam Kỳ Khởi Nghĩa, Quận 1, Th
>     *   **Dịch vụ mở rộng:**
>         *   Thu tiền hộ: 200.000₫
>     *   **Chi phí dự kiến:** 21.000₫
>     *   **Nút:** Đặt giao hàng

Cước phí dịch vụ cộng thêm: Đơn hàng thu tiền hộ (COD) ứng tiền dưới 500.000 VNĐ/đơn hàng: 5.000 VNĐ

Lưu ý:

- Tài xế được phép kiểm tra hàng hóa trước khi nhận hàng từ người gửi;

- Người nhận cần thanh toán đúng số tiền thu tiền hộ (COD) cho tài xế Green SM khi nhận hàng;

(*) Thông tin chi tiết về tính năng CODtại đây.

2.Tính năng Giao hàng tận tay (D2D)

Giao hàng tận tay (D2D – door to door)là một phương thức giao hàng mà tài xế sẽ giao hàng đến tận tay người nhận, thay vì chỉ giao tại một điểm nhất định.

Điều này mang lại sự tiện lợi và linh hoạt cho người nhận hàng, vì họ không cần phải đến một điểm giao nhận cụ thể để lấy hàng.

Cách thức sử dụng dịch vụ Giao hàng tận tay (D2D)

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/04/cc252bcd-express2.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất sang định dạng Markdown tiếng Việt:
> 
> # TÍNH NĂNG GIAO HÀNG TẬN TAY
> 
> ## Hình ảnh 1: Màn hình nhận chuyến
> ```
> 14:53
> 80%
> Bạn nhận được đơn... Đơn hàng mới, cách bạn 0.4...
> Cước phí: 65.000₫
> Ứng tiền: 500.000
> Thẻ/Vĩ
> 
> 6,2 km - 1 điểm dừng
> Đang cách bạn 0,5 km
> Royal City
> 72A Nguyễn Trãi, P.Thượng Đình, Q.Thanh Xuân, Hà Nội, 10000, Vietnam
> 94 NGÕ 402 ĐƯỜNG MỸ ĐÌNH
> Phường Mỹ Đình 1, Quận Nam Từ Liêm, Thành phố Hà Nội, VNM
> 
> Giao hàng tận tay
> Giao hàng ứng tiền
> 
> Nhận chuyến 26
> ```
> 
> ## Hình ảnh 2: Màn hình chi tiết chuyến đi (Điểm giao hàng)
> ```
> 14:54
> ← Chi tiết chuyến đi
>   Nhắn tin
>   Gọi điện
> 
> Điểm giao hàng
> 94 NGÕ 402 ĐƯỜNG MỸ ĐÌNH
> Phường Mỹ Đình 1, Quận Nam Từ Liêm, Thành phố Hà Nội, VNM
> 
> Tầng 10+
> Loại hàng hóa: Tài liệu
> Kích thước: Nhỏ
> Khối lượng: 1kg
> routedetai_collectcod_te
> 500000
> Khách nhận hàng
> linh
>   Nhắn tin
>   Gọi điện
> 
> Cước phí chuyến đi
> Nhận thanh toán: Thẻ/Vĩ
> Cước phí: 65.000₫
> Khách thanh toán: 65.000₫
> ```
> 
> ## Hình ảnh 3: Màn hình chi tiết chuyến đi (Dịch vụ)
> ```
> 14:55
> ← Chi tiết chuyến đi
>   Nhắn tin
>   Gọi điện
> 
> Cước phí chuyến đi
> Nhận thanh toán: Thẻ/Vĩ
> Cước phí: 65.000₫
> Khách thanh toán: 65.000₫
> Hợp đồng điện tử >
> 
> Dịch vụ
> Giao Hàng HN
> Giao hàng tận cửa
> Giao hàng ứng tiền
> Cài đặt chế độ nhận đơn
> Dừng hoạt động
> Liên hệ hỗ trợ
> ```
> 
> ---
> 
> ## Chú thích ảnh:
> 
> **Nhận biết đơn giao tận tay tại màn hình nhận chuyến**
> 
> **Chi tiết điểm giao hàng (do Khách hàng ghi chú)**
> 
> **Click vào "Chi tiết chuyến đi" để xem các dịch vụ mở rộng Khách hàng đã sử dụng**
> 
> ---
> 
> **Phụ phí giao hàng tận cửa = 10.000 VNĐ/ Điểm giao hàng tận cửa**

Cước phí dịch vụ cộng thêm: Đơn hàng Giao hàng tận tay (D2D): 10,000 VNĐ

Lưu ý:

- Không bao gồm phí gửi xe khi giao hàng (nếu có);

- Không áp dụng cho đơn hàng có nhiều điểm giao;

3.Chương trình Bảo hiểm hàng hóa Xanh Express:

An tâm giao nhận hàng hóa với Xanh Express cùng quyền lợi Bảo hiểm lên tới 100% giá trị đơn hàng:

- Bảo vệ hàng hóa trước các rủi ro như cháy, hỏng hóc, mất mát do các nguyên nhân liệt kê theo điều kiện, điều khoản của Bảo hiểm.

- Bồi thường 100% giá trị hàng hóa theo chứng từ chứng minh giá trị, không vượt quá số tiền Bảo hiểm đã chọn.

- Hỗ trợ chi phí sửa chữa hoặc thay thế hàng hóa hỏng hóc, mất mát dựa trên hóa đơn/chứng từ sửa chữa.

| Số tiền Bảo hiểm | Gói Cơ Bản | Gói Bạc | Gói Vàng |
| --- | --- | --- | --- |
| Chi phí Bảo hiểm | 1.000 VNĐ | 2.000 VNĐ | 5.000 VNĐ |
| Số tiền Bảo hiểm tối đa/Điểm giao hàng (áp dụng đối với Tài liệu) | 500.000 VNĐ | 1.000.000 VNĐ | 1.000.000 VNĐ |
| Số tiền Bảo hiểm tối đa/Đơn hàng/Điểm giao hàng (áp dụng đối với Hàng hóa khác) | 3.000.000 VNĐ | 10.000.000 VNĐ | 30.000.000 VNĐ |

(*) Thông tin chi tiếttại đây.
