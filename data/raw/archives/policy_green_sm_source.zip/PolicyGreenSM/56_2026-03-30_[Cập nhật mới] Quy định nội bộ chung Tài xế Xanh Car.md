# [Cập nhật mới] Quy định nội bộ chung Tài xế Xanh Car

- **Ngày đăng:** 2026-03-30
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-van-quy-dinh-noi-bo-chung-tai-xe-xanh-car-2026](https://www.greensm.com/vn-vi/news/cap-nhat-van-quy-dinh-noi-bo-chung-tai-xe-xanh-car-2026)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Tại Green SM, xây dựng một môi trường làm việc đáp ứng các tiêu chí về: thượng tôn kỷ luật, văn minh, tôn trọng, hợp tác luôn là ưu tiên hàng đầu. Kể từ 30/03/2026, Green SM bổ sung và cập nhật mới một số quy định thuộc “Nội bộ chung Tài xế Xanh Car” nhằm chuẩn hóa hệ thống nội quy chung và đảm bảo tính công bằng, minh bạch trong việc áp dụng chế độ đãi ngộ/xử lý vi phạm dành cho Bác Tài Xanh.

1/ Thông tin chung:

| Đối tượng áp dụng | Bác Tài Xanh TaxiBác Tài Xanh VanBác Tài Xanh Liên TỉnhGọi chung 3 nhóm trên là “Bác Tài Xanh” |
| --- | --- |
| Hiệu lực áp dụng | Từ 30/03/2026 tới khi có thông báo tiếp theo |
| Khu vực áp dụng | Toàn quốc |

2/ Chi tiết các quy định được bổ sung mới:

2.1/Vớinhóm “Bác Tài Xanh Liên Tỉnh”:

Bổ sung nhóm Bác Tài Xanh Liên Tỉnh vào nhóm đối tượng áp dụng các quy định/chế độ đãi ngộ/xử lý vi phạm sau:

–Quy định chung:Áp dụng bộ quy định nội quy chung giống với nhóm Bác Tài Xanh Taxi & Bác Tài Xanh Van. Nổi bật với:

| Quy định | Chi tiết |
| --- | --- |
| Quy định làm việc | Trang phục làm việc | Thực hiện theo quy định tại “Tiêu chuẩn dịch vụ” đối với từng nhóm Bác Tài Xanh |

– Chế độ đãi ngộ:Áp dụng chế độ đãi ngộ và khen thưởng giống với nhóm Bác Tài Xanh Taxi và Bác Tài Xanh Van. Nổi bật với:

| Chế độ đãi ngộ | Chi tiết |
| --- | --- |
| Phúc lợi | Lương | –Được xem xét điều chỉnh lươngtheo tính chất công việc và tình hình hoạt động thực tế của Công ty trong từng giai đoạn. |
| Các khoản phúc lợi cố định theo quy định của pháp luật | –Được đóng Bảo hiểm bắt buộctheo quy định của Nhà nước (Bảo hiểm Xã hội, Bảo hiểm Y tế, Bảo hiểm Thất nghiệp) sau khi ký HĐLĐ chính thức |
| Khám sức khỏe định kỳ | – Được khám sức khỏe định kỳ01 lần/năm |
| Quà Tết Âm Lịch | – Được tặng quà Tết Âm lịch vớimức 2,000,000đ net/người/nămnếu gia nhập Công ty trước ngày 01/10 hàng năm và đã ký Hợp đồng lao động. |

– Nguyên tắc xử lý vi phạm:Áp dụng giống với nguyên tắc thanh tra & xử lý vi phạm chung dành cho Bác Tài Xanh. Tuy nhiên, bổ sung thêm một số hành vi vi phạm đặc thù:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/03/f6a8a4a1-260330_qdnbc-01-920x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> | Nhóm Lỗi                   | Bổ sung mới                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | Hình thức xử lý vi phạm                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
> | :------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
> | **Nhóm 1b:** Các lỗi đặc biệt nghiêm trọng | **3.2.2.10:** Không tuân thủ lộ trình/điều phối của Công ty, bao gồm: - Tự ý chạy sai lộ trình, bỏ điểm đón/trả, đón/trả sai địa điểm hoặc không đón khách, làm ảnh hưởng đến quyền lợi khách hàng và/hoặc uy tín, hình ảnh Công ty. - Loại trừ các trường hợp khách quan như: khách không nghe máy sau 03 lần liên hệ trong 10 phút; không liên lạc được; hoặc bất khả kháng khác.                                                                                                                                                                                  | - Sa thải hoặc chấm dứt HĐLĐ theo Nội quy lao động của Công ty và/hoặc; - Giảm/cắt các khoản thưởng theo Chính sách Thu nhập từng thời kỳ số tiền **5,000,000₫**; - Yêu cầu bồi hoàn toàn bộ số tiền gian lận. Nếu vi phạm về việc đăng tải thông tin sai sự thật/tiêu cực thì phải đính chính, xin lỗi. Trường hợp có dấu hiệu vi phạm pháp luật hình sự, Công ty sẽ chuyển Cơ quan Công an để truy cứu trách nhiệm theo quy định.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
> |                            | **3.2.3.1:** Tự ý chở khách/chở hàng không tạo cuốc; chở khách không thuộc danh sách hành khách do công ty phân công; hoặc hủy cuốc/hủy chuyến nhưng vẫn thực hiện vận chuyển khách/hàng hóa.                                                                                                                                                                                                                                                                                                                                                                                        | Giảm/cắt các khoản Thưởng theo Chính sách Thu nhập từng thời kỳ: - Số tiền **5,000,000₫** và yêu cầu bồi hoàn toàn bộ số tiền gian lận (nếu có) nếu **vi phạm lần 1**; - Số tiền **8,000,000₫** và yêu cầu bồi hoàn toàn bộ số tiền gian lận (nếu có) nếu **vi phạm lần 2**.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
> | **Nhóm 2:** Các lỗi lớn   | **3.2.3.3:** Kéo dài hành trình hoặc thay đổi cung đường/điểm đón, trả khách do nguyên nhân khách quan hoặc theo yêu cầu của khách hàng nhưng không kịp thời báo cáo Công ty (bao gồm trường hợp không phát sinh hành vi gian lận). | Giảm/cắt các khoản Thưởng theo Chính sách Thu nhập từng thời kỳ: - Số tiền **1,000,000₫** và yêu cầu bồi hoàn toàn bộ số tiền gian lận (nếu có) nếu **vi phạm lần 1**; - Số tiền **3,000,000₫** và yêu cầu bồi hoàn toàn bộ số tiền gian lận (nếu có) nếu **vi phạm lần 2**; - Số tiền **5,000,000₫** và yêu cầu bồi hoàn toàn bộ số tiền gian lận (nếu có) nếu **vi phạm lần 3**. |
> ```

2.2. Áp dụng chung cho toàn bộ “Bác Tài Xanh”:

Tiến hành thay đổi/bổ sung một số nguyên tắc thanh tra & xử lý vi phạm mới sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/03/f127b62f-260330_qdnbc-851x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> ## Thay đổi/bổ sung mới | Chi tiết điều chỉnh | Hình thức xử lý vi phạm
> ---|---|---
> Chuyển hành vi vi phạm "bất hợp tác/chống đối" tại Nhóm 2. Lỗi lớn lên Nhóm 1a. Các lỗi đặc biệt nghiêm trọng | Bất hợp tác, chống lại hoặc phản ứng tiêu cực, kêu gọi, lôi kéo người khác thực hiện chống đối với Công ty dưới bất cứ hình thức nào, xúi giục đồng nghiệp chống lại các lệnh hợp pháp của cấp trên hoặc Bộ phận có thẩm quyền. | • Giảm/cắt thưởng **10,000,000₫** khi vi phạm **Lần 1**<br>• Chấm dứt HĐLĐ khi vi phạm **Lần 2**
> Tăng mức xử lý vi phạm lỗi "gây va chạm do chủ quan" thuộc Nhóm 2. Lỗi Lớn | **3.2.3.4:** Số tiền từ **2,000,000₫ đến 5,000,000₫** căn cứ theo mức độ vi phạm và thiệt hại | • Gây va chạm tai nạn do lỗi chủ quan với mức độ thiệt hại **dưới 5,000,000₫**: **2,000,000₫/lần.**<br>• Gây va chạm tai nạn do lỗi chủ quan với mức độ thiệt hại **từ 5,000,000₫ đến dưới 20,000,000₫**: **3,000,000₫/lần.**<br>• Gây va chạm tai nạn do lỗi chủ quan với mức độ thiệt hại **từ 20,000,000₫ đến dưới 30,000,000₫**: **4,000,000₫/lần.**<br>• Gây va chạm tai nạn do lỗi chủ quan với mức độ thiệt hại **từ 30,000,000₫ trở lên**: **5,000,000₫/lần.**
> Bổ sung lỗi "hủy cuốc/tuần" thuộc Nhóm 2. Lỗi lớn *Áp dụng riêng cho Bác Tài Xanh Taxi* | **3.2.3.5:** Số tiền từ **100,000₫ đến 500,000₫** tùy theo mức độ vi phạm đối với trường hợp Bác Tài Xanh phát sinh số lượt hủy cuốc trong tuần vượt mức cho phép, làm ảnh hưởng đến chất lượng dịch vụ và/hoặc hình ảnh Công ty (nguyên nhân cố ý hoặc vô ý) | • Hủy **06-07** cuốc/tuần: Trừ **100,000₫/tuần;**<br>• Hủy **08-09** cuốc/tuần: Trừ **200,000₫/tuần;**<br>• Hủy **10-12** cuốc/tuần: Trừ **300,000₫/tuần;**<br>• Hủy **trên 12** cuốc/tuần: Trừ **500,000₫/tuần**

Các nội dung khác trong quy định nội quy chung không thay đổi.

Chi tiết về quy định nội quy chung dành cho Tài Xế Xanh Car, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
