# Chính sách thưởng thêm 02/09 cho Tài xế vận doanh tại Hà Nội

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-2-9-cho-tai-xe-tai-ha-noi](https://www.greensm.com/vn-vi/news/thuong-2-9-cho-tai-xe-tai-ha-noi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Đại lễ 02/09 không chỉ là niềm tự hào chung của cả nước, mà còn là dịp đặc biệt để Green SM gửi lời tri ân đến các Bác tàisẽ hết mình vận doanh, phục vụ khách hàng trong những ngày tổng duyệt, diễu binh và các hoạt động chào mừng Quốc khánh tại Thủ đô.

Trong khung giờ quy định, chỉ cần vận doanh đều đặn, Bác tài sẽ đượcthưởng thêm 10% doanh số cho mỗi chuyến xe hoàn thành– nguồn động lực để bứt phá thu nhập trong không khí lễ hội rộn ràng!

Chi tiết chương trình thưởng như sau:

![Thưởng thêm cho Tài xế Hà Nội](https://cdn.xanhsm.com/2025/08/4c27f22b-250829_thuongthemhanoi-1024x992.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # ĐẠI LỄ 02/09
> 
> ## Thưởng thêm 10% DOANH SỐ cho Bác tài tại Hà Nội
> 
> | Tiêu chí           | Nội dung                                                                                                                                                                                                                                       |
> | :---------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Đối tượng áp dụng** | Tài xế Taxi và Tài xế Platform phát sinh cuốc đón khách tại các quận (theo địa giới hành chính cũ) gồm: Đống Đa, Ba Đình, Hoàn Kiếm, Hai Bà Trưng, Tây Hồ và Khu vực Trung tâm triển lãm Quốc gia (VEC)                                          |
> | **Thời gian áp dụng** | - 16h00 - 23h59 ngày 30/08 và 01/09/2025 <br> - 04h00 - 14h59 ngày 02/09/2025                                                                                                                                                              |
> | **Mức thưởng**    | Thưởng thêm **10% doanh số** cho mỗi cuốc xe hoàn thành trong khung giờ, khu vực áp dụng                                                                                                                                                      |
> | **Điều kiện nhận thưởng** | - Hoàn thành tối thiểu **03 chuyến/ngày** trong khung giờ tại khu vực áp dụng <br> - Tỷ lệ nhận và hoàn thành cuốc trong ngày đạt từ **85%** trở lên                                                                                           |

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM
