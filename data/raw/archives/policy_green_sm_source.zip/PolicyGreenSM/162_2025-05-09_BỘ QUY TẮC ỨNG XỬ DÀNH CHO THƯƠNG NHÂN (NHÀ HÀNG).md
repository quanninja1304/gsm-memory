# BỘ QUY TẮC ỨNG XỬ DÀNH CHO THƯƠNG NHÂN (NHÀ HÀNG)

- **Ngày đăng:** 2025-05-09
- **Chuyên mục:** Nhà hàng
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/bo-quy-tac-ung-xu-danh-cho-thuong-nhan-nha-hang](https://www.greensm.com/vn-vi/news/bo-quy-tac-ung-xu-danh-cho-thuong-nhan-nha-hang)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Quý Đối tác Nhà hàng thân mến,

Nhằm duy trì, nâng cao chất lượng dịch vụ theo tiêu chuẩn 5 sao,Green SMcập nhật “Bộ quy tắc ứng xử dành cho Đối tác Nhà hàng”. Thông tin chi tiết như sau:

### I. QUY ĐỊNH CHUNG

- Đối với các hành vi chưa được đề cập trong Bộ Quy Tắc Ứng Xử này nhưng xét về tính chất, mức độ, khả năng gây ảnh hưởng đến người dùng và các tiêu chuẩn, nguyên tắc hoạt động của Green SM, tùy từng trường hợp cụ thể, Green SM có toàn quyền xem xét đưa ra hình thức xử lý phù hợp.

- Nguyên tắc xử lý:Minh bạch, nhất quán, theo mức độ vi phạm, theo số lần vi phạm, có thể bỏ qua các cấp thấp nếu vi phạm nghiêm trọng.

![Bộ quy tắc ứng xử dành cho Đối tác Nhà hàng](https://cdn.xanhsm.com/2025/05/b50fdfd9-quy-tac-ung-xu-1024x535.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # GREEN SM MERCHANT
> 
> # QUY TẮC ỨNG XỬ
> dành cho
> # THƯƠNG NHÂN
> # NHÀ HÀNG
> ```

Bộ quy tắc ứng xử dành cho Đối tác Nhà hàng

### II. QUY TẮC ỨNG XỬ

#### 1. Đối với Khách hàng:

1.1. Đảm bảo chất lượng, an toàn vệ sinh thực phẩm theo quy định.

1.2. Tuân thủ đúng các quy định/ hướng dẫn thực hiện, Tiêu chuẩn dịch vụ Green SM trong quá trình hợp tác.

1.3. Tôn trọng quyền riêng tư và bảo mật thông tin của Khách hàng.

1.4. Tuyệt đối tuân thủ quy định pháp luật trong quá trình hoạt động.

#### 2. Đối với Đối tác Tài xế:

2.1. Tôn trọng Đối tác Tài xế của Green SM.

2.2. Không phân biệt đối xử Đối tác Tài xế Green SM với các Tài xế ứng dụng khác/người dùng của Nhà hàng

### III. CHẾ TÀI XỬ LÝ VI PHẠM QUY TẮC ỨNG XỬ

#### 1. Nguyên tắc chung:

- Bộ Quy tắc ứng xử áp dụng cho toàn bộ Đối tác Nhà hàng trên nền tảng Green SM Food. (*)

- Đối với lỗi vận hành: mỗi đơn hàng vi phạm được tính là một lần vi phạm.

- Đối với lỗi chất lượng/ khiếu nại: mỗi sự vụ được tính là một lần vi phạm.

- Các lỗi tuân thủ/ hiển thị trong cùng ngày có thể được gộp.

- Green SM có quyền nâng mức xử lý trong trường hợp vi phạm tần suất cao.

- Số lần vi phạm Nhóm 2–6 được tái thiết lập sau 30 ngày.

(*) Loại trừ ngoại lệ xử lý lỗi nhóm 3,4,5,6 đối với nhóm Đối tác lớn – danh sách được phê duyệt hàng tháng bởi Giám Đốc Khối Delivery.

#### 2. Quy định xử lý vi phạm đối tác Nhà hàng:

| NHÓM VI PHẠM | Hành vi vi phạm | Chế tài |
| --- | --- | --- |
| I | NHÓM 1: GIAN LẬN & VI PHẠM NGHIÊM TRỌNG |
| 1 | Lợi dụng hệ thống nhằm trục lợi dưới mọi hình thức. | Tùy theo tính chất, mức độ vi phạm và quyết định của Green SM, Đối tác Nhà hàng có thể bị áp dụng một, một số hoặc toàn bộ các biện pháp xử lý sau:– Chấm dứt hợp tác vĩnh viễn trên nền tảng.– Truy thu toàn bộ giá trị khuyến mại đã được áp dụng sai quy định (nếu có).– Yêu cầu bồi thường thiệt hại phát sinh (nếu có).– Chuyển hồ sơ tới cơ quan chức năng để xử lý theo quy định pháp luật trong trường hợp cần thiết. |
| 2 | Tạo đơn hàng ảo hoặc đánh giá ảo nhằm thao túng dữ liệu vận hành |
| 3 | Lạm dụng các chương trình khuyến mại do nền tảng triển khai. |
| 4 | Sử dụng phần mềm, công cụ hoặc bất kỳ hình thức can thiệp kỹ thuật nào nhằm gian lận. |
| 5 | Có hành vi liên hệ với Khách hàng/ Tài xế để thực hiện đơn hàng/ giao dịch bên ngoài ứng dụng |
| 6 | Lạm dụng, khai thác hoặc sử dụng trái phép thông tin Khách hàng. |
| 7 | Cung cấp thông tin sai lệch, không trung thực trong quá trình điều tra, xác minh. |
| 8 | Dùng ứng dụng, đơn hàng Green SM để quảng cáo cho ứng dụng khác dưới bất kỳ hình thức nào. |
| 9 | Thái độ, hành vi không đúng mực, khiếm nhã, quấy rối Khách hàng/Tài xế/ nhân viên/ thương nhân khác của Green SM (nhắn tin, gọi điện đe dọa, hoặc bất kỳ hình thức nào) | Tùy theo tính chất, mức độ vi phạm và quyết định của Green SM, Đối tác Nhà hàng có thể bị áp dụng một, một số hoặc toàn bộ các biện pháp xử lý sau:– Chấm dứt hợp tác vĩnh viễn trên nền tảng.– Truy thu toàn bộ giá trị khuyến mại đã được áp dụng sai quy định (nếu có). |
| 10 | Không thông báo kịp thời bộ phận hỗ trợ của Green SM ngay khi xảy sự cố nghiêm trọng liên quan đến Khách hàng/ thực phẩm/ Tài xế nhằm trốn tránh trách nhiệm liên quan. |
| 11 | Truyền thông phát ngôn sai sự thật về Green SM với Khách hàng/ Tài xế/ nhân viên/ thương nhân khác của Green SM dưới bất kỳ hình thức nào. |
| 12 | Không hợp tác, cố tình cung cấp sai, cung cấp không đầy đủ/ kịp thời thông tin, tài liệu liên quan đến đơn hàng, giao dịch trên ứng dụng Green SM. |
| 13 | Sử dụng thông tin, hình ảnh của Khách hàng/ Tài xế/ nhân viên của Green SM ngoài mục đích thực hiện dịch vụ theo Hợp đồng hợp tác với Green SM gây ảnh hưởng tới Khách hàng /Tài xế/ nhân viên của Green SM (đăng tải trên trang Mạng xã hội, cộng đồng, nhắn tin, gọi điện làm phiền sau khi hoàn tất đơn hàng…) |
| 14 | Đăng tải hình ảnh, kinh doanh các mặt hàng thuộc danh mục cấm theo quy định của pháp luật và/ hoặc danh mục cấm theo chính sách của Green SM tại từng thời điểm |
| 15 | Vi phạm tuân thủ nghĩa vụ của tổ chức, cá nhân kinh doanh thực phẩm theo quy định pháp luật gây ảnh hưởng nghiêm trọng, như tuân thủ điều kiện đảm bảo an toàn thực phẩm, gây ảnh hưởng sức khỏe Khách hàng/ người dùng theo kết quả xác minh và bằng chứng của Green SM và/ hoặc cơ quan chức năng. |
| 16 | Vi phạm liên tiếp 5 lần đối với các lỗi Nhóm 2 và/ hoặc Nhóm 3 trong 30 ngày. |
| 17 | Không thực hiện đầy đủ các nghĩa vụ tài chính theo quy định. |

| NHÓM VI PHẠM | Hành vi vi phạm | Chế tài |
| --- | --- | --- |
| II | NHÓM 2: CHẤT LƯỢNG MÓN & VSATTP | Lần 1 | Lần 2 | Lần 3 | Lần 4 |
| 18 | Không đảm bảo các tiêu chuẩn về vệ sinh an toàn thực phẩm trong quá trình chế biến, bảo quản và cung cấp món ăn bao gồm: Khu vực chế biến không được vệ sinh sạch sẽ, có đọng nước thải trên sàn trong quá trình chuẩn bị/ trước khi đóng cửa.Rác thải vứt không đúng nơi quy định | Cảnh báo vi phạmYêu cầu Nhà hàng giao lại món hoặc bồi hoàn cho Khách hàng | Tạm đóng gian hàng03 ngàyYêu cầu Nhà hàng giao lại món hoặc bồi hoàn cho Khách hàng | Tạm đóng gian hàng07 ngàyYêu cầu Nhà hàng giao lại món hoặc bồi hoàn cho Khách hàng | Green SM đánh giá mức độ vi phạm và xem xét chuyển lỗi nhóm 1 |
| 19 | Món ăn có dị vật, bao gồm nhưng không giới hạn: tóc, côn trùng, vật thể lạ hoặc các yếu tố gây mất vệ sinh khác. |
| 20 | Món ăn không đảm bảo chất lượng, bao gồm các trường hợp món bị sống, hỏng, ôi thiu hoặc không đảm bảo an toàn khi sử dụng. |
| 21 | Giao sai món, thiếu món hoặc không đúng theo nội dung đơn hàng đã được xác nhận. | Cảnh báo vi phạmYêu cầu Nhà hàng giao lại món hoặc bồi hoàn cho Khách hàng | Tạm đóng gian hàng03 ngàyYêu cầu Nhà hàng giao lại món hoặc bồi hoàn cho Khách hàng | Tạm đóng gian hàng07 ngàyYêu cầu Nhà hàng giao lại món hoặc bồi hoàn cho Khách hàng | Tạm đóng gian hàng14 ngàyYêu cầu Nhà hàng giao lại món hoặc bồi hoàn cho Khách hàng |
| 22 | Món ăn không đúng với mô tả, hình ảnh hoặc thông tin đã công bố trên nền tảng, gây hiểu nhầm cho Khách hàng. |
| 23 | Không cung cấp đầy đủ, hợp lệ các giấy tờ liên quan đến vệ sinh an toàn thực phẩm theo quy định của pháp luật hoặc theo yêu cầu của nền tảng. |
| 24 | Phát sinh lỗi nhóm 2 phía trên và có gây ra ảnh hưởng đến sức khỏe của Khách hàng, khiến họ cần can thiệp y tế hoặc phát sinh chi phí khám chữa bệnh. | Trong trường hợp vi phạm nghiêm trọng hoặc có ảnh hưởng đến sức khỏe Khách hàng, Green SM có quyền áp dụng một, một số hoặc toàn bộ các biện pháp sau mà không phụ thuộc vào số lần vi phạm:Tạm đóng gian hàng ngay lập tức trong các trường hợp:a. Phát sinh sự cố liên quan đến vệ sinh an toàn thực phẩm có ảnh hưởng đến sức khỏe của Khách hàng.b. Đối tác không phản hồi hoặc không phối hợp với Green SM trong vòng 24h kể từ khi nhận thông báo qua các kềnh: email. Điện thoại, SMS, Zalo…– Yêu cầu Đối tác Nhà hàng thực hiện bồi hoàn cho Khách hàng đối với các đơn hàng phát sinh vi phạm.– Thực hiện khấu trừ giá trị đơn hàng và/ hoặc voucher khuyến mãi (tùy theo chính sách từng thời kỳ của Green SM) trực tiếp vào ví/ đối soát của Nhà hàng để bồi hoàn thiệt hại cho Khách hàng.– Yêu cầu Nhà hàng phối hợp hỗ trợ chi trả/ đền bù chi phí khám chữa bệnh phát sinh của Khách hàng (nếu có).– Áp dụng các biện pháp tạm đóng gian hàng có thời hạn hoặc các chế tài bổ sung khác tùy theo mức độ vi phạm và tần suất tái phạm. |

| NHÓM VI PHẠM | Hành vi vi phạm | Chế tài |
| --- | --- | --- |
| III | NHÓM 3: VẬN HÀNH ĐƠN HÀNG | Lần 1 | Lần 2 | Lần 3 | Lần 4 |
| 25 | Tự ý hủy đơn hàng với lý do không hợp lý. | Cảnh báo vi phạm | Tạm đóng gian hàng 01 ngày | Tạm đóng gian hàng03 ngày;và yêu cầuNhà hàng tham gia, hoàn thành chương trình tái đào tạo bắt buộc trước khi mở lại gian hàng. | Tạm đóng gian hàng07 ngày;và yêu cầuNhà hàng tham gia, hoàn thành chương trình tái đào tạo bắt buộc trước khi mở lại gian hàng. |
| 26 | Không chuẩn bị món kịp thời, dẫn đến việc Tài xế phải chờ đợi quá lâu trên 30 phút (trừ các món do đặc thù chế biến). |
| 27 | Không cập nhật trạng thái món ăn/ chế biến trên hệ thống, dẫn đến phát sinh hủy đơn hoặc ảnh hưởng đến quá trình giao nhận. |
| 28 | Sai giờ hoạt động đã đăng ký trên hệ thống (ví dụ: nhận đơn khi cửa hàng thực tế đã đóng cửa). |
| 29 | Tự ý chỉnh sửa đơn hàng mà không thông báo hoặc không được sự đồng ý của Khách hàng. |
| 30 | Gây cản trở quá trình giao nhận của Tài xế, bao gồm nhưng không giới hạn: không giao hàng, không đóng gói, trì hoãn bàn giao đơn hàng. |
| 31 | Có sự phân biệt với các món ăn đặt trên ứng dụng Green SM và tại Nhà hàng/ đơn vị khác (số lượng, giá cả, chất lượng…) |
| 32 | Phát sinh lỗi nhóm 3 phía trên và gây gián đoạn vận hành hoặc ảnh hưởng tiêu cực đến nhiều đơn hàng/Khách hàng/ Tài xế | Căn cứ vào tính chất và mức độ vi phạm, Green SM có quyền áp dụng một, một số hoặc toàn bộ các biện pháp xử lý sau đối với Đối tác Nhà hàng:– Yêu cầu Nhà hàng thực hiện bồi hoàn cho Khách hàng giá trị đơn hàng và/ hoặc bồi hoàn cho Tài xế phí vận chuyển được chia sẻ đối với các đơn hàng phát sinh vi phạm.– Thực hiện khấu trừ giá trị đơn hàng và/ hoặc voucher khuyến mãi (tùy theo chính sách từng thời kỳ của Green SM) trực tiếp vào ví/ đối soát của Nhà hàng để bồi hoàn thiệt hại cho Khách hàng.– Áp dụng biện pháp tạm đóng gian hàng có thời hạn trong trường hợp vi phạm ảnh hưởng đến trải nghiệm Khách hàng hoặc tỷ lệ hủy đơn.– Áp dụng các chế tài bổ sung khác tùy theo mức độ vi phạm và tần suất tái phạm. |

| NHÓM VI PHẠM | Hành vi vi phạm | Chế tài |
| --- | --- | --- |
| IV | NHÓM 4: TRẢI NGHIỆM & HỢP TÁC | Lần 1 | Lần 2 | Lần 3 | Lần 4 |
| 33 | Không phản hồi khiếu nại từ Khách hàng hoặc nền tảng trong thời gian quy định (trong vòng 24 giờ). | Cảnh báo vi phạm | Tạm đóng gian hàng 01 ngày | Tạm đóng gian hàng03 ngày;và yêu cầu Nhà hàng tham gia, hoàn thành chương trình tái đào tạo bắt buộc trước khi mở lại gian hàng. | Tạm đóng gian hàng07 ngày;và yêu cầu Nhà hàng tham gia, hoàn thành chương trình tái đào tạo bắt buộc trước khi mở lại gian hàng. |
| 34 | Phân biệt đối xử hoặc có hành vi bất lợi với Đối tác Tài xế, bao gồm nhưng không giới hạn ở việc từ chối phục vụ, ưu tiên xử lý đơn hàng của người dùng/ đơn vị khác. |
| 35 | Phát sinh lỗi nhóm 4 phía trên và không phản hồi, xử lý khắc phục kịp thời. | Green SM có quyền khóa gian hàng vĩnh viễn nếu Nhà hàng không phản hồi hoặc không phối hợp xử lý với Green SM trong vòng 03 ngày làm việc kể từ thời điểm nhận được yêu cầu xử lý (bao gồm cả thời gian gian hàng bị tạm đóng). |

| NHÓM VI PHẠM | Hành vi vi phạm | Chế tài |
| --- | --- | --- |
| V | NHÓM 5: TUÂN THỦ & KHÁC | Lần 1 | Lần 2 | Lần 3 | Lần 4 |
| 36 | Chưa cung cấp đầy đủ thông tin liên quan đến hàng hóa, giấy phép đủ điều kiện kinh doanh theo Pháp luật. | Nhắc nhở (kèm yêu cầu hoàn thành) | Tạm đóng gian hàng01 ngày(kèm yêu cầu hoàn thành) | Tạm đóng gian hàng03 ngày(kèm yêu cầu hoàn thành) | Tạm đóng gian hàng07 ngày(kèm yêu cầu hoàn thành) |
| 37 | Không tham gia các chương trình đào tạo, hướng dẫn bắt buộc theo yêu cầu của Green SM. |
| 38 | Không bảo quản, sử dụng hoặc làm hư hỏng thiết bị phục vụ hoạt động trên nền tảng. | Nhắc nhở đồng thời khấu trừ chi phí (nếu phát sinh) | Tạm đóng gian hàng03 ngàyđồng thời khấu trừ chi phí (nếu phát sinh) | Tạm đóng gian hàng07 ngàyđồng thời khấu trừ chi phí (nếu phát sinh) | Tạm đóng gian hàng14 ngàyđồng thời khấu trừ chi phí (nếu phát sinh) |
| VI | NHÓM 6: MENU & HIỂN THỊ | Lần 1 | Lần 2 | Lần 3 | Lần 4 |
| 39 | Thiết lập hoặc hiển thị thông tin thực đơn không đúng quy định, bao gồm: Mô tả, hình ảnh, chú thích không chính xác hoặc gây hiểu nhầm.Thông tin không tuân thủ tiêu chuẩn hiển thị của nền tảng. | Căn cứ vào tính chất và mức độ vi phạm, Green SM có quyền áp dụng một, một số hoặc toàn bộ các biện pháp xử lý sau:– Yêu cầu gỡ bỏ hoặc chỉnh sửa ngay lập tức các nội dung vi phạm.– Cảnh báo vi phạm trong trường hợp lần đầu hoặc mức độ nhẹ.– Tạm đóng gian hàng cho đến khi hoàn tất việc khắc phục vi phạm.– Áp dụng các biện pháp xử lý cao hơn trong trường hợp vi phạm có dấu hiệu gian lận hoặc điều hướng giao dịch ngoài nền tảng. |
| 40 | Đăng tải thông tin không phù hợp trên nền tảng, bao gồm nhưng không giới hạn: Số điện thoại cá nhân, thông tin liên hệ ngoài nền tảng |
