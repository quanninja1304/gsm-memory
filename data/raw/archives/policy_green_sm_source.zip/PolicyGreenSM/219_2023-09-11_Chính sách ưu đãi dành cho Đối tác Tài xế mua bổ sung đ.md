# Chính sách ưu đãi dành cho Đối tác Tài xế mua bổ sung đồng phục

- **Ngày đăng:** 2023-09-11
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-uu-dai-danh-cho-doi-tac-tai-xe-mua-bo-sung-dong-phuc](https://www.greensm.com/vn-vi/news/chinh-sach-uu-dai-danh-cho-doi-tac-tai-xe-mua-bo-sung-dong-phuc)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Tin vui cho các Đối tác Tài xế của Green SM Bike đây! Green SM Bike đang có chính sách ưu đãi dành cho Đối tác Tài xế mua bổ sung đồng phục từ ngày 08/09/2023.

Các đồng phục có thể mua bổ sung bao gồm áo khoác, mũ bảo hiểm, áo mưa. Combo đồng phục này là những phụ kiện không thể thiếu giúp Đối tác Tài xế đảm bảo an toàn và bảo vệ sức khỏe khi lái xe.

Để sở hữu combo đồng phục chất lượng từ Green SM Bike, các Đối tác Tài xế có thể tới mưa trực tiếp tại:

- Địa chỉ: Tầng B1 tòa R3 Royal City, 72 Nguyễn Trãi, Thanh Xuân, Hà Nội

- Thời gian làm việc: từ thứ 2 – thứ 7 vào 8h30 – 17h30

* Một số lưu ý cho các Đối tác Tài xế khi mua đồng phục:

- Giá bán khuyến mãi được áp dụng với số lượng đồng phục có hạn.

- Thời gian áp dụng: giá bán khuyến mãi được áp dụng cho tới khi có thông báo mới nhất.

- Kể từ lần lấy đồng phục thứ 03 (bao gồm lần phát đồng phục miễn phí), Đối tác Tài xế chỉ có thể mua đồng phục sau khi chương trình khuyến mãi đã kết thúc, đồng thời mua với giá bán niêm yết

Chúc các Đối tác Tài xế có những chuyến xe thoải mái và hiệu quả trong thời gian tới!

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/09/222eb7e8-dsc08746-1024x683.jpg)
