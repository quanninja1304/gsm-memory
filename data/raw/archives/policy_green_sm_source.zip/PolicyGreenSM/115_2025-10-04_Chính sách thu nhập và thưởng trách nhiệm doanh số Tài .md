# Chính sách thu nhập và thưởng trách nhiệm doanh số Tài xế Xanh Car tại Khánh Hòa 1, 2; Huế 1; Đà Nẵng 2

- **Ngày đăng:** 2025-10-04
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-car-khanhhoa-hue-danang2](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-car-khanhhoa-hue-danang2)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Với mục đích hỗ trợ Bác tài quản lý thu nhập một cách minh bạch và chủ động hơn, Green SM xin thông báo về việc cập nhậtChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấmcôngmới.

👉 Thời gian áp dụng:Từ 04/10/2025cho đến khi có thông báo mới

👉 Chi tiết chính sách: Bác tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/f414b115-xanh-car_kh12_hue1_dnang2-632x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CẬP NHẬT CHÍNH SÁCH THU NHẬP VÀ THƯỞNG TRÁCH NHIỆM DOANH SỐ
> 
> *   **Đối tượng áp dụng:** Tài xế Taxi tại Depot Khánh Hòa 1, 2; Huế 1; Đà Nẵng 2
> *   **Thời gian áp dụng:** Từ ngày 04/10/2025 đến khi có thông báo mới
> 
> ## Nội dung chính sách
> Cập nhật mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công
> 
> ## THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> **Xanh SM Car**
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ |
> | :---- | :---------------------------- | :------------ |
> | Mức 0 | Dưới 800.000                  | 26%           |
> | Mức 1 | Từ 800.000 đến dưới 1.100.000  | 33%           |
> | Mức 2 | Từ 1.100.000 đến dưới 1.400.000 | 36%           |
> | Mức 3 | Từ 1.400.000 đến dưới 1.700.000 | 41%           |
> | Mức 4 | Từ 1.700.000 đến dưới 2.000.000 | 45%           |
> | Mức 5 | Từ 2.000.000 trở lên          | 49%           |
> 
> ## TIÊU CHUẨN CHẤM CÔNG
> **Xanh SM Car**
> 
> | Tháng áp dụng   | Khu vực áp dụng (Depot/HUB) | Tiêu chí               | Từ T2 - T5  | TỪ T6 - CN, ngày Lễ, Tết | TỪ T2 - CN, ngày Lễ, Tết |
> | :-------------- | :-------------------------- | :--------------------- | :---------- | :----------------------- | :----------------------- |
> |                 |                             | Tỷ lệ nhận cuốc        | 85%         |                          | 80%                      |
> |                 |                             | Tỷ lệ hoàn thành cuốc | 85%         |                          | 85%                      |
> | 4, 5, 6, 7, 8   |                             |                        | Từ 600.000  | Từ 600.000               | Từ 1.100.000             |
> | 3, 9, 10, 11, 12 | Khánh Hòa 1,2              |                        | Từ 540.000  | Từ 540.000               | Từ 990.000               |
> | 4, 5, 6, 7, 8, 12 | Huế 1                       | Doanh số (VNĐ/ngày)    | Từ 700.000  | Từ 800.000               | Từ 1.100.000             |
> | 3, 9, 10, 11    |                             |                        | Từ 630.000  | Từ 720.000               | Từ 990.000               |
> | 3, 5, 6, 7, 8, 9, 12 | Đà Nẵng 2                 |                        | Từ 600.000  | Từ 700.000               | Từ 1.100.000             |
> | 4, 10, 11       |                             |                        | Từ 540.000  | Từ 630.000               | Từ 990.000               |

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Trân trọng,Đội ngũ Green SM.
