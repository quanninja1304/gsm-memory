# Chính sách thu nhập và thưởng trách nhiệm doanh số Tài xế Taxi tại Hà Nội, TP.HCM

- **Ngày đăng:** 2025-10-04
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-hn-hcm](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-hn-hcm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Với mục đích hỗ trợ Bác tài quản lý thu nhập một cách minh bạch và chủ động hơn, Green SM xin thông báo về việc cập nhậtChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấmcôngmới.

👉 Thời gian áp dụng:Từ 04/10/2025cho đến khi có thông báo mới

👉 Chi tiết chính sách: Bác tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/3f282a5e-txtx_hcm1267_hn123-420x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CẬP NHẬT CHÍNH SÁCH THU NHẬP VÀ THƯỜNG TRÁCH NHIỆM DOANH SỐ
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Depot Hồ Chí Minh 1, 2, 6, 7; Hà Nội 1, 2, 3
> **Thời gian áp dụng:** Từ ngày 04/10/2025 đến khi có thông báo mới
> 
> ## Nội dung chính sách
> Cập nhật khung giờ cao điểm, mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công
> 
> ## THƯỜNG TRÁCH NHIỆM VÀ DOANH SỐ
> 
> | Khu vực áp dụng  | TP. Hồ Chí Minh (cũ), Hà Nội                                     |
> | :--------------- | :--------------------------------------------------------------- |
> | **Thời gian**    | Từ thứ 2 đến Thứ 6                     | Thứ 7, Chủ nhật                     | Tết Âm lịch (5 ngày) |
> | **Khung giờ cao điểm** | 06:00-08:59;<br>16:00-21:59           | 09:00-11:59;<br>17:00-23:59           | Không áp dụng        |
> 
> ### Xanh SM Car
> 
> **Tỷ lệ chia sẻ**
> 
> | Mức   | Doanh số (VNĐ/ngày)              | Cuốc xe thường | Cuốc cao điểm (Hà Nội/TP. Hồ Chí Minh cũ) |
> | :---- | :------------------------------- | :------------- | :--------------------------------------- |
> | Mức 0 | Dưới 1.000.000                   | 25%            | 33%                                      |
> | Mức 1 | Từ 1.000.000 đến dưới 1.300.000   | 30%            | 39%                                      |
> | Mức 2 | Từ 1.300.000 đến dưới 1.500.000   | 35%            | 45%                                      |
> | Mức 3 | Từ 1.500.000 đến dưới 1.800.000   | 40%            | 52%                                      |
> | Mức 4 | Từ 1.800.000 đến dưới 2.100.000   | 44%            | 56%                                      |
> | Mức 5 | Từ 2.100.000 trở lên             | 48%            | 60%                                      |
> 
> ### Xanh SM Premium
> 
> **Tỷ lệ chia sẻ**
> 
> | Mức   | Doanh số (VNĐ/ngày)              | Cuốc xe thường | Cuốc cao điểm (Hà Nội/TP. Hồ Chí Minh cũ) |
> | :---- | :------------------------------- | :------------- | :--------------------------------------- |
> | Mức 0 | Dưới 900.000                     | 25%            | 33%                                      |
> | Mức 1 | Từ 900.000 đến dưới 1.200.000     | 32%            | 41%                                      |
> | Mức 2 | Từ 1.200.000 đến dưới 1.400.000   | 37%            | 47%                                      |
> | Mức 3 | Từ 1.400.000 đến dưới 1.700.000   | 42%            | 54%                                      |
> | Mức 4 | Từ 1.700.000 đến dưới 2.000.000   | 45%            | 58%                                      |
> | Mức 5 | Từ 2.000.000 trở lên             | 48%            | 62%                                      |
> 
> ## TIÊU CHUẨN CHẤM CÔNG
> 
> ### Xanh SM Car
> 
> | Tháng áp dụng | Tiêu chí               | TỪ T2 - T5 | TỪ T6 - CN, ngày Lễ, Tết | TỪ T2 - CN, ngày Lễ, Tết |
> | :------------ | :--------------------- | :--------- | :----------------------- | :----------------------- |
> |               | Tỷ lệ nhận cuốc        | 85%        | 80%                      | 75%                      | 70% |
> |               | Tỷ lệ hoàn thành cuốc  | 85%        | 85%                      | 85%                      | 85% |
> | **3,4,5,6,7,8,12** | Doanh số (VNĐ/ngày)    | Từ 800.000 | Từ 1.000.000             | Từ 1.500.000             | Từ 1.800.000             | Từ 2.200.000 |
> | **9,10,1**    | Doanh số (VNĐ/ngày)    | Từ 720.000 | Từ 900.000               | Từ 1.350.000             | Từ 1.620.000             | Từ 1.980.000 |
> 
> ### Xanh SM Premium
> 
> | Tháng áp dụng | Tiêu chí               | TỪ T2 - T5 | TỪ T6 - CN, ngày Lễ, Tết | TỪ T2 - CN, ngày Lễ, Tết |
> | :------------ | :--------------------- | :--------- | :----------------------- | :----------------------- |
> |               | Tỷ lệ nhận cuốc        | 85%        | 80%                      | 75%                      | 70% |
> |               | Tỷ lệ hoàn thành cuốc  | 85%        | 85%                      | 85%                      | 85% |
> | **3,4,5,6**   | Doanh số (VNĐ/ngày)    | Từ 800.000 | Từ 1.000.000             | Từ 1.200.000             | Từ 1.600.000             | Từ 2.100.000 |
> | **9,10,11**   | Doanh số (VNĐ/ngày)    | Từ 720.000 | Từ 900.000               | Từ 1.080.000             | Từ 1.440.000             | Từ 1.890.000 |
> ```

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Trân trọng,Đội ngũ Green SM.
