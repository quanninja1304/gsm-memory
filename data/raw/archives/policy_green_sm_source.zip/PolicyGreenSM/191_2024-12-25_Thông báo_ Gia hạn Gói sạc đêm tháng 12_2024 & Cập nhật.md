# Thông báo: Gia hạn Gói sạc đêm tháng 12/2024 & Cập nhật Chính sách ưu đãi sạc xe 2025

- **Ngày đăng:** 2024-12-25
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-goi-sac](https://www.greensm.com/vn-vi/news/chinh-sach-goi-sac)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Green SM xin thông báo về việcgia hạn Gói sạc đêm tháng 12/2024và cập nhậtChính sách ưu đãi sạc xe năm 2025như sau:

I/ Giai đoạn 26 – 31/12/2024:

- Tài xế đã đăng kýGói sạc tiêu chuẩntừ ngày20 – 25/12/2024sẽkhông được kích hoạtvàkhông bị tính phícho Gói sạc này.

- Tài xế đã đăng kýGói sạc không giới hạn giờ thấp điểmtừ ngày 20-25/12/2024 đã được ghi nhận trên hệ thống và có thể sử dụng gói sạc cho tới hết ngày 31/12/2024.

- Các Tài xế chưa đăng kýGói sạc không giới hạn giờ thấp điểmcần thao tác đăng ký ngay để được ghi nhận và sử dụng trong giai đoạn 26-31/12/2024.

II/ Giai đoạn kể từ Tháng 01/2025:

Chính sách ưu đãi sạc xe 2025được áp dụng như sau:

1.       Đối tượng áp dụng:

- Tài xế Taxi trên toàn quốc sử dụng xe thuộc sở hữu của GSM.

- Đang làm việc trong thời gian Chính sách có hiệu lực và có đăng ký gói sạc.

2.     Thời gian áp dụng:Từ ngày 01/01/2025 đến khi có thông báo mới.

3.     Nội dung chính sách:

- Miễn phísạc pin trong khung giờ đêm.

- Giảm 50%chi phí sạc trong các khung giờ còn lại.

- Tài xế mới trong thời gian tập nghề đượchỗ trợ phí sạckhi đạt mốc doanh số tháng.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/12/ba414196-filethietkemoi-01-960x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> ## CHÍNH SÁCH ƯU ĐÃI SẠC XE
> 
> Áp dụng từ ngày **01/01/2025** đến khi có thông báo mới
> 
> ## ĐỐI TƯỢNG ÁP DỤNG
> *   Tài xế Taxi trên toàn quốc sử dụng xe thuộc sở hữu của GSM.
> *   Đang làm việc trong thời gian Chính sách có hiệu lực.
> 
> ## CHÍNH SÁCH ƯU ĐÃI
> 
> | Thời gian                | Miễn phí chi phí sạc       | Giảm giá 50% chi phí sạc |
> | :----------------------- | :------------------------- | :----------------------- |
> | Từ thứ 2 đến thứ 5       | **22h00 - 06h00** ngày hôm sau | Các khung giờ còn lại    |
> | Từ thứ 6 đến chủ nhật | **23h00 - 06h00** ngày hôm sau |                          |
> 
> **Lưu ý:**
> *   Chính sách không áp dụng với Tài xế sử dụng xe được cho thuê.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/12/925a699c-update1-898x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH ƯU ĐÃI SẠC XE CHO TÀI XẾ MỚI
> 
> Áp dụng từ ngày **01/01/2025** đến khi có thông báo mới
> 
> Tài xế Taxi mới trong thời gian tập nghề sẽ được hỗ trợ phí sạc khi đạt doanh số tháng như sau:
> 
> | Khu vực          | Mốc doanh số tháng (VNĐ) | Hỗ trợ phí sạc (VNĐ) |
> | :--------------- | :----------------------- | :------------------ |
> | Hà Nội,          | 21.000.000               | 500.000             |
> | TP. Hồ Chí Minh  | 16.500.000               | 300.000             |
> | Các tỉnh còn lại | 15.500.000               | 300.000             |
> |                  | 12.500.000               | 200.000             |
> 
> **Lưu ý:**
> * Số tiền hỗ trợ sẽ được trả qua lương hàng tháng.
> * Tài xế mới vẫn được hưởng Chính sách ưu đãi sạc xe tương tự Tài xế hiện hữu.
> * Trong trường hợp Tài xế bắt đầu làm việc vào giữa tháng, mốc doanh số và chi phí hoàn được tính theo tỉ lệ giữa ngày công chuẩn của Tài xế và ngày công chuẩn tháng.
> ```

Mến chúc Bác tài hoạt động an toàn và hiệu quả với chính sách mới!

Trân trọng,Đội ngũ GSM
