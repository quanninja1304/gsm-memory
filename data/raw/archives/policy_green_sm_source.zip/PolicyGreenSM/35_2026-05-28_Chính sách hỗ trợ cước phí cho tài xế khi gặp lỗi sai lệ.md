# Chính sách hỗ trợ cước phí cho tài xế khi gặp lỗi sai lệch định vị dành cho các đơn hàng Express Doanh Nghiệp

- **Ngày đăng:** 2026-05-28
- **Chuyên mục:** Cẩm nang tài xế, Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-ho-tro-cuoc-phi-tai-xe-gap-loi-dinh-vi-don-hang-express-doanh-nghiep](https://www.greensm.com/vn-vi/news/chinh-sach-ho-tro-cuoc-phi-tai-xe-gap-loi-dinh-vi-don-hang-express-doanh-nghiep)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Từ ngày 27/05/2026, Đối tác tài xế sẽ được hỗ trợ cước phí khi phải di chuyển thêm do điểm giao hàng trên ứng dụng bị sai lệch so với điểm giao hàng thực tế.

Đối tượng & phạm vi áp dụng

- Áp dụng cho: Tài xế 2 bánh toàn quốc (Bike cơ hữu, Platform, RTO)

- Đơn hàng áp dụng: Tất cả đơn Express doanh nghiệp 1H, 2H (Shopee, Long Châu, Capichi, Jollibee…)

- Thời gian: Từ 27/05/2026

Mức hỗ trợ

- Sai lệch trên 1km: hỗ trợ 5.000đ/km, tối đa 15.000đ/đơn

- Sai lệch dưới 1km: không hỗ trợ

- Công thức: Số tiền hỗ trợ = X(km) × 5.000đ Trong đó X(km) là khoảng cách thực tế tài xế phải di chuyển thêm, tính từ điểm giao trên app đến điểm giao thực tế.

Quy trình nhận hỗ trợ (4 bước)

- Khi phát sinh đơn sai lệch định vị, tài xế giao hàng như bình thường, chụp ảnh và thao tác giao hàng đúng tại điểm giao thực tế.

- Điền link Hỗ trợ cước phí sai định vị trong vòng24 giờkể từ thời điểm hoàn thành đơn:https://forms.gle/GDXVXR1xCpKfAz3r7

- Green SM kiểm tra tính hợp lệ và phản hồi.

- Đền bù theo quy trình bồi hoàn thông thường (trong 14–30 ngày).

Lưu ý quan trọng:Tài xế cần cung cấp bằng chứng xác thực việc thay đổi địa điểm giao hàng, bao gồm nhưng không giới hạn:

- Ảnh chụp giao hàng thể hiện rõ địa điểm giao thực tế

- Tin nhắn/cuộc gọi từ Người gửi/Người nhận thông báo về việc thay đổi địa điểm giao hàng

![Chính sách hỗ trợ cước phí cho tài xế khi gặp lỗi sai lệch định vị dành cho các đơn hàng Express Doanh Nghiệp  ](https://cdn.xanhsm.com/2026/05/b94b73f9-1-1024x643.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # TIN VUI CHO BÁC TÀI XANH
> ## HỖ TRỢ CƯỚC SAI LỆCH ĐỊNH VỊ
> 
> **Từ ngày 27/05/2026**
> 
> Bác Tài sẽ được hỗ trợ cước phí khi phải di chuyển thêm do điểm giao hàng trên ứng dụng bị sai lệch so với điểm giao hàng thực tế.
> 
> | Tiêu đề               | Nội dung                                                                                                                                           |
> | :-------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Đối tượng và phạm vi áp dụng** | Bác Tài Xanh Bike, Bike Platform, Bike thuê xe sở hữu (RTO) <br> Đơn hàng áp dụng: Tất cả đơn Express doanh nghiệp 1H, 2H (Shopee, Long Châu, Capichi, Jollibee,...) |
> | **Mức hỗ trợ**        | Sai lệch **trên 1km**: hỗ trợ **5.000đ/km**, tối đa **15.000đ/ đơn** <br> Sai lệch **dưới 1km**: **KHÔNG HỖ TRỢ**                                 |
> | **Công thức**         | Số tiền hỗ trợ = X (km) x 5.000đ <br> Trong đó X (km) là khoảng cách thực tế Bác Tài phải di chuyển thêm, tính từ điểm giao trên app đến điểm giao thực tế |
> ```

![Chính sách hỗ trợ cước phí cho tài xế khi gặp lỗi sai lệch định vị dành cho các đơn hàng Express Doanh Nghiệp  ](https://cdn.xanhsm.com/2026/05/018571b7-2-1024x643.png)

> **[Nội dung trích xuất từ ảnh]:**
> Tuyệt vời! Đây là nội dung từ hình ảnh đã được trích xuất và định dạng Markdown tiếng Việt:
> 
> # TIN VUI CHO BÁC TÀI XANH
> ## HỖ TRỢ CƯỚC SAI LỆCH ĐỊNH VỊ
> 
> ### CÁCH NHẬN HỖ TRỢ
> 
> 1.  Khi phát sinh đơn sai lệch định vị, Bác Tài giao hàng như bình thường, chụp ảnh và thao tác giao hàng đúng tại điểm giao thực tế.
> 2.  Điền link hỗ trợ cước phí sai định vị trong vòng **24 giờ** kể từ thời điểm hoàn thành đơn: Link form: [https://forms.gle/GDXVXR1xCpKfAz3r7](https://forms.gle/GDXVXR1xCpKfAz3r7)
> 3.  Green SM kiểm tra tính hợp lệ và phản hồi.
> 4.  Đền bù theo quy trình bồi hoàn thông thường (trong 14-30 ngày).
> 
> ---
> 
> **LƯU Ý QUAN TRỌNG**
> 
> Bác Tài cần cung cấp **bằng chứng xác thực** việc thay đổi địa điểm giao hàng, bao gồm nhưng không giới hạn:
> *   Ảnh chụp giao hàng thể hiện rõ địa điểm giao thực tế.
> *   Tin nhắn/ cuộc gọi từ Người gửi/ Người nhận thông báo về việc thay đổi địa điểm giao hàng.
> 
> ---
> 
> **Minh họa trên điện thoại:**
> 
> *   **Đơn hàng Express 1H**
> *   **Sai lệch định vị > 1km**
> *   **Được hỗ trợ thêm cước phí**

| Câu hỏi | Trả lời |
| --- | --- |
| Quãng đường sai lệch của tôi là 5km, tôi được hỗ trợ bao nhiêu? | Chính sách hỗ trợ 5.000đ/km sai lệch và tối đa 15.000đ/đơn, nên với các đơn sai lệch >3km đối tác sẽ được hỗ trợ 15.000đ/đơn sai lệch. |
| Đơn của tôi sai lệch định vị 800m, tôi có được hỗ trợ không? | Không. Chính sách chỉ áp dụng cho đơn có khoảng cách sai lệchtrên 1km.Các đơn sai lệch dưới 1km sẽ không được hỗ trợ cước phí. |
| Tôi quên điền form trong 24 giờ sau khi hoàn thành đơn, tôi có được hỗ trợ truy thu không? | Không. Để đảm bảo tính chính xác trong việc kiểm tra, đối soát, các yêu cầu hỗ trợ gửi sau 24 giờ kể từ thời điểm hoàn thành đơn sẽkhông được tiếp nhận. Tài xế cần chủ động điền form ngay sau khi giao xong đơn sai lệch. |
| Tôi cần cung cấp những bằng chứng gì để chứng minh đơn của tôi bị sai lệch định vị? | Tài xế cần cung cấp ít nhất một trong các bằng chứng sau:– Ảnh chụp giao hàng thể hiện rõ địa điểm giao thực tế (biển số nhà, tên đường, landmark…).– Tin nhắn hoặc ảnh chụp cuộc gọi từ Người gửi/Người nhận thông báo về việc thay đổi địa điểm giao hàng.– Trường hợp không cung cấp đủ bằng chứng, GSVH có quyền từ chối hỗ trợ. |
| Đơn hàng của tôi không phải đơn Express 1H, 2H thì có được hỗ trợ không? | Không. Chính sách chỉ áp dụng cho đơnExpress doanh nghiệp 1H, 2Hcủa các đối tác như Shopee, Long Châu, Capichi, Jollibee… Các loại đơn khác (giao hàng thường, đơn cá nhân…) không thuộc phạm vi áp dụng của chính sách này. |
| Khi nào tôi nhận được tiền hỗ trợ sau khi điền form? | Sau khi tài xế gửi form, Green SM sẽ kiểm tra tính hợp lệ và phản hồi kết quả. Tiền hỗ trợ sẽ được đền bù theoquy trình hoàn thông thường, trong vòng 14-30 ngàykể từ thời điểm yêu cầu được duyệt. |

Trân trọngĐội ngũ Green SM Bike
