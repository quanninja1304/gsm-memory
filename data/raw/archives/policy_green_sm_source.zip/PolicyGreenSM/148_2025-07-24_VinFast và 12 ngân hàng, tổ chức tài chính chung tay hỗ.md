# VinFast và 12 ngân hàng, tổ chức tài chính chung tay hỗ trợ người dân Hà Nội chuyển sang xe điện

- **Ngày đăng:** 2025-07-24
- **Chuyên mục:** Báo chí
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/vinfast-va-12-ngan-hang-to-chuc-tai-chinh-chung-tay-ho-tro-nguoi-dan-ha-noi-chuyen-sang-xe-dien](https://www.greensm.com/vn-vi/news/vinfast-va-12-ngan-hang-to-chuc-tai-chinh-chung-tay-ho-tro-nguoi-dan-ha-noi-chuyen-sang-xe-dien)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Hà Nội, ngày 24/7/2025 – VinFast đã ký kết thỏa thuận hợp tác với 12 ngân hàng và tổ chức tài chính lớn nhằm hỗ trợ người dân Thủ đô chuyển đổi từ xe xăng sang xe điện. Với loạt ưu đãi chưa từng có như cho vay trả góp (theo chính sách riêng của từng ngân hàng) lên tới 70-90% giá xe, thời hạn vay lên tới 8 năm, lãi suất thấp hơn mặt bằng tới 3-4% trong 3 năm đầu; VinFast tặng 10% giá xe và 100% lệ phí trước bạ cho xe máy điện…, quá trình chuyển đổi xanh sẽ trở nên dễ dàng hơn cho tất cả mọi người.

Liên minh các ngân hàng, đối tác tài chính lớn hợp tác cùng VinFast hỗ trợ người dân Thủ đô chuyển đổi xanh gồm có: Vietcombank, VietinBank, BIDV, MBB, Techcombank, VPBank, HDBank, Sacombank, TPBank, MSB, Lotte Finance, Shinhan Finance. Đây đều là những đơn vị tiên phong trong chuyển đổi xanh và đang thúc đẩy mạnh mẽ nguồn vốn xanh cho các chương trình phát triển bền vững, hướng tới mục tiêu tăng trưởng xanh.

Lễ ký kết hợp tác giữa 12 ngân hàng, tổ chức tài chính lớn với VinFast là dấu mốc đặc biệt cho thấy sự hưởng ứng, chung sức đồng lòng của cộng đồng doanh nghiệp với chủ trương của Chính phủ và tinh thần đồng hành, hỗ trợ người dân.

![Hợp tác giữa 12 ngân hàng, tổ chức tài chính lớn với VinFast là dấu mốc đặc biệt cho thấy sự hưởng ứng, chung sức đồng lòng của cộng đồng doanh nghiệp với chủ trương của Chính phủ và tinh thần đồng hành, hỗ trợ người dân.](https://cdn.xanhsm.com/2025/07/d58265af-a2-1024x548.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> LỄ KÝ KẾT HỢP TÁC
> GIỮA VINFAST VÀ CÁC ĐỐI TÁC NGÂN HÀNG
> Hợp lực kiến tạo
> Kỷ nguyên
> Xanh
> ```

Hợp tác giữa 12 ngân hàng, tổ chức tài chính lớn với VinFast là dấu mốc đặc biệt cho thấy sự hưởng ứng, chung sức đồng lòng của cộng đồng doanh nghiệp với chủ trương của Chính phủ và tinh thần đồng hành, hỗ trợ người dân.

Theo thỏa thuận hợp tác, VinFast và các ngân hàng sẽ cùng nhau xây dựng các gói vay và giải pháp tài chính ưu đãi hấp dẫn, với các điều kiện, thủ tục linh hoạt, đơn giản để giúp cho người dân dễ dàng chuyển đổi sang xe điện.

Với khách hàng mua ô tô điện VinFast và đăng ký biển số Hà Nội, các ngân hàng sẽ hỗ trợ vay trả góp lên tới 70-80% giá xe trong thời hạn tối đa lên tới 8 năm (theo chính sách riêng của từng ngân hàng). Khách hàng sẽ được VinFast và ngân hàng hỗ trợ thêm 3% lãi suất/năm so với lãi suất thông thường trong 3 năm đầu. Ngoài ra, nếu khách hàng mua xe để đăng ký kinh doanh dịch vụ trên nền tảng Green SM Platform, mức hỗ trợ ưu đãi lãi suất từ VinFast và ngân hàng sẽ là 4%/năm trong 3 năm đầu. Đồng thời, tài xế sẽ được GSM chia sẻ doanh thu cố định 90% trong vòng 3 năm. Ưu đãi này sẽ được áp dụng đồng thời với các chính sách khác của VinFast như Mãnh liệt Tinh thần Việt Nam – Vì tương lai xanh lần 3 (ưu đãi 4% trên giá niêm yết), hay Thu xăng – Đổi điện với ưu đãi lên tới 100 triệu đồng.

Với khách hàng cá nhân mua xe máy điện có hộ khẩu thường trú hoặc tạm trú trên địa bàn Hà Nội, VinFast cùng với đối tác tài chính sẽ mang đến cơ hội sở hữu xe ngay với 0 đồng vốn đối ứng cho khách hàng. Cụ thể, nếu mua xe để vận doanh trên nền tảng Green SM Platform, VinFast sẽ tặng ngay cho khách hàng 10% giá xe. 90% còn lại khách hàng có thể vay mua xe trả góp trong vòng tối đa 3 năm với sự bảo lãnh của GSM. Như vậy, khách hàng không cần chi ra khoản vốn đối ứng ban đầu mà có thể nhận xe ngay với chỉ 0 đồng.

Nếu mua xe máy điện để phục vụ các nhu cầu cá nhân khác, khách hàng Thủ đô chỉ cần chi ra 10% giá xe. VinFast sẽ tặng cho khách hàng 10%, còn lại 80% khách hàng có thể vay trả góp trong vòng tối đa 3 năm. Đặc biệt, trong thời gian từ 24/7 đến 24/10/2025, khách hàng mua xe máy điện VinFast có hộ khẩu thường trú hoặc tạm trú tại Hà Nội sẽ được tặng ngay 100% lệ phí trước bạ.

Các ưu đãi hấp dẫn từ cả VinFast và các đối tác ngân hàng sẽ trở thành trợ lực mạnh mẽ, giúp người dân Thủ đô tăng tốc chuyển đổi xanh, sớm hoàn thành mục tiêu của Chỉ thị 20/CT-TTg và các mục tiêu phát triển bền vững khác.

Phát biểu tại buổi lễ ký kết thỏa thuận hợp tác, ông Lê Việt Đức – Giám đốc Khối Bán lẻ Ngân hàng Thương mại Cổ phần Công Thương Việt Nam (VietinBank), đại diện cho các tổ chức tài chính chung tay cùng VinFast thúc đẩy chuyển đổi xanh tại Thủ đô, cho biết:“Chiến lược phát triển hiện nay của VietinBank và nhiều tổ chức tín dụng được định hình rõ nét theo các chuẩn mực ESG (Môi trường – Xã hội – Quản trị). Chúng tôi ưu tiên tài trợ các dự án, phương án kinh doanh mang lại tác động tích cực cho môi trường và cộng đồng. Việc hợp tác với Vingroup trong chiến dịch chuyển đổi xanh là minh chứng cho cam kết mạnh mẽ về phát triển bền vững và khẳng định vai trò dẫn dắt trong kiến tạo tương lai kinh tế xanh. Chúng tôi tin tưởng rằng, việc đồng hành cùng Vingroup trong quá trình chuyển đổi từ xe xăng sang xe điện sẽ tiếp tục mở ra nhiều cơ hội đột phá, mang lại giá trị thực tiễn cho xã hội và góp phần vào hành trình “zero phát thải” của Quốc gia”.

![Ông Lê Việt Đức, Giám đốc Khối Bán lẻ Ngân hàng Thương mại Cổ phần Công Thương Việt Nam (VietinBank), đại diện cho các tổ chức tài chính chung tay cùng VinFast thúc đẩy chuyển đổi xanh tại Thủ đô phát biểu tại lễ ký kết hợp tác.](https://cdn.xanhsm.com/2025/07/d00e46ad-a3-1024x683.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> ## VINFAST
> 
> **LỄ KÝ KẾT HỢP TÁC**
> **GIỮA VINFAST VÀ CÁC ĐỐI TÁC NGÂN HÀNG**
> 
> **Hợp lực kiến tạo Kỷ nguyên Xanh**
> 
> Hà Nội, ngày 07.2025
> 
> (Logo VinFast trên bục phát biểu)
> ```

Ông Lê Việt Đức, Giám đốc Khối Bán lẻ Ngân hàng Thương mại Cổ phần Công Thương Việt Nam (VietinBank), đại diện cho các tổ chức tài chính chung tay cùng VinFast thúc đẩy chuyển đổi xanh tại Thủ đô phát biểu tại lễ ký kết hợp tác.

Ông Lê Khắc Hiệp – Phó Chủ tịch Tập đoàn Vingroup chia sẻ:“Chuyển đổi xanh, phát triển bền vững không phải là câu chuyện riêng của một doanh nghiệp, mà cần có sự chung tay, góp sức của tất cả mọi thành phần trong xã hội. Sự hưởng ứng, hợp tác của 12 ngân hàng, tổ chức tài chính lớn ngày hôm nay cùng với các công ty trong hệ sinh thái xanh Vingroup chính là minh chứng cho tầm nhìn chiến lược và sự đồng lòng của cộng đồng doanh nghiệp với các mục tiêu chung của đất nước. Tôi tin tưởng rằng với sự quyết liệt từ Chính phủ, sự ủng hộ, đồng thuận từ người dân và đóng góp thiết thực từ phía doanh nghiệp, Hà Nội cũng như các địa phương khác trên cả nước sẽ ngày càng xanh, sạch hơn, góp phần đưa Việt Nam sớm hoàn thành mục tiêu Net Zero đã cam kết với thế giới”.

![Ông Lê Khắc Hiệp, Phó Chủ tịch Tập đoàn Vingroup phát biểu tại lễ ký kết hợp tác.](https://cdn.xanhsm.com/2025/07/057763cf-a1-1024x683.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> # VINFAST
> ## LỄ KÝ KẾT HỢP TÁC
> ### GIỮA VINFAST VÀ CÁC ĐỐI TÁC NGÂN HÀNG
> Hợp lực kiến tạo
> Kỷ nguyên
> Xanh
> Hà Nội, 4.07.2025
> ## VINFAST

Ông Lê Khắc Hiệp, Phó Chủ tịch Tập đoàn Vingroup phát biểu tại lễ ký kết hợp tác.

Để tạo điều kiện thuận lợi cho người dân dễ dàng chuyển đổi sang xe điện, bên cạnh các giải pháp tài chính hấp dẫn, kể từ ngày 29/07/2025, VinFast và các đối tác sẽ tổ chức chuỗi sự kiện“Ngày hội xanh: Thu xe xăng – Lên đời xe xanh”tại Hà Nội, TP.HCM và các tỉnh thành trên cả nước. Khách hàng đang sử dụng ô tô, xe máy động cơ đốt trong có thể mang xe đến sự kiện để định giá và bán lại với thủ tục nhanh gọn, minh bạch, đồng thời chuyển đổi sang xe điện để được hưởng các ưu đãi hấp dẫn. Chương trình cũng được triển khai đồng thời tại các nhà phân phối chính hãng VinFast trên toàn quốc./.
