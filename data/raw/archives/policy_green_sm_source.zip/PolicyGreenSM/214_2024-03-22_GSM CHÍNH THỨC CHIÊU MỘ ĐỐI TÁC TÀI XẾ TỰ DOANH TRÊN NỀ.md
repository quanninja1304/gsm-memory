# GSM CHÍNH THỨC CHIÊU MỘ ĐỐI TÁC TÀI XẾ TỰ DOANH TRÊN NỀN TẢNG GREEN SM PLATFORM

- **Ngày đăng:** 2024-03-22
- **Chuyên mục:** Báo chí, Công ty
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/gsm-chinh-thuc-chieu-mo-doi-tac-tai-xe-tu-doanh-tren-nen-tang-xanh-sm-platform](https://www.greensm.com/vn-vi/news/gsm-chinh-thuc-chieu-mo-doi-tac-tai-xe-tu-doanh-tren-nen-tang-xanh-sm-platform)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Hà Nội, ngày 22/03/2024 – Công ty Cổ phần Di chuyển Xanh và Thông minh (GSM) chính thức chiêu mộ đối tác tài xế tự doanh để cung cấp dịch vụ taxi công nghệ thuần điện trên ứng dụng Green SM, với chính sách chia sẻ doanh thu lên tới 80%. Mức chia sẻ này sẽ được duy trì trong 3 năm đầu tiên cho những đối tác vay mua xe trả góp thông qua chính sách ưu đãi lãi suất đặc biệt của GSM, qua đó đảm bảo nguồn thu nhập ổn định và sự chủ động, an tâm tối đa cho các đối tác tài xế.

Kể từ ngày hôm nay, tất cả các chủ sở hữu xe ô tô điện VinFast trên toàn quốc có thể đăng ký tự doanh trên nền tảng Green SM Platform để nhận được mức chia sẻ doanh thu lên tới 80%, mức cao nhất thị trường hiện nay. Trong quá trình hoạt động, tùy theo tình hình thực tế tại từng giai đoạn, GSM sẽ đề xuất chính sách thưởng phù hợp trên cơ sở đảm bảo lợi ích của các đối tác tài xế hài hòa với thực tế thị trường.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/03/35f889d2-anh-1-vinfast_vf-5_vinfast-blue_vung-tau_img_7347-xanh-sm-platform-1024x683.jpg)

Chủ xe điện VinFast có thể đăng ký tự doanh trên nền tảng Green SM Platform

Không chỉ hoàn toàn chủ động, linh hoạt về thời gian hoạt động, các đối tác tự doanh trên nền tảng Green SM Platform còn được toàn quyền tiếp cận và khai thác cộng đồng khách hàng đông đảo của Green SM trên toàn quốc – những người đã hình thành thói quen và nhu cầu di chuyển thường xuyên bằng xe điện.

Đặc biệt, những người tham gia gói vay mua xe điện VinFast trả góp để tự doanh trên nền tảng Green SM Platform do GSM cung cấp sẽ được hưởng đặc quyền về giá trị vay cao nhất lên đến 70% giá trị xe; thời hạn cho vay tối thiểu 5 năm, dài nhất lên đến 8 năm; lãi suất ưu đãi hấp dẫn chỉ 5% trong 2 năm đầu tiên. Đồng thời, GSM cam kết duy trì mức chia sẻ doanh thu 80% (nếu đạt chỉ tiêu kinh doanh tối thiểu) trong suốt 3 năm đầu tiên.

Lãi suất cố định trong 2 năm đầu giúp chủ xe không bị ảnh hưởng bởi biến động của thị trường, qua đó có thể chủ động phương án tài chính và nguồn thu nhập cá nhân. Chỉ cần thanh toán trước 30% giá trị xe, đối tác tài xế đã có thể sở hữu ngay một chiếc ô tô điện thông minh VinFast và bắt đầu tạo ra nguồn thu nhập để thanh toán gốc vay và lãi hàng tháng.

Ông Nguyễn Văn Thanh – Tổng giám đốc Công ty GSM toàn cầu cho biết:“Với nền tảng Green SM Platform, GSM kỳ vọng thu hút thêm hàng triệu đối tác tài xế, là những cánh tay nối dài cho sứ mệnh kiến tạo giải pháp giao thông xanh, tiện lợi và bền vững, đẩy nhanh công cuộc chuyển đổi xanh của Việt Nam và hướng tới mở rộng ra toàn cầu. Đây cũng là cơ hội để nhiều người có thể tiếp cận và sử dụng các phương tiện thuần điện văn minh, thân thiện với môi trường.”

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/03/b8da8bbe-anh-2-dji_0497.00_03_15_18.still013-1024x540.jpg)

GSM chiêu mộ đối tác tài xế tham gia tiên phong chuyển đổi xanh

Green SM Platform là nền tảng công nghệ đa dịch vụ thuần điện đầu tiên tại Việt Nam do GSM phát triển, nhằm kết nối các chủ xe VinFast có nhu cầu cung cấp dịch vụ vận tải với khách hàng, qua đó lan tỏa xu hướng sống xanh trong cộng đồng và tạo ra nguồn thu nhập hấp dẫn cho các chủ xe điện VinFast. Dự kiến từ ngày 28/03/2024, đối tác tài xế có thể bắt đầu đón khách hàng đặt xe điện qua ứng dụng Green SM.

| GSM có thể hỗ trợ đối tác tài xế đào tạo bằng lái xe hạng B2, thực hiện đăng kiểm đúng tiêu chuẩn (có kinh doanh và có lắp thiết bị giám sát hành trình), cấp chứng nhận đăng ký xe và biển số xe phục vụ kinh doanh.Các đối tác tài xế đăng ký thành công, hoàn thành chương trình đào tạo về kỹ năng, nghiệp vụ và các tiêu chuẩn dịch vụ của Green SM, đảm bảo đồng bộ về chất lượng dịch vụ “5 sao” giữa Green SM Taxi và Green SM Platform, dự kiến bắt đầu tự doanh từ ngày 28/03/2024.Đối tác có nhu cầu tự doanh trên nền tảng Green SM Platform có thể đăng ký ngay từ hôm nay và tìm hiểu thêm về các gói hỗ trợ bằng cách truy cập:https://www.xanhsm.com/platform/. |
| --- |
