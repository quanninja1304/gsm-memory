# Cập nhật về Quy định luật giao thông 2025 và mức phạt mới

- **Ngày đăng:** 2025-01-07
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-quy-dinh-giao-thong-moi](https://www.greensm.com/vn-vi/news/cap-nhat-quy-dinh-giao-thong-moi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Từ ngày01/01/2025, Luật Trật tự An toàn Giao thông Đường bộ 2024vàLuật Đường bộ 2024chính thức có những điều chỉnh mới so với Luật Giao thông đường bộ 2008 cùng vớiNghị định 168/2024/NĐ-CPquy địnhmức phạt mớisẽ được áp dụng. Các Bác tài hãy cùng cập nhật thông tin để đảm bảo tuân thủ  đúng Pháp luật nhé.

💡Mức phạt tăng cao đối với các lỗi vi phạm:

1. Không chấp hành đèn tín hiệu giao thông, đi ngược chiều.

2. Sử dụng điện thoại khi lái xe.

3. Vượt quá tốc độ quy định.

4. Điều khiển xe khi sử dụng chất kích thích.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/e5350d8e-202512_nghidinh168-01-1024x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Các hành vi vi phạm giao thông sẽ tăng mức xử phạt theo Nghị định 168
> 
> **Có hiệu lực từ 01/01/2025**
> 
> **XANH SM**
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/6388de77-202512_nghidinh168-02-2-1024x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Đối với xe ô tô
> 
> | Hành vi | Mức phạt tiền theo Nghị định 100, 123 (VNĐ) | Mức phạt tiền theo Nghị định 168 (VNĐ) |
> |---|---|---|
> | Không chấp hành hiệu lệnh của đèn tín hiệu | | 18.000.000 - 20.000.000 |
> | Đi ngược chiều của đường một chiều, đi ngược chiều trên đường có biển "Cấm đi ngược chiều" | 4.000.000 - 6.000.000 | 18.000.000 - 20.000.000 |
> | Không giảm tốc độ (hoặc dừng lại) và nhường đường khi điều khiển xe chạy từ trong ngõ, đường nhánh ra đường chính; Không nhường đường cho xe đi trên đường ưu tiên, đường chính từ bất kỳ hướng nào tới tại nơi đường giao nhau | 800.000 - 1.000.000 | 4.000.000 - 6.000.000 |
> | Chuyển hướng không nhường quyền đi trước cho người đi bộ, xe lăn tại nơi có vạch kẻ đường dành cho người đi bộ | 300.000 - 400.000 | |
> | Mở cửa xe, để cửa xe mở không bảo đảm an toàn gây tai nạn giao thông | 400.000 - 600.000 | 20.000.000 - 22.000.000 |
> | Vận chuyển hàng hóa là phương tiện vận tải, máy móc, thiết bị kỹ thuật, hàng dạng trụ không chằng buộc hoặc chằng buộc không theo quy định | 600.000 - 800.000 | 18.000.000 - 22.000.000 |
> | Không chấp hành hiệu lệnh chỉ dẫn của người điều khiển giao thông | | 18.000.000 - 20.000.000 |
> | Cản trở, không chấp hành yêu cầu kiểm tra, kiểm soát của người thực thi công vụ | 4.000.000 - 6.000.000 | 35.000.000 - 37.000.000 |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/b5384ce9-202512_nghidinh168-03-2-1024x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Đối với xe ô tô
> 
> | Hành vi | Mức phạt tiền theo Nghị định 100, 123 (VNĐ) | Mức phạt tiền theo nghị định 168 (VNĐ) |
> |---|---|---|
> | Lạng lách, đánh võng, chạy quá tốc độ đuổi nhau trên đường bộ, dùng chân điều khiển vô lăng xe khi xe đang chạy trên đường | 10.000.000-12.000.000 | 40.000.000-50.000.000 |
> | Vi phạm nồng độ cồn vượt quá 50 miligam đến 80 miligam/100 mililit máu hoặc vượt quá 0,25 miligam đến 0,4 miligam/1 lít khí thở | 16.000.000-18.000.000 | 18.000.000-20.000.000 |
> | Điều khiển xe chạy quá tốc độ trên 35km/h | 10.000.000-12.000.000 | 12.000.000-14.000.000 |
> | Điều khiển xe ô tô gắn biển số không rõ chữ, số (không gắn đủ biển số, che dán biển số, biển số bị bẻ cong, che lấp, làm thay đổi chữ, số, màu sắc...) hoặc gắn biển số không đúng với chứng nhận đăng ký xe hoặc gắn biển số không do cơ quan có thẩm quyền cấp | 4.000.000-6.000.000 | 20.000.000-26.000.000 |
> | Dùng tay cầm và sử dụng điện thoại hoặc các thiết bị điện tử khác khi điều khiển phương tiện tham gia giao thông đang di chuyển trên đường bộ | 2.000.000-3.000.000 | 4.000.000-6.000.000 |
> | Điều khiển xe chở người bốn bánh có gắn động cơ, xe chở hàng bốn bánh có gắn động cơ đi vào đường cao tốc | | 12.000.000-14.000.000 |
> | Dừng xe, đỗ xe trên đường cao tốc không đúng nơi quy định | 10.000.000-12.000.000 | |
> | Điều khiển xe đi ngược chiều trên đường cao tốc | 16.000.000-18.000.000 | |
> | Lùi xe trên đường cao tốc | | 30.000.000-40.000.000 |
> | Quay đầu xe trên đường cao tốc | 10.000.000-12.000.000 | |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/1a04bf57-202512_nghidinh168-04-1-1024x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Đối với xe mô tô
> 
> | Hành vi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Mức phạt tiền theo Nghị định 100, 123 (VNĐ) | Mức phạt tiền theo nghị định 168 (VNĐ) |
> | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------- | :------------------------------------ |
> | Không chấp hành hiệu lệnh của đèn tín hiệu giao thông                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | 800.000 - 1.000.000                       | 4.000.000 - 6.000.000                 |
> | Điều khiển xe trên đường mà trong máu hoặc hơi thở có nồng độ cồn vượt quá 50 miligam đến 80 miligam/100 mililit máu hoặc vượt quá 0,25 miligam đến 0,4 miligam/1 lít khí thở                                                                                                                                                                                                                                                                                                                                                                                                                                                      | 4.000.000 - 5.000.000                     | 6.000.000 - 8.000.000                 |
> | Điều khiển xe trên đường mà trong máu hoặc hơi thở có nồng độ cồn vượt quá 80 miligam/100 mililit máu hoặc vượt quá 0,4 miligam/1 lít khí thở                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | 6.000.000 - 8.000.000                     | 8.000.000 - 10.000.000                |
> | Điều khiển xe chạy quá tốc độ quy định trên 20 km/h                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | 4.000.000 - 5.000.000                     | 6.000.000 - 8.000.000                 |
> | Điều khiển xe mô tô đi vào đường cao tốc                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | 2.000.000 - 3.000.000                     | 4.000.000 - 6.000.000                 |
> | Đi ngược chiều của đường một chiều                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | 1.000.000 - 2.000.000                     |                                       |
> | Điều khiển xe lạng lách, đánh võng                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |                                           |                                       |
> | Gây tai nạn giao thông không dừng ngay phương tiện, không giữ nguyên hiện trường, không trợ giúp người bị nạn, không ở lại hiện trường hoặc không đến trình báo ngay với cơ quan công an, Ủy ban nhân dân nơi gần nhất                                                                                                                                                                                                                                                                                                                                                                                                        | 6.000.000 - 8.000.000                     | 8.000.000 - 10.000.000                |

🛎LƯU Ý DÀNH CHO BÁC TÀI:

1.CẦNtìm hiểu và nắm rõ các quy định mới vềĐIỂM MỚI QUY ĐỊNH VỀ VẬN TẢI ĐƯỜNG BỘđể tránh vi phạm không đáng có.

2.LUÔNtuân thủ nghiêm luật giao thông.

3. ĐẢM BẢOan toàn cho bản thân và khách hàng.

🎯 Hãy cùng Green SM chung tay xây dựng văn hóa giao thông an toàn và văn minh nhé!

Trân trọng,Đội ngũ GSM.

——————————————————

ĐIỂM MỚI QUY ĐỊNH VỀ VẬN TẢI ĐƯỜNG BỘ

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/1173bef7-save-1-1024x622.png)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là nội dung văn bản, số liệu, tiêu đề và bảng biểu được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> | STT | Điểm mới | Luật Giao thông đường bộ 2008 | Luật trật tự ATGT đường bộ 2024 và Luật Đường bộ 2024 | Đánh giá |
> |---|---|---|---|---|
> | 1 | Thay đổi hạng bằng lái ô tô dưới 9 chỗ chở người | Quy định 2 hạng bằng lái B1, B2 | **Thay đổi, quy định:** - Chỉ còn hạng B cấp chung cho người lái xe ô tô chở người đến 08 chỗ (không kể chỗ của người lái xe); - Hạng B1 cấp cho người lái xe mô tô ba bánh và các loại xe quy định cho giấy phép lái xe hạng A1. **Cấp đổi:** - B1 số tự động -> B với hạn chế chỉ điều khiển xe tự động; - B1, B2 -> B hoặc C1. **Chưa cấp đổi:** - B1 số tự động cấp cho người ko hành nghề lái xe tiếp tục điều khiển xe ô tô số tự động đến 8 chỗ; - B1 cấp cho người ko hành nghề lái xe lái xe tiếp tục điều khiển ô tô chở đến 8 chỗ; - B2 cấp cho người hành nghề lái xe tiếp tục lái xe ô tô chở người đến 8 chỗ. | **Lưu ý:** với các tiêu chí tuyển dụng/thu hút tài xế từ 1/1/2025 |
> | 2 | Thay đổi hạng bằng lái xe máy (xe mô tô 2 bánh) | Quy định hạng A1 cấp cho người lái xe mô tô hai bánh có dung tích xi-lanh từ 50 cm3 đến dưới 175 cm3; | **Thay đổi, quy định:** - Hạng A1 cấp cho người lái xe mô tô hai bánh có dung tích xi-lanh đến 125 cm3 hoặc có công suất động cơ điện đến 11 kW; - Hạng A cấp cho người lái xe mô tô 2 bánh có dung tích xi-lanh trên 125 cm3 hoặc động cơ điện trên 11kW và các loại xe hạng A1. **Cấp đổi:** - A1 -> A với hạn chế chỉ điều khiển xe mô tô 2 bánh dung tích xi lanh đến dưới 175cm3 hoặc công suất động cơ điện dưới 14kW; - A2 -> A - A3 -> B1 **Chưa cấp đổi:** | **Lưu ý:** - Với các tiêu chí tuyển dụng/thu hút tài xế từ 1/1/2025; - Rà soát kiểm tra công suất của các xe máy điện đã giao cho TX (mốc trên dưới 11kW) với hạng bằng lái mà TX đã được cấp. |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/ddb1754e-save-2-1024x621.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> | | | | |
> |---|---|---|---|
> | | | | - A1 tiếp tục điều khiển xe mô tô hai bánh có dung tích xi-lanh từ 50 cm³ đến dưới 175 cm³ hoặc có công suất động cơ điện từ 04 kW đến dưới 14 kW; |
> | | | | - A2 tiếp tục điều khiển xe mô tô hai bánh có dung tích xi-lanh từ 175 cm³ trở lên hoặc có công suất động cơ điện từ 14 kW trở lên và các loại xe thuộc hạng A1 trên. |
> | 3 | Điểm của GP lái xe | Không có | - Mỗi GPLX có 12 điểm, số điểm bị trừ mỗi lần vi phạm tùy thuộc vào tính chất và mức độ vi phạm (chi tiết tại Nghị định 168/2024/NĐ-CP) <br> - Giấy phép lái xe chưa bị trừ hết điểm và không bị trừ điểm trong thời hạn 12 tháng từ ngày bị trừ điểm gần nhất thì được phục hồi đủ 12 điểm. <br> - Trường hợp giấy phép lái xe bị trừ hết điểm thì người có giấy phép lái xe không được điều khiển phương tiện tham gia giao thông đường bộ theo giấy phép lái xe đó. <br> - Hồi phục điểm: <br> • Sau ít nhất là 06 tháng kể từ ngày bị trừ hết điểm, người có giấy phép lái xe được tham gia kiểm tra nội dung kiến thức pháp luật về trật tự, an toàn giao thông đường bộ theo quy định do lực lượng Cảnh sát giao thông tổ chức, có kết quả đạt yêu cầu thì được phục hồi đủ 12 điểm. <br> • Xe máy kiểm tra lý thuyết. <br> • Xe ô tô phải kiểm tra lý thuyết và mô phỏng. | Lưu ý: <br> - Truyền thông cho TX để nâng cao trách nhiệm tuân thủ pháp luật; <br> - Theo dõi điểm GPLX của TX để đảm bảo ko giao xe cho TX đã bị trừ hết điểm (ko đủ điều kiện điều khiển phương tiện) |
> | 4 | Bổ sung quy định về chở trẻ em ở cùng hàng ghế lái | | Khi chở trẻ em dưới 10 tuổi và chiều cao dưới 1,35 mét trên xe ô tô không được cho trẻ em ngồi cùng hàng ghế với người lái xe, trừ loại xe ô tô chỉ có một hàng ghế; người lái xe phải sử dụng, hướng dẫn sử dụng thiết bị an toàn phù hợp cho trẻ em <br> Hiệu lực từ 1/1/2026 | Lưu ý truyền thông cho TX |
> | 5 | Sửa đổi quy định về tín hiệu đèn giao thông | a) Tín hiệu xanh là được đi; <br> b) Tín hiệu đỏ là cấm đi; <br> c) Tín hiệu vàng là phải dừng lại trước vạch dừng, trừ trường hợp | Tín hiệu đèn màu xanh là được đi; trường hợp người đi bộ, xe lăn của người khuyết tật đang đi ở lòng đường, người điều khiển phương tiện tham gia giao thông đường bộ phải giảm tốc độ hoặc dừng lại nhường đường cho người đi bộ, xe lăn của người khuyết tật qua đường; | Truyền thông cho TX |
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/9494f1ba-save-3-1024x614.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> | | | | |
> |---|---|---|---|
> | | đã đi quá vạch dừng thì được đi tiếp; trong trường hợp tín hiệu vàng nhấp nháy là được đi nhưng phải giảm tốc độ, chú ý quan sát, nhường đường cho người đi bộ qua đường. | - Tín hiệu đèn màu vàng phải dừng lại trước vạch dừng; trường hợp đang đi trên vạch dừng hoặc đã đi qua vạch dừng mà tín hiệu đèn màu vàng thì được đi tiếp; trường hợp tín hiệu đèn màu vàng nhấp nháy, người điều khiển phương tiện tham gia giao thông đường bộ được đi nhưng phải quan sát, giảm tốc độ hoặc dừng lại nhường đường cho người đi bộ, xe lăn của người khuyết tật qua đường hoặc các phương tiện khác; - Tín hiệu đèn màu đỏ là cấm đi. | |
> | 6 | Thay đổi thời gian bắt buộc bật đèn xe | Lái xe bật đèn chiếu sáng từ 19 giờ ngày hôm trước đến 05 giờ ngày hôm sau, khi sương mù, thời tiết xấu hạn chế tầm nhìn | Người lái xe phải bật đèn chiếu sáng phía trước trong thời gian từ 18 giờ ngày hôm trước đến 06 giờ ngày hôm sau hoặc khi có sương mù, khói, bụi, trời mưa, thời tiết xấu làm hạn chế tầm nhìn. | Truyền thông cho TX để lưu ý tránh vi phạm do quy định mở rộng phổ thời gian bật đèn từ 1/1/2025 |
> | 7 | Quy định cụ thể giá kinh doanh DV vận tải taxi | Giá cước được tính: - Theo đồng hồ tính tiền trên cơ sở bảng giá kê khai; hoặc - Theo phần mềm tính tiền trên cơ sở bản giá kê khai và bản đồ số. | Tiền cước chuyến đi do hành khách lựa chọn theo một trong các phương thức sau đây: a) Tiền cước được tính thông qua đồng hồ tính tiền; b) Tiền cước được tính qua phần mềm tính tiền có kết nối trực tiếp với hành khách thông qua phương tiện điện tử; c) Tiền cước theo thoả thuận với đơn vị kinh doanh vận tải. | Quy định theo hướng mở rộng phương thức tính giá cước taxi, đó là theo thỏa thuận, tuy nhiên vẫn cần thực hiện kê khai giá tùy theo quyết định của mỗi địa phương. Cách thức kê khai, PC sẽ phối hợp cùng KD&VH. |
> | 8 | Quy định cụ thể về thời gian làm việc của người lái xe ô tô | Thời gian làm việc không được quá 10 giờ/ngày và ko được lái xe liên tục quá 04 giờ. | Thời gian lái xe không quá 10 giờ/ngày và không quá 48 giờ/tuần Lái xe liên tục không quá 04 giờ và Đảm bảo các quy định liên quan của BLLĐ | Điều chỉnh các quy định/chính sách về thời gian làm việc của TXTX (nếu có) Truyền thông với TX để tuân thủ |
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/a820da4d-save-4-1024x629.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> | | | | |
> |---|---|---|---|
> | **9** | **Thời hạn của GPLX** | - A1, A2, A3 ko thời hạn;<br/>- B1 có thời hạn đến khi người LX đủ 55 tuổi với nữ và đủ 60 tuổi với nam;<br/>- A4, B2 thời hạn 10 năm | - A1, A, B1 ko thời hạn;<br/>- B và C1 thời hạn 10 năm |
> | **10** | **Bổ sung trường hợp xe mô tô 2 bánh (xe máy) được chở 03 người** | | Bổ sung thêm trường hợp chở 03 người nếu chở người già yếu, người khuyết tật | Lưu ý cho VHB |
> | **11** | **Bổ sung quy định xe đưa rước học sinh** | | Xe chở trẻ em mầm non, học sinh phải:<br/>- Có thiết bị ghi nhận hình ảnh trẻ em mầm non, học sinh và thiết bị có chức năng cảnh báo, chống bỏ quên trẻ em trên xe, niên hạn sử dụng ko quá 20 năm;<br/>- Có màu sơn theo quy định của Chính phủ (sử dụng màu sơn vàng đậm phù bên ngoài thân xe trước và hai cạnh bên xe phía trên cửa sổ có biển báo đậu hiệu nhận biết là xe chuyên dùng chở trẻ em<br/>- Phải có dây đai an toàn phù hợp lứa tuổi hoặc sử dụng ghế ngồi phù hợp. | Lưu ý nếu triển khai dịch vụ xe Hợp đồng đưa đón học sinh |
> | **12** | **Xe mô tô, xe gắn máy phải kiểm định khí thải** | | - Xe có thời gian tính từ năm sản xuất đến 05 năm: không phải nộp hồ sơ và không phải mang xe đến cơ sở đăng kiểm để kiểm định khí thải.<br/>- Xe có thời gian tính từ năm sản xuất trên 05 năm thì chủ xe phải mang xe đến cơ sở đăng kiểm để kiểm định khí thải.<br/>Trong đó,<br/>- Xe trên 5 năm đến 12 năm tuổi phải kiểm định 2 năm một lần;<br/>- Xe trên 12 năm tuổi phải kiểm định hàng năm. | |
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/0a6a2493-save-5-1024x332.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> | | | (Việc này thực hiện theo lộ trình tại các văn bản sẽ được ban hành trong thời gian tới). | |
> |---|---|---|---|
> | 13 | Thay đổi nhiều mức phạt vi phạm giao thông (bao gồm cả trừ điểm GPLX) | Chi tiết Nghị định 168/2024/NĐ-CP<br><br>Nghị định<br>168-2024-xử phạt-vi- | |
> | 14 | Cá nhân kinh doanh vận tải | Mặc dù Luật Đường bộ 2024 đề cập tới cá nhân kinh doanh vận tải nhưng điều kiện để kinh doanh vận tải là Giấy phép vận tải chỉ cấp cho doanh nghiệp, HTX, hộ gia đình nên cá nhân muốn kinh doanh vận tải cần tối thiểu lập hộ kinh doanh và xin GPVT.<br><br>Cá nhân muốn hợp tác kinh doanh vận tải với đơn vị vận tải cần đăng ký kinh doanh và xin GPVT.<br><br>(Đây cũng là ý kiến của Vụ Vận tải) | |
> ```
