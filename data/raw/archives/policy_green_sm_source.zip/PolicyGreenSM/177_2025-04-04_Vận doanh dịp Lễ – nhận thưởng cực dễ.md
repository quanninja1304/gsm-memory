# Vận doanh dịp Lễ – nhận thưởng cực dễ

- **Ngày đăng:** 2025-04-04
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-gio-to](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-gio-to)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm chào mừngGiỗ tổ Hùng Vương, đồng thời tạo cơ hội giúp Bác tàigia tăng thu nhập, Green SM triển khai chính sáchthưởng hấp dẫn tại các bến xevàsân bay Tân Sơn Nhất!

📌 Chi tiết mức thưởng và điều kiện áp dụng như sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/4acf616f-20250404_facebook_chinh-sach-thuong-gio-to-856x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> 
> # Chính sách thưởng
> ## Vào dịp Giỗ Tổ Hùng Vương
> 
> **Đối tượng áp dụng:** Tài xế Taxi, Tài xế Car Platform, Tài xế Đối tác Green Car tại Hà Nội, Đà Nẵng và TP.HCM
> 
> ## Nội dung chính sách
> 
> | Hạng mục            | Chính sách tại các bến xe                                                                                                                                                                                                                                   | Chính sách tại sân bay Tân Sơn Nhất                                                                                                                                                                                                                                                                                         |
> | :------------------ | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Thời gian áp dụng** | Ngày 7/4                                                                                                                                                                                                                                                   | Từ 5/4 - 7/4                                                                                                                                                                                                                                                                                                                 |
> | **Mức thưởng**      | Thưởng 15.000 VNĐ/cuốc xe hoàn thành từ 2h - 6h sáng có điểm đón tại các bến xe                                                                                                                                                                             | Thưởng 25.000 VNĐ/cuốc xe hoàn thành có điểm đón tại sân bay                                                                                                                                                                                                                                                                 |
> | **Điều kiện thưởng** | Áp dụng tại các bến xe: 1/ Hà Nội: Giáp Bát, Nước Ngầm, Mỹ Đình, Gia Lâm 2/ Đà Nẵng: Bến xe Trung tâm Đà Nẵng 3/ TP.HCM: An Sương, Miền Đông, Miền Tây, Bến Tàu | Tỷ lệ nhận và hoàn thành chuyến trung bình/ngày đạt ≥ 85% (tính trên tổng các cuốc xe có điểm đón tại sân bay Tân Sơn Nhất) |
> 
> **Lưu ý:** Tiền thưởng sẽ được cộng trực tiếp vào Ví Tài xế vào Thứ 5 của tuần kế tiếp.
> 
> BÊN XE SÂN BAY

Mọi thắc mắc, Bác tài vui lòng liên hệ Đội xe để được hỗ trợ kịp thời.Mến chúc các Bác tài vận doanh hiệu quả và tận hưởng trọn vẹn ưu đãi từ chính sách!

Trân trọng,Đội ngũ Green SM.
