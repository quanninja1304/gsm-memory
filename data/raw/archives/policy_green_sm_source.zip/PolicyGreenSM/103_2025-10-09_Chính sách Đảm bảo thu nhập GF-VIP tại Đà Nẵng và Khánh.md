# Chính sách Đảm bảo thu nhập GF-VIP tại Đà Nẵng và Khánh Hòa

- **Ngày đăng:** 2025-10-09
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-dam-bao-thu-nhap-gf-vip-da-nang-khanh-hoa](https://www.greensm.com/vn-vi/news/chinh-sach-dam-bao-thu-nhap-gf-vip-da-nang-khanh-hoa)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm đảm bảo thu nhập ổn định và ghi nhận nỗ lực của các Bác tài đang vận doanh dịch vụ GF-VIP, Công ty triển khaiChính sách Đảm bảo thu nhập tối thiểu 700.000đ/ngày. Chính sách này giúp Bác tài yên tâm vận doanh, duy trì hiệu suất làm việc và nâng cao chất lượng dịch vụ.

Chi tiết chính sách như sau:

![Chính sách Đảm bảo thu nhập GF VIP tại Đà Nẵng và Khánh Hòa](https://cdn.xanhsm.com/2025/10/98e02a15-251007_-dn1kh12-1-784x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> ## Chính sách Đảm bảo thu nhập dành cho Tài xế GF VIP
> 
> Áp dụng tại Depot/HUB Đà Nẵng 1; Khánh Hòa 1, 2
> 
> ### Thời gian áp dụng
> Từ ngày 26/08 đến hết ngày 25/12/2025
> 
> ### Mức đảm bảo thu nhập
> *   **Bác tài sẽ được đảm bảo thu nhập tối thiểu 700.000đ/ngày**
> *   **Chính sách áp dụng tối đa 26 ngày/tháng; từ ngày thứ 27 trở đi, thu nhập tính theo chính sách lương, thưởng hiện hành.**
> 
> ### Lưu ý
> Mức thưởng trên đã bao gồm toàn bộ các khoản: Lương cơ bản, Thưởng Trách nhiệm và Thưởng doanh số theo ngày. Nghĩa là:
> *   Nếu thu nhập thực tế (bao gồm các khoản thưởng trên) chưa đạt 700.000đ/ngày, Công ty sẽ hỗ trợ phần chênh lệch để đạt đủ 700.000đ/ngày.
> *   Nếu thu nhập thực tế cao hơn 700.000đ/ngày, Bác tài sẽ nhận theo đúng số thực tế đạt được (không áp dụng thêm Chính sách Đảm bảo thu nhập).
> 
> ### Điều kiện áp dụng
> *   Hoàn thành tối thiểu 1 cuốc/ngày
> *   Tỷ lệ nhận và hoàn thành chuyến trung bình mỗi ngày ≥ 85%

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác tài vận doanh an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
