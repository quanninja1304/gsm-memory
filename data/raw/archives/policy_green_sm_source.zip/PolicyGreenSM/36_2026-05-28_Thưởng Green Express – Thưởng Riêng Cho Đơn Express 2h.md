# Thưởng Green Express – Thưởng Riêng Cho Đơn Express 2h

- **Ngày đăng:** 2026-05-28
- **Chuyên mục:** Cẩm nang tài xế, Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-green-express-thuong-rieng-cho-don-express-2h](https://www.greensm.com/vn-vi/news/thuong-green-express-thuong-rieng-cho-don-express-2h)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh ơi, “đơn Green Express 2H” đang áp dụng chính sách thưởng!

Green SM Expresstriển khai chương trình thưởng dành riêng cho các chuyến Green Express 2H không ghép được đơn – cơ hội để Bác Tài Xanh gia tăng thu nhập và tối ưu hiệu quả vận doanh mỗi ngày.

- Thời gian áp dụng:từ 28/5 – 21/6/2026

- Dịch vụ áp dụng:Green Express 2H không ghép được đơn

- Đối tượng áp dụng:Bác Tài Xanh Bike, Bike Platform, Bike Thuê xe sở hữu (RTO) tại Hà Nội và TPHCM(cũ)

![Thưởng Green Express - Thưởng Riêng Cho Đơn Express 2h](https://cdn.xanhsm.com/2026/05/290a78b4-anh-dinh-kem-trong-bai-chuong-trinh-thuong-don-express-1024x643.png)

> **[Nội dung trích xuất từ ảnh]:**
> # ĐƠN EXPRESS 2H CÓ THÊM THƯỞNG
> # CHẠY CÀNG NHIỀU – THU NHẬP CÀNG TĂNG
> 
> **GREEN SM**
> 
> **Từ ngày 28/05 - 21/06/2026**
> 
> **Bật app canh đơn ngay hôm nay!**
> 
> Bác Tài Xanh tại Hà Nội & TP.HCM (cũ) hoàn thành đơn Green Express 2H sẽ nhận thêm thưởng theo quãng đường:
> 
> *   **8KM ĐẦU:** Thưởng thêm 1.000₫/km
> *   **Từ km thứ 9 trở đi:** Thưởng thêm 500đ/km
> 
> **ĐẶC BIỆT**
> Bác tài có thể "THƯỞNG CHỐNG THƯỞNG" khi vừa nhận thưởng đơn Express 2H, vừa tích lũy điểm thưởng theo khung giờ áp dụng.

Chi tiết chương trình thưởng:

- 8km đầu tiên:+1.000đ/km

- Từ Km thứ 9 trở đi:+500đ/km

Ví dụ:Với đơn hàng Green Express 2H không ghép được đơn dài 12km

→ 8km đầu nhận: 8×1000đ = 8.000đ→ 4km tiếp theo nhận: 4×500đ = 2.000đ

Tổng thưởng thêm: 10.000đ/chuyến

Nhanh tay bật app để không bỏ lỡ chương trình thưởng nóng từGreen SM Express!

Trân trọng,

Đội ngũ Green SM Express
