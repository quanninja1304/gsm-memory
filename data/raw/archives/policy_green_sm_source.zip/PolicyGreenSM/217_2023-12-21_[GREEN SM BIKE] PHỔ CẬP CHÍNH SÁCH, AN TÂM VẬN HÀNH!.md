# [GREEN SM BIKE] PHỔ CẬP CHÍNH SÁCH, AN TÂM VẬN HÀNH!

- **Ngày đăng:** 2023-12-21
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/xanh-sm-bike-pho-cap-chinh-sach-an-tam-van-hanh](https://www.greensm.com/vn-vi/news/xanh-sm-bike-pho-cap-chinh-sach-an-tam-van-hanh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Hiện tại Green SM Bike có những chương trình thưởng nào? Điều kiện nhận thưởng là gì?

Thấu hiểu các Quý Đối tác Tài xế, đặc biệt là những Quý Đối tác mới – sẽ có nhiều vấn đề băn khoăn về các chính sách/cách tính thưởng, Green SM Bike gửi tới Quý Đối tác đầy đủ thông tin các chương trình thưởng hiện nay như sau:

- Thưởng đảm bảo thu nhập.

- Thưởng vượt mốc chuyến/ngày.

- Thưởng điểm tuần

Chi tiết các chính sách thưởng, Quý Đối tác vui lòng tham khảo hình ảnh bên dưới:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/12/28d13423-20122023_chinh-sach_1-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP
> 
> Tổng thu nhập Gộp = Chia sẻ doanh số cơ bản (1) + Thưởng đảm bảo thu nhập (2) + Thưởng vượt mốc chuyến/ngày (3) + Thưởng điểm tuần (4)
> 
> ## (1) CHIA SẺ DOANH SỐ CƠ BẢN
> 
> Chia sẻ doanh số cơ bản = 73% x Doanh số\*
> 
> (\*): Doanh số bao gồm cả các phí yêu cầu đặc biệt của dịch vụ Xanh Express (giao tận tay, phí giao hàng cồng kềnh...)

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/12/509b3a84-20122023_chinh-sach_2-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP
> 
> ## (2) THƯỞNG ĐẢM BẢO THU NHẬP
> 
> Ví dụ:
> * Đối tác Tài xế Xanh Bike 5h trực tuyến 6 tiếng, hoàn thành 05 chuyến, tổng doanh số thực hiện được là 250,000 VNĐ.
> * Tài xế đạt điều kiện nhận chuyến và hoàn thành chuyến 90%.
> ✓ Chia sẻ doanh cơ bản = 73% x 250,000 = 182,500 VNĐ.
> ✓ Thưởng đảm bảo thu nhập = 200,000 – 182,500 = 17,500 VNĐ.
> 
> | | Đại sứ Xanh Bike 5h | Đại sứ Xanh Bike 8h | Đại sứ Xanh Bike 10h |
> |---|---|---|---|
> | Mức thu nhập đảm bảo (VNĐ/ngày) | 200.000 VNĐ | 320.000 VNĐ | 400.000 VNĐ |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/12/7de10908-20122023_chinh-sach_3-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THU NHẬP
> 
> ## (3) THƯỞNG VƯỢT MỐC CHUYẾN/NGÀY
> 
> **Ví dụ:**
> * Đối tác Tài xế Xanh Bike 8h hoàn thành 17 chuyến.
> * Thưởng vượt mốc Đối tác Tài xế nhận được = [(16 - 12 + 1) x 4,000] + (1 x 6,000) = 26,000 VNĐ.
> 
> | Các mốc | Đại sứ Xanh Bike 5h | Đại sứ Xanh Bike 8h & 10h |
> |---|---|---|
> | **Số chuyến*** | **Mức thưởng/chuyến vượt (VNĐ)** | **Số chuyến** | **Mức thưởng/chuyến vượt (VNĐ)** |
> | **Mốc 1** | Từ 8 - 12 chuyến | 4.000 VNĐ | Từ 12 - 16 chuyến | 4.000 VNĐ |
> | **Mốc 2** | Trên 12 chuyến | 6.000 VNĐ | Trên 16 chuyến | 6.000 VNĐ |
> 
> (*): Số chuyến bao gồm cả chuyến dịch vụ Bike và dịch vụ Express.
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/12/bd199a76-20122023_chinh-sach_4-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP
> ## (4) THƯỞNG ĐIỂM TUẦN
> 
> | Mức   | ĐẠI SỨ XANH BIKE 5h             |                                | ĐẠI SỨ XANH BIKE 8h & 10h          |                                |
> | :---- | :----------------------------- | :----------------------------- | :-------------------------------- | :----------------------------- |
> |       | **Điểm thưởng**                | **Mức thưởng (VNĐ/tuần)**      | **Điểm thưởng**                   | **Mức thưởng (VNĐ/tuần)**      |
> | Mức 0 | Dưới 90 điểm                   | Không thưởng                   | Dưới 135 điểm                     | Không thưởng                   |
> | Mức 1 | Từ 90 điểm - 114 điểm          | 200.000 VNĐ                    | Từ 135 điểm - 164 điểm            | 500.000 VNĐ                    |
> | Mức 2 | Từ 115 điểm - 134 điểm         | 300.000 VNĐ                    | Từ 165 điểm - 194 điểm            | 600.000 VNĐ                    |
> | Mức 3 | Từ 135 điểm trở lên            | 400.000 VNĐ                    | Từ 195 điểm - 224 điểm            | 700.000 VNĐ                    |
> | Mức 4 | N/A                            | N/A                            | Từ 225 điểm trở lên               | 1,100.000 VNĐ                  |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/12/5e787675-21122023_dieu-kien-chinh-sach-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # ĐIỀU KIỆN NHẬN THƯỞNG
> 
> | TT | TIÊU CHÍ                                     | ĐẠI SỨ XANH BIKE 5H | ĐẠI SỨ XANH BIKE 8H | ĐẠI SỨ XANH BIKE 10H |
> | :-- | :------------------------------------------- | :----------------- | :----------------- | :------------------ |
> | 1  | Số giờ trực tuyến tối thiểu/ngày            | 5h                 | 8h                 | 10h                 |
> | 2  | Số giờ trực tuyến tối thiểu vào các khung giờ cao điểm/ngày | 1.5h               | 2.5h               | 3h                  |
> | 3  | Số chuyến tối thiểu/ngày                   | 5 chuyến           | 8 chuyến           | 10 chuyến           |
> | 4  | Tỷ lệ nhận chuyến                            |                    | `>= 90%`           |                     |
> | 5  | Tỷ lệ hoàn thành chuyến                     |                    | `>=90%`            |                     |
> 
> ✓ Chính sách (2) & (3): Áp dụng đồng thời 5 điều kiện trên.
> ✓ Chính sách (4): Áp dụng điều kiện 4 & 5.
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/12/6054a05a-20122023_chinh-sach_6-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CÁCH QUY ĐỔI ĐIỂM THEO KHUNG GIỜ
> 
> | Khung giờ/ngày | Dịch vụ Bike & Express (Điểm thưởng/1 chuyến xe hoàn thành) |
> | :------------- | :---------------------------------------------------------: |
> |                |                   **Thứ 2 - thứ 6**                   | **Thứ 7 - CN** |
> | 00:00–04:59    |                             1                             |       1        |
> | 05:00–08:59    |                             2                             |       1        |
> | 09:00–11:59    |                             1                             |      1,5       |
> | 12:00–15:59    |                             1                             |       1        |
> | 16:00–19:59    |                             2                             |       2        |
> | 20:00–23:59    |                             1                             |       2        |
> 
> Giờ cao điểm được xác định trong các khung giờ:
> * Từ thứ Hai đến thứ Sáu: (i) 05:00–08:59 và (ii) 16:00–19:59
> * Thứ Bảy và Chủ Nhật: (i) 09:00–11:59 và (ii) 16:00–23:59

Thời gian áp dụng: Từ ngày 01/12/2023.

Điều kiện nhận thưởng: Quý Đối tác Tài xế cần đạt đồng thời các điều kiện sau

- Số giờ trực tuyến tối thiểu/ngày;

- Số giờ trực tuyến tối thiểu vào khung giờ cao điểm/ngày;

- Số chuyến tối thiểu/ngày;

- Tỷ lệ nhận chuyến;

- Tỷ lệ hoàn thành chuyến (theo các cấp Đại sứ đăng ký).

Nếu có thêm bất kỳ vấn đề nào cần hỗ trợ, Đối tác vui lòng liên hệ kênh Tổng đài: 0247 109 6839 (ấn phím 2) nhé!Chúc Quý Đối tác Tài xế sức khỏe, hoạt động hiệu quả và tăng thu nhập tối đa cùng Green SM Bike!

Trân trọng,Đội ngũ Green SM Bike.
