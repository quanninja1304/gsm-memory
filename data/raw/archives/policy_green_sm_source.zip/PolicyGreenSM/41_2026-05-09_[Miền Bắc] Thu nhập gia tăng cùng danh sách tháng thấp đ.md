# [Miền Bắc] Thu nhập gia tăng cùng danh sách tháng thấp điểm được bổ sung mới  

- **Ngày đăng:** 2026-05-09
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/mien-bac-thu-nhap-gia-tang-cung-danh-sach-thang-thap-diem-duoc-bo-sung-moi](https://www.greensm.com/vn-vi/news/mien-bac-thu-nhap-gia-tang-cung-danh-sach-thang-thap-diem-duoc-bo-sung-moi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,Nhằm đảm bảo các Bác Tài Xanhluôn đáp ứng doanh số khoán (chỉ tiêu ngày) trong giai đoạn thấp điểmcủa năm theo “QUY ĐỊNH VỀ KHỐI LƯỢNG CÔNG VIỆC TỐI THIỂU/NGÀY”, qua đó giúp Bác Tài Xanh an tâm vận doanh và từng bước gia tăng thu nhập, Green SM chính thức cập nhật danh sách các tháng thấp điểm mới. Chi tiết cụ thể như sau:

Đối tượng áp dụng:Bác Tài Xanh Taxi đang vận doanh cùng Green SMThời gian áp dụng:Từ kỳ lương tháng 5/2026Định nghĩ về “Tháng thấp điểm”:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/05/e7a305a5-thumb-scheme-phu-luc-thang-thap-diem-1-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # DRIVER GREEN SM
> # THÁNG THẤP ĐIỂM
> Doanh số khoán (chỉ tiêu ngày) được áp dụng mức 90% so với mức khoán cơ sở
> 
> *"Tháng thấp điểm được xét theo tháng dương lịch (tính từ ngày đầu tiên tới hết ngày cuối cùng tháng dương lịch)"
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/05/67a48c22-thang-thap-diem_mien-bac-1024x424.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # DANH SÁCH THÁNG THẤP ĐIỂM
> 
> **DIỄN GIẢI**
> 
> *   **Bổ sung mới:** (ô màu xanh lá)
> *   **Hiện tại:** (ô màu xám)
> 
> | Miền    | Depot         | Tỉnh/Thành phố (Theo địa giới hành chính cũ) | Tháng thấp điểm                                                                 |
> | :------ | :------------ | :------------------------------------------- | :----------------------------------------------------------------------------- |
> |         |               |                                              | 1 \| 2 \| 3 \| 4 \| 5 \| 6 \| 7 \| 8 \| 9 \| 10 \| 11 \| 12                     |
> | Miền Bắc | Bắc Ninh 1    | Bắc Ninh                                     |      \|      \|      \|      \|      \|      \|      \|      \|      \|      \|      \|      |
> |         | Tuyên Quang 1 | Hà Giang                                     |      \|      \|      \|      \|      \|      \|      \|      \|      \|      \|      \|      |
> |         | Hải Phòng 1   | Hải Dương                                    |      \|      \|      \|      \|      \|      \|      \|      \|      \|      \|      \|      |
> |         | Phú Thọ 1     | Hòa Bình                                     |      \|      \|   X  \|      \|   X  \|   X  \|   X  \|   X  \|      \|      \|      \|      |
> |         | Hưng Yên 1    | Hưng Yên                                     |      \|      \|      \|      \|   X  \|   X  \|   X  \|   X  \|      \|      \|      \|      |
> |         | Lào Cai 1     | Lào Cai                                      |      \|      \|      \|      \|      \|   X  \|   X  \|   X  \|      \|      \|      \|      |
> |         | Quảng Ninh 1  | Quảng Ninh                                  |      \|      \|      \|      \|      \|      \|      \|      \|   X  \|   X  \|   X  \|   X  |
> |         | Hưng Yên 2    | Thái Bình                                    |      \|      \|   X  \|   X  \|   X  \|   X  \|   X  \|   X  \|      \|      \|      \|      |
> |         | Thái Nguyên 1 | Thái Nguyên                                  |      \|      \|      \|      \|      \|      \|      \|   X  \|      \|      \|      \|      |

Việc điều chỉnh trên được kỳ vọng sẽ giảm áp lực mức doanh số khoán cho Bác Tài Xanh trong giai đoạn thấp điểm, mang tới nhiều hơn cơ hội gia tăng thu nhập và đạt thưởng từ các chính sách thu nhập của Green SM.

Green SM khuyến khích Bác Tài Xanh luôn:

💙 Tăng cường vận doanh, đặc biệt trong các khung giờ cao điểm tại các khu vực có nhu cầu cao💙 Nhận và hoàn thành tất cả chuyến xe được phân bổ để đảm bảo đạt điều kiện và tối đa việc nhận thưởng từ các chương trình💙 Lan tỏa và chia sẻ thông tin chương trình thưởng tới các Bác Tài Xanh khác trong cộng đồng

Mọi thắc mắc về việc cập nhật trên, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp trong thời gian sớm nhất.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
