# Lưu ý quan trọng: Tuân thủ quy định về hình ảnh phương tiện khi vận doanh cùng Green SM

- **Ngày đăng:** 2026-09-06
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/luu-y-quan-trong-tuan-thu-quy-dinh-ve-hinh-anh-phuong-tien-khi-van-doanh-cung-green-sm](https://www.greensm.com/vn-vi/news/luu-y-quan-trong-tuan-thu-quy-dinh-ve-hinh-anh-phuong-tien-khi-van-doanh-cung-green-sm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Thời gian gần đây, Green SM ghi nhận một số trường hợp gắn, dán hoặc trưng bày trên phương tiện các vật dụng, hình ảnh có dấu hiệu nhận diện của đơn vị khác hoạt động cùng lĩnh vực khi đang cung cấp dịch vụ qua ứng dụng Green SM.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/09/504d175d-web-1-3.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> LƯU Ý QUAN TRỌNG
> Tuân thủ quy định về hình ảnh phương tiện
> khi vận doanh cùng Green SM
> 
> [Logo] GREEN SM
> [Biểu tượng điện thoại] 1555
> ✓ GREEN
> *Hình ảnh chỉ mang tính chất minh họa
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/09/e84d97b6-web-2-3-1024x753.png)

> **[Nội dung trích xuất từ ảnh]:**
> ✓ GREEN SM
> 
> Theo Điều 18 – Bộ Quy tắc ứng xử dành cho **Đối tác Tài xế Car Platform của Green SM**, cập nhật ngày 01/06/2026, quy định rõ: "Không mang bất kỳ vật dụng, thiết bị nào có thể hiện dấu hiệu nhận diện của đơn vị khác hoạt động trong cùng lĩnh vực với Green SM khi đang cung cấp dịch vụ cho Khách hàng thông qua ứng dụng Green SM."
> 
> Đây là hành vi vi phạm nghiêm trọng, làm ảnh hưởng trực tiếp đến hình ảnh thương hiệu và trải nghiệm của Khách hàng. Hành vi vi phạm trên được xử lý theo cơ chế lũy tiến như sau:
> 
> | | Vi phạm | Hình thức xử lý |
> |---|---|---|
> | X | Vi phạm lần 1 | Trừ Ví Tài xế 1.000.000 đồng |
> | XX | Vi phạm lần 2 | Trừ Ví Tài xế 3.000.000 đồng |
> | XXX | Vi phạm lần 3 | Trừ Ví Tài xế 5.000.000 đồng |
> 
> *Hình ảnh chỉ mang tính chất minh họa

Đề nghị Bác Tài Xanh nghiêm túc tuân thủ quy định về hình ảnh phương tiện khi cung cấp dịch vụ cho Khách hàng thông qua ứng dụng Green SM. Từ đó duy trì hình ảnh Bác Tài Xanh chuyên nghiệp, đồng nhất và đáng tin cậy trong mắt Khách hàng.

Chi tiết Bộ Quy tắc ứng xử dành cho Đối tác Tài xế Car Platform tại đây:Cập nhật Bộ Quy tắc Ứng xử dành cho Đối tác Tài xế Car Platform từ ngày 01/06/2026

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Green SM
