# [GREEN SM BIKE] THÔNG BÁO TỔNG DOANH THU CHỊU THUẾ & SỐ THUẾ THU NHẬP CÁ NHÂN (TNCN) PHẢI NỘP NGÂN SÁCH NHÀ NƯỚC NĂM 2024

- **Ngày đăng:** 2024-09-24
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/xanh-sm-bike-thong-bao-tong-doanh-thu-chiu-thue-va-so-thue-thu-nhap-ca-nhan-tncn-phai-nop-ngan-sach-nha-nuoc-nam-2024](https://www.greensm.com/vn-vi/news/xanh-sm-bike-thong-bao-tong-doanh-thu-chiu-thue-va-so-thue-thu-nhap-ca-nhan-tncn-phai-nop-ngan-sach-nha-nuoc-nam-2024)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

Đối tác Tài xế thân mến,

Căn cứ theo quy định của Luật Quản lý thuế, Green SM Bike xin thông báo kế hoạch hoàn thành nghĩa vụ nộp thuế thu nhập cá nhân (TNCN) vào Ngân sách Nhà nước trong năm 2024 đối với các Đối tác có doanh thu từ/trên 100 triệu đồng như sau:

1.Số tiền thuế cần nộp = Tổng doanh thu chịu thuế * thuế suấtTrong đó:

- Tổng doanh thu chịu thuế là các khoản doanh thu bao gồm: Tổng thu nhập từ cuốc xe (sau khi trừ phí sử dụng ứng dụng) và tổng tiền thưởng (thưởng tuần, thưởng đảm bảo thu nhập, thưởng vượt mốc chuyến và các chương trình thưởng khác).

- Thuế suất theo quy định: 1.5%

2. Cách thức mà Quý Đối tác hoàn thành nộp thuế TNCN:

- Thống kê doanh thu & số tiền nộp thuế: Ngày 22 hàng tháng, tổng doanh thu chịu thuế & số tiền nộp thuế TNCN của Đối tác sẽ được GỬI VÀO ĐỊA CHỈ GMAIL mà Đối tác đã đăng ký với Green SM Bike. Đối tác vui lòng kiểm tra kỹ nội dung trong gmail cá nhân của mình nhé!

- Đối với Tài xế có tổng thu nhập >100 triệu đồng tại thời điểm 31/8/2024: Công ty sẽ tiến hành trừ ví 50.000đ/ngày cho tới khi hoàn thành nghĩa vụ thuế TNCN. Phần thu nhập phát sinh từ ngày 1/9/2024 trở đi sẽ được đối soát thu nhập vào ngày 22 hàng tháng và trừ tiền thuế TNCN phát sinh thêm (01 lần/tháng) vào ngày 25 của tháng đối soát.

- Đối với Tài xế phát sinh tổng thu nhập >100 triệu đồng từ ngày 1/9/2024 trở đi: Công ty sẽ gửi đối soát thu nhập vào ngày 22 và trừ ví tài xế ngày 25 số tiền 50.000đ/ngày cho tới khi hoàn thành.

Lưu ý: Công ty sẽ cập nhật phương thức đối soát và thu thuế TNCN trên App Tài xế trong thời gian tới và sẽ thông báo tới Quý Tài xế ngay khi có bản cập nhật.

Nếu có bất kỳ thắc mắc, Đối tác vui lòng tham khảo thông tin trong bảng bên dưới hoặc liên hệ kênh Tổng đài: 0247 109 6839 để được hỗ trợ!

Trân trọng,Đội ngũ Green SM Bike.

TÌM HIỂU CÁC CÂU HỎI THƯỜNG GẶP

1. GSM thực hiện việc khấu trừ thuế của cá nhân kinh doanh theo quy định nào?

Việc khấu trừ được thực hiện theo Quy định tại điểm c, khoản 5, Điều 7 Nghị định 126/2020/NĐ-CP ngày 19/10/2020 quy định chi tiết một số điều của Luật Quản lý thuế, có hiệu lực thi hành từ ngày 05/12/2021 (“NĐ 126”)

2. Thuế suất là bao nhiêu?

A. Theo quy định của cơ quan quản lý thuế, trường hợp Đối tác có thu nhập từ hoạt động hợp tác kinh doanh với cty> 100 triệu đồng/năm, GSM sẽ hỗ trợ khấu trừ và nộp hộ thuế TNCN cho Đối tác, như sau:

Khấu trừ khoản tiền tương ứng với 1,5% trên tổng doanh thu chia sẻ của Đối tác.

B. Theo quy định của cơ quan quản lý thuế, trường hợp Đối tác có thu nhập từ hoạt động hợp tác kinh doanh với GSM ≤ 100 triệu đồng/năm.

Chưa đạt ngưỡng doanh thu chịu thuế TNCN. Không phải thực hiện nghĩa vụ thuế TNCN.

3. GSM có thực hiện toàn bộ nghĩa vụ thuế cho cá nhân kinh doanh hay không?

KHÔNG. GSM chỉ thực hiện việc thu hộ và nộp hộ đối với doanh thu chia sẻ mà Đối tác nhận được từ các cuốc xe phát sinh từ ứng dụng GSM và các khoản thưởng mà Đối tác nhận được từ GSM.

4. Làm sao tôi kiểm tra được doanh thu trong năm của mình thuộc mức chịu thuế TNCN (mức trên 100 triệu đồng)?

Nếu doanh thu trong năm của Đối tác > 100 triệu đồng, hệ thống sẽ cập nhật phương thức đối soát và theo dõi doanh thu chịu thuế, thuế TNCN phải nộp trên Ứng dụng Tài xế trong mục Thuế thu nhập cá nhân.

Trường hợp doanh thu trong năm của Đối tác ≤100 triệu đồng/năm, hệ thống sẽ không gửi bảng tổng kết doanh thu trên. Nếu Đối tác có thông tin thắc mắc cần hỗ trợ có thể liên hệ về GSM.

5. Làm thế nào để tôi biết mình đã được GSM khấu trừ & nộp hộ nghĩa vụ thuế từ hoạt động kinh doanh hợp tác với GSM?

GSM thực hiện nghĩa vụ thu hộ, nộp hộ nghĩa vụ thuế phát sinh từ hoạt động hợp tác kinh doanh của Đối tác tài xế 2 bánh vào tài khoản kho bạc nhà nước của Cục thuế TP. Hồ Chí Minh theo Mã số thuế (MST) của Quý Đối tác. Để thực hiện tra soát nghĩa vụ thuế phát sinh từ hoạt động kinh doanh cá nhân của mình tại GSM, Quý Đối tác chủ động liên hệ với Cơ quan Thuế để kiểm tra lại nghĩa vụ thuế đã được GSM kê khai thay và nộp hộ trên hệ thống của Cơ quan Thuế.

Lưu ý: Trường hợp Quý Đối tác không cung cấp MST, không cung cấp thông tin để đăng ký MST, GSM sẽ không thể thực hiện việc kê khai theo MST của Quý Đối tác mà kê khai gộp chung vào mã số nộp thay cho tất cả cá nhân thuộc diện không cung cấp MST. Do vậy Đối tác cần bổ sung thông tin MST để tiện việc tra cứu sau này.

Tra cứu MST tại đây: https://tracuunnt.gdt.gov.vn/tcnnt/mstcn.jsp (lưu ý: Đường dẫn này không dùng để tra soát nghĩa vụ thuế phát sinh từ hoạt động kinh doanh cá nhân của Đối tác tại GSM).

6. Vì sao đối với nghĩa vụ thuế thu và nộp hộ Đối tác cho kỳ tính thuế năm 2023 GSM không tiếp tục cung cấp xác nhận chứng từ khấu trừ thuế cho Đối tác như trước kia?

Theo quy định tại khoản 5 Điều 7 Nghị định 126/2020/NĐ-CP ngày 19/10/2020 của Chính phủ quy định chi tiết một số điều của Luật Quản lý thuế, Điều 8, khoản 1 Điều 16 Thông tư 40/2021/TT-BTC ngày 01/6/2021 của Bộ Tài chính hướng dẫn thuế giá trị gia tăng, thuế thu nhập cá nhân và quản lý thuế đối với hộ kinh doanh, cá nhân kinh doanh, và Công văn hướng dẫn số 13872/CTTPHCM-TTHT ngày 01/11/2022 của Cục Thuế TP.HCM về chính sách thuế, GSM có trách nhiệm kê khai thay, nộp thay thuế thu nhập cá nhân phát sinh từ hoạt động hợp tác kinh doanh cho Quý Đối tác theo mã số thuế của Đối tác (bảng kê chi tiết cá nhân kinh doanh mẫu 01-1/BK-CNKD) bằng hình thức trực tuyến thay vì nộp bản cứng bảng kê theo CMND/CCCD của Đối tác như trước kia. Do đó, kể từ kỳ tính thuế 2023, Đối tác chủ động liên hệ với Cơ quan thuế để kiểm tra lại nghĩa vụ thuế đã được GSM kê khai thay và nộp hộ trên hệ thống của Cơ Quan Thuế.

7. Tôi có được giảm trừ gia cảnh hay không?

Theo quy định của cơ quan quản lý thuế, thu nhập từ kinh doanh sẽ không được áp dụng giảm trừ gia cảnh.

8. Tôi có được khấu trừ các chi phí phục vụ việc kinh doanh ( xăng, chi phí sửa chữa, bảo dưỡng xe...) hay không?

KHÔNG. Theo quy định của cơ quan quản lý thuế, phương pháp tính thuế TNCN của cá nhân kinh doanh là phương pháp tính thuế trực tiếp trên doanh thu và các khoản hỗ trợ (không khấu trừ chi phí phục vụ kinh doanh).

9. Thời hạn thực hiện nghĩa vụ thuế TNCN của cá nhân kinh doanh xe 2 bánh là khi nào?

Căn cứ công văn số 6605/CT-TTHT ngày 06/07/2018 của Cục Thuế TP.HCM về chính sách thuế cá nhân kinh doanh tham gia mô hình hoạt động vận tải bằng xe 2 bánh: “… tổng hợp kê khai thuế theo mẫu số 01/CNKD hàng tháng/Quý…”

Để thuận lợi cho việc thực hiện, định kỳ vào kỳ kê khai thuế, GSM lập một tờ khai chung để khai thay cho tất cả các cá nhân và kèm theo hồ sơ khai thuế danh sách các cá nhân với các thông tin cụ thể về mã số thuế, tổng doanh thu bao gồm các khoản thưởng cá nhân được nhận, thuế đã khấu trừ và các thông tin có liên quan”.

Như vậy: Định kỳ hàng tháng/Quý, GSM sẽ thực hiện kê khai thuế cho các cá nhân kinh doanh vận tải bằng xe 2 bánh.

10. Điều gì sẽ xảy ra nếu Đối tác nộp chậm thuế?

Cơ quan quản lý thuế sẽ truy thu và áp dụng các mức phạt chậm với những trường hợp nộp chậm (căn cứ theo Điều 3 Thông tư 130/2016/TT-BTC ngày 12/6/2016 của Bộ tài Chính). Vì vậy rất mong Đối tác nghiêm túc chấp hành và thực hiện nghĩa vụ thuế đầy đủ, đúng hạn.

Lưu ý: Thời hạn hoàn thành nghĩa vụ kê khai và nộp thuế là ngày 31/03 hằng năm.

11. Đối tác có hoàn cảnh khó khăn có được gia hạn thời hạn thực hiện nghĩa vụ nộp thuế?

KHÔNG, trừ trường hợp Đối tác thuộc các trường hợp được gia hạn nộp thuế theo quy định tạiĐiều 31 Thông tư 156/2013/TT-BTCngày 06/11/2013 của Bộ Tài chính hướng dẫn thi hành Luật Quản lý thuế.

12. Khoản thuế TNCN phát sinh từ các chương trình thưởng của tôi đã được GSM khấu trừ hằng tuần, vậy tôi sẽ bị khấu trừ thêm một lần nữa khoản thuế TNCN vào đợt thu thuế này hay sao?

KHÔNG. Khoản thuế TNCN từ các chương trình thưởng đã được GSM khấu trừ và tạm trích lại để thực hiện kế hoạch hoàn thành nghĩa vụ thuế trong năm của Đối tác, nghĩa là Đối tác sẽ không bị khấu trừ thêm một lần nào nữa đối với khoản thuế TNCN phát sinh từ các chương trình thưởng.

13. Doanh thu trong năm của tôi >100 triệu đồng và nằm trong đối tượng phải thu thuế TNCN. Trường hợp nếu tôi không muốn đóng 50.000đ/ngày mà muốn khấu trừ 1 lần duy nhất về khoản tiền thuế TNCN thì GSM có hỗ trợ không?

Có.Đối tác có nhu cầu thực việc kê khai và nộp khoản tiền thuế TNCN phát sinh trong năm qua một lần khấu trừ duy nhất, vui lòng cung cấp thông tin

14. Trường hợp tài khoản GSM Driver của tôi bị khóa và doanh thu trong năm của tôi <100 triệu đồng, vậy khoản tiền thuế TNCN của tôi có được hoàn không? Và hoàn như thế nào?

Có. GSM vẫn sẽ thực hiện theo đúng quy định của cơ quan quản lý thuế về việc hoàn thuế TNCN cho Đối tác. Cụ thể tại các trường hợp sau:

Tài khoản GSM Driver của Đối tác bị tạm khóa: Khoản tiền thuế TNCN sẽ được chuyển về Ví tiền mặt mà Đối tác đã liên kết về GSM khi đăng ký hoạt động. Đối tác vẫn có thể thực hiện rút khoản tiền đã hoàn từ Ví tiền mặt đó.

Ngưng quyền sử dụng ứng dụng vĩnh viễn và thanh lý hợp đồng: GSM sẽ tiến hành chuyển khoản tiền thuế TNCN về tài khoản ngân hàng cá nhân mà Đối tác đã đăng ký khi hoạt động với GSM.

15. Doanh thu trong năm của tôi >100 triệu đồng và nằm trong đối tượng phải thu thuế TNCN. Trường hợp này, Tôi sẽ nộp thuế như thế nào

– Tại tháng Đối tác có Thu nhập trong năm từ hợp đồng hợp tác với GSM = 100 triệu đồng.

+ Ngày 22 tại phát sinh, Đối tác sẽ nhận được thông báo từ GSM về việc Đối tác thuộc trường hợp phải nộp thuế TNCN (kèm bảng kê doanh thu, thuế TNCN phải nộp). Số tiền thuế phải thu = 100.000.000 * 1,5% = 1.500.000 đồng

+ Từ ngày 25 trở đi, GSM thực hiện khấu trừ thuế TNCN bằng hình thức trừ ví của Đối tác; số tiền khấu trừ: 50.000 đ/ngày cho đến khi thu đủ số tiền thuế TNCN mà Đối tác có nghĩa vụ phải nộp cho Ngân sách nhà nước.

– Thu thuế TNCN đối với phần thu nhập trong năm trên 100 triệu đồng:

+ Ngày 22 hàng tháng, Đối tác sẽ nhận được thông báo từ GSM về tổng thu nhập chịu thuế và số thuế TNCN Đối tác còn phải nộp.

+ Ngày 25 hàng tháng: GSM thực hiện khấu trừ thuế TNCN bằng hình thức trừ ví của Đối tác

16. Số tiền thuế TNCN phải nộp của tôi được tính như thế nào?

Số tiền thuế cần đóng = ( Tổng thu nhập từ cuốc xe (sau khi trừ chiết khấu) + Số tiền thưởng của chương trình ) * thuế suất (1.5%).

VD : doanh thu từ cuốc xe : 90.000.000 vnđ (sau khi trừ phí sử dụng ứng dụng)

Tổng tiền thưởng: 15.000.000VNĐ => Số tiền thuế cần đóng: (90.000.000vnd + 15.000.000) * 1.5% = 1.575.000đ
