# Chính sách thưởng Tết Dương lịch dành cho Tài xế Taxi

- **Ngày đăng:** 2024-12-31
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-tet-duong-lich-tai-xe-taxi](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-tet-duong-lich-tai-xe-taxi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhân dịp Tết Dương Lịch 2025, Green SM trân trọng triển khaichương trình thưởng đặc biệtnhư một lời tri ân chân thành đến các Bác tài đã luôn đồng hành, tận tâm và nỗ lực không ngừng trong việc mang đến những trải nghiệm dịch vụ tốt nhất cho khách hàng.

🎉Hãy cùng Green SM khám phá chương trình thưởng:

- Thời gian áp dụng:Ngày 01/01/2025.

- Đối tượng áp dụng:Tài xế Taxi.

- Nội dung chính sách:–Thưởng thêm từ 8% đến 10%vào cácmức chia sẻ doanh sốtheo chính sách thu nhập hiện tại.–Áp dụng thêm mức khuyến khích số 5cho các khu vực:Hà Nội, TP.HCM và Đà Nẵng.

- Chi tiết chương trình:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/12/6b5a5890-20241231_chinhsachthuong-01-1-scaled.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> XANH SM
> CHÍNH SÁCH
> THƯỞNG TẾT DƯƠNG LỊCH
> DÀNH CHO TÀI XẾ TAXI
> 
> Thời gian áp dụng: Ngày 01/01/2025
> Đối tượng áp dụng: Tài xế Taxi
> 
> **Chi tiết chính sách**
> * Thưởng thêm từ 8% - 10% vào các mức chia sẻ doanh số theo chính sách thu nhập hiện tại
> * Áp dụng thêm mức khuyến khích số 5 cho Hà Nội, HCM và Đà Nẵng
> 
> **TỶ LỆ THƯỞNG TRÁCH NHIỆM & DOANH SỐ QUY ĐỊNH CHO TỪNG TỈNH/ THÀNH PHỐ**
> (Dòng xe Green Car)
> 
> **Hà Nội, TP.HCM, Đà Nẵng**
> 
> | Mức | Doanh số (VNĐ/ngày)        | Giờ thường | Giờ cao điểm | Thường thêm ngày lễ | Giờ thường Ngày Lễ | Giờ cao điểm Ngày Lễ |
> | :--- | :------------------------- | :---------- | :------------ | :------------------ | :---------------- | :------------------ |
> | Mức 0 | Dưới 1.000.000            | 25%         | 33%           | Không thường      | 25%               | 33%                 |
> | Mức 1 | Từ 1.000.000 - <1.300.000 | 30%         | 39%           | Không thường      | 30%               | 39%                 |
> | Mức 2 | Từ 1.300.000 - <1.600.000 | 35%         | 45%           | 8%                  | 43%               | 53%                 |
> | Mức 3 | Từ 1.600.000 - <2.100.000 | 40%         | 52%           | 8%                  | 48%               | 60%                 |
> | Mức 4 | Từ 2.100.000 - <2.700.000 | 46%         | 60%           | 8%                  | 54%               | 68%                 |
> | Mức 5 | Từ 2.700.000 trở lên      | 46%         | 60%           | 10%                 | 56%               | 70%                 |
> 
> **Tỉnh Nhóm 1: Bà Rịa - Vũng Tàu, Quảng Ninh**
> 
> | Mức | Doanh số (VNĐ/ngày)      | Giờ thường | Giờ cao điểm | Thường thêm ngày lễ | Giờ thường Ngày lễ | Giờ cao điểm Ngày lễ |
> | :--- | :----------------------- | :---------- | :------------ | :------------------ | :----------------- | :------------------- |
> | Mức 0 | Dưới 850.000             | 25%         | 28%           | Không thường      | 25%                | 28%                  |
> | Mức 1 | Từ 850.000 - <1.150.000 | 33%         | 38%           | 8%                  | 41%                | 46%                  |
> | Mức 2 | Từ 1.150.000 - <1.650.000 | 37%         | 42%           | 8%                  | 45%                | 50%                  |
> | Mức 3 | Từ 1.650.000 - <2.100.000 | 46%         | 52%           | 8%                  | 54%                | 60%                  |
> | Mức 4 | Từ 2.100.000 trở lên    | 48%         | 55%           | 10%                 | 58%                | 65%                  |
> 
> **Tỉnh Nhóm 2: Khánh Hòa, Huế, Quảng Nam**
> 
> | Mức | Doanh số (VNĐ/ngày)      | Giờ thường | Giờ cao điểm | Thường thêm ngày lễ | Giờ thường Ngày Lễ | Giờ cao điểm Ngày lễ |
> | :--- | :----------------------- | :---------- | :------------ | :------------------ | :---------------- | :------------------- |
> | Mức 0 | Dưới 800.000             | 25%         | 28%           | Không thường      | 25%               | 28%                  |
> | Mức 1 | Từ 800.000 - <1.100.000 | 32%         | 37%           | 8%                  | 40%               | 45%                  |
> | Mức 2 | Từ 1.100.000 - <1.600.000 | 37%         | 42%           | 8%                  | 45%               | 50%                  |
> | Mức 3 | Từ 1.600.000 - <2.000.000 | 45%         | 50%           | 8%                  | 53%               | 58%                  |
> | Mức 4 | Từ 2.000.000 trở lên    | 48%         | 53%           | 10%                 | 58%               | 63%                  |
> 
> **Tỉnh Nhóm 3: Tỉnh Bình Dương, Đồng Nai, Bắc Ninh, Hưng Yên, Quảng Bình, Long An, Bình Phước, Kiên Giang, NinhBình, Tiền Giang**
> 
> | Mức | Doanh số (VNĐ/ngày)      | Giờ thường | Thường thêm ngày lễ | Giờ thường Ngày Lễ |
> | :--- | :----------------------- | :---------- | :------------------ | :---------------- |
> | Mức 0 | Dưới 750.000             | 25%         | Không thường      | 25%               |
> | Mức 1 | Từ 750.000 - <1.000.000 | 32%-34%     | 8%                  | 40%-42%           |
> | Mức 2 | Từ 1.000.000 - <1.400.000 | 37%-38%     | 8%                  | 45%-46%           |
> | Mức 3 | Từ 1.400.000 - <1.650.000 | 45%-46%     | 8%                  | 53%-54%           |
> | Mức 4 | Từ 1.650.000 trở lên    | 48%         | 10%                 | 58%               |
> 
> **Tỉnh Nhóm 4: Các tỉnh còn lại**
> 
> | Mức | Doanh số (VNĐ/ngày)      | Giờ thường | Giờ cao điểm (Thanh Hoá) | Thường thêm ngày lễ | Giờ thường Ngày Lễ | Giờ cao điểm Ngày Lễ |
> | :--- | :----------------------- | :---------- | :----------------------- | :------------------ | :---------------- | :------------------- |
> | Mức 0 | Dưới 650.000             | 25%         | 28%                      | Không thường      | 25%               | 28%                  |
> | Mức 1 | Từ 650.000 - <950.000   | 31%-33%     | 37%                      | 8%                  | 39%-41%           | 45%                  |
> | Mức 2 | Từ 950.000 - <1.350.000 | 37%-38%     | 42%                      | 8%                  | 46%-46%           | 50%                  |
> | Mức 3 | Từ 1.350.000 - <1.650.000 | 45%         | 50%                      | 8%                  | 53%               | 58%                  |
> | Mức 4 | Từ 1.650.000 trở lên    | 48%         | 53%                      | 10%                 | 58%               | 63%                  |
> 
> **Khung giờ cao điểm Ngày lễ:**
> * Hà Nội, TP.HCM, Đà Nẵng: 09:00 - 10:59; 17:00 - 18:59 và 21:00 - 22:59
> * Các tỉnh thành còn lại: 17:00 - 23:59

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/12/6d4d1836-20241231_chinhsachthuong-02-2-scaled.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THƯỞNG TẾT DƯƠNG LỊCH DÀNH CHO TÀI XẾ TAXI
> 
> **Thời gian áp dụng:** Ngày 01/01/2025
> **Đối tượng áp dụng:** Tài xế Taxi
> 
> ## Chi tiết chính sách
> * Thưởng thêm từ **8% - 10%** vào các mức chia sẻ doanh số theo chính sách thu nhập hiện tại
> * Áp dụng thêm mức khuyến khích số 5 cho Hà Nội, HCM và Đà Nẵng
> 
> ## TỶ LỆ THƯỞNG TRÁCH NHIỆM & DOANH SỐ QUY ĐỊNH CHO TỪNG TỈNH/THÀNH PHỐ
> (Dòng xe Luxury Car)
> 
> ### Hà Nội, TP.HCM, Đà Nẵng
> 
> | Mức | Doanh số (VNĐ/ngày) | Giờ thường | Giờ cao điểm | Thưởng thêm ngày lễ | Giờ thường Ngày lễ | Giờ cao điểm Ngày Lễ |
> | :---- | :-------------------- | :------------ | :------------ | :------------------ | :---------------- | :-------------------- |
> | Mức 0 | Dưới 900.000 | 25% | 32% | Không thưởng | 25% | 32% |
> | Mức 1 | Từ 900.000 - <1.200.000 | 32% | 41% | Không thưởng | 32% | 41% |
> | Mức 2 | Từ 1.200.000 - <1.500.000 | 38% | 50% | 8% | 46% | 58% |
> | Mức 3 | Từ 1.500.000 - <2.000.000 | 45% | 59% | 8% | 53% | 67% |
> | Mức 4 | Từ 2.000.000 - <2.500.000 | 48% | 62% | 8% | 56% | 70% |
> | Mức 5 | Từ 2.500.000 trở lên | 48% | 62% | 10% | 58% | 72% |
> 
> ### Nhóm 1: Bà Rịa - Vũng Tàu, Quảng Ninh
> 
> | Mức | Doanh số (VNĐ/ngày) | Giờ thường | Giờ cao điểm | Thưởng thêm ngày lễ | Giờ thường Ngày Lễ | Giờ cao điểm Ngày lễ |
> | :---- | :-------------------- | :------------ | :------------ | :------------------ | :---------------- | :-------------------- |
> | Mức 0 | Dưới 750.000 | 25% | 28% | Không thưởng | 25% | 28% |
> | Mức 1 | Từ 750.000 - <1.050.000 | 30% | 35% | 8% | 38% | 43% |
> | Mức 2 | Từ 1.050.000 - <1.400.000 | 37% | 41% | 8% | 45% | 49% |
> | Mức 3 | Từ 1.400.000 - <1.900.000 | 45% | 50% | 8% | 53% | 58% |
> | Mức 4 | Từ 1.900.000 trở lên | 48% | 52% | 10% | 58% | 62% |
> 
> ### Nhóm 2: Khánh Hòa, Huế, Quảng Bình
> 
> | Mức | Doanh số (VNĐ/ngày) | Giờ thường | Giờ cao điểm | Thưởng thêm ngày lễ | Giờ thường Ngày Lễ | Giờ cao điểm Ngày Lễ |
> | :---- | :-------------------- | :------------ | :------------ | :------------------ | :---------------- | :-------------------- |
> | Mức 0 | Dưới 700.000 | 25% | 28% | Không thưởng | 25% | 28% |
> | Mức 1 | Từ 700.000 - <950.000 | 28%-30% | 35% | 8% | 36%-38% | 43% |
> | Mức 2 | Từ 950.000 - <1.300.000 | 33%-35% | 39% | 8% | 41%-43% | 47% |
> | Mức 3 | Từ 1.300.000 - <1.700.000 | 40% | 45% | 8% | 48% | 53% |
> | Mức 4 | Từ 1.700.000 trở lên | 48% | 50% | 10% | 58% | 60% |
> 
> ### Tinh Nhóm 3: Bình Dương, Đồng Nai, Long An, Hưng Yên, Bắc Ninh, Tây Ninh, Kiên Giang, Vĩnh Phúc, Ninh Bình, Tiền Giang, Bình Phước
> 
> | Mức | Doanh số (VNĐ/ngày) | Giờ thường | Thưởng thêm ngày lễ | Giờ thường Ngày Lễ |
> | :---- | :-------------------- | :------------ | :------------------ | :---------------- |
> | Mức 0 | Dưới 550.000 | 25% | Không thưởng | 25% |
> | Mức 1 | Từ 550.000 - <700.000 | 32%-34% | 8% | 40%-42% |
> | Mức 2 | Từ 700.000 - <1.000.000 | 40%-42% | 8% | 48%-50% |
> | Mức 3 | Từ 1.000.000 - <1.400.000 | 45%-46% | 8% | 53%-54% |
> | Mức 4 | Từ 1.400.000 trở lên | 48% | 10% | 58% |
> 
> ### Tỉnh Nhóm 4: Các tỉnh còn lại
> 
> | Mức | Doanh số (VNĐ/ngày) | Giờ thường | Giờ cao điểm (Thanh Hoá) | Thường thêm ngày Lễ | Giờ thường Ngày Lễ | Giờ cao điểm Ngày Lễ |
> | :---- | :-------------------- | :------------ | :----------------------- | :------------------ | :---------------- | :-------------------- |
> | Mức 0 | Dưới 500.000 | 25% | 28% | Không thưởng | 25% | 28% |
> | Mức 1 | Từ 500.000 - <700.000 | 34%-36% | 40% | 8% | 42%-44% | 48% |
> | Mức 2 | Từ 700.000 - <900.000 | 40%-42% | 46% | 8% | 48%-50% | 54% |
> | Mức 3 | Từ 900.000 - <1.100.000 | 43%-45% | 50% | 8% | 51%-53% | 58% |
> | Mức 4 | Từ 1.100.000 trở lên | 48% | 52% | 10% | 58% | 62% |
> 
> **Khung giờ cao điểm Ngày lễ:**
> * **Hà Nội, TP.HCM, Đà Nẵng:** 09:00-10:59; 17:00-18:59 và 21:00-22:59
> * **Các tỉnh thành còn lại:** 17:00-23:59

🌟 Hãy cùng Green SM khởi đầu năm mới thật bùng nổ! Mến chúc các Bác tài một năm mới An khang – Thịnh vượng!

Trân trọng,Đội ngũ GSM
