# Chính sách thu nhập và thưởng trách nhiệm doanh số Tài xế Xanh Limo tại TP.HCM

- **Ngày đăng:** 2025-10-20
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-limo-hcm](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-limo-hcm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Với mục đích hỗ trợ Bác tài quản lý thu nhập một cách minh bạch và chủ động, Green SM xin thông báo vềChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấm công.

👉 Thời gian áp dụng: Từ20/10/2025cho đến khi có thông báo mới.👉 Chi tiết chính sách: Bác tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/97e5dddc-251020_chinhsach-web-1-967x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP
> # VÀ THƯỞNG TRÁCH NHIỆM DOANH SỐ
> 
> **Đối tượng áp dụng**: Tài xế Xanh Limo tại Depot Hồ Chí Minh 1, 2, 6, 7
> **Thời gian áp dụng**: Từ ngày 20/10/2025 đến khi có thông báo mới
> 
> ## Nội dung chính sách
> Mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công
> 
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> 
> | Khu vực áp dụng       |                                                                            TP. Hồ Chí Minh (cũ)                                                                           |
> | :-------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Thời gian             | Từ thứ 2 đến Thứ 6                                                                     | Thứ 7, Chủ nhật                                                                    | Tết Âm lịch (5 ngày) |
> | Khung giờ cao điểm    | 06:00-08:59;<br/>16:00-21:59                                                           | 09:00-11:59;<br/>17:00-23:59                                                        | Không áp dụng        |
> 
> ## Xanh Limo
> ### Tỷ lệ chia sẻ
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Cuốc xe thường | Cuốc cao điểm |
> | :---- | :---------------------------- | :------------- | :------------ |
> | Mức 0 | Dưới 1.000.000                | 25%            | 33%           |
> | Mức 1 | Từ 1.000.000 đến dưới 1.300.000 | 30%            | 39%           |
> | Mức 2 | Từ 1.300.000 đến dưới 1.500.000 | 35%            | 45%           |
> | Mức 3 | Từ 1.500.000 đến dưới 1.800.000 | 40%            | 52%           |
> | Mức 4 | Từ 1.800.000 đến dưới 2.100.000 | 44%            | 56%           |
> | Mức 5 | Từ 2.100.000 trở lên          | 48%            | 60%           |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/3822800f-251020_chinhsach-web-2-1024x654.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # TIÊU CHUẨN CHẤM CÔNG
> 
> **Xanh Limo**
> 
> | Tháng áp dụng       | Tiêu chí             | Từ T2 - T5 | Từ T6 - CN, ngày Lễ, Tết | Từ T2 - CN, ngày Lễ, Tết |
> | :------------------ | :------------------- | :--------- | :----------------------- | :----------------------- |
> |                     | Tỷ lệ nhận cuốc      | ≥85%       | ≥80%                     | ≥75%                     |
> |                     | Tỷ lệ hoàn thành cuốc | ≥85%       | ≥85%                     | ≥85%                     |
> | **9, 10, 11**       | Doanh số (VNĐ/ngày)  | Từ 720.000 | Từ 900.000               | Từ 1.350.000             |
> | Các tháng còn lại   |                      | Từ 800.000 | Từ 1.000.000             | Từ 1.500.000             |

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác tài vận doanh an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
