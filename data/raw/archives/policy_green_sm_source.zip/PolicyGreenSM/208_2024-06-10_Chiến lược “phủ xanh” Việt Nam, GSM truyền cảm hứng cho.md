# Chiến lược “phủ xanh” Việt Nam, GSM truyền cảm hứng cho cộng đồng

- **Ngày đăng:** 2024-06-10
- **Chuyên mục:** Báo chí
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chien-luoc-phu-xanh-viet-nam-gsm-truyen-cam-hung-cho-cong-dong](https://www.greensm.com/vn-vi/news/chien-luoc-phu-xanh-viet-nam-gsm-truyen-cam-hung-cho-cong-dong)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Nỗ lực bền bỉ cùng những bước đi mạnh mẽ của GSM, như việc tung loạt chính sách ưu đãi hấp dẫn chưa từng có cho cả khách hàng và đối tác tài xế trên nền tảng Green SM Platform, được xem là một chiến lược tổng lực của GSM nhằm “phủ xanh” Việt Nam.

“Thiên thời, địa lợi” để chuyển đổi xanh

Thị trường gọi xe Việt Nam lại tiếp tục “dậy sóng” với động thái mới từ hãng taxi điện của tỷ phú Phạm Nhật Vượng. Theo đó, từ ngày 1/6 đến 31/8, cả khách hàng và các đối tác tài xế độc lập của GSM đều được hưởng lợi lớn từ loạt chính sách ưu đãi cực mạnh tay trong chương trình “Mùa hè xanh vì Tương lai xanh”.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/06/d0f32fb0-a1-22-9132.jpg.webp)

Chương trình mới của Green SM mang đến nhiều “món quà” dành tặng khách hàng

Cụ thể, trong suốt 3 tháng diễn ra chương trình, khách hàng gọi taxi Green SM sẽ được hưởng giá cước thấp hơn tới 15% so với ngày trước, đảm bảo mỗi chuyến đi bằng taxi điện đều có mức giá tốt nhất thị trường.

Đáng chú ý, 3 khách hàng “trồng” được nhiều cây xanh nhất khi quy đổi lượng giảm phát thải CO2 từ số kilomet di chuyển bằng taxi điện sẽ nhận giải thưởng là 3 chuyến đi tới Paris (Pháp) tham dự trực tiếp Lễ bế mạc Olympic Paris 2024. Phần thưởng trị giá tương đương hơn 115 triệu đồng.

Anh Thanh Bình (Thanh Xuân, Hà Nội), một khách quen của Green SM cho biết từ ngày taxi điện ra đời, ngay cả những thời điểm hãng không có khuyến mại anh cũng ưu tiên sử dụng bởi “ngồi xe điện sướng hơn hẳn xe xăng”. Quan trọng hơn, với anh Bình, sử dụng phương tiện không phát thải đã trở thành “nhận diện” của những công dân cấp tiến, vì môi trường.

“Ngày càng nhiều người chuyển sang sử dụng taxi điện bởi lợi ích không chỉ cho bản thân mà cho cả môi trường”, anh Bình tin tưởng.

Trong khi đó, anh Quang Hưng, một tài xế chạy xe dịch vụ tại Hà Nội, lại nhìn thấy cơ hội từ chính sách mới của nền tảng gọi xe thương hiệu Việt. Vốn đang có kế hoạch chuyển từ xe xăng sang xe điện VinFast vì tính kinh tế hơn hẳn, anh Hưng càng mừng khi GSM tăng mạnh tỷ lệ chia sẻ doanh thu cho đối tác tài xế độc lập lên 87% – cao nhất thị trường hiện nay.

Đặc biệt, với những tài xế như anh, việc sở hữu ô tô điện đang dễ dàng hơn bao giờ hết nhờ loạt chính sách ưu đãi mua xe trả góp “3 nhất” từ chương trình “Mãnh liệt Tinh thần Việt Nam” của VinFast.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/06/11dc38df-a2-18-6930.jpg.webp)

Nhiều tài xế đối tác đã lựa chọn VF 5 Plus để chạy dịch vụ, thay thế xe xăng

Theo đó, với số tiền dự tính khoảng 200 triệu đồng bán chiếc xe xăng cũ hiện tại, anh Hưng dư sức trả trước 20% giá trị chiếc VF 5 Plus – chỉ hơn 100 triệu đồng. Số tiền còn lại, nhờ chính sách hỗ trợ lãi suất của VinFast mà mỗi tháng anh Hưng chỉ phải thanh toán khoảng 5 triệu đồng. Theo anh, mức chi này cũng tương đương số tiền hàng tháng anh tiết kiệm được từ mức chênh lệch giữa chi phí nhiên liệu, chi phí bảo dưỡng của xe điện so với xe xăng.

“Vừa hưởng ưu đãi từ chương trình mua trả góp của VinFast, vừa được hưởng mức chia sẻ doanh thu cao nhất thị trường từ Green SM thì đúng là ‘thiên thời, địa lợi’ để chuyển đổi sang xe điện”, anh Hưng phân tích.

Cú hích tăng tốc quá trình “phủ xanh” Việt Nam

Nhiều chuyên gia đánh giá, chính sách “khủng” của GSM khiến sức hấp dẫn của taxi điện nhân đôi, nhân ba và chắc chắn sẽ tạo nên một làn sóng chuyển đổi xanh mạnh mẽ, cả từ phía người tiêu dùng và giới kinh doanh xe dịch vụ.

Hiện nay, ngoài GSM, 3 nền tảng gọi xe phổ biến khác là Grab, Be và Gojek đều có mức chiết khấu khá cao, tối thiểu 25% đối với dịch vụ taxi. Đồng nghĩa, với mỗi cuốc xe, tài xế chỉ được chia sẻ chưa tới 75% doanh thu. Nhiều tài xế taxi công nghệ từng “khóc ròng” vì thu nhập thấp, trong khi giá xăng liên tục biến động.

Bởi thế, mức chia sẻ doanh thu từ GSM được đánh giá là “chưa từng có” dành cho các đối tác tài xế độc lập. Với chính sách này, ông Nguyễn Văn Thanh, Tổng Giám đốc Công ty Cổ phần Di chuyển Xanh và Thông minh GSM, kỳ vọng, Green SM Platform sẽ khuyến khích các tài xế trên toàn quốc cùng chung tay vì mục tiêu cung cấp dịch vụ di chuyển thân thiện với môi trường. Đến nay, nền tảng này đã có gần 1.000 đối tác tài xế độc lập là các chủ xe điện VinFast.

Bên cạnh đó, đến nay, Green SM đã đưa vào vận hành gần 30.000 taxi thuần điện ở hơn 40 tỉnh, thành trên cả nước. GSM cũng truyền cảm hứng cho hơn 30 đối tác doanh nghiệp chuyển đổi sang xe điện để nối dài những hành trình xanh trên khắp Việt Nam. Không những thế, việc giảm giá cước đang tạo điều kiện tốt hơn nữa để khách hàng chuyển sang sử dụng phương tiện di chuyển không phát thải.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/06/92bfc714-a3-11-2488.jpg.webp)

Green SM đang trên đà hoàn thành mục tiêu “phủ xanh” Việt Nam

“Tôi tin rằng, mức giá tốt, dịch vụ chất lượng cao và ý nghĩa đặc biệt của việc di chuyển xanh sẽ khiến cộng đồng dần thay đổi thói quen đi lại theo hướng bền vững hơn”, ông Thanh chia sẻ mục tiêu của Green SM nhắm tới không phải thứ hạng thị phần mà là “số 1 trong lòng khách hàng” về chất lượng dịch vụ 5 sao với chi phí tốt nhất.

Thực tế, hướng đi của Green SM đã và đang tạo thay đổi tích cực cho môi trường. Theo thống kê, chỉ trong vòng 1 năm, với hàng chục triệu chuyến đi xanh, Green SM đã góp phần cắt giảm hơn 52.000 tấn CO2, tương đương 2,6 triệu cây xanh quang hợp trong một năm. Tính trung bình, cứ mỗi 16,8 km di chuyển bằng xe điện, khách hàng đã cùng với Green SM cắt giảm được lượng khí thải CO2 tương đương với trồng mới 1 cây xanh.

Những thay đổi thiết thực ấy khiến ngày càng nhiều người dùng chuyển đổi thói quen di chuyển, đặc biệt là thế hệ tiêu dùng mới đang lựa chọn lối sống xanh và ưu tiên những sản phẩm, dịch vụ hướng tới sự phát triển bền vững. “Không nhất thiết phải lên rừng trồng cây mới là giúp bảo vệ môi trường. Mỗi người từ hành động nhỏ nhất là chọn cách đi lại cũng đang chung tay phủ xanh Việt Nam”, một chuyên gia về chiến lược phát triển bền vững nói về Green SM.

Các chuyên gia cho rằng, cùng với những bước đi thần tốc, chiến lược khác biệt của GSM đã vượt xa tầm vóc của một startup vì lợi nhuận đơn thuần, đồng thời cho thấy vị thế của một doanh nghiệp vì cộng đồng, vì xã hội. Nhờ đó, GSM nhận được sự tin yêu, ủng hộ của đông đảo khách hàng và trở thành cái tên đầu tiên được nhắc tới, không chỉ trong lĩnh vực gọi xe mà còn là thương hiệu tiên phong trong tiến trình chuyển đổi xanh của Việt Nam.

(theo Đầu Tư Tài Chính)
