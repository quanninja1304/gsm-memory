# Thông báo: Kết thúc chính sách thưởng đối với Car Platform

- **Ngày đăng:** 2025-04-06
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/ket-thuc-chuong-trinh-thuong-car-platform](https://www.greensm.com/vn-vi/news/ket-thuc-chuong-trinh-thuong-car-platform)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Green SM xin gửi lời cảm ơn chân thành đến các Bác tài đã đồng hành và tích cực tham gia các chương trình thưởng trong thời gian vừa qua.

Công ty xin thông báo:kể từ ngày 7/4/2025, chương trình thưởng dành cho Bác tài Car Platform trên toàn quốc sẽ kết thúc.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/ef30c914-20250404_tamngungchinhsach-1024x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> ## THÔNG BÁO
> 
> ### TẠM NGƯNG TRIỂN KHAI CHÍNH SÁCH THƯỞNG
> 
> **Thời gian áp dụng:**
> Từ ngày 7/4/2025 đến khi có thông báo mới
> 
> **Đối tượng áp dụng:**
> Bác tài Car Platform trên toàn quốc
> ```

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Green SM Platform
