# [GREEN SM NGON] Thông báo chương trình thưởng và thu nhập

- **Ngày đăng:** 2025-07-21
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/xanh-sm-ngon-thong-bao-chuong-trinh-thuong-va-thu-nhap](https://www.greensm.com/vn-vi/news/xanh-sm-ngon-thong-bao-chuong-trinh-thuong-va-thu-nhap)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Đối tác Tài xế thân mến,

Với mong muốn hỗ trợĐối tác Tài xếcó thêm nhiều đơn hàng, gia tăng thu nhập cùng dịch vụ mới,Green SM Ngonxin được gửi đến các Bác tài thông tin cập nhật về các chính sách liên quan đến thưởng và thu nhập cho đơn hàng Green SM Ngon như sau:

- Khu vực áp dụng: Hà Nội, TP.HCM

- Đối tượng áp dụng: Toàn bộ tài xế đã kích hoạt dịch vụ Green SM Ngon (không bao gồm tài xế đăng ký chương trình chuyên Food

- Đối với đơn hàng Green SM Ngon, ngoài mức chia sẻ doanh số cơ bản (chưa bao gồm VAT và thuế TNCN), Đối tác Tài xế sẽ được nhận đồng thời 03 chương trình thưởng. Chi tiết như sau:Thưởng chuyến khung giờ cao điểmThưởng tuần lên tới 230.000 VNĐ (áp dụng đến hết ngày 27/07/2025)Thưởng bổ sung (áp dụng đến hết ngày 27/07/2025)

![[GREEN SM NGON] THÔNG BÁO CHƯƠNG TRÌNH THƯỞNG VÀ THU NHẬP](https://cdn.xanhsm.com/2025/07/b92dd6be-2107_chinh-sach-thu-nhap-xanh-sm-ngon-724x1024.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THU NHẬP DÀNH CHO TÀI XẾ XANH SM NGON
> 
> ## THỜI GIAN ÁP DỤNG
> Từ 21/05/2025 cho đến khi có thông báo mới
> 
> Chia sẻ doanh số cơ bản = 75% * doanh số cuốc xe
> 
> | Thưởng giờ thấp điểm | Thưởng giờ cao điểm (*) |
> | :------------------ | :-------------------- |
> | 2.000 VNĐ/chuyến    | 3.000 VNĐ/chuyến      |
> 
> Lưu ý: Mức chia sẻ doanh số chưa bao gồm khoản khấu trừ Thuế GTGT (VAT) và Thuế thu nhập cá nhân (TNCN)
> 
> ## THƯỞNG TUẦN
> Áp dụng đến hết ngày 27/07/2025
> 
> | TIÊU CHÍ             | MỨC THƯỞNG   |
> | :------------------- | :----------- |
> | Hoàn thành 40 đơn/tuần | 80.000 vnđ   |
> | Hoàn thành 60 đơn/tuần | 140.000 vnđ  |
> | Hoàn thành 90 đơn/tuần | 230.000 vnđ  |
> 
> ## THƯỞNG BỔ SUNG
> Áp dụng đến hết ngày 27/07/2025
> 
> | TIÊU CHÍ                                                                 | MỨC THƯỞNG      |
> | :----------------------------------------------------------------------- | :-------------- |
> | Đơn có khoảng cách lấy hàng >1.5km                                        | 2.000vnđ/chuyến |
> | Hoàn thành 3 đơn/ngày có điểm lấy/trả hàng tại quận Hà Đông, Long Biên (Hà Nội) | 20.000 vnđ      |
> | Hoàn thành 3 đơn/ngày có điểm lấy/trả hàng tại quận 4, quận 7 (TPHCM)      | 20.000 vnđ      |
> 
> ## ĐIỀU KIỆN
> 
> | TIÊU CHÍ                     | ĐIỀU KIỆN |
> | :--------------------------- | :-------- |
> | Tỷ lệ nhận chuyến (**)       | >= 90%    |
> | Tỷ lệ hoàn thành chuyến (**) | >= 90%    |
> | Số ngày vận doanh trong tuần | >= 5 ngày |
> 
> (*) Giờ cao điểm: 11:00 - 13:00, 14:00 - 17:00, 18:00 - 20:00 (từ thứ 2 - CN)
> (**) Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến có bao gồm các cuốc nối chuyến
> ```

Lưu ý:

- Đơn hàng Green SM Ngon đã triển khai áp dụng phí gửi xe (5.000VNĐ/chuyến). Đối với đơn hàng thanh toán bằng thẻ/ví, phí gửi xe tự động cộng vào phí giao hàng và chuyển vào ví Đối tác. Đối với đơn thanh toán tiền mặt, phí gửi xe được cộng vào phí giao hàng.

- Dịch vụ Green SM Ngon sẽ được bật mặc định cùng dịch vụ Xanh Bike & Xanh Express.

- Đơn hàng Green SM Ngon không áp dụng với chương trình Thưởng cuối tuần và Thưởng doanh số cao.

Trân trọng,Đội ngũ Green SM Ngon.
