# [HÀ NỘI] CẬP NHẬT QUY ĐỊNH DOANH SỐ TỐI THIỂU

- **Ngày đăng:** 2025-06-19
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-quy-dinh-doanh-so-toi-thieu-tai-ha-noi](https://www.greensm.com/vn-vi/news/cap-nhat-quy-dinh-doanh-so-toi-thieu-tai-ha-noi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

Đối tác Tài xế thân mến,

Việc duy trì hoạt động đều đặn mỗi ngày không chỉ giúp Đối tác Tài xế tối ưu thu nhập cá nhân, mà còn góp phần lan tỏa giá trị Xanh đến cộng đồng. Với mong muốn thúc đẩy tinh thần vận doanh, góp thêm nhiều chuyến xe Xanh cho môi trường, Green SM xin thông báo nội dung cập nhật mức doanh số tối thiểu(**) như sau:

1. Thời gian áp dụng:Từ ngày 23/06/2025

2. Khu vực áp dụng: Hà Nội

3. Đối tượng áp dụng: Đối tác Tài xế Green SM Bike

4. Nội dung chi tiết:

- Green SM Bike áp dụng mức khoán doanh số tối thiểu280.000 VNĐ/ngày vận doanh/tài xế (*). Trường hợp Đối tác Tài xế không đạt mức doanh số tối thiểu, công ty sẽ tiến hành truy thu20% phần doanh số khoán chưa đạtbằng hình thức trừ ví hàng ngày.

Ví dụ: Đối tác Tài xế chỉ đạt doanh số 200.000 VNĐ/ngày

=> mức truy thu doanh số = 20% * (280.000 – 200.000) = 16.000 VNĐ.

(*) Ngày vận doanh là ngày Đối tác Tài xế hoạt động có phát sinh doanh số.

(**) Doanh số tối thiểu được hiển thị trên Ứng dụng Tài xế tại phần: Thống kê thu nhập, mục ” Doanh số”.

Toàn bộ thông tin chi tiết về chính sách & quy định vận doanh, Đối tác Tài xế vui lòng tham khảotại đây.

Chúc Đối tác Tài xế nhiều sức khỏe, vững tay lái và gia tăng thu nhập!

Trân trọng,

Đội ngũ Green SM Bike
