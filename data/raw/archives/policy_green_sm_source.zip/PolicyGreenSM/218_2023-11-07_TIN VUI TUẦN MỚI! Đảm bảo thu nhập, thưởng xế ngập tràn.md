# TIN VUI TUẦN MỚI! Đảm bảo thu nhập, thưởng xế ngập tràn!

- **Ngày đăng:** 2023-11-07
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tin-vui-tuan-moi-dam-bao-thu-nhap-thuong-xe-ngap-tran](https://www.greensm.com/vn-vi/news/tin-vui-tuan-moi-dam-bao-thu-nhap-thuong-xe-ngap-tran)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Mọi người đã biết tin gì chưa? Green SM Bike có chính sách thu nhập mới!!Không chỉ nỗ lực lan tỏa giá trị xanh bền vững đến cộng đồng, Green SM Bike vẫn luôn cố gắng mang đến cho các Đối tác Tài xế (ĐTTX) một môi trường làm việc chuyên nghiệp, an tâm và chủ động gia tăng thu nhập. Vì vậy, Green SM Bike chính thức giới thiệuChính sách thu nhập mới.Khu vực áp dụng:Cả nước.Thời gian áp dụng:•Từ ngày 01/11/2023(đối với  đối tác tài xế gia nhập từ ngày 01/11/2023).•Từ ngày 06/11/2023(đối với  đối tác tài xế gia nhập trước ngày 01/11/2023).🌟 Với chính sách thu nhập mới, Đối tác sẽ đượcáp dụng đồng thời 4 chương trình thưởnghấp dẫn, nhận tổng thu nhập lên tới 20 triệu/tháng:1. Thưởng đảm bảo thu nhập.2. Thưởng vượt mốc chuyến/ngày.3. Thưởng điểm tuần.4. Thưởng nóng(dành riêng cho Đối tácgia nhập từ ngày 01/11/2023 – 30/11/2023).Thông tin chi tiết về chương trình thưởng, Đối tác vui lòng tham khảo hình ảnh bên dưới

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/11/0f6a96a9-cs-thu-nhap-dai-su-bike-t11.pptx-1-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THU NHẬP
> 
> | Tổng thu nhập Gộp = | Chia sẻ doanh số cơ bản (1) | + | Thưởng đảm bảo thu nhập (2) | + | Thưởng vượt mốc chuyến/ngày (3) | + | Thưởng điểm tuần (4) | + | Thưởng nóng (5) |
> |---|---|---|---|---|---|---|---|---|---|
> 
> ## (1) Chia sẻ doanh số cơ bản
> 
> **Chia sẻ doanh số cơ bản = 73% x Doanh số**
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/11/acd75078-cs-thu-nhap-dai-su-bike-t11.pptx-4-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP
> 
> ## (2) Thưởng đảm bảo thu nhập
> 
> **Ví dụ:**
> 
> *   Đại sứ Xanh Bike 5h trực tuyến 6 tiếng, hoàn thành 05 chuyến, tổng doanh số thực hiện được là 250,000 VNĐ.
> *   Đối tác đạt điều kiện nhận chuyến và hoàn thành chuyến >=90%.
> *   Chia sẻ doanh cơ bản = 73% x 250,000 = 182,500 VNĐ.
> *   Thưởng đảm bảo thu nhập = 200,000 – 182,500 = 17,500 VNĐ.
> 
> | | Đại sứ Xanh Bike 5h | Đại sứ Xanh Bike 8h | Đại sứ Xanh Bike 10h |
> | :---------------------- | :-------------------- | :------------------ | :------------------- |
> | **Mức thu nhập đảm bảo (VNĐ/ngày)** | 200,000 | 320,000 | 400,000 |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/11/273f99af-cs-thu-nhap-dai-su-bike-t11.pptx-3-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP
> 
> ## (3) Thưởng vượt mốc chuyến/ ngày
> 
> **Ví dụ:**
> Đại sứ Xanh Bike 8h hoàn thành 17 chuyến.
> Thưởng vượt mốc mà Tài xế nhận được = [(16 – 12 + 1) x 4,000] + (1 x 6,000) = 26,000 VNĐ.
> 
> | Các mốc | **Đại sứ Xanh Bike 5h** | **Đại sứ Xanh Bike 8h & 10h** |
> |---|---|---|
> | | **Số chuyến** | **Mức thưởng/ chuyến vượt (VNĐ)** | **Số chuyến** | **Mức thưởng/ chuyến vượt (VNĐ)** |
> | **Mốc 1** | Từ 8 – 12 chuyến | 4,000 | Từ 12 – 16 chuyến | 4,000 |
> | **Mốc 2** | Trên 12 chuyến | 6,000 | Trên 16 chuyến | 6,000 |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/11/7e925d4a-cs-thu-nhap-dai-su-bike-t11.pptx-2-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THU NHẬP
> 
> ## (4) Thưởng điểm tuần
> 
> | Mức   | Đại sứ Xanh Bike 5h          | Mức thưởng (VNĐ/ tuần) | Đại sứ Xanh Bike 8h & 10h          | Mức thưởng (VNĐ/ tuần) |
> | :---- | :--------------------------- | :-------------------- | :--------------------------------- | :-------------------- |
> | Mức 0 | Dưới 90 điểm                 | Không thưởng           | Dưới 135 điểm                      | Không thưởng           |
> | Mức 1 | Từ 90 điểm – 114 điểm        | 200.000               | Từ 135 điểm – 164 điểm             | 500.000               |
> | Mức 2 | Từ 115 điểm – 134 điểm       | 300.000               | Từ 165 điểm – 194 điểm             | 600.000               |
> | Mức 3 | Từ 135 điểm trở lên          | 400.000               | Từ 195 điểm – 224 điểm             | 700.000               |
> | Mốc 4 | N/A                          | N/A                   | Từ 225 điểm trở lên                | 1.100.000             |
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/11/9b181292-cs-thu-nhap-dai-su-bike-t11.pptx-5-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP
> 
> ## (5) Thưởng nóng\*
> 
> Trong vòng 07 ngày đầu tiên tính từ ngày gia nhập, Tài xế Xanh Bike hoàn thành chuyến xe sẽ nhận thưởng nóng như sau:
> 
> | SỐ CHUYẾN HOÀN THÀNH | MỨC THƯỞNG NÓNG |
> | :------------------- | :---------------- |
> | 50 - 99 chuyến       | 500.000 VNĐ       |
> | Từ 100 chuyến trở lên | 1.000.000 VNĐ     |
> 
> \*Áp dụng cho Đối tác Tài xế nhận việc từ ngày 01/11/2023 - 30/11/2023.
> 
> ---
> XANH SM

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/11/17cf33aa-cs-thu-nhap-dai-su-bike-t11.pptx-6-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # ĐIỀU KIỆN NHẬN THƯỞNG
> 
> | TT  | Tiêu chí                                            | Đại sứ Xanh Bike 5h | Đại sứ Xanh Bike 8h | Đại sứ Xanh Bike 10h |
> | :-- | :-------------------------------------------------- | :------------------ | :------------------ | :------------------- |
> | 1   | Số giờ trực tuyến tối thiểu/ngày                    | 5h                  | 8h                  | 10h                  |
> | 2   | Số giờ trực tuyến tối thiểu vào các khung giờ cao điểm/ ngày | 1,5h                | 2,5h                | 3h                   |
> | 3   | Số chuyến tối thiểu/ ngày                           | 5 chuyến           | 8 chuyến           | 10 chuyến           |
> | 4   | Tỷ lệ nhận chuyến                                   |                     | >= 90%              |                      |
> | 5   | Tỷ lệ hoàn thành chuyến                             |                     | >= 90%              |                      |
> 
> **✓ XANH SM**
> **✓ Chính sách thưởng (2) & (3): Áp dụng đồng thời 5 điều kiện trên.**
> **✓ Chính sách thưởng (4) & (5): Áp dụng điều kiện 4 & 5.**

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/11/a574185f-cs-thu-nhap-dai-su-bike-t11.pptx-7-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CÁCH QUY ĐỔI ĐIỂM THEO KHUNG GIỜ
> 
> | Khung giờ/ngày | Điểm thưởng / 1 chuyến xe hoàn thành | |
> |---|---|---|
> | | Thứ 2 – Thứ 6 | Thứ 7 & CN |
> | 00:00 – 04:59 | 1 | 1 |
> | 05:00 – 08:59 | 2 | 1 |
> | 09:00 – 11:59 | 1 | 1,5 |
> | 12:00 – 15:59 | 1 | 1 |
> | 16:00 – 19:59 | 2 | 2 |
> | 20:00 – 23:59 | 1 | 2 |
> 
> Giờ cao điểm được xác định trong các khung giờ:
> * Từ thứ Hai đến thứ Sáu: (i) 05:00 – 08:59 và (ii) 16:00 – 19:59
> * Thứ Bảy và Chủ Nhật: (i) 09:00 – 11:59 và (ii) 16:00 – 23:59

📌LƯU Ý:•Đối với ĐTTX gia nhập từ 01/11/2023:cấp Đại sứ được ghi nhận theo thông tin tại thời điểm đăng ký.•Đối với ĐTTX gia nhập trước ngày 01/11/2023:vui lòng đăng ký lại cấp Đại sứ mớitại đây(hạn chót: 23h59p ngày 12/11/2023). Nếu ĐTTX không đăng ký cấp Đại sứ mới trong thời gian này, Green SM Bike mặc định: Đại sứ cấp 1 -> Đại sứ Xanh Bike 8 giờ, Đại sứ cấp 2 -> Đại sứ Xanh Bike 5h.• Tất cả ĐTTX có thể đăng ký thay đổi cấp Đại sứ sau đó và được chuyển đổi vào mỗi thứ 2 đầu tiên hàng tháng.

Cơ hội vàng để gia tăng thu nhập đây rồi, Đối tác Tài xế mau mau đăng ký cấp Đại sứ ngay thôi!!
