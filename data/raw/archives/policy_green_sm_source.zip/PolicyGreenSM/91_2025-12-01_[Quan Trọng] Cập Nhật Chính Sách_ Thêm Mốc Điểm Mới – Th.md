# [Quan Trọng] Cập Nhật Chính Sách: Thêm Mốc Điểm Mới – Thưởng Trong Tầm Tay!

- **Ngày đăng:** 2025-12-01
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-xanh-sm-bike-tai-ha-noi-tphcm-binh-duong-dong-nai](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-xanh-sm-bike-tai-ha-noi-tphcm-binh-duong-dong-nai)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Đối tác Tài xế thân mến,

Nhằm hỗ trợ Đối tác vận doanh hiệu quả, đảm bảo quyền lợi và tối ưu thu nhập trong quá trình hoạt động,Green SM Bikethông báo đến Đối tác về việc cập nhật chính sách thu nhập,áp dụng từ ngày 01/12/2025như sau:

✅Nội dung cập nhật:

- Bổ sung mức thưởng tuần cấp 2

- Điều chỉnh điều kiện nhận thưởng tuần

📍Khu vực áp dụng:Hà Nội, TP.Hồ Chí Minh, Bình Dương, Đồng Nai

Toàn bộ nội dung chi tiết, Đối tác Tài xế vui lòng tham khảo trong ảnh bên dưới.

![[QUAN TRỌNG] CẬP NHẬT CHÍNH SÁCH: THÊM MỐC ĐIỂM MỚI - THƯỞNG TRONG TẦM TAY!](https://cdn.xanhsm.com/2025/12/50a5eaf3-1_chinh-sach-thu-nhap-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THU NHẬP DÀNH CHO TÀI XẾ XANH SM BIKE
> 
> Áp dụng từ ngày 01/12/2025
> 
> **TỔNG THU NHẬP GỘP** = Chia sẻ doanh số (1) + Thưởng tuần (2) + Thưởng khác (nếu có) (3)
> 
> ## (1) Chia sẻ doanh số
> 
> **CHIA SẺ DOANH SỐ = 70% x DOANH SỐ**
> 
> ## GHI CHÚ:
> 
> *   Doanh số bao gồm cả các phí yêu cầu đặc biệt của dịch vụ Xanh Express (giao tận tay, phí giao hàng cồng kềnh...)
> *   Mức chia sẻ doanh số chưa bao gồm khoản khấu trừ Thuế Thu nhập cá nhân (PIT) & thuế GTGT (VAT)
> ```

![[QUAN TRỌNG] CẬP NHẬT CHÍNH SÁCH: THÊM MỐC ĐIỂM MỚI - THƯỞNG TRONG TẦM TAY!](https://cdn.xanhsm.com/2025/12/abec4720-2_thuong-tuan-hn-hcm-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> ## CHÍNH SÁCH THU NHẬP DÀNH CHO TÀI XẾ XANH SM BIKE
> Áp dụng từ ngày 01/12/2025
> 
> ### (2) THƯỞNG TUẦN
> Khu vực áp dụng: Hà Nội, TP.Hồ Chí Minh, Bình Dương và Đồng Nai
> 
> | MỨC ĐIỂM THƯỞNG        | MỨC THƯỞNG CẤP 1 | MỨC THƯỞNG CẤP 2 |
> |------------------------|------------------|------------------|
> | 400 - dưới 700 điểm     | 200.000 VNĐ      | 160.000 VNĐ      |
> | 700 - dưới 1100 điểm    | 400.000 VNĐ      | 320.000 VNĐ      |
> | 1100 - dưới 1400 điểm   | 800.000 VNĐ      | 640.000 VNĐ      |
> | Từ 1400 điểm trở lên   | 1.200.000 VNĐ    | 960.000 VNĐ      |
> 
> | Khu vực                          | Điều kiện áp dụng                    | Mức thưởng cấp 1 | Mức thưởng cấp 2 |
> |----------------------------------|--------------------------------------|------------------|------------------|
> | Hà Nội                           | Số ngày vận doanh                    | >= 5 ngày        | 4 ngày           |
> |                                  | Tỷ lệ nhận chuyến, hoàn thành chuyến | >= 85%           | >= 85%           |
> | TP.Hồ Chí Minh, Bình Dương, Đồng Nai | Số ngày vận doanh                    | >= 5 ngày        | 4 ngày           |
> |                                  | Tỷ lệ nhận chuyến, hoàn thành chuyến | >= 90%           | >= 90%           |

![[QUAN TRỌNG] CẬP NHẬT CHÍNH SÁCH: THÊM MỐC ĐIỂM MỚI - THƯỞNG TRONG TẦM TAY!](https://cdn.xanhsm.com/2025/12/74d896e5-3_bang-quy-doi-diem-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP DÀNH CHO TÀI XẾ XANH SM BIKE
> **Áp dụng từ ngày 01/12/2025**
> 
> ## BẢNG QUY ĐỔI ĐIỂM THƯỞNG
> 
> | Dịch vụ             | 6h00-8h59 | 11h00-13h59 | 16h00-18h59 | 9h00-10h59, 14h00-15h59, 19h00-21h59, 22h00-5h59 |
> |---------------------|-----------|-------------|-------------|---------------------------------------------------|
> | Xanh SM Bike        | 10        | 5           | 10          | 5                                                 |
> | Xanh Express siêu tốc | 5         | 10          | 5           | 5                                                 |
> | Xanh Express 2h     | 10        | 20          | 10          | 10                                                |
> | Xanh SM Ngon        | 15        | 30          | 30          | 15                                                |
> 
> **Lưu ý:**
> * Bổ sung điểm thưởng khung giờ 22h00 - 5h59
> * Đơn giao hàng đa điểm được tính theo số điểm giao

![250226_Quy dinh doanh so toi thieu](https://cdn.xanhsm.com/2026/02/4ec90c0b-250226_quy-dinh-doanh-so-toi-thieu-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> XANH SM
> 
> Áp dụng từ ngày 23/02/2026
> 
> **CHÍNH SÁCH DOANH SỐ TỐI THIỂU DÀNH CHO TÀI XẾ XANH SM BIKE**
> 
> | Khu vực                                                                                             | Mức khoán doanh số tối thiểu | Mức xử phạt                                                                                                                                                             |
> | :-------------------------------------------------------------------------------------------------- | :-------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Hà Nội                                                                                              | 1.400.000 VNĐ /tuần         | Trong trường hợp **không đạt** mức doanh số tối thiểu, Đối tác Tài xế sẽ bị truy thu **20% phần Doanh số khoán chưa đạt** bằng hình thức Trừ Ví tài xế |
> | TP.Hồ Chí Minh (bao gồm Bình Dương), Đồng Nai                                                      | 1.100.000 VNĐ /tuần         |                                                                                                                                                                         |
> | Đà Nẵng                                                                                             | 1.000.000 VNĐ /tuần         |                                                                                                                                                                         |
> | Quảng Ninh, Hải Phòng, Nghệ An, Huế, Khánh Hòa, TP.Hồ Chí Minh (khu vực Bà Rịa - Vũng Tàu cũ) | 500.000 VNĐ /tuần           |                                                                                                                                                                         |
> ```

![250226_Quy dinh van doanh](https://cdn.xanhsm.com/2026/02/a5938e45-250226_quy-dinh-van-doanh-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH QUẢN LÝ VẬN DOANH DÀNH CHO TÀI XẾ XANH SM BIKE
> 
> ## QUY ĐỊNH TRỰC TUYẾN & TỶ LỆ VẬN HÀNH
> 
> | Tiêu chí             | Nội dung                                                                                                                                                                                                                                                                                                                      |
> | -------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Quy định trực tuyến** | - Cảnh báo nếu Đối tác không trực tuyến/không phát sinh chuyến xe trong 02 ngày liên tiếp. <br> - Công ty sẽ tiến hành thu hồi xe và thu phí sử dụng xe nếu 05 ngày liên tiếp Đối tác không trực tuyến/không phát sinh chuyến xe mà không có lý do hợp lệ. <br> - Áp dụng phí sử dụng xe đối với các ngày không vận doanh vượt quy định, cụ thể: Thu phí sử dụng xe 50.000 VNĐ/ngày từ ngày không vận doanh thứ 5 trở đi/tháng. |
> | **Quy định tỷ lệ vận hành** | - Trường hợp Đối tác Tài xế có tỷ lệ chấp nhận chuyến dưới 50%: Hệ thống sẽ mặc định bật tính năng "Nhận chuyến tự động" tới 23h59 của ngày vận doanh đó.                                                                                                                                                                |

Trong thời gian tới, Green SM sẽ tiếp tục theo dõi, đánh giá hiệu quả chính sách để có điều chỉnh phù hợp với nhu cầu thực tiễn và cam kết đồng hành cùng Đối tác trên hành trình tăng trưởng bền vững.

Một số giải đáp liên quan đến chính sách, vui lòng tham khảotại đây

Xin cảm ơn và chúc Đối tác Tài xế vận doanh an toàn – hiệu quả – thu nhập vượt trội!

Trân trọng,

Đội ngũ Green SM Bike
