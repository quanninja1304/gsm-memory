# [Cập nhật mới] Điều chỉnh chính sách thưởng dành cho dịch vụ Green SM Mini

- **Ngày đăng:** 2026-03-13
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/dieu-chinh-chinh-sach-thuong-dich-vu-green-sm-mini-03-2026](https://www.greensm.com/vn-vi/news/dieu-chinh-chinh-sach-thuong-dich-vu-green-sm-mini-03-2026)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm đảm bảo cho Bác Tài Xanh khi vận doanh dịch vụ Green SM Mini được hưởng đầy đủ quyền lợi thu nhập, chính sách thưởng của dịch vụ sẽ có những điều chỉnh mới, cụ thể như sau:

- Thời gian áp dụng: Áp dụng từ kỳ lương Tháng 3/2026

- Đối tượng áp dụng: Bác Tài Xanh hoạt động dịch vụ Green SM Mini

CHI TIẾT CHÍNH SÁCH THƯỞNG

| Chính sách | Chi tiết |
| --- | --- |
| Hỗ trợ phí sạc xe | Bác Tài Xanh hoạt động dịch vụ Green SM Mini sẽ được hoàn chi phí sạc 50.000VNĐ/ngày trong 03 tháng đầu kể từ ngày chạy dịch vụ Xanh Mini nếu thỏa mãn các điều kiện sau:– Tỷ lệ nhận chuyến tối thiểu từ 90%– Tỷ lệ hoàn thành chuyến tối thiểu từ 90%– Hoàn thành tối thiểu từ 08 chuyến/ngày với doanh số trung bình 50.000 VNĐ/chuyến. |
| Thưởng “Đảm bảo thu nhập” | – Phạm vi áp dụng: Hà Nội, TP HCM (địa giới hành chính cũ) và các tỉnh còn lại– Thời gian áp dụng: Trong 03 tháng đầu kể từ ngày chạy dịch vụ Green SM Mini– Mức ĐBTN: 600.000 VNĐ/ngày |
| Điều kiện áp dụng chung |
| Tỷ lệ nhận chuyến tối thiểu từ 90% |
| Tỷ lệ hoàn thành chuyến tối thiểu từ 90% |
| Đảm bảo 100% tuân thủ lệnh phân ca của Đội xe |
| Điều kiện áp dụng riêng |
| Đối với Hà Nội & Tp. Hồ Chí Minh(theo địa giới hành chính cũ) | Đối với các tỉnh/thành phố còn lại |
| Hoàn thành tối thiểu từ 08 chuyến/ngày | Hoàn thành tối thiểu từ 06 chuyến/ngày |
| CT Tài xế thân thiết (Loyalty) | Áp dụng theo CS hiện hành giống với Bác Tài Xanh Taxi chi tiết tại đây:CHƯƠNG TRÌNH TÀI XẾ THÂN THIẾT LOYALTY / Green SM |
| Thưởng cho KOC | Áp dụng theo CS hiện hành giống với Bác Tài Xanh Taxi |
| Thưởng vượt công chuẩn tại Tp. HCM | Thưởng 200,000 VNĐ/ngày đối với Bác Tài Xanh Green SM Mni có ngày công làm việc vượt công chuẩn tối thiểu 1 ngày/tháng, tối đa không quá 800.000 VNĐ/tháng/Bác Tài Xanh. |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/03/0f3d68b2-xanh-mini-ky-luong-t3-768x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> **BÁC TÀI XANH**
> 
> **Điều chỉnh chính sách thưởng**
> **Dành cho dịch vụ**
> **Green SM Mini**
> 
> **1900 2088**
> **GREEN SM**
> 
> **XEM THÊM NGAY**
> ```

Mọi thắc mắc về chính sách, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Mến chúc Bác Tài Xanh vận doanh hiệu quả và an toàn!

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
