# Green SM Ngon công bố chính sách miễn phí dịch vụ cho Nhà Hàng mới trong dịp cuối năm

- **Ngày đăng:** 2025-10-01
- **Chuyên mục:** Nhà hàng, Ưu đãi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/xanh-sm-ngon-cong-bo-chinh-sach-mien-phi-dich-vu-cho-nha-hang-moi](https://www.greensm.com/vn-vi/news/xanh-sm-ngon-cong-bo-chinh-sach-mien-phi-dich-vu-cho-nha-hang-moi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Ngày 1/10/2025, Green SM Ngon chính thức công bố chính sách miễn phí dịch vụ cuối năm nhằm hỗ trợ các Đối tác nhà hàng giảm rào cản gia nhập và tối đa hóa lợi nhuận ngay trong giai đoạn cuối năm.

Cụ thể, từ nay đến31/10/2025, các nhà hàng, quán ăn và thương hiệu F&B đăng ký vàkích hoạt thành công gian hàngtrên Green SM Ngon sẽ nhận được hàng loạtquyền lợi hấp dẫn:

![các nhà hàng, quán ăn và thương hiệu F&B đăng ký và kích hoạt thành công gian hàng trên Green SM Ngon sẽ nhận được hàng loạt quyền lợi hấp dẫn](https://cdn.xanhsm.com/2025/10/7fd9d75d-250930_xanhdk-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM NGON
> 
> ## Quyền lợi
> 
> *   Merchant đủ điều kiện sẽ được miễn 100% phí dịch vụ từ ngày kích hoạt đến 31/12/2025.
> *   Vẫn áp dụng các loại phí khác (nếu có) như phí giao hàng, phí thanh toán điện tử.
> *   Được ưu tiên truyền thông trong các hoạt động giới thiệu merchant mới trên nền tảng.
> *   Được hỗ trợ gói hiển thị nhiều vị trí + Mã đồng tài trợ để tăng traffic trong giai đoạn ưu đãi.
> 
> ## Điều kiện
> 
> *   Đăng ký và kích hoạt thành công hết ngày 31/10/2025
> *   Giấy tờ pháp lý hợp lệ theo quy định pháp luật.
> *   KHÔNG cộng dồn với các ưu đãi đặc biệt khác trong cùng giai đoạn.
> *   Cập nhật đầy đủ và chính xác menu, giá bán, hình ảnh theo chuẩn guideline của Xanh SM Ngon.
> *   Duy trì trạng thái hoạt động ổn định trong giai đoạn ưu đãi: tối thiểu 90% ngày mở cửa/tháng, tham gia tối thiểu 01 gói Đồng tài trợ 50% trong 14 ngày kể từ ngày kích hoạt.
> *   Cho phép Xanh SM Ngon sử dụng tên, logo, hình ảnh thương hiệu trong các chiến dịch truyền thông.

*** Lưu ý:Sau giai đoạn ưu đãi, merchant tiếp tục tuân thủ hợp đồng và chuyển sang mức chiết khấu chuẩn (20%) từ ngày1/1/2026.

![Chiến lược của Green SM Ngon là kiến tạo thói quen tiêu dùng – nơi người Việt ưu tiên lựa chọn nền tảng Việt cho những bữa ăn hàng ngày. ](https://cdn.xanhsm.com/2025/10/07d8aa43-1-1024x686.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> XANH SM
> NGON
> ```

Chiến lược của Green SM Ngon là kiến tạo thói quen tiêu dùng – nơi người Việt ưu tiên lựa chọn nền tảng Việt cho những bữa ăn hàng ngày. 

Gia nhập mạng lưới đối tác củaGreen SM Ngonngay hôm nay để cùng kiến tạo bản đồ ẩm thực Việt sống động, khai phá hàng triệu nhu cầu tiêu dùng mới và dẫn đầu cuộc đua doanh thu trong kỷ nguyên giao hàng trực tuyến.

Đăng ký ngay để được tư vấn tại:https://xanhsmmc.onelink.me/QOU8/mea3q5uj
