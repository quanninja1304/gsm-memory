# Cập nhật bộ quy tắc ứng xử dành cho Bác Tài Xanh Bike (Áp dụng từ 05/06/2026)

- **Ngày đăng:** 2025-12-15
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-bo-quy-tac-ung-xu-danh-cho-doi-tac-tai-xe-bike](https://www.greensm.com/vn-vi/news/cap-nhat-bo-quy-tac-ung-xu-danh-cho-doi-tac-tai-xe-bike)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Quý Đối tác Tài xế thân mến,

Với mong muốn tiếp tục nâng cao chất lượng dịch vụ, chất lượng đội ngũ Bác Tài Xanh, Green SM xin thông báo cập nhật “Bộ Quy tắc ứng xử” dành cho Bác Tài Xanh Bike áp dụng từ ngày 05/06/2026. Thông tin chi tiết như sau:

- Đối tượng áp dụng:Bác Tài Xanh Bike

- Thời gian áp dụng:Từ05/06/2026cho đến khi có thông báo mới

- Nội dung cập nhật:Bổ sung hành vi nhóm lỗi Nhóm 2, Nhóm 4

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/09/debb7d9d-xanh-sm_banner-express-qtux-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> XANH SM
> 
> ## CẬP NHẬT
> # BỘ QUY TẮC ỨNG XỬ
> DÀNH CHO ĐỐI TÁC TÀI XẾ XANH SM BIKE
> 
> **Các từ ngữ khác xuất hiện trong hình:**
> * XANHSM
> * XANH SM
> * WSHNY
> ```

Cập nhật bộ quy tắc ứng xử dành cho Bác Tài Xanh Bike (Áp dụng từ 05/06/2026)

I. QUY TẮC ỨNG XỬ

1. Đối với khách hàng

1.1. Cung cấp dịch vụ chuyên nghiệp cho khách hàng đảm bảo Tiêu chuẩn dịch vụ của Green SM.

1.2. Tôn trọng quyền riêng tư và bảo mật thông tin của khách hàng.

1.3. Đảm bảo an toàn tuyệt đối cho khách hàng (cả về thể chất và tinh thần).

2. Đối với bản thân Đối tác Tài xế

2.1. Tuân thủ quy định đồng phục của Green SM.

2.2. Trung thực trong quá trình thực hiện Hợp đồng hợp tác với Green SM.

2.3. Tuân thủ đúng các quy định/hướng dẫn thực hiện, Tiêu chuẩn dịch vụ Green SM trong quá trình hợp tác.

2.4. Tuyệt đối tuân thủ quy định pháp luật trong quá trình hoạt động.

3. Đối với tài khoản ứng dụng và tài sản/thiết bị được Green SM cung cấp:

3.1. Sử dụng tài khoản ứng dụng đúng quy định. Đối tác Tài xế cần tuân thủ quy định bảo mật tài khoản và không được chia sẻ tài khoản ứng dụng

của mình với các cá nhân khác.

3.2. Bảo quản và giữ gìn các tài sản/thiết bị được Green SM cung cấp theo thỏa thuận với Green SM và quy định pháp luật.

4. Hình thức xử lý vi phạm Quy tắc ứng xử (Điều chỉnh và bổ sung)

4.1 Nhóm 1: Các lỗi đặc biệt nghiêm trọng

4.1.1. Hình thức xử lý: Chấm dứt Hợp đồng hợp tác vĩnh viễn và/hoặc trừ khoản tiền tối thiểu từ 2.000.000 đồng tương đương với tỷ lệ giảm tương ứng trên Khoản chia sẻ doanh số cơ bản, đồng thời yêu cầu bồi hoàn toàn bộ số tiền gian lận và/hoặc toàn bộ chi phí bồi thường thiệt hại mà Green SM đã trả thay Đối tác Tài xế cho Khách hàng/Người thứ ba phải chịu do hành vi vi phạm của Đối tác Tài xế gây ra, đồng thời không được Thưởng tuần (nếu có), gồm các hành vi gian lận nhằm trục lợi từ khách hàng, ứng dụng/chính sách của Green SM bao gồm nhưng không giới hạn một trong các vi phạm sau:

- Hủy cuốc xe nhưng vẫn chở khách hàng và/hoặc lợi dụng chính sách trả hàng của đơn hàng giao hàng/Food.

- Lợi dụng lỗ hổng hệ thống để trục lợi.

- Thu thêm tiền của khách hàng trái quy định.

- Sử dụng phương tiện của Green SM để làm việc/hợp tác với đơn vị khác.

- Can thiệp vào các chương trình khuyến khích, thưởng, khuyến mại (lạm dụng, trục lợi…).

- Tự tạo, phối hợp/thông đồng cùng người khác/khách hàng/quán ăn/nhà hàng tạo chuyến xe/đơn hàng ảo nhằm trục lợi.

- Dùng các ứng dụng hoặc phần mềm khác để trục lợi hoặc tạo ưu thế trong việc nhận chuyến xe.

- Thực hiện hành vi trộm cắp, phá hoại tài sản bao gồm tài sản công ty và tài sản khách hàng, quán ăn/nhà hàng, đối tác công ty.

- Gian dối tiền gửi xe mặc dù không phát sinh tiền gửi xe hoặc giá trị gửi xe ít hơn thực tế thông báo để hỗ trợ

- Sử dụng phương tiện không khớp với thông tin tài khoản; cho mượn hoặc cho người khác sử dụng tài khoản/phương tiện/trang thiết bị của mình mà Green SM cung cấp dưới bất kỳ hình thức nào.

- Có phản ánh từ khách hàng từ 04 lần trở lên (bao gồm các trường hợp có bằng chứng và không có bằng chứng) trong vòng 30 ngày.

- Vi phạm lần 4 đối với các lỗi Nhóm 2 và Nhóm 3.

4.1.2. Hình thức xử lý: Chấm dứt Hợp đồng hợp tác vĩnh viễn và/hoặc trừ vào Tiền đặt cọc khoản tiền tương đương toàn bộ chi phí bồi thường thiệt hại mà Green SM đã trả thay Đối tác Tài xế cho Khách hàng/Người thứ ba phải chịu do hành vi vi phạm của đối tác Tài xế gây ra, đồng thời không được Thưởng tuần (nếu có), gồm các hành vi vi phạm sau đây:

- Vi phạm Luật an toàn giao thông gây hậu quả nghiêm trọng (tai nạn, va chạm…). Không hỗ trợ khách hàng khi xảy ra tai nạn/sự cố.

- Sử dụng xe vào mục đích vi phạm pháp luật; chống đối người thi hành công vụ.

- Không báo bộ phận hỗ trợ của Green SM ngay khi xảy ra tai nạn/sự cố có khách hàng/hàng hóa trên phương tiện và trốn tránh trách nhiệm liên quan.

- Thái độ, hành vi không đúng mực, khiếm nhã, quấy rối khách hàng/nhà hàng (nhắn tin, gọi điện gạ gẫm vì bất cứ mục đích nào).

- Chiếm dụng/Sử dụng trái phép tài sản, hàng hóa của khách hàng/nhà hàng/quán ăn.

- Sử dụng giấy tờ giả mạo (giấy phép lái phương tiện, căn cước công dân…).

- Tàng trữ/vận chuyển, sử dụng ma túy/vũ khí trên xe với bất kỳ mục đích nào. Sử dụng rượu/bia/chất kích thích/thuốc lá trong khi đang thực hiện chuyến xe/đơn hàng và thực hiện các hành vi vi phạm pháp luật khác. Hút thuốc lá tại địa điểm có quy định cấm hút thuốc lá.

- Cư xử thô lỗ, to tiếng với khách hàng/nhà hàng/quán ăn, hoặc các đối tượng khác khi có sự hiện diện của khách hàng/nhà hàng/quán ăn. Phân biệt chủng tộc/tôn giáo/quốc tịch/vùng miền/ngoại hình/giới tính dưới bất kỳ hình thức nào.

- Sử dụng thông tin của khách hàng/nhà hàng/quán ăn ngoài mục đích để thực hiện dịch vụ cho khách hàng theo Hợp đồng hợp tác với Green SM gây ảnh hưởng tới khách hàng/nhà hàng/quán ăn (đăng lên các trang MXH, các cộng đồng, nhắn tin, gọi điện làm phiền Khách hàng/nhà hàng/quán ăn sau khi hoàn tất chuyến xe, tiết lộ/mua bán thông tin khách hàng/nhà hàng/quán ăn …).

- Tự ý ghi hình/chụp ảnh và phát tán/sử dụng hình ảnh của khách hàng/nhà hàng/quán ăn.

- Sử dụng đồng phục/thương hiệu của Green SM cho mục đích cá nhân gây ảnh hưởng hình ảnh/uy tín của Green SM. Bất hợp tác, chống đối hoặc phản ứng tiêu cực, kêu gọi, lôi kéo người khác thực hiện chống đối với Green SM dưới bất cứ hình thức nào.

- Truyền thông, phát ngôn sai sự thật về cán bộ nhân viên hoặc hoạt động của Green SM dưới bất cứ hình thức nào.

- Yêu cầu/gợi ý khách hàng: thanh toán thêm cước, bo/tip, trả phí cầu đường cao hơn thực tế, và các khoản tiền không đúng theo quy định. Không trả lại tiền thừa cho khách hàng.

- Mặc đồng phục hoặc mang bất kỳ vật dụng, thiết bị nào có thể hiện dấu hiệu nhận diện của đơn vị khác hoạt động trong cùng lĩnh vực với Green SM khi cung cấp dịch vụ cho khách hàng thông qua Ứng dụng Green SM.

- Có hành vi tự ý ghép đơn hàng ngoài ứng dụng, cập nhật sai trạng thái đơn hàng làm ảnh hưởng đến thời gian giao hàng và chất lượng dịch vụ.

- Bao che lỗi nghiêm trọng của các đối tác khác của Green SM.

- Cố tình cung cấp thông tin sai sự thật, không hợp tác theo yêu cầu của Green SM về các vấn đề liên quan hoặc phát sinh từ việc thực hiện Hợp đồng hợp tác (bao gồm nhưng không giới hạn các sự vụ phát sinh với khách hàng, quyền kiểm tra của Green SM theo Hợp đồng hợp tác…).

- Vi phạm lỗi Nhóm 2 nhưng bị khách hàng tố cáo, gây ảnh hưởng đến hình ảnh và uy tín của Green SM, khiến Green SM phải bồi thường cho Khách hàng.

4.2 Nhóm 2: Các lỗi nghiêm trọng

4.2.1. Hình thức xử lý: Khấu trừ số tiền 200.000 đồng khi vi phạm lần 1; 500.000 đồng khi vi phạm lần 2 và 1.000.000 đồng khi vi phạm lần 3 vào Ví Tài xế và không được Thưởng tuần (nếu có) đối với Đối tác Tài xế, gồm các hành vi vi phạm sau đây:

- Kéo dài thời gian hoàn thành chuyến /hủy chuyến sai lý do/hủy chuyến không thông báo với Khách hàng/Nhà hàng và hoặc bồi thường chi phí hàng hóa quy định tại mục 4.4.3.4.

- Tranh giành khách hàng, ngăn cản hoặc gây trở ngại cho đối tác khác trong việc phục vụ khách hàng.

- Môi giới, chuyển khách hàng cho tài xế khác phục vụ hoặc nhận khách hàng do môi giới từ tài xế khác.

- Chấm dứt hành trình/yêu cầu khách hàng xuống phương tiện giữa đường/bỏ hàng hóa khi khách hàng không yêu cầu.

- Vi phạm Luật an toàn giao thông khác: vượt đèn đỏ, vượt giới hạn tốc độ, lấn làn, đi ngược chiều, sử dụng điện thoại khi di chuyển

- Có phản ánh từ khách hàng liên tục một lỗi từ 2 lần trở lên trong vòng 07 ngày áp dụng đối với trường hợp chưa có bằng chứng rõ ràng.

- Nhận chuyến xe nhưng không đón khách hàng/chở hàng hóa.

- Không tuân thủ đúng quy định về diện mạo nêu tại Tiêu chuẩn dành cho Đối tác Tài xế Green SM Bike.

- Mua sai món/sai quán ăn, nhà hàng/giao nhầm đơn hàng hoặc làm hư hỏng mất vệ sinh an toàn thực phẩm đối với đơn hàng Food.

- Không trang bị đầy đủ túi giao đồ ăn theo quy định của Green SM khi thực hiện đơn hàng Food.

- Không tuân thủ hướng dẫn tại khu vực nhà hàng gây ảnh hưởng hình ảnh công ty.

- Không thực hiện đúng quy trình của đơn hàng Food/Giao hàng bao gồm:

- Không liên hệ khách hàng để xác nhận trước khi thực hiện nhận hàng hóa Express/Food để thực hiện đơn giao.

- Không đồng kiểm hàng hóa/kiểm tra món ăn/hóa đơn/muỗng, đũa…trước khi giao hàng.

- Cố tình giao sai hoặc kéo dài thời gian giao hàng, dẫn tới khách hàng từ chối nhận hàng.

- Không hoàn thành nghĩa vụ nạp ví để thanh toán phần thu hộ đối với đơn Giao hàng/Food trước 10h sáng ngày tiếp theo.

- Không hoàn thành nghĩa vụ hoàn hàng theo đúng quy định khi thực hiện giao hàng thất bại (đối với đơn hàng Express), trong mọi trường hợp Đối tác Tài xế buộc phải đền bù/bồi thường theo quy định tại mục 4.4.3.5.

13. Có thái độ không thân thiện với khách hàng mức độ nhẹ: không to tiếng, thô lỗ hay khiếm nhã.

4.2.2. Khấu trừ số tiền 500.000 đồng khi vi phạm lần 1; 1.000.000 đồng khi vi phạm lần 2 vào Ví Tài xế; chấm dứt hợp tác vĩnh viễn khi vi phạm lần 3 và không được Thưởng tuần (nếu có) đồng thời yêu cầu bồi hoàn toàn bộ số tiền gian lận đối với Đối tác Tài xế, gồm các hành vi vi phạm sau đây:

- Che biển kiểm soát và không vi phạm Quy định dịch vụ nào khác, ngoại trừ các trường hợp đang bị Cơ quan Công an xử lý.

4.3. Nhóm 3: Các lỗi nhỏ

Hình thức xử lý: khấu trừ số tiền 200.000 đồng/lần vi phạm (không quá 03 lần) vào Ví Tài xế và không được Thưởng tuần (nếu có) đối với Đối tác Tài xế, gồm các hành vi vi phạm sau đây:

- Nhận chuyến xe nhưng không đón khách hàng/chở hàng hóa, sau đó tự hủy hoặc yêu cầu khách hàng hủy.

- Trả khách hàng/hàng hóa sai điểm đến (do lỗi định vị) mà không được sự đồng ý của khách hàng hoặc chở khách hàng/hàng hóa không đúng lộ trình tối ưu.

- Không hợp tác khi được mời đến làm việc; Không cung cấp đủ, đúng yêu cầu/thời hạn về hồ sơ/thông tin và không có lý do chính đáng.

- Thực hiện chuyến xe không đúng dịch vụ trên ứng dụng (giao hàng trên dịch vụ chở khách, nhận chở khách hàng trên dịch vụ giao hàng…).

- Không tuân thủ theo Tiêu chuẩn hành vi phục vụ theo Tiêu chuẩn dịch vụ xe máy điện.

- Vuốt đón/trả khách sớm trước khi hoàn thành chuyến.

- Chụp ảnh hàng hóa/món ăn giao nhận với các cuốc xe giao hàng/Food sai tiêu chuẩn.

4.4. Nhóm 4: Các hành vi vi phạm khác

4.4.1. Khóa Tài khoản (tạm dừng hợp tác) cho đến khi làm rõ trách nhiệm để xem xét xử lý (kể cả xét chuyển Cơ quan Công an xử lý nếu đủ căn cứ và đền bù theo giá trị thiệt hại cụ thể, gồm các hành vi vi phạm sau đây:

- Không bảo dưỡng định kỳ theo mốc Km quy định, trong trường hợp Đối tác Tài xế không thực hiện trong vòng 5 ngày kể từ ngày tạm khóa tài khoản sẽ chuyển thành lỗi Nhóm 1.

- Không đưa xe tới địa điểm Green SM yêu cầu để kiểm soát thân vỏ và dán lại tem thiết bị sau bảo dưỡng.

- Không theo dõi bảo quản phương tiện dẫn tới hư hỏng.

- Làm mất phương tiện/phụ kiện/linh kiện/giấy tờ phương tiện.

- Thường xuyên để dung lượng pin dưới 20% gây hư hỏng.

- Không bảo quản tốt dẫn tới sạc pin bị móp/vỡ/vào nước.

- Va chạm gây gãy/vỡ/trầy xước lớn tới ngoại quan phương tiện.

- Tự ý đem phương tiện đi sửa chữa/bảo dưỡng ngoài hệ thống xưởng.

- Tự ý tráo đổi/thay thế/độ chế/thêm bớt linh kiện phụ tùng của phương tiện hoặc cầm cố, thế chấp phương tiện.

- Làm mất/hư hỏng hàng hóa của khách hàng/nhà hàng/quán ăn.

- Vận chuyển hàng hóa thuộc danh mục hàng hóa cấm lưu thông, hàng hóa không được vận chuyển theo quy định của Pháp luật.

- Phương tiện không đảm bảo các tiêu chuẩn an toàn theo quy định của Pháp luật.

4.4.2. Khấu trừ số tiền 200.000 đồng khi vi phạm lần 1 vào Ví Tài xế và không được Thưởng tuần; Khấu trừ số tiền 500.000 đồng khi vi phạm từ lần 2 vào Ví Tài xế và không được Thưởng tuần đối với lỗi sau đây:

- Không tham gia các buổi hướng dẫn theo thông báo của Green SM; Không đạt các bài kiểm tra về Chất lượng dịch vụ theo tiêu chuẩn Green SM

4.4.3. “Tài khoản ví” của Đối tác Tài xế sẽ bị trừ số tiền tương đương nghĩa vụ tài chính mà Đối tác Tài xế phải thực hiện với Green SM; hành vi này sẽ chuyển sang Nhóm 1 sau 05 ngày, khi:

- Đối tác Tài xế không thực hiện đầy đủ nghĩa vụ tài chính với Green SM theo quy định (15 ngày kể từ ngày đến hạn).

- Đối tác Tài xế có trách nhiệm bồi thường chi phí thu hồi phương tiện thực tế (cấn trừ tiền đặt cọc) tối thiểu không thấp hơn 500.000 đồng/xe khi: Không chấp hành việc thu hồi/hoàn trả phương tiện về đúng địa điểm do Green SM chỉ định khi chấm dứt hợp tác hoặc theo yêu cầu/thông báo của Green SM.

- Đối tác Tài xế sẽ không được hoàn lại khoản tiền đặt cọc sau khi đã trừ các nghĩa vụ tài chính liên quan đến việc Chấm dứt hợp tác nếu Không hợp tác hoàn thiện thủ tục Thanh lý Hợp đồng hợp tác với Green SM.

- Đối tác Tài xế có trách nhiệm bồi hoàn toàn bộ chi phí hàng hóa của đơn hàng Green SM Food nếu đơn hàng bị hủy (do Tài xế chọn sai lý do) và không do lỗi/yêu cầu của Nhà hàng /Khách hàng.

- Đối tác Tài xế có trách nhiệm bồi hoàn toàn bộ giá trị hàng hóa của đơn hàng theo giá trị Green SM Express xác nhận với Đối tác/Khách hàng khi phát sinh các trường hợp quá hạn hoàn hàng/thất lạc hàng hóa và không do lỗi/yêu cầu của Khách hàng.

4.4.4. Trường hợp Đối tác Tài xế có tỷ lệ hoàn thành chuyến và/hoặc tỷ lệ chấp nhận chuyến <70% (tính trên tất cả các dịch vụ) sẽ bị xử phạt như sau:

- Khấu trừ số tiền 100.000 đồng khi vi phạm 03 ngày/tuần vào Ví Tài xế đối với Đối tác Tài xế đạt trung bình 5 đơn/ngày (*) trở lên.

- Khấu trừ số tiền 200.000 đồng khi vi phạm 03 ngày/tuần vào Ví Tài xế đối với Đối tác Tài xế đạt trung bình dưới 5 đơn/ngày (*);

- Chấm dứt Hợp đồng hợp tác nếu vi phạm 03 lần (tuần) liên tiếp.

(*) Số đơn trung bình được tính trên ngày vận doanh/tuần

4.4.5. Khấu trừ số tiền 50.000 đồng/ngày vi phạm đối với Đối tác Tài xế Vi phạm quy định trực tuyến theo chính sách tùy từng thời điểm Green SM đã ban hành và thông báo tới các Đối tác.

- Đối tác Tài xế không vận doanh dưới 04 ngày/tháng: không thu phí sử dụng xe.

- Đối tác Tài xế không vận doanh trong tháng từ ngày thứ 5 trở lên: thu phí sử dụng xe 50.000đ/ngày.

- Đối tác Tài xế không vận doanh liên tiếp 5 ngày (không có lí do phê duyệt hợp lệ): Thu phí sử dụng xe 50.000đ/ngày và thu hồi xe.

(*) Chu kỳ tháng tính từ ngày 1 hàng tháng4.4.6. Đối tác Tài xế có thể bị tạm khóa nhận chuyến trong một khoảng thời gian khi vi phạm các nhóm lỗi 3,4 tùy theo chính sách quy định của Green SM từng thời kỳ.

Trân trọngĐội ngũ Green SM
