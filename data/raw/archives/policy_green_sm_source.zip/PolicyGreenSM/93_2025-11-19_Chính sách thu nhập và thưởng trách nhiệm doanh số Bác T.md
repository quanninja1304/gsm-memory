# Chính sách thu nhập và thưởng trách nhiệm doanh số Bác Tài Green SM Limo tại Depot Đà Nẵng 1

- **Ngày đăng:** 2025-11-19
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-limo-da-nang](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-limo-da-nang)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài thân mến,

Với mục đích hỗ trợ Bác Tài quản lý thu nhập một cách minh bạch và chủ động, Green SM xin thông báo vềChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấm công.

👉 Thời gian áp dụng: Từ20/11/2025cho đến khi có thông báo mới.👉 Chi tiết chính sách: Bác Tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/11/48ec2fb6-251118_chinhsachdanang-01-1.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP VÀ THƯỞNG TRÁCH NHIỆM DOANH SỐ
> 
> **Đối tượng áp dụng:** Bác Tài Xanh SM Limo tại Depot Đà Nẵng 1
> **Thời gian áp dụng:** Từ ngày 20/11/2025 cho đến khi có thông báo mới
> 
> ## Nội dung chính sách
> Mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công
> 
> ## THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> Xanh SM Limo
> 
> | Mức   | Doanh số (VNĐ/ngày)        | Tỷ lệ chia sẻ |
> | :---- | :------------------------- | :------------ |
> | Mức 0 | Dưới 1.000.000             | 25%           |
> | Mức 1 | Từ 1.000.000 đến dưới 1.300.000 | 30%           |
> | Mức 2 | Từ 1.300.000 đến dưới 1.500.000 | 35%           |
> | Mức 3 | Từ 1.500.000 đến dưới 1.800.000 | 40%           |
> | Mức 4 | Từ 1.800.000 đến dưới 2.100.000 | 44%           |
> | Mức 5 | Từ 2.100.000 trở lên       | 48%           |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/11/bc42b98f-251118_chinhsachdanang-02-1-1024x561.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # TIÊU CHUẨN CHẤM CÔNG
> 
> ## Xanh SM Limo
> 
> | Tháng áp dụng       | Tiêu chí                  | Từ T2 - T5  | Từ T6 - CN, ngày Lễ, Tết | Từ T2 - CN, ngày Lễ, Tết |
> | :------------------ | :------------------------ | :---------- | :----------------------- | :----------------------- |
> |                     | Tỷ lệ nhận cuốc           | 85%         | 85%                      | 80%                      |
> |                     | Tỷ lệ hoàn thành cuốc     | 85%         | 85%                      | 85%                      |
> | 4, 10, 11           | Doanh số (VNĐ/ngày)       | Từ 720.000  | Từ 720.000               | Từ 1.350.000             |
> | Các tháng còn lại   | Doanh số (VNĐ/ngày)       | Từ 800.000  | Từ 800.000               | Từ 1.500.000             |

Mọi thắc mắc Bác Tài vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác Tài vận doanh an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
