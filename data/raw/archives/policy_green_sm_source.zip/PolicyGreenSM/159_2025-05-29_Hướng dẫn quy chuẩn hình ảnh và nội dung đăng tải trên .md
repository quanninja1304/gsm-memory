# Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Green SM Merchant dành cho Nhà hàng

- **Ngày đăng:** 2025-05-29
- **Chuyên mục:** Nhà hàng
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/huong-dan-quy-chuan-hinh-anh-va-noi-dung-dang-tai-tren-ung-dung-xanh-sm-merchant-danh-cho-nha-hang](https://www.greensm.com/vn-vi/news/huong-dan-quy-chuan-hinh-anh-va-noi-dung-dang-tai-tren-ung-dung-xanh-sm-merchant-danh-cho-nha-hang)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Quý Đối tác Nhà hàng thân mến,

Nhằm đảm bảo tính đồng bộ về hình ảnh và nội dung trong toàn bộ hệ sinh thái Green SM Food, đồng thời thể hiện định vị cao cấp với tiêu chí chuẩn vị – chuẩn gu – chuẩn chất lượng 5 sao,Green SM Foodxin gửi đến Quý Đối tác Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Green SM Merchant.

Tài liệu này được xây dựng với mục tiêu:

- Tối ưu từng điểm chạm với người dùng trong quá trình trải nghiệm ứng dụng và lựa chọn món ăn.

- Hỗ trợ Đối tác vận hành hiệu quả, giảm thiểu sai sót trong quá trình triển khai nội dung.

Quy chuẩn chính thứcáp dụng từ ngày 23/05/2025, hy vọng tài liệu sẽ là công cụ hữu ích, giúp Quý Nhà hàng yên tâm vận hành và phát triển đồng hành cùng Green SM Food.

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/a5fdf5fe-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-3-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Quy chuẩn hình ảnh chung
> 
> | Yếu tố         | Quy chuẩn                                                                                                                                                                                                                                                                   |
> | :------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Loại hình ảnh  | Ảnh thật 100%, chụp món ăn thật, đúng với tên món ăn, không gây nhầm lẫn cho khách hàng                                                                                                                                                                                    |
> | Phong cách     | Tối giản – hiện đại – sạch sẽ – nhấn mạnh hình ảnh món ăn với các thành phần chính, tạo cảm giác ngon miệng                                                                                                                                                              |
> | Ánh sáng       | Tự nhiên hoặc đèn trắng. Không dùng filter vàng, cam, hoặc ánh sáng loang lổ                                                                                                                                                                                               |
> | Bối cảnh       | Nền trung tính (gỗ sáng, đá trắng, bàn gỗ nhạt). Tránh nền bẩn, phông rối                                                                                                                                                                                                  |
> | Đạo cụ         | Có thể dùng khăn ăn, bộ muỗng đũa, ly nước - nhưng phải sạch sẽ và tinh tế                                                                                                                                                                                                   |
> | Sắp đặt món ăn | Gọn gàng, có bố cục. Không chụp lộn xộn, trào nước, rơi vãi                                                                                                                                                                                                                 |
> | Chụp món combo | Mỗi món riêng biệt + thêm ảnh combo tổng thể                                                                                                                                                                                                                               |
> | Yếu tố con người | Không có. Trừ trường hợp lifestyle (tay gắp đồ ăn), tuyệt đối không thấy mặt                                                                                                                                                                                           |
> | Màu món ăn     | Tươi ngon, bóng, mọng. Không thâm, xỉn, không ngon mắt, cảm giác không tươi, hồng                                                                                                                                                                                          |
> 
> 03 Quy định chung

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/8c5c0dc8-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-4-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Quy chuẩn hình ảnh – Do & Don'ts
> 
> **Do:** Chụp món ăn thật, nguyên vẹn, trình bày đẹp. Món ăn phải ở trung tâm hình, nhìn rõ thành phần.
> 
> **Don't:** Dùng ảnh không có bản quyền, tạo bằng AI, vẽ minh họa còn nguyên watermark, chứa logo của bất kì thương hiệu nào. Ảnh bị cắt quá nhiều, mờ, không rõ thành phần.
> 
> 03 Quy định chung

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/5ecf3f18-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-5-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Quy chuẩn hình ảnh – Do & Don'ts
> 
> **Do:** Ánh sáng vừa phải, giữ nguyên màu món ăn.
> 
> **Don't:** Ánh sáng quá mạnh hoặc quá yếu, không nhìn rõ món, làm đổi màu món ăn, nhìn kém ngon/thiếu an toàn
> 
> 03 Quy định chung

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/ef53156b-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-6-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Quy chuẩn hình ảnh – Do & Don'ts
> 
> **Do:** Background sạch, tinh tế, màu trung tính
> 
> **Don't:** Nền bẩn, nền rối, có vật dụng cá nhân (điện thoại, chén ăn dở...)
> 
> EXPRESS
> 
> 03 Quy định chung

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/77c5dcfd-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-7-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Quy chuẩn hình ảnh – Do & Don'ts
> 
> **Do:** Ảnh chụp theo 2 góc: top-down và 45°. Nếu chụp góc khác phải đảm bảo hình dạng món ăn vẫn chuẩn xác.
> 
> **Don't:** Chụp góc nghiêng lệch, bóp méo hình ảnh món ăn, gây hiểu nhầm cho người dùng.
> 
> ---
> 03 | Quy định chung

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/0576a3fd-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-8-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Quy chuẩn nội dung
> 
> ## Giọng văn thương hiệu
> 
> * Tuân theo các quy chuẩn nội dung & giọng văn trong bộ quy chuẩn thương hiệu chung của Xanh SM
> * Giọng tinh gọn - chuyên nghiệp - dễ hiểu - chính xác. Dùng ngôn ngữ chuẩn tiếng Việt
> * Hạn chế từ ngữ sáo rỗng, khẩu hiệu lập lại
> * Nhấn mạnh các USP: Chuẩn ngon, chuẩn bị, chuẩn giờ, 5 sao, xanh, bền vững....
> * Không phô trương quá mức, không giật tít
> 
> ## Minh họa một số từ ngữ nên và không nên dùng
> 
> | Nên                                      | Không nên                                        |
> | :-------------------------------------- | :----------------------------------------------- |
> | "Nguyên liệu chọn lọc", "gà hữu cơ", "tươi mỗi ngày" | "Ăn là ghiền", "ngon bá cháy", "ngon xỉu lên xỉu xuống" |
> | "Bếp trưởng", "công thức riêng", "kiểm định vệ sinh" | "Chế biến kiểu nhà làm", "giống mẹ nấu"         |
> | "Rau sạch, cá tươi, bò Mỹ"               | "Bò bình dân", "rau luộc ăn chống đói"          |
> | "Giao chuẩn giờ", "bảo hiểm món ăn"     | "Ship lẹ lẹ ăn liền", "giao cực nhanh luôn nè"  |
> 
> ## Cấu trúc thông tin món ăn
> 
> | Yếu tố         | Quy định cụ thể                                                                                                                                                                             |
> | :------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
> | Tên món        | Có dấu, viết hoa đầu từ, không emoji.                                                                                                                                                     |
> | Mô tả ngắn     | 1-2 câu mô tả đặc điểm nổi bật, nguyên liệu, cách chế biến đặc biệt. Chèn các từ ngữ khẳng định chất lượng món ăn                                                                        |
> | Lưu ý đặc biệt | Nếu có nguyên liệu dễ gây dị ứng: trứng, sữa, hải sản - cần ghi rõ                                                                                                                         |
> 
> ## Minh họa mô tả đúng và sai
> 
> | Nên                                                                                                                                                                                | Không nên                                                                                                                               |
> | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------- |
> | Cơm gà nướng sốt Teriyaki                                                                                                                                                           | Cơm gà Teriyaki ngon bá cháy!!!                                                                                                        |
> | Gà đùi tươi nướng tại chỗ, phủ sốt Teriyaki Nhật đặc trưng. Ăn kèm cải xanh luộc và cơm gạo dẻo thơm. Có chứa: nước tương, mè đen. | Gà nướng siêu ngon, nước sốt đặc biệt siêu cuốn luôn nhé cả nhà ơi!!! Ai không ăn là tiếc 😩 |
> 
> 03 Quy định chung

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/598fc092-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-10-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Merchant Setup (Bắt buộc có)
> 
> ## Ảnh quán ăn: cover
> *   Image size: 1200 x 675 pixel - Tỉ lệ 16:9
> *   Max size < 500 KB
> *   Resolution: 72 px/inch
> *   Định dạng: JPG, PNG
> *   Số lượng hình: 1 hình
> *   Nếu chưa có ảnh phù hợp, được dùng ảnh minh họa trong tối đa 30 ngày. Hình minh họa phải liên quan đến sản phẩm đang bán, không được chứa tên & logo của bất kì thương hiệu nào Ưu tiên dùng hình có bản quyền trong kho Xanh SM cung cấp
> 
> ## Ảnh quán ăn: avatar
> *   Image size: 750x750pixel Tỉ lệ 1:1
> *   Resolution: 72 px/inch
> *   Max size < 500 KB
> *   Định dạng: JPG, PNG
> *   Số lượng hình: 1 hình
> *   Nếu chưa có ảnh phù hợp, được dùng ảnh minh họa trong tối đa 30 ngày. Hình minh họa phải liên quan đến sản phẩm đang bán, không được chứa tên & logo của bất kì thương hiệu nào. Ưu tiên dùng hình có bản quyền trong kho Xanh SM cung cấp
> 
> ## Tên cửa hàng:
> *   Tạo trên admin: limit 225 ký tự
> *   Hiển thị tốt: 56 ký tự
> 
> ## Mô tả cửa hàng:
> *   Tạo trên admin: limit 225 ký tự
> *   Hiển thị tốt: 56 - 170 ký tự
> 
> ## Cuisine/danh mục mô tả:
> *   Hiển thị tốt: 32 ký tự
> *   Vd: Trà - Cà phê - Sinh tố
> 
> ## Xem gần đây
> Vô tình lướt qua, bất ngờ đang chờ đợi
> 
> ---
> 
> **Minh họa giao diện ứng dụng:**
> 
> **Hình ảnh 1: Màn hình đặt nhóm**
> *   **Tiêu đề:** Jollibee - Tân Hiệp
> *   **Đánh giá:** 4.2 (1230+)
> 
> **Hình ảnh 2: Màn hình Xem gần đây**
> *   **Tiêu đề:** Gà nướng Ô Ó O - Lê Văn Linh
> *   **Đánh giá:** 4.4 (1230+) · 2km
> 
> **Hình ảnh 3: Màn hình Đặt lại**
> *   **Tiêu đề:** Gà nướng O O O - Gà nước nhiều - Lê Văn...
> *   **Đánh giá:** 4.4 (1230+) · 2km
> *   **Tiêu đề:** Trà sữa Phúc Long
> *   **Đánh giá:** 4.4 (1230+) · 2km
> *   **Tiêu đề:** Gà nướng
> *   **Đánh giá:** 4.4
> 
> **Hình ảnh 4: Phần Xem gần đây**
> *   **Tiêu đề:** Gà nướng Ô Ó O - Gà nước nhiều - Lê Văn...
> *   **Đánh giá:** 4.4 (1230+) · 2km
> *   **Tiêu đề:** Trà sữa Phúc Long
> *   **Đánh giá:** 4.4 (1230+) · 2km
> *   **Tiêu đề:** Gà nư
> *   **Đánh giá:** 4.4

![Hướng dẫn quy chuẩn hình ảnh và nội dung đăng tải trên ứng dụng Merchant dành cho Nhà hàng](https://cdn.xanhsm.com/2025/05/6f13f397-gsm_mkt12_quy-chuan-hinh-anh-noi-dung-in-app-xanh-sm-ngon-images-11-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> # Menu Item Setup (Bắt buộc có)
> 
> **Ảnh món ăn:**
> * Cover: Tỉ lệ 1:1
> * Image size: 1200x1200px
> * Resolution: 72 px/inch
> * Max size <2MB
> * Định dạng: JPG
> * Số lượng hình: 4 hình
> * Nếu chưa có ảnh phù hợp, được dùng ảnh minh họa trong tối đa 30 ngày. Hình minh họa phải liên quan đến sản phẩm đang bán, không được chứa tên & logo của bất kì thương hiệu nào. Ưu tiên dùng hình có bản quyền trong kho Xanh SM cung cấp
> 
> **Tên món ăn:**
> * Tạo trên admin: limit 225 ký tự
> * Hiển thị tốt: 20-56 ký tự
> 
> **Mô tả món ăn:**
> * Tạo trên admin: limit 225 ký tự
> * Hiển thị tốt: 56-170 ký tự
> * Có thể tận dụng mô tả bằng AI dựa vào hình món ăn
> 
> ---
> 
> **Minh họa giao diện ứng dụng:**
> 
> *   **Giao diện trên cùng:**
>     *   Thời gian: 12:15
>     *   Tiêu đề: Kiểm tra món
>     *   Món ăn minh họa: Một bát mì tôm với trứng và rau.
>     *   Loại đồ uống: Trà sữa
> 
> *   **Giao diện sản phẩm:**
>     *   **Trái:**
>         *   Logo: XANH SM
>         *   Tên sản phẩm: Mì tôm thịt bò
>         *   Giá: 20.000₫
>     *   **Phải:**
>         *   Logo: XANH SM
>         *   Tên sản phẩm: Mì tôm hải sản + trứng
>         *   Giá: 20.000₫
> 
> *   **Ưu đãi hôm nay:**
>     *   **Trái:**
>         *   Ưu đãi: -25%
>         *   Tên sản phẩm: Combo Burger +... tây + Coca
>     *   **Giữa:**
>         *   Ưu đãi: -25%
>         *   Tên sản phẩm: Trà sữa Phúc Long
>         *   Giá: 20.000₫
>     *   **Phải:**
>         *   Ưu đãi: -25%
>         *   Tên sản phẩm: Com... tây
> 
> *   **Safe zone:**
>     *   Safe zone
>     *   16:9

Mọi thắc mắc hoặc cần hỗ trợ trong quá trình triển khai, Quý Đối tác vui lòng liên hệ với đội ngũGreen SM Foodđể được giải đáp kịp thời.

Hotline: 0247 123 9999

Email: support.vn@greensm.com

Green SM Food chân thành cảm ơn sự hợp tác và đồng hành của Quý Đối tác Nhà hàng trên hành trình nâng tầm trải nghiệm ẩm thực cùng Green SM Food.
