# Danh Sách Khách Hàng Trúng Thưởng Chương Trình “Vòng Xanh May Mắn”

- **Ngày đăng:** 2026-08-01
- **Chuyên mục:** Công ty
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/danh-sach-khach-hang-trung-thuong-chuong-trinh-vong-xanh-may-man](https://www.greensm.com/vn-vi/news/danh-sach-khach-hang-trung-thuong-chuong-trinh-vong-xanh-may-man)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Green SMxin chúc mừng Quý khách hàng đã trúng thưởng trong chương trình “Vòng Xanh May Mắn“.

Chương trình diễn ra từ00:00 ngày 08/11/2025 đến 23:59 ngày 30/06/2026trên ứng dụngGreen SM.

![Green SM chính thức chuyển đổi tổng đài chăm sóc khách hàng sang đầu số 1555](https://cdn.xanhsm.com/2026/04/09edeada-anh-thumb-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> *   **Biển số xe:** 29K - 007.55
> *   **Logo trên xe:** GREEN SM PREMIUM
> *   **Số điện thoại trên xe:** BOOK NOW! 1555
> *   **Logo trên áo:** V GREEN
> ```

Sau quá trình tổng hợp và xác minh kết quả theo quy định,Green SMxin công bố danh sách khách hàng trúng thưởng như sau:

1. Giải thưởng hiện vật:

| STT | Tên giải thưởng | Mô tả giải thưởng | Số lượng giải thưởng | Link Danh sách khách hàng trúng thưởng | Hình thức trao thưởng |
| --- | --- | --- | --- | --- | --- |
| 1 | Lá bồ đề phủ vàng | Hãng: DojiMã sản phẩm: DZAAX0000900001 Kích thước (D x R x C – cm): 5 x 7 | 430 | [LINK] | CSKH của Green SM sẽ liên hệ để thông báo và hướng dẫn cách thức nhận thưởng theo quy định. |
| 2 | Kim Tiền Tài Lộc và Thẻ quà tặng Green Gift Card 200.000 VNĐ (Thay cho Vé concert 8WONDER Winter 2025 – hạng VIP 1) | – Hãng: Doji Mã sản phẩm: DMNBA0504480001 Kích thước (D x R x C – cm): 19*14*25– Mã Code thẻ quà tặng Green Gift Card Hạn mức: 200.000 VNĐSử dụng: Tất cả các dịch vụ trên ứng dụng Green SM bao gồm: di chuyển, giao hàng, đặt đồ ănHạn sử dụng: nạp thẻ vào ứng dụng Green SM trước ngày 31/12/2026 | 4 |
| 3 | Khánh Kim Long Hiến Thụy; Thẻ quà tặng Green Gift Card 500.000 VNĐ và Thẻ quà tặng Green Gift Card 200.000 VNĐ (Thay cho Vé concert 8WONDER Winter 2025 – hạng GA) | – Hãng: Doji Mã sản phẩm: DGFAZ0000100001 Kích thước (D x R x C – cm): 34*3,7– Mã Code thẻ quà tặng Green Gift Card Hạn mức: 500.000 VNĐSử dụng: Tất cả các dịch vụ trên ứng dụng Green SM bao gồm: di chuyển, giao hàng, đặt đồ ănHạn sử dụng: nạp thẻ vào ứng dụng Green SM trước ngày 31/12/2026– Mã Code thẻ quà tặng Green Gift Card Hạn mức: 200.000 VNĐSử dụng: Tất cả các dịch vụ trên ứng dụng Green SM bao gồm: di chuyển, giao hàng, đặt đồ ănHạn sử dụng: nạp thẻ vào ứng dụng Green SM trước ngày 31/12/2026 | 24 |
| 4 | Huawei Watch GT4 – 46mm (brown) – 55020BHR | Hãng: HuaweiMã sản phẩm: 55020BHRMàu: Nâu | 2 | [LINK] |
| 5 | Huawei Watch GT4 – 41mm (white) – 55020BGC | Hãng: HuaweiMã sản phẩm: 55020BGCMàu: trắng | 2 |
| 6 | Huawei Watch Fit 3 NFC Edition (grey – 55020CEY) | Hãng: Huawei Mã sản phẩm: 55020CEYMàu: xám | 3 |
| 7 | Huawei Watch Fit 3 Edition (moon white – 55020CJU) | Hãng: Huawei Mã sản phẩm: 55020CJUMàu: Trắng pha xám | 2 |
| 8 | Huawei Watch Fit 3 Edition (green – 55020CFA) | Hãng: Huawei Mã sản phẩm: 55020CFAMàu: xanh | 3 |
| 9 | Huawei Watch Fit 3 Edition (black – 55020CFC) | Hãng: Huawei Mã sản phẩm: 55020CFCMàu: đen | 1 |
| 10 | Huawei Watch Fit 3 NFC Edition (pearl white – 55020CEX) | Hãng: Huawei Mã sản phẩm:55020CEXMàu: trắng ngọc trai | 3 |
| 11 | Huawei Matepad SE 10.36 4Gb + 64Gb (black – 53013NEW) | Hãng: Huawei Mã sản phẩm: 53013NEWMàu: đen | 2 |
| 12 | Cặp vé khứ hồi Việt Nam – Mỹ hạng Premium Economy | Hãng: Eva AirSản phẩm: Cặp vé khứ hồi | 1 |
| 13 | Thẻ quà tặng Green Gift Card 500.000 VNĐ | Mã Code thẻ quà tặng Green Gift Card Hạn mức: 500.000 VNĐSử dụng: Tất cả các dịch vụ trên ứng dụng Green SM bao gồm: di chuyển, giao hàng, đặt đồ ănHạn sử dụng: nạp thẻ vào ứng dụng Green SM trước ngày 31/12/2026 | 128 | [LINK] | Quà tặng được cộng trực tiếp vào ví E-Green của khách hàng |
| 14 | Thẻ quà tặng Green Gift Card 200.000 VNĐ | Mã Code thẻ quà tặng Green Gift Card Hạn mức: 200.000 VNĐSử dụng: Tất cả các dịch vụ trên ứng dụng Green SM bao gồm: di chuyển, giao hàng, đặt đồ ănHạn sử dụng: nạp thẻ vào ứng dụng Green SM trước ngày 31/12/2026 | 288 |
| 15 | Thẻ quà tặng Green Gift Card 100.000 VNĐ | Mã Code thẻ quà tặng Green Gift Card Hạn mức: 100.000 VNĐSử dụng: Tất cả các dịch vụ trên ứng dụng Green SM bao gồm: di chuyển, giao hàng, đặt đồ ănHạn sử dụng: nạp thẻ vào ứng dụng Green SM trước ngày 31/12/2026 | 528 |
| 16 | Thẻ quà tặng Green Gift Card 50.000 VNĐ | Mã Code thẻ quà tặng Green Gift Card Hạn mức: 50.000 VNĐSử dụng: Tất cả các dịch vụ trên ứng dụng Green SM bao gồm: di chuyển, giao hàng, đặt đồ ănHạn sử dụng: nạp thẻ vào ứng dụng Green SM trước ngày 31/12/2026 | 688 |

2. Giải thưởng điện tử:

| STT | Tên giải thưởng | Mô tả giải thưởng | Số lượng giải thưởng | Link Danh sách khách hàng trúng thưởng | Hình thức trao thưởng |
| --- | --- | --- | --- | --- | --- |
| 1 | Voucher giảm 15% tối đa 50K đối với dịch vụ xe máy | Dịch vụ sử dụng: Green Bike/ Green Bike PlusHạn sử dụng: 30 ngày kể từ ngày nhận mã | 11.938.740 | Khách hàng nhận thông báo trúng thưởng và quà sẽ được gửi trực tiếp vào tài khoản của khách hàng ngay khi quay trúng. |
| 2 | Voucher giảm 10% tối đa 50K đối với dịch vụ ô tô | Dịch vụ sử dụng: Green Car/ Green Premium/ Green LimoHạn sử dụng: 30 ngày kể từ ngày nhận mã | 20.028.174 |
| 3 | Voucher giảm 15% tối đa 50K đối với dịch vụ Giao hàng | Dịch vụ sử dụng: Giao hàngHạn sử dụng: 30 ngày kể từ ngày nhận mã | 3.326.261 |
| 4 | Voucher đồng giá phí vận chuyển 3.000VNĐ cho đơn hàng có khoảng cách nhỏ hơn 3km và giá trị món ăn từ 80.000VNĐ đối với dịch vụ Đặt món ăn | Dịch vụ sử dụng: Đặt món ănHạn sử dụng: 30 ngày kể từ ngày nhận mã | 1.439.177 |
| 5 | Gói hội viên Green Unlimited cá nhân 6 tháng | Số mã giảm hàng tháng (tổng cộng 6 tháng):10 mã giảm 16% lên đến 50K cho Green Car, Green Premium10 mã giảm 15% Green Bike, Green Bike Plus10 mã giảm 8% mọi đơn giao hàng Green Express50 mã giảm 15K cho đơn từ 50K cho Green SM FoodƯu tiên ghép tài xế điểm cao, nhận chuyến nhanh hơn. | 120.000 |
| 6 | Gói free xem phim 3 tháng trên Galaxy Play | Hãng: Galaxy PlaySản phẩm: VoucherHSD: Đến 31/05/2026 | 3.000 | [LINK] | Trả thưởng dưới dạng mã Voucher thông qua kênh thông báo bên trong ứng dụng Green SM. |
| 7 | Voucher giảm 49% khi sử dụng dịch vụ Facial Bar toàn quốc | Hãng: Facial BarSản phẩm: VoucherPhạm vi áp dụng: Combo Làn da lụa là – Ánh Mắt Thanh Xuân giảm còn 400.000đ (giá gốc 783.000đ) Combo bao gồm: – 01 buổi Joukin – Nâng dưỡng làn da lụa là không tỳ vết giá gốc 588.000đ – 01 buổi Kanyuu – Trao trả sự rạng rỡ nơi ánh mắt giá gốc 195.000đHSD: Đến 01/03/2026 | 3.000 |
| 8 | E-voucher Vietravel 500.000 VNĐ cho booking từ 20 triệu | Hãng: VietravelSản phẩm: VoucherHSD: Đến 31/03/2026 | 500 |
| 9 | E-voucher 1.000.000 VNĐ cho booking từ 30 triệu | Hãng: VietravelSản phẩm: VoucherHSD: Đến 31/03/2026 | 500 |

(*) Thông tin số điện thoại trong danh sách đính kèm sẽ được hiển thị một phần nhằm đảm bảo quyền riêng tư của khách hàng.

Lưu ý:

- Khách hàng vui lòng đảm bảo thông tin tài khoản và số điện thoại đăng ký trên ứng dụng Green SM còn hiệu lực.

- Trường hợp Green SM không thể liên hệ hoặc khách hàng không hoàn tất thủ tục nhận thưởng trong thời hạn quy định theo thể lệ chương trình, giải thưởng sẽ được xử lý theo quy định của chương trình và quy định của pháp luật.

- Mọi quyết định của Green SM liên quan đến kết quả chương trình đều được thực hiện theo thể lệ đã công bố.

- Mọi thắc mắc vui lòng liên hệ Tổng đài 1555 hoặc Trung tâm hỗ trợ trong ứng dụng Green SM.

Một lần nữa,Green SMxin chúc mừng các khách hàng may mắn và cảm ơn Quý khách hàng đã luôn đồng hành cùng Green SM trên hành trình lan tỏa lối sống xanh.

Hãy tiếp tục sử dụng dịch vụ và theo dõi Green SM để có thể nhận thêm những phần quà hấp dẫn trong các chương trình sắp tới!
