# [CẬP NHẬT] Vào Xanh – Tặng Xe Cùng Chính Sách Bảo Đảm Thu Nhập Cho Bác Tài Xanh Bike Thuê Xe Sở Hữu (RTO)

- **Ngày đăng:** 2026-05-23
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/vao-xanh-tang-xe-cung-chinh-sach-bao-dam-thu-nhap-vo-cung-hap-dan](https://www.greensm.com/vn-vi/news/vao-xanh-tang-xe-cung-chinh-sach-bao-dam-thu-nhap-vo-cung-hap-dan)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Green SM chính thức triển khai chương trình “VÀO XANH – TẶNG XE”, cho phép Bác Tài thuê & sở hữu xe máy điện VinFast sau 2 năm, kết hợp cùng Chính sách Bảo đảm Thu nhập vô cùng hấp dẫn giúp Bác Tài an tâm vận doanh ngay từ ngày đầu.

Thông qua chương trình, Bác Tài dễ dàng chuyển đổi từ xe xăng sang xe điện với chi phí thấp, tiết kiệm lên đến 36 triệu, vận hành hiệu quả và tận hưởng nhiều quyền lợi vượt trội.

Đặc biệt, khi tham gia vận doanh cùng Green SM, Bác Tài sẽ được hưởng Chính sách Bảo đảm Thu nhập với các lợi ích nổi bật:

✅ Đảm bảo mức thu nhập ổn định mỗi ngày/tuần – giảm rủi ro những ngày ít cuốc✅ Yên tâm vận doanh ngay từ giai đoạn đầu – không lo chưa quen hệ thống, chưa có tệp khách✅ Tối ưu doanh thu nhờ kết hợp thưởng & chương trình vận hành

Đối tượng áp dụng:Dành cho Bác Tài Xanh Bike đăng ký thuê hoặc mua xe điện VinFast từ Green SM, hoàn tất hồ sơ và bắt đầu chạy trước ngày 30/06/2026.

Thời gian áp dụng:Từ ngày 26/03/2026 đến hết ngày 30/6/2026 hoặc cho đến khi có thông báo mới

Dòng xe áp dụng:Evo đổi pin và Feliz II đổi pin.

👉 Đây chính là giải pháp giúp Bác Tài Xanh có xe chạy ngay – có thu nhập đều – từng bước sở hữu xe, mà không cần áp lực vốn lớn ban đầu.

👉 Chỉ cần đăng ký, Green SM đã chuẩn bị sẵn xe – chính sách – thu nhập để Bác Tài bắt đầu ngay

## Chương trình 1: “VÀO XANH – TẶNG XE “- 4 BƯỚC TỪ CÓ XE CHẠY ĐẾN CHỦ SỞ HỮU XE SAU 2 NĂM

|  | Tài xế cần làm |
| --- | --- |
| Bước 1: Cọc xe & nhận xe ngay | Đặt cọc 3.000.000đ (cọc thuê xe 2.000.000đ và cọc thuê pin 1.000.000đ) → chọn xe → nhận xe vận doanh ngay |
| Bước 2: Vận doanh & tạo thu nhập | Tham gia vận doanh trên Green SM PlatformTham gia thưởng + bảo đảm thu nhập để tối ưu doanh thu |
| Bước 3: Trừ phí tự động mỗi ngày | Hệ thống tự động trừ phí thuê từ Ví tài xế👉 Không cần thao tác, không lo thủ tục, không phát sinh các phụ phí |
| Bước 4: Tích lũy thu nhập từ vận doanh & sở hữu xe | Vừa chạy vừa tích lũy thu nhập từ các cuốc xe.Sau 2 năm → có cơ hội thành chủ sở hữu xe |

Chi tiết chương trình xem tại hình ảnh bên dưới:

![Chương trình 1: “VÀO XANH - TẶNG XE “- 4 BƯỚC TỪ CÓ XE CHẠY ĐẾN CHỦ SỞ HỮU XE SAU 2 NĂM](https://cdn.xanhsm.com/2026/05/91d23d8c-image-2-2-1024x644.png)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất sang định dạng Markdown:
> 
> Áp dụng từ ngày 30/5/2026
> 
> # VÀO XANH - TẶNG XE
> Chương trình thuê & sở hữu xe máy điện VinFast
> 
> # Sở hữu xe(*)
> 
> | Dòng xe          | Evo (đổi pin)      | Feliz II (đổi pin)  |
> | :--------------- | :----------------- | :------------------ |
> | Giá xe công bố   | 19.990.000₫        | 24.900.000₫         |
> | Đặt cọc          | 3.000.000₫         | 3.000.000₫          |
> |                  | 2.000.000₫ (Cọc xe) & 1.000.000₫ (Cọc pin) | 2.000.000₫ (Cọc xe) & 1.000.000₫ (Cọc pin) |
> | Giá thuê cố định | 60.000đ/ngày       | 67.000/ngày         |
> 
> (*) Tặng 01 xe Evo (trị giá 19.990.000 VNĐ) khi CTV giới thiệu thành công 50 Tài Xế mới gia nhập Xanh SM Bike Platform

![Chương trình 1: “VÀO XANH - TẶNG XE “- 4 BƯỚC TỪ CÓ XE CHẠY ĐẾN CHỦ SỞ HỮU XE SAU 2 NĂM](https://cdn.xanhsm.com/2026/05/81e99509-image-1-3-1024x644.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH ƯU ĐÃI ĐẶC BIỆT
> # VÀO XANH - TẶNG XE
> 
> | Chính sách                   | Nội dung                                                                                                                                                                                                    | Điều kiện                                                                                                                                                                                                                                                                                                                                                                          |
> | :--------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Chính sách Thu xăng đổi điện** | Hỗ trợ **1.000.000 VNĐ** tiền đặt cọc khi Tài xế bán xe xăng hiện tại cho Đại lý phân phối được GSM giới thiệu.                                                                                                | Áp dụng đối với TX Bike thuê xe máy điện VinFast và tham gia Platform trước ngày **30/06/2026**                                                                                                                                                                                                                                                                                     |
> | **Chính sách miễn phí đổi pin** | Miễn phí đổi pin tối đa **05 lần/ngày** Miễn phí đổi pin trong thời gian **2 năm**, tối đa đến **30/6/2028** cho ngày T khi Tài xế đạt điều kiện ngày T-1.                                                       | * Tỉ lệ hoàn chấp nhận chuyến: >=90%/tuần <br> * Tỉ lệ hoàn thành chuyến >=95%/tuần <br> * Số cuốc hoàn thành ngày T-1 >=10 cuốc/ngày, và doanh số ngày T-1 >=400.000VNĐ/ngày                                                                                                                                                                                                        |
> | **Chính sách miễn phí thuê pin** | Áp dụng cho Tài xế tham gia Green SM Bike Platform trước ngày **30/06/2026**. Miễn phí thuê pin trong thời gian **2 năm**, tối đa đến **30/6/2028** cho khách hàng thuê 1 và 2 pin/ tháng. | Đạt ≥ **250 cuốc/ tháng** và doanh số ≥ **10.000.000 VNĐ/tháng**                                                                                                                                                                                                                                                                                                                       |
> 
> ## Lưu ý
> 
> * Bác Tài đã gia nhập Green SM Bike Platform hoặc đặt cọc mua/thuê xe trước ngày **30/05/2026** được miễn phí đổi pin/thuê pin **3 năm** (tối đa đến **31/03/2029**).
> * Chính sách miễn phí đổi pin/thuê pin chỉ áp dụng cho tài xế đối tác tham gia GSM trước ngày **30/6/2026**.

## Chương trình 2: BẢO ĐẢM THU NHẬP VÔ CÙNG CẠNH TRANH

Thu nhập khi vận doanh cùng Green SM Platform đã có Green SM đảm bảo, Bác Tài yên tâm vận doanh với thu nhập hấp dẫn

2.1. Áp dụng tại khu vực Hà Nội, TPHCM (cũ)

Đảm bảo thu nhập mỗi ngày vận doanh

Đảm bảo phát tới 17 cuốc mỗi ngày

Hỗ trợ đặc biệt: Thiếu cuốc, Green SM bù 36.000 đồng mỗi cuốc*

![[GKVH] Ảnh RTO - 4](https://cdn.xanhsm.com/2026/05/5d67e3df-4-1024x643.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> # VÀO XANH - TẶNG XE
> ## CHÍNH SÁCH ĐẢM BẢO THU NHẬP
> dành cho Bác Tài thuê/mua xe Vinfast
> 
> | | Tài xế part-time | Tài xế full-time |
> |---|---|---|
> | Mức đảm bảo theo ngày | 360.000 vnđ | 600.000 vnđ |
> | Số cuốc đảm bảo phát/ngày (*) | 10 | 17 |
> | **ĐIỀU KIỆN** | | |
> | Số giờ hoạt động/ngày (**) | >= 6h | >= 10h |
> | Thời gian hoạt động | Từ 6h - 22h hàng ngày (tối thiểu 1 trong 2 khung cao điểm: 6h-8h59 hoặc 16h-18h59) |
> | Khu vực hoạt động | Khu vực trung tâm theo danh sách |
> | Tỷ lệ hoạt động | - Tỷ lệ nhận chuyến >= 95%<br>- Tỷ lệ hoàn thành chuyến >= 90% |
> 
> (*) Nếu GSM không phát đủ số cuốc tối thiểu sẽ bù thu nhập theo mức 36,000 VNĐ/ cuốc
> (**) Nếu TX bị phát hiện gian lận sẽ không được hưởng quyền lợi
> 
> ## DANH SÁCH CÁC KHU VỰC ÁP DỤNG
> (theo địa giới hành chính cũ)
> 
> *   **Thành phố Hà Nội:** Quận Ba Đình, Quận Hoàn Kiếm, Quận Tây Hồ, Quận Long Biên, Quận Cầu Giấy, Quận Đống Đa, Quận Hai Bà Trưng, Quận Hoàng Mai, Quận Thanh Xuân, Quận Nam Từ Liêm, Quận Bắc Từ Liêm, Quận Hà Đông
> *   **Thành phố Hồ Chí Minh:** Quận 1, Quận 12, Quận Gò Vấp, Quận Bình Thạnh, Quận Tân Bình, Quận Tân Phú, Quận Phú Nhuận, TP Thủ Đức, Quận 3, Quận 10, Quận 11, Quận 4, Quận 5, Quận 6, Quận 8, Quận 7, Quận Bình Tân

2.2 Áp dụng tại các thị trường khác:

️Đảm bảo thu nhập lên đến 11 triệu/tháng (Full-time/toàn thời gian)

Part-time/bán thời gian vẫn có thu nhập tối thiểu 6.2 triệu/tháng

👉 Điều kiện dễ dàng – thu nhập vững vàng

![[GKVH] Ảnh RTO - 5](https://cdn.xanhsm.com/2026/05/6325e375-5-1024x643.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> # VÀO XANH - TẶNG XE
> ## CHÍNH SÁCH ĐẢM BẢO THU NHẬP
> dành cho Bác Tài thuê/mua xe Vinfast
> 
> **Áp dụng:** Quảng Ninh, Hải Phòng, Thanh Hóa, Bắc Ninh, Thái Nguyên, Nghệ An, Đà Nẵng, Huế, Long An, Tây Ninh, Bà Rịa Vũng Tàu, Đồng Nai, Bình Dương
> 
> | | Tài xế part-time | Tài xế full-time |
> |---|---|---|
> | Mức đảm bảo theo tháng | **6.200.000 vnđ** | **11.000.000 vnđ** |
> | Số cuốc hoàn thành/tuần | 48 | 84 |
> | **ĐIỀU KIỆN** | Số cuốc hoàn thành/tháng | 192 | 336 |
> | Tỷ lệ hoạt động | | - Tỷ lệ nhận chuyến = 100%<br>- Tỷ lệ hoàn thành chuyến >=90% |

2.3. Chương trình miễn phí đồng phục

Green SM tặng miễn phí combo đồng phục bao gồm:

- 1 bộ đồng phục trị giá 510.000đ

- 1 túi túi Food Green SM Ngon

2.4. Chương trình Thưởng Tài xế mới:

Hình thức chi trả: Cộng trực tiếp vào ví Tài xế

![[GKVH] Ảnh RTO - 6](https://cdn.xanhsm.com/2026/05/c32d4f5c-6-1024x643.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản đã được trích xuất và định dạng theo yêu cầu:
> 
> # VÀO XANH - TẶNG XE
> 
> ## CHÍNH SÁCH ĐẢM BẢO THU NHẬP
> dành cho Bác Tài thuê/mua xe Vinfast
> 
> | Chính sách | Nội dung | Điều kiện |
> |---|---|---|
> | **Chính sách chia sẻ doanh số** | • Năm 1: Tài xế được chia sẻ 90% doanh số <br> • Năm 2-3: Tài xế được chia sẻ 85% doanh số | Áp dụng đối với Tài xế có nhu cầu thuê hoặc mua xe máy điện VinFast và tham gia Platform trước ngày 30/6/2026 |
> | **Chính sách thưởng gia nhập** | Thưởng nóng 500.000₫ | Tài xế đã hoàn thành ≥ 450 cuốc/tháng gần nhất trên nền tảng gọi xe khác |
> | | Thưởng nóng 300.000₫ | Tài xế đã hoàn thành ≥ 350 cuốc/tháng gần nhất trên nền tảng gọi xe khác |
> | **Chính sách miễn phí đồng phục** | Miễn phí combo đồng phục và túi giữ nhiệt | |
> | **Chính sách hỗ trợ tài xế tiên phong** | Giảm điều kiện vận doanh trong 01 năm đầu tiên cho Tài xế đặt cọc thuê xe trước ngày 31/05/2026 | - TP Hà Nội, Hồ Chí Minh: Tài xế hoàn thành tối thiểu 190 cuốc/tháng trên Nền tảng Green SM Platform.<br> - Các tỉnh thành khác: Tài xế hoàn thành tối thiểu 130 cuốc/tháng trên Nền tảng Green SM Platform |

GÓC GIẢI ĐÁP

| STT | Câu hỏi | Gải đáp |
| --- | --- | --- |
| 1 | Có bắt buộc chạy vào khung giờ cao điểm không? | Đối tác tài xế tại khu vực Hà Nội & TP.HCM (cũ) cần hoạt động tối thiểu 1 khung giờ cao điểm/ngàyKhung giờ cao điểm– Khung cao điểm sáng 6h-8h59– Khung cao điểm chiều16h-18h59 |
| 2 | Nếu Tài xế không Chạy đủ số chuyến? | Chính sách bảo đảm thu nhập được áp dụng nhằm hỗ trợ Đối tác Tài xế trong trường hợp hệthống phân bổ cuốc chưa đủ.👉 Do đó, để đủ điều kiện nhận hỗ trợ, Đối tác cần đạt mốc tối thiểu số cuốc hoàn thành/ngày dựa theo nhóm đã đăng ký trước đó🔹 Trường hợp không đạt đủ số cuốc tối thiểu ngày:– Chính sách bảo đảm thu nhập không được áp dụng khi không đáp ứng các điều kiện về vận hành được cung cấp ở bản thông tin trên.– Thu nhập của Đối tác sẽ được tính theo doanh thu thực tế từ các chuyến đã hoàn thành |
| 3 | Nếu Green SM không phát đủ cuốc thì chính sách bảo đảm thu nhập như thế nào? | Nhằm đảm bảo thu nhập ổn định cho Đối tác Tài xế toàn thời gian trong trường hợp hệ thống chưa phân bổ đủ cuốc, Green SM triển khai cơ chế bảo đảm thu nhập theo ngày như sau:👉 Khi Đối tác hoàn thành 15 cuốc thành công/ngày, Green SM sẽ áp dụng chính sách hỗ trợ tương ứng với mức doanh thu thực tế:Trường hợp 1: Doanh thu dưới 600.000đ/ngày– Green SM sẽ bù phần chênh lệch để đảm bảo tổng thu nhập đạt 600.000đ/ngàyTrường hợp 2: Doanh thu đạt từ 600.000đ/ngày trở lên– Green SM sẽ hỗ trợ thêm 72.000đ– Tương đương bù thêm 2 cuốc (~36.000đ/cuốc) Tài xế cần tuân thủ các điều kiện chương trình ở bảng thông tin trên |
| 4 | Có yêu cầu về điều kiện tín dụng/nợ xấu mới dược thuê hay không? | Không yêu cầu điều kiện bổ sung. XanhSM không yêu cầu kiểm tra lịch sử tín dụng hay nợ xấu ngân hàng. Chính sách thuê xe hỗ trợ tối đa tài xế có cơ hội việc làm và bảo đảm thu nhập trong quá trình vận doanh. |
| 5 | Thời điểm hoàn thành hồ sơ là tính thời điểm nào? Ngày đăng kí hồ sơ, ngày nhận xe, ngày đào tạo, ngày chạy cuốc đầu hay như thế nào? | Thời gian hoàn tất hồ sơ tính từ khi tài khoản Platform của tài xế được kích hoạt. |
| 6 | TX có được chuyển từ cọc mua xe sang thuê xe không? | Có, tuy nhiên tài xế cần làm đơn xin hoàn cọc và cần được VinFast chấp thuận. Sau khi hoàn tất, tài xế có thể thực hiện đặt cọc lại để thuê xe theo chương trình |
| 7 | TX sau khi tham gia thuê xe mà muốn chuyển sang mua đứt luôn thì có được không? | Có. Tài xế có thể mua lại xe vào bất cứ thời điểm nào. Giá mua lại sẽ được tính theo giá trị khấu hao còn lại của xe tại thời điểm mua. |
| 8 | Trong quá trình vận doanhn, nếu TX bị khóa tài khoản, thì có được hoàn cọc không ? | Không. Tài xế sẽ không được hoàn cọc nếu vi phạm Quy tắc ứng xử của Green SM Platform và bị chấm dứt Hợp đồng Hợp tác |
| 9 | Chiến dịch này có áp dụng cho dòng xe Viper không? Khi nào áp dụng, hình thức áp dụng thế nào? | Chương trình Green SM Bike Rental chưa áp dụng cho dòng Viper. Chương trình hiện chỉ tập trung cho 2 dòng xe đổi pin – được định vị chủ lực cho ngành gọi xe công nghệ: Evo và Feliz II. |
| 10 | Chính sách chi tiết của miễn phí đổi pin và thuê pin? | Tài xế gia nhập trước 30/06/2026 sẽ được miễn phí đổi pin trong thời gian 2 năm, tối đa đến 30/06/2028. Tài xế được miễn phí đổi pin ngày T (tối đa 05 lần/ngày)– Chạy độc quyền trên app GSM với tỉ lệ hoàn chấp nhận chuyến >=90%/tuần, tỉ lệ hoàn thành chuyến >=95%/tuần.– Đạt ≥ 10 cuốc/ ngày và ≥ 400.000 VNĐ doanh số/ngày trong ngày T-1.Sau 30/06/2026, quy định của chính sách miễn phí đổi pin sẽ quay về chính sách gốc:– Khu vực HN& TPHCM (cũ): Số cuốc xe >=13 cuốc/ngày. Hoặc doanh số >= 520.000đ/ngày– Khu vực còn lại: Số cuốc xe >=11 cuốc/ngày, Hoặc doanh số >=440.000đ/ngày– Tỷ lệ hủy cuốc <5%; Tỷ lệ bỏ trôi cuốc <10%Chính sách miễn phí thuê pin chỉ áp dụng cho các TX gia nhập từ nay đến hết 30/06/2026:– Tài xế được miễn phí thuê pin trong 2 năm (tối đa đến 30/06/2028) cho khách hàng thuê 1 và 2 pin/ tháng, cho Tài xế:+ Đạt ≥ 250 cuốc/ tháng và doanh số ≥ 10.000.000 VNĐ/tháng.Lưu ý: Tài xế đối tác đã gia nhập Green SM Bike Platform hoặc đặt cọc mua/thuê xe trước ngày 30/05/2026 được miễn phí đổi pin/ thuê pin 3 năm (tối đa đến 31/03/2029) |
| 11 | CTV Thủ lĩnh đã nhận xe Evo/Felix để làm truyền thông thì có được nhận hoa hồng bán xe nữa không? | Trường hợp CTV giới thiệu đủ 50 tài xế, CTV sẽ nhận xe và không được lựa chọn phương án nhận hoa hồng. Nếu số lượng giới thiệu dưới 50 tài xế, CTV vẫn được nhận hoa hồng theo chính sách giới thiệu và phải trả lại xe đã nhận.Từ tài xế thứ 51 trở đi, CTV được quyền lựa chọn giữa tích lũy để nhận xe hoặc nhận hoa hồng, và không được áp dụng đồng thời hai phương án. |
