# Thể lệ chương trình Xanh Bạn Mới

- **Ngày đăng:** 2024-12-11
- **Chuyên mục:** Cộng đồng, Ưu đãi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/the-le-chuong-trinh-xanh-sm-referral](https://www.greensm.com/vn-vi/news/the-le-chuong-trinh-xanh-sm-referral)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

Xin chân thành cảm ơn bạn đã đồng hành cùng Green SM. Chúng tôi thường xuyên tổ chức các chương trình giới thiệu hấp dẫn, nhằm khuyến khích cộng đồng cùng nhau phát triển. Tham gia chương trình giới thiệu, bạn không chỉ giúp bạn bè, người thân trải nghiệm dịch vụ tiện ích mà còn có cơ hội nhận được nhiều phần thưởng giá trị như phiếu giảm giá, tiền mặt,…

Để đảm bảo quyền lợi cho tất cả thành viên, Green SM xây dựng bộ quy tắc chung cho các chương trình giới thiệu. Khi tham gia, bạn đồng ý tuân thủ các quy định này. Mọi vi phạm sẽ dẫn đến việc hủy bỏ quyền tham gia chương trình, thu hồi phần thưởng và thậm chí khóa tài khoản.

Ngoài ra, có thể có những điều khoản cụ thể áp dụng cho từng chương trình giới thiệu, tùy thuộc vào từng thời điểm và khu vực. Vui lòng đọc kỹ thông tin chi tiết của chương trình trước khi tham gia.

## 1. Điều kiện để trở thành người giới thiệu:

- Là cư dân hợp pháp tại đang sinh sống tại Việt Nam.

- Đã đủ 18 tuổi.

- Sở hữu một tài khoản Green SM đang hoạt động và được Green SM cấp mã giới thiệu. Mỗi người chỉ được phép sử dụng một tài khoản Green SM để tham gia chương trình giới thiệu.

## 2. Ai có thể nhận ưu đãi giới thiệu?

Người được giới thiệu (Referee)/Người được mời (Invitee) (sau đây gọi chung là “Người được giới thiệu”) đủ điều kiện nhận ưu đãi sẽ là:

- Bạn bè, người thân của bạn khi đăng ký sử dụng dịch vụ Green SM qua mã giới thiệu của bạn.

- Để đủ điều kiện nhận ưu đãi, người được giới thiệu phải là người dùng mới của Green SM và hoàn thành các yêu cầu theo quy định của chương trình (ví dụ: hoàn thành chuyến đi đầu tiên).

Các hành vi không được phép:

- Tạo nhiều tài khoản để gian lận.

- Xác nhận chuyến đi/giao hàng ảo.

- Can thiệp vào hệ thống hoặc cung cấp thông tin sai lệch.

Khi giới thiệu, bạn hiểu rõ và đảm bảo rằng:

- Bạn có trách nhiệm thu thập sự chấp thuận của người được giới thiệu để cung cấp thông tin cho Green SM và Bạn đã thu thập được sự chấp thuận của người được giới thiệu trước khi cung cấp thông tin cho Green SM.

- Người được giới thiệu hiểu rõ về chương trình và các điều khoản tham gia.

## 3. Làm cách nào để sử dụng mã giới thiệu?

Bạn có thể chia sẻ mã giới thiệu của mình với bạn bè, người thân để họ nhận được ưu đãi khi sử dụng dịch vụ của Green SM. Tuy nhiên, bạn cần tuân thủ các quy định sau:

- Giới hạn sử dụng:Số lần sử dụng và chia sẻ mã giới thiệu có thể bị giới hạn tùy thuộc vào từng chương trình.

- Sử dụng đúng mục đích:Mã giới thiệu chỉ dành cho mục đích cá nhân và không được sử dụng để kinh doanh.

- Bảo vệ thương hiệu:Bạn không được sử dụng mã giới thiệu để quảng cáo sai lệch hoặc gây hiểu nhầm về Green SM.

- Tuân thủ pháp luật:Việc sử dụng mã giới thiệu phải tuân thủ các quy định của pháp luật và chính sách của Green SM.

Các hành vi bị nghiêm cấm:

- Gian lận:Tạo nhiều tài khoản, mua bán mã giới thiệu, sử dụng bot tự động.

- Quảng cáo sai sự thật:Đưa ra thông tin sai lệch về Green SM hoặc chương trình giới thiệu.

- Vi phạm bản quyền:Sử dụng trái phép logo, hình ảnh, nội dung của Green SM.

Nếu vi phạm các quy định trên, tài khoản của bạn có thể bị khóa và bạn sẽ mất quyền tham gia chương trình.

## 4. Bạn sẽ nhận được gì khi giới thiệu bạn bè?

Khi bạn giới thiệu thành công bạn bè hoặc người thân đăng ký sử dụng dịch vụ Green SM và họ hoàn thành các yêu cầu theo quy định, bạn sẽ nhận được những phần thưởng hấp dẫn. Phần thưởng có thể bao gồm:

- Giảm giá:Tặng mã giảm giá để sử dụng các dịch vụ của Green SM.

- Tiền mặt:Tặng tiền mặt vào tài khoản thẻ xanh điện tử để sử dụng các dịch vụ của Green SM.

- Ưu đãi đặc biệt:Tham gia các chương trình ưu đãi dành riêng cho thành viên giới thiệu.

Lưu ý:

- Thời hạn:Phần thưởng thường có thời hạn sử dụng nhất định.

- Điều kiện:Để nhận được phần thưởng, người được giới thiệu phải hoàn thành các yêu cầu cụ thể như hoàn thành chuyến đi đầu tiên, đạt số điểm nhất định,…

- Phần thưởng có thể thay đổi:Giá trị và loại hình phần thưởng có thể thay đổi tùy thuộc vào từng chương trình và thời điểm.

## 5. Người được giới thiệu sẽ nhận được gì?

Khi bạn đăng ký sử dụng dịch vụ Green SM qua mã giới thiệu của bạn bè, bạn có thể nhận được những ưu đãi hấp dẫn tùy theo chương trình của Green SM tại từng thời điểm như:

- Giảm giá:Tặng ngay mã giảm giá cho chuyến đi đầu tiên.

- Ưu đãi đặc biệt:Có cơ hội nhận nhiều ưu đãi khác như giảm giá, quà tặng,…

Lưu ý:

- Loại ưu đãi:Loại ưu đãi và giá trị ưu đãi có thể khác nhau tùy thuộc vào từng chương trình và thời điểm.

- Điều kiện:Để nhận được ưu đãi, bạn cần đảm bảo hoàn thành các yêu cầu theo quy định tại từng thời điểm (ví dụ: hoàn tất đăng ký tài khoản, điền đầy đủ thông tin cá nhân).

## 6. Điều khoản thay đổi

Green SM có quyền điều chỉnh, tạm dừng hoặc kết thúc chương trình giới thiệu bất cứ lúc nào. Quyết định này có thể được thực hiện vì nhiều lý do, bao gồm:

- Nghi ngờ gian lận:Nếu có dấu hiệu gian lận trong quá trình tham gia chương trình.

- Sửa đổi quy định:Để phù hợp với những thay đổi trong chính sách hoặc điều kiện kinh doanh.

- Lý do khác:Vì các lý do khác mà Green SM thấy phù hợp.

Trong trường hợp chương trình bị tạm dừng hoặc kết thúc:

- Phần thưởng chưa sử dụng:Các phần thưởng chưa được sử dụng có thể bị mất hiệu lực.

- Thông báo:Green SM sẽ thông báo trước ít nhất 14 ngày trước khi chương trình kết thúc để bạn có thời gian sử dụng phần thưởng.

- Cập nhật quy định:Green SM có quyền cập nhật các quy định của chương trình giới thiệu bất cứ lúc nào. Việc bạn tiếp tục tham gia chương trình sau khi có cập nhật sẽ được coi là bạn đã đồng ý với các quy định mới.
