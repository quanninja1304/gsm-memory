# Thể lệ cuộc thi sáng tạo “Chuyến xe tự hào”

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, Tài xế Green SM Bike, Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/the-le-cuoc-thi-sang-tao-tu-hao-bac-tai-xanh](https://www.greensm.com/vn-vi/news/the-le-cuoc-thi-sang-tao-tu-hao-bac-tai-xanh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Nhân dịp Quốc Khánh 02/09, Green SM gửi lời tri ân đến những Bác Tài Xanh – những người vẫn miệt mài trên từng tuyến phố, mang đến những chuyến đi an toàn và sự tận tâm phục vụ trong ngày lễ. Từ 30/08 – 02/09, cuộc thi sáng tạo “Chuyến xe tự hào” được phát động như một hành trình lưu giữ khoảnh khắc: là hình ảnh chiếc xe Xanh nổi bật giữa phố phường rực rỡ cờ hoa, là nụ cười thân thiện của khách hàng hay đơn giản là giây phút yên bình của Bác Tài trong công việc. Hãy cùng ghi lại và lan tỏa những khoảnh khắc đáng tự hào ấy để tôn vinh hành trình xanh của chính mình.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/08/d04ed0d6-cuoc-thi-sang-tao2-1024x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> BÁC TÀI
> XANH
> 
> Cuộc thi sáng tạo
> Chuyến xe tự hào
> 
> Thời gian:
> 30.8.2025 - 2.9.2025
> 
> Giải đặc biệt:
> 5.000.000 VNĐ
> ```

# Thời gian đăng bài lan tỏa

Chương trình được triển khai từ ngày 30.8 – 2.9.2025

# Đối tượng tham gia

– Bác Tài Green SM 4 bánh (ngoại trừ đối tác): Bao gồm Green SM Taxi và Green SM Platform– Bác Tài Green SM 2 bánh (ngoại trừ đối tác): Bao gồm Green SM Bike và Green SM Bike Platform

# Phạm vi tổ chức

Toàn quốc.

# Hình thức tham gia

Bước 1:Chụp ảnh/Quay video lưu giữ lại quá trình làm việc trong dịp lễ từ 30.8 – 2.9.2025Bước 2:Viết 1 caption chia sẻ cảm xúc, câu chuyện hoặc niềm tự hào dân tộc gắn liền với hành trình vận doanh cùng Green SM.Bước 3:Đăng tải công khai trên Facebook cá nhân kèm hashtag #XanhSM #TuHaoBacTaiXanh #ManhliettinhthanVietNamBước 4:Đổi avatar Mãnh Liệt Tinh Thần Việt Nam trên trang Facebook dự thiBước 5:Điền link bài dự thi tại:https://forms.gle/n2L21KBQ7CQdoDqN9để được ghi nhận tham gia

# Cơ cấu giải thưởng

– 01 giải đặc biệt: Trị giá 5.000.000 VNĐDành cho tác phẩm đứng nhất tổng điểm Lan Tỏa – Sáng Tạo– 02 Giải nhất: Mỗi giải trị giá 2.000.000 VNĐDành cho tác phẩm đứng thứ 2 & 3 tổng điểm Lan Tỏa – Sáng Tạo– 05 Giải nhì: Mỗi giải trị giá 500.000 VNĐDành cho tác phẩm đứng thứ 4 đến 8 tổng điểm Lan Tỏa – Sáng Tạo– 12 Giải Khuyến Khích: Mỗi giải trị giá 200.000 VNĐDành cho các tác phẩm đứng thứ 9 đến 20 tổng điểm Lan Tỏa – Sáng Tạo

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/08/dfb336bb-250100_tet-2025_xanh-sm-bike_xanhsm0683-2-1024x1016.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Đây là nội dung được trích xuất từ hình ảnh:
> 
> **Văn bản:**
> * CHAO LONG
> * 103 LÓF-CO NGHIỆN THIỆN
> * DODGERS
> * LA
> * XANHSH
> 
> **Số liệu:**
> * 103
> 
> **Tiêu đề:**
> Không có tiêu đề rõ ràng trong hình ảnh.
> 
> **Bảng biểu:**
> Không có bảng biểu trong hình ảnh.

# Thang điểm chấm bài dự thi:

–Tính sáng tạo:500 điểm(Câu chuyện/ cảm nhận mang tinh thần tích cực, lan tỏa năng lượng tốt).–Tính lan tỏa(like, share, comment): 500 điểm(Tính theo tỷ lệ quy đổi: 1 like/react = 1 điểm, 1 comment = 1 điểm, 1 share = 1 điểm. Tối đa 500 điểm)

# Tiêu chí khác:

– Bài dự thi phải do chính thí sinh sáng tạo, không sao chép, chỉnh sửa từ nguồn khác. Nếu BTC phát hiện gian lận, tác phẩm sẽ bị loại.– Không chấp nhận nội dung vi phạm pháp luật, thuần phong mỹ tục, hoặc liên quan đến chính trị, tôn giáo, bạo lực, kích động, tiêu cực.– Trong trường hợp có tranh chấp về bản quyền, BTC có quyền tạm dừng hoặc hủy kết quả dự thi cho đến khi có kết luận chính thức.– Trong trường hợp phát hiện gian lận (tăng tương tác ảo, sử dụng công cụ hack lượt view/like/share), BTC có quyền hủy kết quả và không trao giải.– BTC có quyền sử dụng hình ảnh/tác phẩm dự thi để phục vụ cho hoạt động truyền thông, quảng bá mà không cần trả thêm chi phí.– Decal phải được dán đúng quy cách chương trình và khung avatar Mãnh Liệt Tinh Thần Việt Nam phải được mở công khai/public.– Quyết định cuối cùng thuộc về BTC.

# Hình thức trả thưởng:

– Trả thưởng thông qua ví tài xế– Trả thưởng sau 30 ngày kể từ khi công bố giải

Mến chúc các Bác Tài một mùa lễ thật rực rỡ, doanh thu vượt bậc và ghi lại thật nhiều khoảnh khắc đáng nhớ qua những thước phim, tấm ảnh đẹp!

Tham gia ngay!
