# Chính sách thu nhập và thưởng trách nhiệm doanh số Tài xế Taxi tại Đà Nẵng 1

- **Ngày đăng:** 2025-10-04
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-txtx-da-nang](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-txtx-da-nang)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Với mục đích hỗ trợ Bác tài quản lý thu nhập một cách minh bạch và chủ động hơn, Green SM xin thông báo về việc cập nhậtChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấmcôngmới.

👉 Thời gian áp dụng:Từ 04/10/2025cho đến khi có thông báo mới

👉 Chi tiết chính sách: Bác tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/a0db3448-251004_txtx_dnang1-501x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CẬP NHẬT CHÍNH SÁCH THU NHẬP VÀ THƯỞNG TRÁCH NHIỆM DOANH SỐ
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Depot Đà Nẵng 1
> **Thời gian áp dụng:** Từ ngày 04/10/2025 đến khi có thông báo mới
> 
> # Nội dung chính sách
> 
> Cập nhật mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công
> 
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> 
> ## Xanh SM Car
> 
> | Mức   | Doanh số (VNĐ/ngày)                 | Tỷ lệ chia sẻ |
> |-------|-------------------------------------|---------------|
> | Mức 0 | Dưới 1.000.000                      | 25%           |
> | Mức 1 | Từ 1.000.000 đến dưới 1.300.000      | 30%           |
> | Mức 2 | Từ 1.300.000 đến dưới 1.500.000      | 35%           |
> | Mức 3 | Từ 1.500.000 đến dưới 1.800.000      | 40%           |
> | Mức 4 | Từ 1.800.000 đến dưới 2.100.000      | 44%           |
> | Mức 5 | Từ 2.100.000 trở lên                | 48%           |
> 
> ## Xanh SM Premium
> 
> | Mức   | Doanh số (VNĐ/ngày)                 | Tỷ lệ chia sẻ |
> |-------|-------------------------------------|---------------|
> | Mức 0 | Dưới 900.000                        | 25%           |
> | Mức 1 | Từ 900.000 đến dưới 1.200.000        | 32%           |
> | Mức 2 | Từ 1.200.000 đến dưới 1.400.000      | 37%           |
> | Mức 3 | Từ 1.400.000 đến dưới 1.700.000      | 42%           |
> | Mức 4 | Từ 1.700.000 đến dưới 2.000.000      | 45%           |
> | Mức 5 | Từ 2.000.000 trở lên                | 48%           |
> 
> # TIÊU CHUẨN CHẤM CÔNG
> 
> ## Xanh SM Car
> 
> | Tháng áp dụng | Tiêu chí            | Từ T2 - T5 | Từ T6 - CN, ngày Lễ, Tết | Từ T2 - CN, ngày Lễ, Tết |
> |---------------|---------------------|------------|--------------------------|--------------------------|
> |               | Tỷ lệ nhận cuốc     | 85%        |                          | 80%                      |
> |               | Tỷ lệ hoàn thành cuốc | 85%        |                          | 85%                      |
> | 3,5,6,7,8,9,12 | Doanh số (VNĐ/ngày) | Từ 800.000 | Từ 800.000               | Từ 1.500.000             |
> | 4,10,11       | Doanh số (VNĐ/ngày) | Từ 720.000 | Từ 720.000               | Từ 1.350.000             |
> 
> ## Xanh SM Premium
> 
> | Tháng áp dụng | Tiêu chí            | Từ T2 - T5 | Từ T6 - CN, ngày Lễ, Tết | Từ T2 - CN, ngày Lễ, Tết |
> |---------------|---------------------|------------|--------------------------|--------------------------|
> |               | Tỷ lệ nhận cuốc     | 85%        |                          | 80%                      |
> |               | Tỷ lệ hoàn thành cuốc | 85%        |                          | 85%                      |
> | 3,5,6,7,8,9,12 | Doanh số (VNĐ/ngày) | Từ 700.000 | Từ 700.000               | Từ 1.200.000             |
> | 4,10,11       | Doanh số (VNĐ/ngày) | Từ 630.000 | Từ 630.000               | Từ 1.080.000             |
> ```

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Trân trọng,Đội ngũ Green SM.
