# QUY TẮC ỨNG XỬ DÀNH CHO TÀI XẾ GREEN SM BIKE

- **Ngày đăng:** 2023-07-27
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/quy-tac-ung-xu-danh-cho-tai-xe](https://www.greensm.com/vn-vi/news/quy-tac-ung-xu-danh-cho-tai-xe)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Không

---

Green SM Bike thông báo “Quy tắc ứng xử dành cho Tài xế ” áp dụng từ 25/07/2023

Tài xế Green SM Bike thân mến,

Bộ “Quy tắc ứng xử dành cho Tài xế Green SM Bike” đưa ra nhằm xây dựng hình ảnh Tài xế Green SM Bike kỷ luật, chuyên nghiệp, tận tâm.

## Tiêu chuẩn vận hành – dịch vụ

### 1.Đối với khách

Cung cấp dịch vụ chuyên nghiệp cho khách

Hành vi vi phạm:

1. Nhận chuyến nhưng không đón khách, tự hủy hoặc yêu cầu khách hủy để trục lợi phí dịch vụ, phí nền tảng.

2. Không liên hệ khách để xác nhận trước khi tới. Đón sai khách, đón khách khi trên phương tiện đang chở khách.

3. Trả khách sai điểm đến mà không được sự đồng ý của khách hoặc chở khách không đúng lộ trình tối ưu.

4. Tranh giành khách, ngăn cản hoặc gây trở ngại cho đối tác khác trong việc đón khách.

5. Môi giới, chuyển khách cho tài xế khác phục vụ hoặc nhận khách do môi giới từ tài xế khác.

6. Chấm dứt hành trình/yêu cầu khách xuống xe giữa đường khi khách không yêu cầu.

7. Cư xử thô lỗ, to tiếng với khách. Phân biệt chủng tộc/tôn giáo/quốc tịch/vùng miền/ngoại hình/giới tính dưới bất kỳ hình thức nào.

Tôn trọng quyền riêng tư và bảo mật thông tin của khách

Hành vi vi phạm:

8. Sử dụng thông tin của khách ngoài mục đích công việc gây ảnh hưởng tới khách (đăng lên các trang MXH, các cộng đồng …).

9. Tự ý ghi hình/chụp ảnh và phát tán/sử dụng hình ảnh của khách với mục đích cá nhân.

Đảm bảo an toàn tuyệt đối cho khách (cả về thể chất và tinh thần)

Hành vi vi phạm:

10. Vi phạm Luật an toàn giao thông gây hậu quả nghiêm trọng (tai nạn, va chạm,…). Bỏ mặc khách khi xảy ra tai nạn/sự cố.

11. Không báo bộ phận hỗ trợ ngay khi xảy ra tai nạn/sự cố có khách trên xe và trốn tránh trách nhiệm liên quan.

12. Thái độ, hành vi không đúng mực, khiếm nhã, quấy rối khách (nhắn tin, gọi điện gạ gẫm vì bất cứ mục đích nào).

Chế tài xử lý vi phạm

- Vi phạm Hành vi 1, 2, 3 chế tài xử lý vi phạm như sau:

| Lần 1 | Lần 2 | Lần 3 |
| --- | --- | --- |
| Khóa tài khoản 3 ngày. | Khóa tài khoản 7 ngày. | Chấm dứt hợp tácvĩnh viễn. |

- Vi phạm Hành vi 4, 5, 6, 7, 8, 9, 10, 11, 12 chấm dứt hợp tác vĩnh viễn.

### 2.Đối với bản thân Đối tác Tài xế

Tuân thủ quy định đồng phục Công ty

Hành vi vi phạm:

1. Không tuân thủ đúng tiêu chuẩn đồng phục của Công ty.

2. Không mặc/mặc thiếu/mặc đồng phục của Công ty cùng với đồng phục của các Công ty khác.

3. Sử dụng đồng phục/thương hiệu của Công ty cho mục đích cá nhân gây ảnh hưởng hình ảnh/uy tín của Công ty.

Duy trì đánh giá tốt của khách/Công ty

Hành vi vi phạm:

4. Không đạt tỷ lệ đánh giá sao tối thiểu theo quy định.

5. Tỷ lệ hủy chuyến hàng tuần cao hơn quy định.

Trung thực trong công việc

Hành vi vi phạm:

6. Yêu cầu/gợi ý khách: thanh toán thêm cước, bo/tip, trả phí cầu đường cao hơn thực tế, và các khoản tiền không đúng theo quy định.

7. Không trả lại tiền thừa cho khách. Chiếm dụng/Sử dụng trái phép tài sản của khách.

8. Có bất kỳ hành vi gian lận nhằm trục lợi từ ứng dụng/chính sách bao gồm nhưng không giới hạn một trong các vi phạm sau:

- Can thiệp vào các chương trình khuyến khích, thưởng, khuyến mãi.

- Phối hợp/thông đồng cùng người khác/khách tạo chuyến xe, tách thành nhiều chuyến ngắn, tạo cuốc ảo

- Tạo các chuyến đi giả mạo sử dụng hình thức thanh toán không tiền mặt hoặc thẻ Visa/Master Card giả.

- Dùng các ứng dụng hoặc phần mềm khác để trục lợi hoặc tạo ưu thế trong việc nhận chuyến xe.

9. Các hành vi không trung thực khác: hủy chuyến xe nhưng vẫn chở khách, in hóa đơn chứng từ khống,…

Chế tài xử lý vi phạm

- Vi phạm Hành vi 1, 2, 4, 5 chế tài xử lý vi phạm như sau:

| Lần 1 | Lần 2 | Lần 3 |
| --- | --- | --- |
| Khóa tài khoản 3 ngày. | Khóa tài khoản 7 ngày. | Chấm dứt hợp tácvĩnh viễn. |

- Vi phạm Hành vi 3: Chấm dứt hợp tác vĩnh viễn.

- Vi phạm Hành vi 6, 7, 8, 9: Chấm dứt hợp tác vĩnh viễn và áp dụng truy thu/ thu hồi chi phí (nếu có).

### 3.Đối với tài khoản ứng dụng và Tài sản/Thiết bị được Công ty cung cấp

Sử dụng tài khoản ứng dụng đúng quy định

Hành vi vi phạm:

1. Có hành vi sang nhượng/cho mượn hoặc cho người khác sử dụng tài khoản của mình dưới bất kỳ hình thức nào.

2. Sử dụng phương tiện không khớp với thông tin tài khoản.

Bảo quản và đảm bảo xe và phụ kiện, giấy tờ đúng quy định

Hành vi vi phạm:

3. Làm mất xe/phụ kiện/linh kiện/giấy tờ xe.

4. Không theo dõi bảo quản xe dẫn tới hư hỏng, hoặc không bảo dưỡng định kỳ theo mốc Km/thời gian quy định.

5. Thường xuyên để dung lượng pin dưới 20% gây hư hỏng.

6. Không bảo quản tốt dẫn tới sạc pin bị móp/vỡ/vào nước.

7. Va chạm gây gãy/vỡ/trầy xước lớn tới ngoại quan xe.

8. Tự ý đem xe đi sửa chữa/bảo dưỡng ngoài hệ thống xưởng.

9. Tự ý tráo đổi/thay thế/độ chế/thêm bớt linh kiện phụ tùng của xe hoặc cầm cố, thế chấp xe.

Chế tài xử lý vi phạm

- Vi phạm Hành vi 1, 2, chế tài xử lý vi phạm như sau: Chấm dứt hợp tác vĩnh viễn.

- Vi phạm Hành vi 3, 4, 5, 6, 7, 8, 9:– Tạm dừng hợp tác cho đến khi làm rõ trách nhiệm để xem xét xử lý (cả xét chuyển Cơ quan Công an xử lý nếu đủ căn cứ).– Đền bù theo giá trị thiệt hại cụ thể.

* Lưu ý dành cho ứng viên tham gia phỏng vấn:

- Yêu cầu mặc quần dài, áo có cổ, đi giày hoặc xăng-đan.

- Không mặc áo sát nách, quần ngắn/lửng, đi dép lê/dép tổ ong/dép trong nhà
