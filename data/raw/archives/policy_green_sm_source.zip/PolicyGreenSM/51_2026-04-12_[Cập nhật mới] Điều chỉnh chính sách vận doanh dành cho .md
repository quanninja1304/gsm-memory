# [Cập nhật mới] Điều chỉnh chính sách vận doanh dành cho Bác Tài Xanh Van

- **Ngày đăng:** 2026-04-12
- **Chuyên mục:** Cẩm nang tài xế, Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-moi-dieu-chinh-chinh-sach-van-doanh-danh-cho-bac-tai-xanh-van](https://www.greensm.com/vn-vi/news/cap-nhat-moi-dieu-chinh-chinh-sach-van-doanh-danh-cho-bac-tai-xanh-van)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/04/12509912-xanhvan-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # BÁC TÀI XANH
> 
> Cập nhật mới
> ## ĐIỀU CHỈNH CHÍNH SÁCH VẬN DOANH DÀNH CHO BÁC TÀI XANH VAN
> 
> **Thời gian áp dụng:**
> Kể từ 10/04/2026

Bác Tài Xanh thân mến,

Kể từ 10/04/2026, Green SM tiến hành điều chỉnh chính sách thu nhập và ưu đãi sạc xe dành cho Bác Tài Xanh Van nhằm tăng chất lượng và hiệu suất công việc. Cụ thể như sau:

1. Chính sách Đảm bảo thu nhập dành cho Bác Tài Xanh Van:

| THÔNG TIN CHUNG |
| --- |
| Đối tượng áp dụng | Bác Tài Xanh Van mới tham gia dịch vụ |
| Khu vực áp dụng | Hà Nội & Tp. Hồ Chí Minh (theo địa giới hành chính cũ) |
| Thời gian áp dụng | Áp dụng trong vòng 02 tháng, kể từ khi Bác Tài Xanh Van bắt đầu hoạt động dịch vụ, tính từ ngày 10/04/2026 |
| CHI TIẾT CHÍNH SÁCH ĐẢM BẢO THU NHẬP |
| Mức đảm bảo thu nhập | 520,000đ/ngày |
| Điều kiện áp dụng | – Đảm bảo doanh số tối thiểu/ngày ≥ 700,000đ– Tỷ lệ nhận chuyến ≥ 90%– Tỷ lệ hoàn thành chuyến ≥ 90%– Số giờ vận doanh tối thiểu/ngày ≥ 08 tiếng |

2.Chính sách ưu đãi  “Miễn phí sạc xe”:

| CHITIẾT CHÍNH SÁCH |
| --- |
| Miễn phí các lượt sạc phát sinhtừ lượt thứ 21 trở đi trong thángkhi thỏa mãn điều kiện(Số lần sạc trong tháng được tính từ ngày 26 tháng trước đến 25 tháng kế tiếp) |
| Thời gian miễn phí chi phí sạc xe tuần T |

| Thứ 2 | Từ 06h00 đến 23h59 |
| --- | --- |
| Từ thứ 3 đến chủ nhật | Từ 0h00 đến 23h59 |

| Điều kiện áp dụngBác Tài Xanh toàn quốc được hưởng chính sách “Miễn phí sạc xe” trong tuần T nếu đồng thời đáp ứng đầy đủ các điều kiện sau trong tuần T-1 |
| --- |
| (1) Sử dụng xe thuộc sở hữu của Green SM và đanglàm việc trong gian chính sách có hiệu lực(2) Đã đăng ký tham gia “Chính sách Miễn phí sạc xe” | Lưu ý:(1) & (2) áp dụng đối với xe thuộc sở hữu của Green SM đã mua và xuất hóa đơn từ ngày 10/02/2026 trở đi |
| – Vận doanh tối thiểu 06 ngày/tuần– Số giờ vận doanh trung bình tối thiểu/ngày ≥ 08 tiếng– Tỉ lệ nhận chuyến ≥ 85%/tuần– Tỉ lệ hoàn thành chuyến ≥ 85%/tuần |

Green SM khuyến khích Bác Tài Xanh tăng cường hoạt động để đáp ứng các yêu cầu từ chính sách từ đó gia tăng cơ hội thu nhập tối đa:

💙 Luôn vận doanh trong các khung giờ cao điểm ban ngày để tận dụng tối đa nhu cầu sử dụng dịch vụ của Khách hàng.💙Duy trì tỷ lệ nhận chuyến & hoàn thành chuyến, cũng như số giờ vận doanh ở mức cao nhất nhằm thỏa mãn các điều kiện chính sách, từ đó tận dụng tối đa lợi ích từ các chính sách.💙 Hạn chế hủy chuyến và luôn sẵn sàng nhận chuyến tối đa khi hệ thống phân bổ.

Việc duy trì vận doanh ổn định, đều đặn không chỉ giúp gia tăng thu nhập mà còn góp phần nâng cao hình ảnh Bác Tài Xanh chuyên nghiệp với chất lượng dịch vụ chuẩn Xanh.

Mọi thắc mắc về chính sách, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả!

Trân trọng,Đội ngũ Đồng hành và Phát triển Bác Tài Xanh
