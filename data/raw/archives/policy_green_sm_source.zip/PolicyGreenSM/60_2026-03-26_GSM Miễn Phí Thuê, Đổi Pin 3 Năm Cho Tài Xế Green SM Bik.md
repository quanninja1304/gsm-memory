# GSM Miễn Phí Thuê, Đổi Pin 3 Năm Cho Tài Xế Green SM Bike

- **Ngày đăng:** 2026-03-26
- **Chuyên mục:** Báo chí
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/gsm-mien-phi-thue-doi-pin-3-nam-cho-tai-xe-xanh-sm-bike](https://www.greensm.com/vn-vi/news/gsm-mien-phi-thue-doi-pin-3-nam-cho-tai-xe-xanh-sm-bike)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Hà Nội, ngày 26/03/2026 – Công ty GSM công bố triển khai chương trình ưu đãi đặc biệt: miễn phí thuê và đổi pin lên tới 3 năm cho tất cả tài xế xe máy điện Green SM Bike. Đây là chính sách khẩn cấp nhằm hỗ trợ tài xế nhanh chóng chuyển đổi sang xe máy điện, góp phần giảm thiểu áp lực nhiên liệu trong bối cảnh thị trường xăng dầu diễn biến khó lường.

Chính sách miễn phí thuê và đổi pin với ưu đãi vượt trội được GSM triển khai nhằm chia sẻ khó khăn với lực lượng tài xế hai bánh trên toàn quốc. Theo đó, tất cả khách hàng đã hoặc sẽ mua các dòng xe máy điện đổi pin của VinFast từ nay đến hết ngày 30/06/2026 và đăng ký vận doanh độc quyền trên nền tảng Green SM Platform sẽ được miễn phí thuê pin trong vòng 3 năm kể từ ngày chốt đơn.

Cùng với đó, thời hạn của chính sách miễn phí đổi pin không giới hạn số lần tại các tủ đổi pin công cộng dành cho các bác tài vận doanh độc quyền trên nền tảng Green SM Platform cũng sẽ được kéo dài đến hết ngày 31/03/2029. Như vậy, trong vòng 3 năm tới, lực lượng Green SM Bike sử dụng xe máy điện đổi pin VinFast trên toàn quốc sẽ được miễn phí hoàn toàn chi phí năng lượng.

Đây là sự hỗ trợ mạnh mẽ và thiết thực chưa từng có dành cho người lao động trên thị trường vận tải, đặc biệt trong bối cảnh giá xăng dầu tăng cao và nguồn cung gặp nhiều thách thức.

![Chương trình miễn phí thuê và đổi pin được áp dụng trên phạm vi toàn quốc, hướng tới các tài xế hai bánh đang hoạt động hoặc có nhu cầu tham gia nền tảng. ](https://cdn.xanhsm.com/2026/03/77c862c6-xanh-bike-22-1024x687.jpg)

Chương trình miễn phí thuê và đổi pin được áp dụng trên phạm vi toàn quốc, hướng tới các tài xế hai bánh đang hoạt động hoặc có nhu cầu tham gia nền tảng. 

Bên cạnh việc được miễn phí năng lượng dài hạn, các tài xế Green SM Bike còn được hưởng chính sách chia sẻ doanh thu vượt trội so với thị trường (lên tới 90% trong năm đầu, 85% trong các năm tiếp theo), mang lại cơ hội tối ưu thu nhập.

Đặc biệt, để tạo điều kiện chuyển đổi xanh cho các tài xế, GSM còn triển khai chương trình “Vào Xanh, Tặng Xe” cho phép tài xế nhận xe ngay để vận doanh mà chưa cần trả hết chi phí mua xe. Cụ thể, tài xế chỉ cần đặt cọc 3 triệu đồng và trả góp hàng tháng từ 1,5 triệu đồng đối với xe VinFast Evo và từ 1,7 triệu đồng đối với xe VinFast Feliz II là có thể sở hữu ngay phương tiện tạo ra thu nhập hàng ngày.

Không chỉ giải quyết bài toán chi phí mua xe ban đầu và chi phí năng lượng, tài xế Green SM Bike còn được hỗ trợ trọn gói chi phí và thủ tục liên quan đến việc đăng ký, đăng kiểm, bảo hiểm, bảo trì, bảo dưỡng và trang bị thiết bị định vị cho xe, ngoài ra còn được đảm bảo thu nhập tới 15 triệu/tháng miễn cọc ký quỹ, miễn lý lịch tư pháp và thưởng gia nhập lên tới 500.000 đồng.

“Thông qua các chính sách đặc biệt của VinFast và GSM, chúng tôi muốn tạo điều kiện tối đa cho các bác tài dễ dàng gia nhập hệ thống Green SM, nâng cao thu nhập thông qua việc giảm phụ thuộc vào nguồn nhiên liệu xăng dầu và hướng tới một môi trường làm việc văn minh, an toàn và lành mạnh hơn. Đây cũng là cách chúng tôi góp phần thúc đẩy công cuộc chuyển đổi xanh, đảm bảo an ninh năng lượng và ổn định an sinh xã hội cho đất nước”, ông Nguyễn Văn Thanh, Tổng Giám đốc Công ty GSM Toàn cầu chia sẻ.

Hiện tại, VinFast đã ra mắt 3 mẫu xe máy điện đổi pin gồm Viper, Feliz II và Evo, với mức giá chỉ từ 19,9 triệu đồng. Khách hàng có thể mua pin hoặc thuê pin với chi phí 175.000 đồng/tháng cho 1 pin và 300.000 đồng/tháng cho 2 pin. Mức phí đổi pin tại tủ đổi pin công cộng là 9.000 đồng/lần./.
