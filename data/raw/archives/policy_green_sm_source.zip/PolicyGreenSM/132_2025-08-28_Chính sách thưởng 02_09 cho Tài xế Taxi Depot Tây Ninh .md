# Chính sách thưởng 02/09 cho Tài xế Taxi Depot Tây Ninh 1

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-cho-tai-xe-taxi-depot-tay-ninh-1](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-cho-tai-xe-taxi-depot-tay-ninh-1)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Dịp lễ Quốc khánh 02/09 là lúc nhu cầu di chuyển tăng vọt – cũng chính là“thời điểm vàng”để Bác tài Green SM tăng tốc thu nhập và rinh thêm thưởng hấp dẫn! Trong 4 ngày cao điểm lễ, Green SM triển khaichính sáchdành riêng cho các Bác tài vận doanh:👉Đối tượng áp dụng: Tài xế Taxi Green SM tại các Depot Tây Ninh 1👉Thời gian áp dụng:Từ30/08 – 02/09/2025👉Nội dung chính sách: Tỷ lệthưởng trách nhiệmvà doanh sốđược điều chỉnhtăng thêmso với ngày thường👉Chi tiết mức thưởng: Bác tài vui lòng xem trong hình ảnh đính kèm

![Chính sách thưởng cho Tài xế Taxi Depot Tây Ninh 1](https://cdn.xanhsm.com/2025/08/b1f2e886-250828-tn1-742x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ ĐẠI LỄ QUỐC KHÁNH 02/09
> 
> **Đối tượng áp dụng:** Tài xế Taxi trực thuộc Depot Tây Ninh 1 (Tây Ninh cũ, không bao gồm Long An) tham gia vận doanh trong dịp Lễ
> **Thời gian áp dụng:** 04 ngày từ ngày 30/08 đến ngày 02/09/2025
> 
> **Nội dung chính sách**
> Tỷ lệ thưởng trách nhiệm và doanh số được điều chỉnh tăng thêm lên đến **10%** so với ngày thường
> 
> ## Xanh SM Car
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ ngày 30 - 31/08 | Tỷ lệ chia sẻ ngày 01 - 02/09 |
> | :---- | :---------------------------- | :-------------------------- | :-------------------------- |
> | Mức 0 | Dưới 650.000                  | 30%                         | 35%                         |
> | Mức 1 | Từ 650.000 đến dưới 950.000    | 38%                         | 43%                         |
> | Mức 2 | Từ 950.000 đến dưới 1.350.000  | 42%                         | 47%                         |
> | Mức 3 | Từ 1.350.000 đến dưới 1.650.000 | 50%                         | 55%                         |
> | Mức 4 | Từ 1.650.000 trở lên          | 53%                         | 58%                         |
> 
> ## Xanh SM Premium
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ ngày 30 - 31/08 | Tỷ lệ chia sẻ ngày 01 - 02/09 |
> | :---- | :---------------------------- | :-------------------------- | :-------------------------- |
> | Mức 0 | Dưới 550.000                  | 30%                         | 35%                         |
> | Mức 1 | Từ 550.000 đến dưới 700.000    | 39%                         | 44%                         |
> | Mức 2 | Từ 700.000 đến dưới 1.000.000  | 47%                         | 52%                         |
> | Mức 3 | Từ 1.000.000 đến dưới 1.400.000 | 51%                         | 56%                         |
> | Mức 4 | Từ 1.400.000 trở lên          | 53%                         | 58%                         |

⚡ Sẵn sàng bứt tốc đại lễ cùng Green SM – càng chạy nhiều, càng nhận chia sẻ cao!

Mến chúc các Bác tài vận hành an toàn và hiệu quả!

Trân trọng,Đội ngũ Green SM
