# Nhắc nhở về việc tuân thủ Nghị định 100/2019/NĐ-CP

- **Ngày đăng:** 2025-03-01
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/nhac-nho-tuan-thu-nghi-dinh-100](https://www.greensm.com/vn-vi/news/nhac-nho-tuan-thu-nghi-dinh-100)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm đảm bảo tuân thủ đúng quy định của pháp luật, đặc biệt làĐiểm t, Khoản 4, Điều 28 của Nghị định 100/2019/NĐ-CP, Quý Đối tác vui lòng lưu ý quy định sau:“Sử dụng xe taxi, xe kinh doanh vận tải hành khách theo hợp đồng, xe kinh doanh vận tải khách du lịch cótrên 70% tổng thời gian hoạt động trong 01 tháng(của xe) tại địa bàn của một địa phương (tỉnh, thành phố trực thuộc trung ương) mà không có phù hiệu do Sở Giao thông vận tải địa phương đó cấp theo quy định.”

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/03/58a9b2be-20260228_nhacnhotuanthu-958x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # NHẮC NHỞ TUÂN THỦ NGHỊ ĐỊNH 100/2019/NĐ-CP
> 
> **Đối tượng áp dụng:** Tài xế Car Platform
> 
> Theo điểm t khoản 4 Điều 28 Nghị định 100/2019/NĐ-CP: "Sử dụng xe taxi, xe kinh doanh vận tải hành khách theo hợp đồng, xe kinh doanh vận tải khách du lịch có trên **70%** tổng thời gian hoạt động trong **01 tháng** (của xe) tại địa bàn của một địa phương (tỉnh, thành phố trực thuộc trung ương) mà không có phù hiệu do Sở Giao thông vận tải địa phương đó cấp theo quy định."
> 
> ### Ví dụ về phạm vi hoạt động hợp lệ
> 
> | Nên | Không nên |
> |---|---|
> | Xe có phù hiệu do Sở Giao thông vận tải TP.HCM cấp. | Xe có phù hiệu do Sở Giao thông vận tải TP.HCM cấp nhưng hoạt động chủ yếu tại Đồng Nai |
> | Trong 01 tháng, tổng thời gian hoạt động tại TP. Hồ Chí Minh > 70%. | Trong 01 tháng, tổng thời gian hoạt động tại TP. Hồ Chí Minh < 70%, trong khi khu vực khác chiếm trên 30%. |
> 
> **Lưu ý quan trọng**
> 
> *   Việc xác định tổng thời gian hoạt động của phương tiện được thực hiện dựa trên dữ liệu từ thiết bị giám sát hành trình.
> *   Nếu vi phạm quy định dù đã được nhắc nhở, Xanh SM sẽ xem xét tạm ngừng cung cấp dịch vụ đối với phương tiện vi phạm.

🚨Lưu ý quan trọng:

- Việc xác định tổng thời gian hoạt động của phương tiện được thực hiện dựa trêndữ liệu từ thiết bị giám sát hành trình.

- Nếu vi phạm quy định dù đã được nhắc nhở, Green SM sẽ xem xét tạm ngừng cung cấp dịch vụ đối với phương tiện vi phạm.

Mến chúc Bác tài hoạt động an toàn và hiệu quả!

Trân trọng,Đội ngũ Green SM Platform.
