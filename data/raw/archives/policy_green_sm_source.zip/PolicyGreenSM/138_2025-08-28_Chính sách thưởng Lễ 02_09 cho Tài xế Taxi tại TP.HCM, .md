# Chính sách thưởng Lễ 02/09 cho Tài xế Taxi tại TP.HCM, Hà Nội và Đà Nẵng

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-2-9-txtx-tai-ha-noi-tphcm-da-nang](https://www.greensm.com/vn-vi/news/thuong-2-9-txtx-tai-ha-noi-tphcm-da-nang)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Dịp lễ Quốc khánh 02/09 là lúc nhu cầu di chuyển tăng vọt – cũng chính là“thời điểm vàng”để Bác tài Green SM tăng tốc thu nhập và rinh thêm thưởng hấp dẫn! Trong 4 ngày cao điểm lễ, Green SM triển khaichính sáchdành riêng cho các Bác tài vận doanh:👉Đối tượng áp dụng: Tài xế Taxi Green SM tại các Depot Hà Nội 1, 2, 3; Hồ Chí Minh 1, 2, 6, 7 và Đà Nẵng 1👉Thời gian áp dụng:Từ30/08 – 02/09/2025👉Nội dung chính sách: Tỷ lệthưởng trách nhiệmvà doanh sốđược điều chỉnhtăng thêmso với ngày thường👉Chi tiết mức thưởng: Bác tài vui lòng xem trong hình ảnh đính kèm

![Chính sách thưởng Lễ 02/09 tại TP.HCM, Hà Nội và Đà Nẵng](https://cdn.xanhsm.com/2025/08/10eea846-250827_hn123hcm1267dn1-688x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # ĐẠI LỄ QUỐC KHÁNH 02/09
> ## THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ LÊN ĐẾN 65%
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Depot Hà Nội 1, 2, 3; Hồ Chí Minh 1, 2, 6, 7 và Đà Nẵng 1 tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** 04 ngày từ ngày 30/08 đến ngày 02/09/2025
> 
> ## Nội dung chính sách
> Tỷ lệ thưởng trách nhiệm và doanh số được điều chỉnh tăng thêm lên đến 19% so với ngày thường
> 
> ### Xanh SM Car
> 
> | Mức   | Doanh số (VNĐ/ngày)            | Tỷ lệ chia sẻ ngày 30 - 31/08 | Tỷ lệ chia sẻ ngày 01 - 02/09 |
> | :---- | :----------------------------- | :-------------------------- | :-------------------------- |
> | Mức 0 | Dưới 1.000.000                 | 33%                         | 38%                         |
> | Mức 1 | Từ 1.000.000 đến dưới 1.300.000 | 39%                         | 44%                         |
> | Mức 2 | Từ 1.300.000 đến dưới 1.600.000 | 45%                         | 50%                         |
> | Mức 3 | Từ 1.600.000 đến dưới 2.100.000 | 52%                         | 57%                         |
> | Mức 4 | Từ 2.100.000 trở lên           | 60%                         | 65%                         |
> 
> ### Xanh SM Premium
> 
> | Mức   | Doanh số (VNĐ/ngày)            | Tỷ lệ chia sẻ ngày 30 - 31/08 | Tỷ lệ chia sẻ ngày 01 - 02/09 |
> | :---- | :----------------------------- | :-------------------------- | :-------------------------- |
> | Mức 0 | Dưới 900.000                   | 32%                         | 37%                         |
> | Mức 1 | Từ 900.000 đến dưới 1.200.000   | 41%                         | 46%                         |
> | Mức 2 | Từ 1.200.000 đến dưới 1.500.000 | 50%                         | 55%                         |
> | Mức 3 | Từ 1.500.000 đến dưới 2.000.000 | 59%                         | 64%                         |
> | Mức 4 | Từ 2.000.000 trở lên           | 62%                         | 67%                         |
> 
> ## Ghi chú
> * **Depot Hà Nội 1, 2, 3:** các Depot trực thuộc Thủ đô Hà Nội
> * **Depot Hồ Chí Minh 1, 2, 6, 7:** các Depot trực thuộc TP. Hồ Chí Minh cũ, không bao gồm Bình Dương và Bà Rịa - Vũng Tàu cũ
> * **Depot Đà Nẵng 1:** Depot trực thuộc Đà Nẵng cũ, không bao gồm Quảng Nam cũ

⚡ Sẵn sàng bứt tốc đại lễ cùng Green SM – càng chạy nhiều, càng nhận chia sẻ cao!

Mến chúc các Bác tài vận hành an toàn và hiệu quả!

Trân trọng,Đội ngũ Green SM
