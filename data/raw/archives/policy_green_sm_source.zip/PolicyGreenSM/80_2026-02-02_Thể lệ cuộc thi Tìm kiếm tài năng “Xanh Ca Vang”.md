# Thể lệ cuộc thi Tìm kiếm tài năng “Xanh Ca Vang”

- **Ngày đăng:** 2026-02-02
- **Chuyên mục:** Cộng đồng, Tài xế Green SM Bike, Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/the-le-cuoc-thi-tim-kiem-tai-nang-xanh-ca-vang](https://www.greensm.com/vn-vi/news/the-le-cuoc-thi-tim-kiem-tai-nang-xanh-ca-vang)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Dành cho các Bác Tài Xanh trên toàn quốc

Từ ngày 02/02 đến 10/03/2026, Green SM tổ chức cuộc thi “Xanh Ca Vang”, mời các Bác Tài Xanh cùng hát và cover ca khúc “Bác Tài Xanh Xin Chào” theo phong cách và câu chuyện của riêng mình.

Đây là sân chơi âm nhạc gần gũi, nơi mỗi Bác Tài có thể ghi lại những khoảnh khắc đời thường sau tay lái, bên gia đình, bạn bè và lan tỏa tinh thần tích cực của người làm nghề dịch vụ mỗi ngày.

Cuộc thi không tìm kiếm giọng ca chuyên nghiệp, không đặt nặng kỹ thuật trình diễn, mà trân trọng sự chân thành, cá tính và câu chuyện thật của mỗi Bác Tài Xanh.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/02/331124ed-0202_16x9xanhcavang-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # XANH SM
> 
> ## XANH CA VÀNG
> 
> **Thời gian:** 02/02 - 25/02
> 
> **Slogan:** LÊN XE CẦM LÁI, LÊN MIC TRỔ TÀI
> 
> **Tổng giải thưởng lên đến:** 58 TRIỆU ĐỒNG
> ```

## 1. Đối tượng tham dự

Tất cả các Bác Tài Xanh hiện đang vận doanh trên nền tảng Green SM tại Việt Nam.

## 2. Hình thức tham dự

### 2.1. Cách thức tham gia

- Sử dụng nhạc nền ca khúc “Bác Tài Xanh Xin Chào” tại đường link nằm trên trang YouTube Green SM Official (https://youtu.be/GaQhQm9aUcI);

- Quay video hát và trình diễn ca khúc “Bác Tài Xanh Xin Chào” theo hình thức cá nhân hoặc tập thể (từ 02 người trở lên);

- Đăng tải video lên Facebook và TikTok cá nhân ở chế độ công khai;

- Bài đăng sử dụng đầy đủ hashtag: #BacTaiXanhXinChao #XanhCaVang để được xem là hợp lệ;

- Video có sự tham gia hỗ trợ phụ họa từ gia đình, bạn bè, đồng nghiệp,… là yếu tố cộng điểm.

### 2.2. Quy định tham dự

Các video có chạy quảng cáo, seeding tương tác hoặc can thiệp tăng tương tác sẽ không được công nhận và bị loại khỏi cuộc thi.

### 2.3. Thời gian dự thi

- Thời gian nhận bài dự thi: Đến hết ngày 10/03/2026

- Thời gian chấm điểm và tổng hợp kết quả: 11/03/2026 – 15/03/2026

- Thời gian công bố kết quả: 16/03/2026

## 3. Cách tính điểm

Tổng điểm của mỗi video dự thi theo hình thức cá nhân & tập thể đều được tính dựa trên 02 tiêu chí:

- Lượt tương tác tự nhiên của bài đăng (lượt tương tác, bình luận, chia sẻ );

- Điểm đánh giá từ Ban Giám Khảo (BGK)

Kết quả chung cuộc của Giải Cá Nhân và Giải Tập Thể được xác định dựa trên tổng điểm tương tác + điểm BGK.

Riêng với những Giải Phụ kết quả được tính theo điểm đánh giá từ BGK.

## 4. Cơ cấu giải thưởng:

Tổng giá trị giải thưởng lên tới 58.000.000 đồng.

### 4.1 Giải Cá Nhân

| Giải Nhất | 1 giải | 5.000.000đ/giải |
| --- | --- | --- |
| Giải Nhì | 2 giải | 3.000.000đ/giải |
| Giải Ba | 3 giải | 1.000.000đ/giải |

Tiêu chí: Top 06 video cover cá nhân có tổng điểm cao nhất, được đánh giá dựa trên:

- Điểm từ BGK;

- Lượt tương tác hợp lệ từ khán giả.

### 4.2 Giải Tập Thể

| Giải Nhất | 1 giải | 10.000.000đ/giải |
| --- | --- | --- |
| Giải Nhì | 2 giải | 6.000.000đ/giải |
| Giải Ba | 3 giải | 2.000.000đ/giải |

Tiêu chí: Top 06 video cover tập thể (từ 02 người trở lên) có tổng điểm cao nhất, được đánh giá dựa trên:

- Điểm từ BGK;

- Lượt tương tác hợp lệ từ khán giả.

### 4.3. Giải Phụ

| Giải Khán Giả Yêu Thích Nhất | 1 giải | 2.000.000đ/giải | Giải video có lượt tương tác hợp lệ cao nhất từ khán giả. |
| --- | --- | --- | --- |
| Giải Xanh Triển Vọng | 10 giải | 500.000đ/giải | Dành cho giọng hát có tiềm năng, thể hiện cảm xúc tốt, mang tính khuyến khích. |
| Giải Xanh Ấn Tượng | 3 giải | 1.000.000đ/giải | Dành cho phần trình diễn tự tin, có thần thái và dấu ấn cá nhân. |
| Giải Xanh Yêu Thương | 3 giải | 1.000.000đ/giải | Dành cho video có sự tham gia, cổ vũ hoặc hỗ trợ biểu diễn từ gia đình, bạn bè, người thân hoặc đồng nghiệp đông và vui nhất. |
| Giải Xanh Sáng Tạo | 3 giải | 1.000.000đ/giải | Dành cho video có ý tưởng trình bày độc đáo, sáng tạo, nhưng vẫn đúng tinh thần cover ca khúc. |

## 5. Cách thức trả thưởng

Giải thưởng sẽ được topup trực tiếp 01 lần vào ví Bác Tài Xanh.

## 6. Điều kiện nhận thưởng

- Bác Tài tham gia và sản phẩm dự thi đạt đủ điều kiện theo thể lệ chương trình;

- Bác Tài không vi phạm các quy định nội bộ của công ty trong thời gian diễn ra cuộc thi;

- Quyết định của Green SM là quyết định cuối cùng.

Từ những chuyến xe quen thuộc đến những giai điệu thân thương, Xanh Ca Vang mong muốn trở thành nơi mỗi Bác Tài Xanh tự tin cất tiếng hát và chia sẻ câu chuyện của mình.

Hãy cùng Green SM hát “Bác Tài Xanh Xin Chào” và lan tỏa niềm tự hào khi khoác lên màu áo Xanh.
