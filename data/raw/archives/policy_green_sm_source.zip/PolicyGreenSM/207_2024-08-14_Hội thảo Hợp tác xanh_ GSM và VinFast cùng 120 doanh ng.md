# Hội thảo Hợp tác xanh: GSM và VinFast cùng 120 doanh nghiệp vận tải chuyển đổi xanh

- **Ngày đăng:** 2024-08-14
- **Chuyên mục:** Báo chí, Công ty
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/hoi-thao-hop-tac-xanh-gsm-va-vinfast-cung-120-doanh-nghiep-van-tai-chuyen-doi-xanh](https://www.greensm.com/vn-vi/news/hoi-thao-hop-tac-xanh-gsm-va-vinfast-cung-120-doanh-nghiep-van-tai-chuyen-doi-xanh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Tuần vừa qua, GSM kết hợp với VinFast tổ chức chuỗi hội thảo về hợp tác xanh, thu hút hơn 120 hãng taxi tham gia sự kiện tại Hà Nội, Đà Nẵng, TP. Hồ Chí Minh.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/08/b2488268-file-7009-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là toàn bộ văn bản và thông tin được trích xuất từ hình ảnh, được định dạng theo Markdown:
> 
> ```markdown
> # MẠNH LIỆT
> # TINH THẦN VIỆT NAM
> Vỉ Tương Lai Xanh
> ```

Tại chuỗi sự kiện, GSM chia sẻ về chính sách đồng hành chuyển đổi xanh, đồng thời tư vấn, giải đáp các câu hỏi của doanh nghiệp mong muốn trở thành đối tác nhượng quyền của GSM trong việc khai thác dịch vụ vận tải taxi bằng xe điện trên toàn quốc.

Một số chính sách nổi bật dành riêng cho các doanh nghiệp tại hội thảo gồm ưu đãi thêm khi mua xe, ưu đãi gói thuê pin phù hợp với hạn mức chạy dịch vụ, hỗ trợ bảo lãnh, hoặc chuyển đổi từ xe xăng sang xe điện. Các đối tác có tiềm năng, khả năng điện hóa nhanh 100% cũng được hưởng thêm một số ưu đãi đặc biệt khi hợp tác với GSM và VinFast.

Chuỗi hội thảo còn có đại diện các doanh nghiệp tiên phong như Lado Taxi (Lâm Đồng), Én Vàng Taxi (Hải Phòng), ASV Airports Taxi (TP. Hồ Chí Minh), Taxi Bách Đại Dũng (Hà Tĩnh), dịch vụ Bạn Uống Tôi Lái (khu vực Tây Nam Bộ) tham dự với vai trò diễn giả. Từ kinh nghiệm tích lũy từ những ngày đầu đồng hành cùng GSM trên chặng đường “điện hóa” giao thông, các đối tác đã có những chia sẻ thực tế, truyền cảm hứng về ngành dịch vụ vận tải, cụ thể ở mảng vận hành taxi bằng xe điện.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/08/9261bc2f-5m0a1497-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> ```markdown
> XANH SM
> MÃNH LIỆT
> TÌNH THÂN VIỆT NAM
> Vì Tương Lai Xanh
> Hà Nội, 31.07.2024
> ```

Ông Nguyễn Ngọc Đồng, Tổng Giám đốc Công ty TNHH Đồng Thúy (đơn vị chủ quản của Lado Taxi) cho biết, quyết định tiếp tục tiên phong đầu tư xe điện vừa là vì tương lai xanh cho thế hệ mai sau, vừa là vì hiệu quả kinh doanh được chứng thực sau hơn 1 năm đưa xe điện vào hãng: “Ngay cả trong những giai đoạn kinh tế khó khăn, Lado Taxi vẫn giữ mức ổn định về doanh thu khi rất nhiều người dân và khách du lịch yêu thích, ủng hộ di chuyển bằng xe điện. Thu nhập của tài xế hãng cũng tốt hơn”.

Hợp tác cùng GSM và VinFast từ tháng 5/2023 để đưa ô tô điện vào khai thác dịch vụ taxi điện đưa đón tại sân bay Nội Bài và Tân Sơn Nhất, ông Nguyễn Duy Hưng, Chủ tịch HĐQT kiêm Tổng Giám đốc ASV cũng nhận định về các ưu thế vượt trội của xe điện như “tiết kiệm nhiên liệu đến 37% so với xe xăng, quy trình quản lý minh bạch với các ứng dụng công nghệ. Khách hàng trải nghiệm cũng hài lòng hơn với xe không mùi, rộng rãi. sạch sẽ”.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/08/8b6844d1-5m0a1818-1024x683.jpg)

Chỉ tính riêng trong đầu năm 2024, khi hiệu quả kinh doanh vận tải bằng xe điện dần trở nên rõ nét, một số đối tác tiên phong đã tái ký cùng GSM để mở rộng quy mô đội xe điện và địa bàn hoạt động độc quyền. Ông Nguyễn Văn Định, Chủ tịch HĐQT Công ty CP Én Vàng Quốc Tế chia sẻ: “Khi hợp tác cùng Green SM và đồng hành phát triển thị trường xe điện, thương hiệu Én Vàng Taxi cũng lan tỏa, được nhiều người biết đến và tin tưởng trải nghiệm”.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/08/65535be9-file-6992-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Hà Nội, 31.07.2024

Nhiều tên tuổi mới cũng tham gia vào mạng lưới giao thông xanh, nâng tổng số đối tác của GSM lên đến 35 doanh nghiệp. Theo ông Định, từ đây mô hình kinh doanh vận tải tại Việt Nam cũng được định hướng rõ nét, tạo ra ngành nghề dịch vụ vận tải “tiết kiệm, thân thiện với môi trường, đóng góp tích cực cho xã hội”.

Dưới ngọn cờ “Mãnh liệt tinh thần Việt Nam”, GSM sẽ cùng VinFast lan tỏa mạnh mẽ tinh thần chuyển đổi xanh, tiếp tục truyền cảm hứng và chào đón sự cộng tác của các doanh nghiệp vận tải, đẩy nhanh quá trình chuyển đổi giao thông xanh, bền vững của thế giới.
