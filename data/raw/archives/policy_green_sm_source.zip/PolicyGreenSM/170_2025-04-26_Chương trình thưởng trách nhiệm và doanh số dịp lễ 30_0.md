# Chương trình thưởng trách nhiệm và doanh số dịp lễ 30/04 – 01/05

- **Ngày đăng:** 2025-04-26
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chuong-trinh-thuong-trach-nhiem-va-doanh-so-dip-le](https://www.greensm.com/vn-vi/news/chuong-trinh-thuong-trach-nhiem-va-doanh-so-dip-le)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Dịp lễ 30/04 – 01/05 là thời điểm nhu cầu di chuyển tăng cao – cũng là cơ hội vàng để Bác tài tăng tốc thu nhập! Nắm bắt cơ hội này, Green SM triển khai chính sách thưởng đặc biệt dành cho Bác tài vận doanh trong 2 ngày lễ cao điểm. Nội dung chương trình như sau:

👉Đối tượng áp dụng: Tài xế Taxi Green SM vận doanh vào ngày 30/04 và 01/05/2025.

👉Chi tiết mức thưởng:Bác tài vui lòng tham khảo ở hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/696fd26e-20250422_hnhcmdn-1024x997.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ 30/04 - 01/05
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Hà Nội, TP.HCM, Đà Nẵng tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** 02 ngày từ ngày 30/04 đến ngày 01/05/2025
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **15%** so với ngày thường.
> 
> | | Xanh Car | | | Xanh Premium | |
> | :---- | :-------------------- | :------------- | :---- | :-------------------- | :------------- |
> | **Mức** | **Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** | **Mức** | **Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0 | Dưới 1.000.000         | 38%            | Mức 0 | Dưới 900.000          | 37%            |
> | Mức 1 | Từ 1.000.000 - < 1.300.000 | 43%            | Mức 1 | Từ 900.000 - < 1.200.000 | 45%            |
> | Mức 2 | Từ 1.300.000 - < 1.600.000 | 48%            | Mức 2 | Từ 1.200.000 - < 1.500.000 | 52%            |
> | Mức 3 | Từ 1.600.000 - < 2.100.000 | 54%            | Mức 3 | Từ 1.500.000 - < 2.000.000 | 60%            |
> | Mức 4 | Từ 2.100.000 trở lên   | 61%            | Mức 4 | Từ 2.000.000 trở lên  | 63%            |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/1bc11c9f-20250422_quangninh-1024x997.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ 30/04 - 01/05
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Quảng Ninh tham gia vận doanh trong dịp lễ
> 
> **Thời gian áp dụng:** 02 ngày từ ngày 30/04 đến ngày 01/05/2025
> 
> **Nội dung chính sách**
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **12%** so với ngày thường.
> 
> | | Xanh Car | | | Xanh Premium | |
> |---|---|---|---|---|---|
> | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0 | Dưới 850.000 | 36% | Mức 0 | Dưới 750.000 | 36% |
> | Mức 1 | Từ 850.000 - < 1.150.000 | 45% | Mức 1 | Từ 750.000 - < 1.050.000 | 42% |
> | Mức 2 | Từ 1.150.000 - < 1.650.000 | 49% | Mức 2 | Từ 1.050.000 - < 1.400.000 | 48% |
> | Mức 3 | Từ 1.650.000 - < 2.100.000 | 58% | Mức 3 | Từ 1.400.000 - < 1.900.000 | 57% |
> | Mức 4 | Từ 2.100.000 trở lên | 60% | Mức 4 | Từ 1.900.000 trở lên | 59% |
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/a14c2cb8-20250422_khanhhoahue-1024x997.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ 30/04 - 01/05
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Khánh Hòa, Huế tham gia vận doanh trong dịp lễ
> 
> **Thời gian áp dụng:** 02 ngày từ ngày 30/04 đến ngày 01/05/2025
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **12%** so với ngày thường.
> 
> | | Xanh Car | | | Xanh Premium | |
> |---|---|---|---|---|---|
> | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0 | Dưới 800.000 | 36% | Mức 0 | Dưới 700.000 | 36% |
> | Mức 1 | Từ 800.000 - < 1.100.000 | 44% | Mức 1 | Từ 700.000 - < 950.000 | 42% |
> | Mức 2 | Từ 1.100.000 - < 1.600.000 | 49% | Mức 2 | Từ 950.000 - < 1.300.000 | 46% |
> | Mức 3 | Từ 1.600.000 - < 2.000.000 | 57% | Mức 3 | Từ 1.300.000 - < 1.700.000 | 52% |
> | Mức 4 | Từ 2.000.000 trở lên | 60% | Mức 4 | Từ 1.700.000 trở lên | 59% |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/f44eed5e-20250422_thanhhoa-1024x995.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ 30/04 - 01/05
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Thanh Hóa tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** 02 ngày từ ngày 30/04 đến ngày 01/05/2025
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến 12% so với ngày thường.
> 
> | | Xanh Car | | Xanh Premium | |
> | :--- | :--- | :--- | :--- | :--- | :--- |
> | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0 | Dưới 650.000 | 36% | Mức 0 | Dưới 500.000 | 36% |
> | Mức 1 | Từ 650.000 -< 950.000 | 44% | Mức 1 | Từ 500.000 - < 700.000 | 47% |
> | Mức 2 | Từ 950.000 - < 1.350.000 | 49% | Mức 2 | Từ 700.000 - < 900.000 | 53% |
> | Mức 3 | Từ 1.350.000 - < 1.650.000 | 57% | Mức 3 | Từ 900.000 - < 1.100.000 | 57% |
> | Mức 4 | Từ 1.650.000 trở lên | 60% | Mức 4 | Từ 1.100.000 trở lên | 59% |
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/9ed24646-20250422_ngoaitru-1024x947.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản đã được trích xuất và định dạng Markdown:
> 
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ 30/04 - 01/05
> 
> *   **Đối tượng áp dụng:** Tài xế Taxi (Xanh Car và Xanh Premium) tham gia vận doanh trong dịp lễ
> *   **Khu vực áp dụng:** Tất cả các tỉnh, thành phố ngoại trừ: Hà Nội, TP.HCM, Đà Nẵng, Huế, Thanh Hóa, Khánh Hòa và Quảng Ninh
> *   **Thời gian áp dụng:** 02 ngày từ ngày 30/04 đến ngày 01/05/2025
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến 10% so với ngày thường.
> 
> | Mức   | Tỷ lệ chia sẻ tăng so với Chính sách ngày thường |
> | :---- | :--------------------------------------------- |
> | Mức 0 |                                                |
> | Mức 1 |                                                |
> | Mức 2 | 10%                                            |
> | Mức 3 |                                                |
> | Mức 4 |                                                |
> 
> **Ví dụ:** Bác tài hoạt động tại tỉnh A, đạt mốc doanh số mức 2. Ngày thường nhận 33% chia sẻ, riêng ngày 30/04 được chia sẻ 43% doanh số (tăng thêm 10%).

🔥 Hãy sẵn sàng “lăn bánh hết ga”, phục vụ khách hàng thật tốt và rinh thưởng hấp dẫn từ Green SM!

Mến chúc các Bác tài vận hành an toàn và hiệu quả!

Trân trọng,Đội ngũ Green SM
