# Ra Mắt “Sổ tay Đối tác Nhà hàng”: Bộ Bí Kíp Dành Cho Chủ Quán

- **Ngày đăng:** 2026-05-20
- **Chuyên mục:** Nhà hàng
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/ra-mat-so-tay-doi-tac-nha-hang](https://www.greensm.com/vn-vi/news/ra-mat-so-tay-doi-tac-nha-hang)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Quý Đối tác Nhà hàng thân mến,

Nhằm đồng hành cùng Quý Đối tác trong quá trình vận hành trên Green SM Food, “Sổ tay Đối tác Nhà hàng” được biên soạn nhằm cung cấp các hướng dẫn và thông tin cần thiết liên quan đến quy tắc ứng xử, tiêu chuẩn dịch vụ, cách sử dụng ứng dụngGreen SM Merchantcũng như các quy trình hỗ trợ trong quá trình hoạt động.

![Ra Mắt “Sổ tay Đối tác Nhà hàng”: Bộ Bí Kíp Dành Cho Chủ Quán ](https://cdn.xanhsm.com/2026/05/4470da30-anh-noi-dung-dau-bai-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> V GREEN SM FOOD
> SỔ TAY
> ĐỐI TÁC NHÀ HÀNG
> ```

Sổ tay giúp Quý Đối tác dễ dàng tra cứu thông tin và tối ưu hoạt động vận hành trên nền tảng Green SM Food với các nhóm nội dung chính bao gồm:

- Quy tắc/Quy định chung

- Hướng dẫn sử dụng ứng dụng Green SM Merchant

- Quy trình bồi hoàn

- Các câu hỏi thường gặp

- Phụ lục

## I. QUY TẮC/QUY ĐỊNH CHUNG

Green SM Food cập nhật Bộ Quy tắc/Quy định chung dành cho Đối tác Nhà hàng với các nội dung liên quan đến quy tắc ứng xử, tiêu chuẩn dịch vụ và các quy định vận hành trên nền tảng nhằm góp phần duy trì chất lượng dịch vụ và nâng cao trải nghiệm Khách hàng.

![I. QUY TẮC/QUY ĐỊNH CHUNG ](https://cdn.xanhsm.com/2026/05/8df88c34-anh-noi-dung-1-1024x439.png)

> **[Nội dung trích xuất từ ảnh]:**
> # I QUY TẮC/QUY ĐỊNH CHUNG
> dành cho
> # THƯƠNG NHÂN
> # NHÀ HÀNG

## II. HƯỚNG DẪN SỬ DỤNG ỨNG DỤNG GREEN SM MERCHANT

Phần hướng dẫn giúp Quý Đối tác cài đặt, đăng nhập và sử dụng ứng dụng Green SM Merchant để quản lý hoạt động kinh doanh trên nền tảng. Bao gồm các thao tác thiết lập quán, quản lý thực đơn, xử lý đơn hàng, thanh toán – đối soát, trang trí gian hàng và triển khai chương trình khuyến mại.

![II. HƯỚNG DẪN SỬ DỤNG ỨNG DỤNG GREEN SM MERCHANT](https://cdn.xanhsm.com/2026/05/82e50599-anh-noi-dung-2-1024x439.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # HƯỚNG DẪN SỬ DỤNG
> ## Ứng dụng GREEN SM MERCHANT
> (Trên màn hình điện thoại hiển thị ứng dụng "Green SM Merchant")
> ```

## III. QUY TRÌNH BỒI HOÀN

Quy trình bồi hoàn được xây dựng nhằm hỗ trợ Quý Đối tác đảm bảo quyền lợi trong quá trình vận hành đối với các đơn hàng bị hủy. Nội dung bao gồm thao tác gửi yêu cầu, điều kiện áp dụng, thời gian xử lý và các lưu ý quan trọng trong quá trình thực hiện.

![III. QUY TRÌNH BỒI HOÀN](https://cdn.xanhsm.com/2026/05/9b5e6935-anh-noi-dung-3-1024x439.png)

> **[Nội dung trích xuất từ ảnh]:**
> III QUY TRÌNH BỒI HOÀN

## IV. CÁC CÂU HỎI THƯỜNG GẶP

Green SM Food tổng hợp các câu hỏi thường gặp liên quan đến vận hành gian hàng trên nền tảng nhằm hỗ trợ Quý Đối tác dễ dàng tra cứu và xử lý nhanh các tình huống phổ biến trong quá trình hoạt động.

![IV. CÁC CÂU HỎI THƯỜNG GẶP](https://cdn.xanhsm.com/2026/05/7159d7b9-anh-noi-dung-4-1024x440.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> IV CÁC CÂU HỎI THƯỜNG GẶP
> ```

## V. PHỤ LỤC

Trong phần Phụ lục, Green SM Food tổng hợp các thông tin và kênh hỗ trợ cần thiết nhằm hỗ trợ Quý Đối tác thuận tiện hơn trong quá trình vận hành và sử dụng nền tảng.

![V. PHỤ LỤC](https://cdn.xanhsm.com/2026/05/80e2e885-anh-noi-dung-5-1024x819.png)

> **[Nội dung trích xuất từ ảnh]:**
> # V PHỤ LỤC
> 
> ## Hotline 24/7:
> **024 7123 9999**
> 
> *   Cần hỗ trợ gấp các vấn đề liên quan tới Ứng dụng lỗi, hủy đơn, sự cố khi vận hành.
> *   Thích hợp cho các tình huống khẩn cấp, cần phản hồi ngay lập tức.
> 
> ## Email CSKH:
> **support.vn@greensm.com**
> 
> *   Cần gửi file, hình ảnh, chứng từ hoặc có yêu cầu chi tiết hơn?
> *   Phù hợp với các nội dung chuyên sâu, cần văn bản phản hồi chính thức.
> 
> ## Trung tâm hỗ trợ trên ứng dụng Green SM Merchant
> Vào ứng dụng Ⓔ Trung tâm hỗ trợ Ⓔ chọn nhóm vấn đề Ⓔ gửi yêu cầu.
> 
> *   Cần kiểm tra thông tin đơn hàng, cập nhật tài khoản, chỉnh sửa hồ sơ.
> *   Hệ thống sẽ phản hồi theo quy trình minh bạch và có mã theo dõi.
> 
> ## Group Facebook:
> **Cộng đồng Đối tác Nhà hàng Green SM Food (Chính thức)**
> 
> *   Cần cập nhật các thông báo mới nhất, hỗ trợ các vấn đề về vận hành.
> *   Phù hợp để chủ động tìm hiểu thông tin, các nội dung chuyên sâu cần có hình ảnh/ clip minh họa.

👉Tải Xuống “Sổ Tay Đối Tác Nhà Hàng”:Tại đây
