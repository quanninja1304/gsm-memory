# Cập nhật chính sách thu nhập: CHÍNH SÁCH THƯỞNG CHO BÁC TÀI XANH LÀ TÀI XẾ THỦ LĨNH 

- **Ngày đăng:** 2026-06-12
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thu-nhap-chinh-sach-thuong-cho-bac-tai-xanh-la-tai-xe-thu-linh](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thu-nhap-chinh-sach-thuong-cho-bac-tai-xanh-la-tai-xe-thu-linh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm góp phần phát triển lực lượng tài xế nòng cốt, bền vững và mở rộng cơ hội để các Bác Tài Xanh Taxi có thể trở thành những Tài xế Thủ lĩnh tiềm năng phát huy khả năng dẫn dắt, truyền cảm hứng vận doanh và đồng hành phát triển đội ngũ Bác Tài Xanh chất lượng trong tương lai, Green SM cập nhật những điểm mới trong “Chính sách thưởng Tài xế Thủ Lĩnh (KOC)”, cụ thể như sau:

Các điểm cập nhật mới:

✅ Điều chỉnh tổng số lượng quản lý Bác Tài Xanh tính trên 01 (một) Tài xế Thủ Lĩnh✅ Điều chỉnh mức “Doanh thu trung bình” thuộc tiêu chuẩn “Năng lực chuyên môn”✅ Điều chỉnh điều kiện đạt thưởng “Thành tích đội nhóm”

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/b4b2fc77-bang-cap-nhat-chinh-sach-thu-nhap-cho-btx-koc-1024x968.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản, số liệu, tiêu đề và bảng biểu được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> ## DRIVER GREEN SM
> ### Cập nhật chính sách thu nhập dành cho Bác Tài Xanh
> ### CHÍNH SÁCH THƯỞNG CHO TÀI XẾ THỦ LĨNH (KOC)
> 
> *   **Đối tượng áp dụng**
>     *   Dành cho Bác Tài Xanh Taxi tham gia chương trình Tài Xế Thủ Lĩnh (KOC)
> *   **Thời gian áp dụng**
>     *   Từ 15/06/2026 tới khi có thông báo mới nhất
> *   **Khu vực áp dụng**
>     *   Hà Nội & Tp. Hồ Chí Minh (Địa giới hành chính cũ)
> 
> ## ĐIỀU KIỆN ÁP DỤNG
> 
> | Điều kiện/Tiêu chí Áp dụng với Tài xế Thủ lĩnh (KOC)    | Trước 15/06/2026                                                                                             | Từ 15/06/2026                                                                                                |
> | :------------------------------------------------------ | :------------------------------------------------------------------------------------------------------------ | :----------------------------------------------------------------------------------------------------------- |
> | **Số lượng Bác Tài Xanh Taxi do Tài xế Thủ lĩnh quản lý** | 20 Bác Tài Xanh Taxi                                                                                          | Tối thiểu từ 20 đến tối đa 50 Bác Tài Xanh Taxi                                                              |
> | **Doanh thu trung bình/ngày**                           | 1.500.000đ/ngày trở lên                                                                                       | 1.000.000đ/ngày trở lên                                                                                      |
> | **Điều kiện đạt thưởng thành tích nhóm**                 | 85% Bác Tài Xanh đang tập nghề trong nhóm có doanh số hàng tháng không thấp hơn mức doanh số tháng quy định | 80% Bác Tài Xanh đang tập nghề trong nhóm có doanh số hàng tháng không thấp hơn mức doanh số tháng quy định |

Các nội dung/điều kiện/tiêu chuẩn khác của chính sách này không có sự thay đổi.

Cùng với những cập nhật mới, Green SM kỳ vọng sẽ có thể:

- Chào đón những gương mặt Tài xế Thủ lĩnh mới, có tiềm năng dẫn dắt và hướng dẫn đội nhóm theo chuẩn dịch vụ, từ đó đào tạo ra những thế hệ Bác Tài Xanh 5 sao chuẩn Xanh.

- Giúp các Tài xế Thủ lĩnh giảm áp lực trong việc quản lý, dẫn dắt và kèm cặp đội nhóm mới nhưng vẫn đảm bảo được hiệu suất vận doanh hiệu quả mỗi ngày.

Vui lòng liên hệ với Đội xe để được giải đáp mọi thắc mắc!

Mến chúc Bác Tài Xanh vận doanh hiệu quả và an toàn!

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
