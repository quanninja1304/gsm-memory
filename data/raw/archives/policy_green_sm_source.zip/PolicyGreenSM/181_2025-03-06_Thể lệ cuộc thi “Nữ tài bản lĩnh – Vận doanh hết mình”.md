# Thể lệ cuộc thi “Nữ tài bản lĩnh – Vận doanh hết mình”

- **Ngày đăng:** 2025-03-06
- **Chuyên mục:** Cẩm nang tài xế, Công ty, Tài xế Green SM Bike, Tài xế Green SM Car, Uncategorized
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/the-le-cuoc-thi-nu-tai-ban-linh-van-doanh-het-minh](https://www.greensm.com/vn-vi/news/the-le-cuoc-thi-nu-tai-ban-linh-van-doanh-het-minh)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Nhằm tôn vinh nỗ lực của đội ngũ Nữ Tài Xanh, Green SM phát động cuộc thi “Nữ Tài bản lĩnh, Vận doanh hết mình” – nơi phái đẹp thể hiện phong độ, khẳng định khả năng vận doanh siêu đỉnh để nâng cao thu nhập với những phần thưởng giá trị!

Nghề tài xế đâu chỉ dành riêng cho nam giới? Trên khắp nẻo đường, Nữ Tài Xanh vẫn ngày ngày vững tay lái, khẳng định tài năng, sự linh hoạt và bản lĩnh vững vàng.

Cuộc thi “Nữ tài bản lĩnh – Vận doanh hết mình” không chỉ là cơ hội để các Nữ Tài Xanh thể hiện kỹ năng vận doanh mà còn là lời khẳng định mạnh mẽ về sự hiện diện và đóng góp của phụ nữ trong ngành vận tải công nghệ.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/03/1af1d6b9-nu-tai-ban-linh-1200x675-1-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # BÁC TÀI XANH
> 
> ## Cuộc thi
> 
> # Nữ Tài Bản Lĩnh
> 
> ### Vận Doanh Hết Mình
> 
> **Tổng Giá Trị Giải Thưởng**
> 
> # 105 TRIỆU
> ```

## Đối tượng tham dự:

Tất cả các Nữ Tài Xanh vận hành dịch vụ trên ứng dụng Green SM, cụ thể:

- Nữ Tài Xanh (tài xế taxi có hợp đồng lao động với GSM);

- Nữ Tài Xanh Platform Car 1 & 2 (tài xế sử dụng xe công ty ký hợp đồng hợp tác với GSM, tài xế tham gia chương trình 2 tài 1 xe, tài xế sử dụng xe cá nhân vận doanh với Green SM);

- Nữ Tài Xanh Platform Bike 1 & 2 (tài xế Bike sử dụng xe công ty, tài xế Bike sử dụng xe cá nhân vận doanh với Green SM).

## Thời gian thi đua:

03/03/2025 – 31/03/2025.

## Phạm vi tổ chức:

Phân theo khu vực, cụ thể:

- Đối với Nữ Tài Xanh và Nữ Tài Xanh Platform Car 1 & 2:Khu vực 01: Hà NộiKhu vực 02: TP. HCMKhu vực 03: Miền BắcKhu vực 04: Miền NamKhu vực 05: Miền Trung

- Đối với Nữ Tài Xanh Platform Bike 1 & 2:Khu vực 01: Hà NộiKhu vực 02: Hồ Chí Minh, Bình Dương, Đồng Nai.Khu vực 03: Đà Nẵng

## Hình thức thi đua:

Thi đua vận doanh, dựa trên doanh số các Nữ Tài Xanh trong thời gian thi đua để xét thưởng. Cụ thể:

Đối với Nữ Tài Xanh và Nữ Tài Xanh Platform Car 1 & 2:

- Theo tuần:Tuần 01: 03/03 – 09/03Tuần 02: 10/03 – 16/03Tuần 03: 17/03 – 23/03Tuần 04: 24/03 – 30/03

- Chung cuộc: 03/03/2025 – 31/03/2025 bao gồm:Chung cuộc toàn quốc.Chung cuộc khu vực.

Đối với Nữ Tài Xanh Platform Bike 1 & 2:

- Theo tuần:Tuần 01: 03/03 – 09/03;Tuần 02: 10/03 – 16/03;Tuần 03: 17/03 – 23/03;Tuần 04: 24/03 – 30/03.

- Chung cuộc: 03/03/2025 – 31/03/2025 bao gồm:Chung cuộc toàn quốc;Chung cuộc khu vực.

## Cơ cấu giải thưởng và cách thức trả thưởng:

Đối với Nữ Tài Xanh và Nữ Tài Xanh Platform Car 1 & 2:

- 01 giải chung cuộc toàn quốc trị giá 10.000.000 VNĐ;

- Chi tiết các giải khác như sau:

HÀ NỘI

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 3.000.000 |
| Giải Nhì | Giải | – | 2 | 1.500.000 |
| Giải Ba | Giải | – | 3 | 1.000.000 |
| TỔNG – HÀ NỘI | 10 |  |

TP. HCM

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 3.000.000 |
| Giải Nhì | Giải | – | 2 | 1.500.000 |
| Giải Ba | Giải | – | 3 | 1.000.000 |
| TỔNG – TP HCM | 10 |  |

MIỀN BẮC

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 3.000.000 |
| Giải Nhì | Giải | – | 1 | 1.500.000 |
| Giải Ba | Giải | – | 2 | 1.000.000 |
| TỔNG – MIỀN BẮC | 8 |  |

MIỀN TRUNG

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 3.000.000 |
| Giải Nhì | Giải | – | 1 | 1.500.000 |
| Giải Ba | Giải | – | 2 | 1.000.000 |
| TỔNG – MIỀN TRUNG | 8 |  |

MIỀN NAM

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 3.000.000 |
| Giải Nhì | Giải | – | 1 | 1.500.000 |
| Giải Ba | Giải | – | 2 | 1.000.000 |
| TỔNG – MIỀN NAM | 8 |  |

Đối với Nữ Tài Xanh Platform Bike 1 & 2:

- 01 giải chung cuộc toàn quốc trị giá 6.000.000 VNĐ;

- Chi tiết các giải khác như sau:

HÀ NỘI

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 2.000.000 |
| Giải Nhì | Giải | – | 3 | 1.000.000 |
| Giải Ba | Giải | – | 10 | 500.000 |
| TỔNG – HÀ NỘI | 18 |  |

TP HCM, BÌNH DƯƠNG,ĐỒNG NAI

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 2.000.000 |
| Giải Nhì | Giải | – | 10 | 1.000.000 |
| Giải Ba | Giải | – | 20 | 500.000 |
| TỔNG –TP HCM, BÌNH DƯƠNG,ĐỒNG NAI | 35 |  |

ĐÀ NẴNG

| Giải thưởng | Đơn vị | Số tuần | Số lượnggiải thưởng | Giá trị giải thưởng(VNĐ) |
| --- | --- | --- | --- | --- |
| Giải Tuần | Giải/Tuần | 4 | 4 | 500.000 |
| Giải Nhất | Giải | – | 1 | 2.000.000 |
| Giải Nhì | Giải | – | 1 | 1.000.000 |
| Giải Ba | Giải | – | 1 | 500.000 |
| TỔNG – ĐÀ NẴNG | 7 |  |

Tổng giá trị giải thưởng:105.000.000 VNĐ.

## Cách thức trả thưởng:

- Trả thưởng bằng cách Topup trực tiếp tiền vào ví tài xế.

## Điều kiện nhận thưởng:

- Đối với Hà Nội và TP. HCM:Nữ Tài Xanh Car đạt tối thiểu 80 cuốc/tuần;Nữ Tài Xanh Bike đạt tối thiểu 140 cuốc/tuần.

- Đối với các vùng còn lại:Nữ Tài Xanh Car đạt tối thiểu 70 cuốc/tuần;Nữ Tài Xanh Bike đạt tối thiểu 130 cuốc/tuần.

- Tài xế không vi phạm quy định nội bộ của công ty trong thời gian diễn ra chương trình.

- Quyết định của Green SM là quyết định cuối cùng.

Hãy cùng Green SM lan tỏa tinh thần bền bỉ, vững vàng và quyết tâm chinh phục mọi thử thách trên hành trình xanh!
