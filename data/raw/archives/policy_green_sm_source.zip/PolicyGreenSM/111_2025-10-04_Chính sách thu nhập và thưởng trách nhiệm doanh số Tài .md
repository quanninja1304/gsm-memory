# Chính sách thu nhập và thưởng trách nhiệm doanh số Tài xế Xanh Premium tại một số Depot/HUB

- **Ngày đăng:** 2025-10-04
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-premium-tai-mot-so-depot](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-premium-tai-mot-so-depot)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Với mục đích hỗ trợ Bác tài quản lý thu nhập một cách minh bạch và chủ động hơn, Green SM xin thông báo về việc cập nhậtChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấmcôngmới.

👉 Thời gian áp dụng:Từ 04/10/2025cho đến khi có thông báo mới

👉 Chi tiết chính sách: Bác tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/884235b9-251004_251004_xanh_pre_hcm8_dnai12_tayninh12_bninh1_hy1_agiang1_ninhbinh1_dongthap11-470x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CẬP NHẬT CHÍNH SÁCH THU NHẬP VÀ THƯỞNG TRÁCH NHIỆM DOANH SỐ
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Depot Hồ Chí Minh 8; Đồng Nai 1; Tây Ninh 1, 2; Hưng Yên 1; Bắc Ninh 1, An Giang 1; Ninh Bình 1; Đồng Tháp 1, Đồng Nai 2.
> 
> **Thời gian áp dụng:** Từ ngày 04/10/2025 đến khi có thông báo mới
> 
> ## Nội dung chính sách
> 
> Cập nhật mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công.
> 
> ## THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> 
> **Xanh SM Premium**
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ |
> | :---- | :---------------------------- | :------------ |
> | Mức 0 | Dưới 550.000                  | 26%           |
> | Mức 1 | Từ 550.000 đến dưới 700.000    | 33%           |
> | Mức 2 | Từ 700.000 đến dưới 950.000    | 38%           |
> | Mức 3 | Từ 950.000 đến dưới 1.200.000  | 43%           |
> | Mức 4 | Từ 1.200.000 đến dưới 1.450.000 | 46%           |
> | Mức 5 | Từ 1.450.000 trở lên          | 49%           |
> 
> ## TIÊU CHUẨN CHẤM CÔNG
> 
> **Xanh SM Premium**
> 
> | Tiêu chí             | Từ T2 - T5 | TỪ T6 - CN, ngày Lễ, Tết | TỪ T2 - CN, ngày Lễ, Tết |
> | :------------------- | :--------- | :----------------------- | :----------------------- |
> | Tỷ lệ nhận cuốc      | 85%        |                          | 80%                      |
> | Tỷ lệ hoàn thành cuốc | 85%        |                          | 85%                      |
> 
> | Tháng áp dụng       | Khu vực áp dụng (Depot/HUB) | Doanh số (VNĐ/ngày) | Từ T2 - T5 | TỪ T6 - CN, ngày Lễ, Tết | TỪ T2 - CN, ngày Lễ, Tết |
> | :------------------ | :-------------------------- | :------------------ | :--------- | :----------------------- | :----------------------- |
> | 5, 6, 7, 8, 9, 12   | Hồ Chí Minh 8               |                     | Từ 600.000 | Từ 600.000               | Từ 1.000.000             |
> | 3, 4, 10, 11        |                             |                     | Từ 540.000 | Từ 540.000               | Từ 900.000               |
> | 5, 6, 7, 8, 9, 12   | Đồng Nai 1                  |                     | Từ 800.000 | Từ 900.000               | Từ 1.000.000             |
> | 3, 4, 10, 11        |                             |                     | Từ 720.000 | Từ 810.000               | Từ 900.000               |
> | 5, 6, 7, 8, 9, 12   | Đồng Nai 2                  |                     | Từ 600.000 | Từ 850.000               | Từ 1.000.000             |
> | 3, 4, 10, 11        |                             |                     | Từ 540.000 | Từ 765.000               | Từ 900.000               |
> | 3, 4, 8, 9, 10, 11, 12 | Bắc Ninh 1                  |                     | Từ 600.000 | Từ 700.000               | Từ 1.000.000             |
> | 5, 6, 7             |                             |                     | Từ 540.000 | Từ 630.000               | Từ 900.000               |
> | 3, 4, 5, 6, 10, 11, 12 | Hưng Yên 1                  |                     | Từ 500.000 | Từ 650.000               | Từ 1.000.000             |
> | 7, 8, 9             |                             |                     | Từ 450.000 | Từ 585.000               | Từ 900.000               |
> | 4, 5, 6, 7, 8, 9, 12 | Tây Ninh 1                  |                     | Từ 600.000 | Từ 650.000               | Từ 1.000.000             |
> | 3, 10, 11           |                             |                     | Từ 540.000 | Từ 585.000               | Từ 900.000               |
> | 4, 5, 6, 7, 8, 9, 12 | Tây Ninh 2                  |                     | Từ 800.000 | Từ 900.000               | Từ 1.000.000             |
> | 3, 10, 11           |                             |                     | Từ 720.000 | Từ 810.000               | Từ 900.000               |
> | 3, 10, 11, 12       | An Giang 1                  |                     | Từ 700.000 | Từ 800.000               | Từ 1.000.000             |
> | 4, 5, 6, 7, 8, 9    |                             |                     | Từ 630.000 | Từ 720.000               | Từ 900.000               |
> | 4, 5, 6, 7, 8, 9    | Ninh Bình 1                 |                     | Từ 500.000 | Từ 650.000               | Từ 1.000.000             |
> | 3, 11               |                             |                     | Từ 450.000 | Từ 585.000               | Từ 900.000               |
> | 3, 4, 5, 6, 7, 8, 9, 12 | Đồng Tháp 1                 |                     | Từ 600.000 | Từ 700.000               | Từ 1.000.000             |
> | 10, 11              |                             |                     | Từ 540.000 | Từ 630.000               | Từ 900.000               |
> ```

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Trân trọng,Đội ngũ Green SM.
