# Tiêu chuẩn dịch vụ Green SM Ngon dành cho Tài xế và Nhà hàng

- **Ngày đăng:** 2025-05-21
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tieu-chuan-dich-vu-xanh-sm-ngon-danh-cho-tai-xe-va-nha-hang](https://www.greensm.com/vn-vi/news/tieu-chuan-dich-vu-xanh-sm-ngon-danh-cho-tai-xe-va-nha-hang)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

## I. Dành cho Tài xế

I.1. Diện mạo

1. Công cụ dụng cụ: Mang túi giữ nhiệt theo quy định của Công ty, đảm bảo túi giữ nhiệt luôn được sạch sẽ, không mùi, không rách. Không để hàng hoá độc hại hoặc có thể gây nhiễm chéo ảnh hưởng đến chất lượng thực phẩm.

I.2. Hành vi phục vụ

I.2.1. Xác nhận đơn hàng

2. Kiểm tra thông tin đơn hàng: Ngay khi nhận đơn hàng, kiểm tra thông tin Nhà hàng, Khách hàng và chi tiết đơn hàng.

3. Liên hệ nhà hàng: Trong vòng 01 phút kể từ khi nhận đơn, liên hệ với khách hàng chào khách “Green SM xin chào” và xác nhận thông tin đơn hàng.

4. Liên hệ khách hàng: Liên hệ với khách hàng chào khách “Green SM xin chào” và xác nhận thông tin đơn hàng.

I.2.2. Đến lấy đơn hàng

5. Thời gian di chuyển: Di chuyển ngay đến nhà hàng sau khi xác nhận đơn hàng.

6. Thông báo nhà hàng: Thông báo mã đơn hàng hoặc đặt món với nhà hàng, ứng tiền thanh toán (nếu cần).

7. Thay đổi thông tin đơn hàng: Nếu thời gian cao điểm, đơn hàng cần thời gian chuẩn lâu: gọi điện cho khách hàng thông báo. Nếu đơn hàng có bất kỳ thay đổi gì về món ăn, số lượng…yêu cầu nhà hàng liên hệ và xác nhận thay đổi với khách hàng.

8. Đợi đơn hàng: Đợi nhà hàng chế biến ở khu vực riêng (nếu có) và giữ trật tự, không chen lấn.

I.2.3. Giao hàng

9. Kiểm tra hàng hóa: Kiểm tra món ăn, số lượng, quy cách đóng gói đúng theo chi tiết đơn hàng và tránh các mặt hàng trong danh mục hàng hóa cấm giao.

10. Chụp ảnh hàng hóa và hóa đơn: Chụp ảnh hàng hóa, hóa đơn rõ nét, đẩy đủ để xác nhận được tình trạng hàng hóa khi nhận/giao.

11. Từ chối giao hàng: Khi có nghi ngờ về hàng hóa cấm hoặc Nhà hàng không cho kiểm tra hàng, xin phép từ chối giao hàng và liên hệ Tổng đài để xác nhận hủy đơn.

12. Xử lý tình huống: Trường hợp không thể đáp ứng yêu cầu của Khách, hướng dẫn Khách gọi cho Tổng đài Chăm sóc Khách.

13. Giao hàng: Nếu có người nhận trực tiếp: Giao hàng cho Khách bằng 2 tay. Nếu không có người nhận, để đúng nơi Khách yêu cầu và chụp ảnh lại gửi cho Khách.

14. Giao hàng không thành công: Khi Khách nhận hàng từ chối nhận thực hiện theo đúng quy trình đơn hàng thất bại và bồi hoàn.

15. Quy định liên lạc: Xác nhận thông tin đơn hàng với Khách, thông báo thời gian giao hàng dự kiến trên ứng dụng. Trường hợp không liên lạc được, đảm bảo gọi cho Khách tối thiểu 3 cuộc gọi trong vòng 10 phút.

I.2.4. Kết thúc chuyến

16. Thanh toán: Thực hiện thanh toán nhanh chóng, chính xác. Không gợi ý, đòi thêm hay tự ý thu thêm tiền của Khách.

17. Kết thúc chuyến: Cám ơn và chào Khách: “Green SM cảm ơn, chúc Anh/chị ngon miệng!” hoặc dùng câu chào phù hợp tình huống thực tế.

## II. Dành cho Nhà hàng

II.1. Tình trạng hoạt động

18. Cửa hàng: Luôn cập nhật tình trạng cửa hàng chính xác: giờ đóng, mở cửa, địa chỉ, số điện thoại…

19. Thực đơn: Cập nhật đầy đủ món ăn và tình trạng hàng hóa, không kinh doanh mặt hàng cấm hoặc mặt hàng chưa được cấp phép kinh doanh.

20. Chất lượng món ăn: Nhà hàng phải duy trì và đảm bảo chất lượng món ăn ổn định, đáp ứng kỳ vọng của khách hàng.

II.2. An toàn Vệ sinh thực phẩm

21. Cơ sở kinh doanh: Đảm bảo hoạt động đúng quy định Pháp luật, có Giấy chứng nhận đăng ký kinh doanh phù hợp với loại hình kinh doanh, có Giấy chứng nhận đủ điều kiện VSATTP còn hiệu lực.

22. Khu vực chế biến: Luôn giữ không gian nhà hàng, khu vực chế biến, dụng cụ, đồ chứa sạch sẽ, không nhiễm khuẩn; có riêng dụng cụ sống và chín; hệ thống thoát nước không ứ đọng; có đủ phương tiện để khử trùng, phòng chống côn trùng động vật.

23. Bảo quản thực phẩm: Bảo quản thực phẩm đúng quy cách tương ứng: nhiệt độ, đóng gói; có tủ kính hoặc thiết bị bảo quản hợp vệ sinh; thực phẩm nguồn gốc rõ ràng.

24. Món ăn: Đảm bảo an toàn VSTP, không rơi dị vật vào món ăn; món ăn, nguyên liệu có thông tin về xuất xứ rõ ràng, còn thời hạn sử dụng, giữ nguyên thuộc tính.

II.3. Hành vi phục vụ

II.3.1. Xác nhận đơn hàng và chuẩn bị đơn hàng

25. Kiểm tra thông tin đơn hàng: Ngay khi nhận đơn hàng, kiểm tra thông tin món ăn, ghi chú của Khách hàng.

26. Thay đổi thông tin đơn hàng: Nếu món ăn hết, hoặc không đảm bảo yêu cầu, liên hệ khách hàng thông báo và xác nhận thay đổi trước khi tiến hành thay đổi trên hệ thống.

27. Chuẩn bị đơn hàng: Chuẩn bị đơn hàng ngay và ưu tiên theo thứ tự đơn đặt hàng. Thời gian chuẩn bị món ăn không quá 15 phút kể từ khi Tài xế đến báo lấy đơn hàng (trừ một số món ăn chế biến đặc thù).

II.3.2. Giao hàng

28. Kiểm tra hàng hóa: Kiểm tra món ăn, số lượng…đúng theo chi tiết đơn hàng và hóa đơn

29. Đóng gói và giao hàng: Đóng gói cẩn thật, giao hàng cho Tài xế và hướng dẫn cách thức bảo quản (nếu có).

30. Giao hàng: Tôn trọng tài xế, không to tiếng, thái độ trong quá trình giao hàng.

II.3.3. Kết thúc đơn hàng

31. Phản hồi: Kiểm tra đánh giá sao, phản hồi, khiếu nại của khách hàng về đơn hàng (nếu có).
