# Hướng Dẫn Hoàn Thành Nghĩa Vụ Thuế Thu Nhập Cá Nhân Năm 2025

- **Ngày đăng:** 2026-07-03
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/huong-dan-hoan-thanh-nghia-vu-thue-thu-nhap-ca-nhan-nam-2025](https://www.greensm.com/vn-vi/news/huong-dan-hoan-thanh-nghia-vu-thue-thu-nhap-ca-nhan-nam-2025)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Dành cho Đối tác Tài xế xe hai bánh của Green SM

Kính gửi Quý Đối tác,

Green SMtrân trọng thông tin tới Quý Đối tác về việc thực hiện nghĩa vụ thuế thu nhập cá nhân (TNCN) đối với hoạt động hợp tác kinh doanh trong năm 2025 theo quy định của pháp luật thuế hiện hành.

Căn cứ điểm c khoản 5 Điều 7 Nghị định số 126/2020/NĐ-CP ngày 19/10/2020 của Chính phủ quy định chi tiết một số điều của Luật Quản lý thuế và Khoản 2, Điều 4, Thông tư số 40/2021/TT-BTC ngày 01/06/2021, Green SM triển khai việc khấu trừ, kê khai và nộp thuế TNCN thay cho Đối tác thuộc diện chịu thuế (Tổng doanh thu trong năm 2025 > 100 triệu đồng); đồng thời thực hiện hoàn trả số thuế đã tạm khấu trừ (nếu có) đối với các trường hợp không thuộc diện phải nộp thuế theo quy định ( Tổng doanh thu trong năm 2025 ≤100 triệu đồng).

![Hướng Dẫn Hoàn Thành Nghĩa Vụ Thuế Thu Nhập Cá Nhân Năm 2025](https://cdn.xanhsm.com/2026/07/a4bae404-thumnail-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # HƯỚNG DẪN HOÀN THÀNH NGHĨA VỤ THUẾ
> 
> ## THU NHẬP CÁ NHÂN NĂM 2025
> 
> (Logo: GREEN SM)
> 
> (Hình ảnh minh họa có một tờ giấy ghi "THUẾ" với các dấu tích, một lịch ghi "2025", các đồng tiền vàng và một tấm khiên bảo vệ. Một người đàn ông mặc áo GREEN SM đang sử dụng điện thoại.)
> ```

1. Thuế suất thuế TNCN áp dụng

Tổng doanh thu thực nhận trong năm 2025được xác định trong khoảng thời gian từ ngày01/01/2025 đến hết ngày 31/12/2025.

Thuế suất thuế TNCN áp dụng: 1,5%

2. Cách xác định số thuế TNCN phải nộp:

2.1 Tổng doanh thu = Doanh thu thực nhận từ các chuyến xe + Tổng tiền thưởng từ các chương trình thưởng

Trong đó:

- Doanh thu thực nhận được ghi nhận từ ngày 01/01/2025 đến ngày 31/12/2025.

- Tổng tiền thưởng bao gồm toàn bộ các khoản thưởng được Green SM chi trả trong cùng kỳ.

2.2   Số thuế TNCN phải nộp = Tổng doanh thu × 1,5%

Lưu ý:

Green SM sử dụng số CCCD hoặc mã số thuế (MST) mà Đối tác đã cung cấp để thể hiện trên chứng từ khấu trừ thuế.

Trường hợp chưa cập nhật CCCD hoặc MST, Quý Đối tác vui lòng bổ sung thông tin theo hướng dẫn trên ứng dụng Green SM Driver để đảm bảo thông tin thuế được ghi nhận chính xác.

3. Xác định nhóm nghĩa vụ thuế

Đối tác được phân loại thành 02 nhóm theo tổng doanh thu phát sinh trong năm 2025.

| Nhóm | Điều kiện | Nội dung xử lý |
| --- | --- | --- |
| Nhóm 1 | Tổng doanh thu năm 2025 từ 100 triệu đồng trở xuống | Không phát sinh nghĩa vụ nộp thuế TNCN. Trường hợp đã bị tạm khấu trừ sẽ được hoàn trả theo kế hoạch của Green SM. |
| Nhóm 2 | Tổng doanh thu năm 2025 trên 100 triệu đồng | Thuộc diện chịu thuế TNCN. Green SM thực hiện khấu trừ, kê khai và nộp thuế thay Đối tác theo quy định. |

Lưu ý: Green SM sẽ gửi thông báo riêng qua ứng dụng và email đã đăng ký để thông tin chi tiết về nhóm nghĩa vụ thuế và số liệu liên quan của từng Đối tác.

NHÓM 1: Tổng doanh thu năm 2025 từ 100 triệu đồng trở xuống

Theo quy định hiện hành, cá nhân kinh doanh có tổng doanh thu trong năm từ 100 triệu đồng trở xuống không thuộc diện phải nộp thuế TNCN.

Do đó:

- Đối tác không phát sinh nghĩa vụ nộp thuế TNCN đối với doanh thu hợp tác kinh doanh trên nền tảng Green SM trong năm 2025.

- Trường hợp đã phát sinh khoản thuế tạm khấu trừ, Green SM sẽ thực hiện hoàn trả theo kế hoạch xử lý và thông báo cụ thể tới Đối tác.

- Khoản hoàn trả (nếu có) sẽ được ghi nhận vào Ví đối tác và hiển thị trong mục Lịch sử Ví trên ứng dụng.

Trường hợp hoạt động trên nhiều nền tảng

Ngưỡng doanh thu 100 triệu đồng/năm được xác định trên tổng doanh thu phát sinh từ tất cả các nền tảng và hoạt động kinh doanh của cá nhân, không tính riêng doanh thu trên Green SM.

Trường hợp doanh thu từ Green SMdưới 100 triệu đồng/năm, nhưngtổng doanh thu từ Green SM và các nền tảng, hoạt động kinh doanh khác cộng lại vượt 100 triệu đồng/năm, Đối táccó trách nhiệm thực hiện kê khai và nộp thuế theo quy định của cơ quan thuế.

Để được hỗ trợ chi tiết, Đối tác vui lòng liên hệ cơ quan thuế quản lý trực tiếp hoặc truy cập Cổng thông tin điện tử của Tổng cục Thuế.

NHÓM 2: Tổng doanh thu năm 2025 trên 100 triệu đồng

Đối tác thuộc diện thực hiện nghĩa vụ thuế TNCN theo quy định hiện hành.

Green SM thực hiện:

- Thông báo doanh thu và số thuế TNCN phải nộp qua ứng dụng và email đã đăng ký.

- Kê khai và nộp số thuế đã khấu trừ vào ngân sách nhà nước theo quy định.

- Cấp chứng từ khấu trừ thuế theo yêu cầu của Đối tác.

Cách yêu cầu chứng từ khấu trừ thuế

Bước 1:Kiểm tra thông tin định danh

Truy cập ứng dụng → Tài khoản/Hồ sơ → Kiểm tra thông tin CCCD và MST.

Bước 2:Cập nhật thông tin còn thiếu

Nếu chưa cung cấp CCCD hoặc MST, vui lòng thực hiện bổ sung theo hướng dẫn trên ứng dụng.

Bước 3:Gửi yêu cầu cấp chứng từ

Truy cập mục Hỗ trợ → Chủ đề thuế → Gửi yêu cầu cấp chứng từ khấu trừ thuế năm 2025.

Green SM sẽ xử lý yêu cầu trong thời gian quy định và phản hồi tới Đối tác.

Lưu ý quan trọng

Đối tác cần thực hiện đầy đủ các nghĩa vụ theo hướng dẫn và đúng thời hạn để tránh các trường hợp truy thu hoặc xử phạt theo quy định của cơ quan thuế.

Câu hỏi thường gặp:

| Câu hỏi | Trả lời |
| --- | --- |
| Vì sao Green SM khấu trừ thuế của tôi? | Việc khấu trừ thuế được Green SM thực hiện theo quy định tại điểm c khoản 5 Điều 7 Nghị định số 126/2020/NĐ-CP ngày 19/10/2020 của Chính phủ quy định chi tiết một số điều của Luật Quản lý thuế. Theo quy định này, tổ chức hợp tác kinh doanh với cá nhân có trách nhiệm khai thuế và nộp thuế thay cho cá nhân đối với phần doanh thu phát sinh từ hoạt động hợp tác kinh doanh. |
| Green SM có thực hiện toàn bộ nghĩa vụ thuế cho tôi không? | Green SM thực hiện khấu trừ, kê khai và nộp thuế thay đối với phần doanh thu phát sinh từ hoạt động hợp tác kinh doanh trên nền tảng Green SM. Đối với các khoản thu nhập phát sinh từ nguồn khác, Đối tác có trách nhiệm tự thực hiện nghĩa vụ thuế theo quy định của pháp luật. |
| Tôi có được giảm trừ các chi phí mà tôi phải tự chi ra như sạc pin hoặc sửa chữa phương tiện… vào doanh thu khi tính thuế không? | Không. Theo quy định hiện hành, thuế TNCN đối với cá nhân kinh doanh được xác định theo tỷ lệ trên doanh thu tính thuế và các khoản hỗ trợ liên quan, không thực hiện khấu trừ các chi phí phục vụ hoạt động kinh doanh. |
| Tôi có được áp dụng giảm trừ gia cảnh không? | Không. Theo quy định hiện hành, thu nhập từ hoạt động kinh doanh của cá nhân không thuộc đối tượng áp dụng giảm trừ gia cảnh khi xác định số thuế phải nộp. |
| Làm thế nào để biết Green SM đã khấu trừ và nộp thuế thay cho tôi? | Green SM thực hiện khấu trừ, kê khai và nộp số thuế phát sinh từ hoạt động hợp tác kinh doanh của Đối tác vào ngân sách nhà nước theo quy định. Đối tác có thể theo dõi thông tin thuế trên các báo cáo doanh thu và yêu cầu cấp chứng từ khấu trừ thuế để đối chiếu khi cần thiết. Để gửi yêu cầu, vui lòng truy cập mụcTrợ giúp/Hỗ trợtrên ứng dụng Green SM Driver. |
| Tôi cần được tư vấn chi tiết hơn về chính sách thuế thì liên hệ ở đâu? | Để được hướng dẫn cụ thể về nghĩa vụ thuế của cá nhân, Đối tác vui lòng liên hệ cơ quan thuế quản lý trực tiếp hoặc truy cập Cổng thông tin điện tử của cơ quan thuế để được hỗ trợ. |

THÔNG TIN HỖ TRỢ

- Trên ứng dụng:Hỗ trợ/Trợ giúp → Chủ đề Thuế.

- Hotline:1555.

- Các kênh hỗ trợ chính thức khác của Green SM.

Green SM trân trọng cảm ơn Quý Đối tác đã đồng hành và hợp tác.

Trân trọng,Đội ngũ Green SM
