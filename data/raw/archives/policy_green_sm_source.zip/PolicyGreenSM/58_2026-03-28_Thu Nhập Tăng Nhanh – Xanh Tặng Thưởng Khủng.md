# Thu Nhập Tăng Nhanh – Xanh Tặng Thưởng Khủng

- **Ngày đăng:** 2026-03-28
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/xanh-sm-bike-thuong-khung-tang-thu-nhap-can-tho-bac-ninh-thanh-hoa-thai-nguyen](https://www.greensm.com/vn-vi/news/xanh-sm-bike-thuong-khung-tang-thu-nhap-can-tho-bac-ninh-thanh-hoa-thai-nguyen)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh Bike ơi!

Tiếp nối những hành trình Xanh trên mọi miền Tổ quốc, Green SM Bike đã có mặt tạiCần Thơ, Bắc Ninh, Thanh Hóa, Thái Nguyên.

Cơ hội tăng thu nhập đã chính thức bắt đầu với nhiều chính sách cực kì hấp dẫn khi rất nhiều khách hàng lựa chọn Green SM khi giá xăng có nhiều biến động. Hãy vận doanh ngay để gia tăng thu nhập.

✅ Chương trình thưởng tuần thấp dẫn lên đến 1.000.000đ/tuần.

⏰ Thời gian áp dụng:02/03/2026

📍 Khu vực áp dụng:Cần Thơ, Bắc Ninh, Thanh Hóa, Thái Nguyên

📌 Lưu ý:Áp dụng tự động nhận chuyến khi tỷ lệ nhận chuyến< 70%

Chi tiết chính sách

![1_Chinh sach thu nhap](https://cdn.xanhsm.com/2026/03/ff17693c-1_chinh-sach-thu-nhap-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THU NHẬP DÀNH CHO BÁC TÀI XANH BIKE
> 
> **Áp dụng toàn quốc từ ngày 02/03/2026**
> 
> **TỔNG THU NHẬP = Chia sẻ doanh số (1) + Thưởng tuần (2) + Thưởng khác (nếu có) (3)**
> 
> **(1) Chia sẻ doanh số**
> 
> | Dịch vụ             | Mức chia sẻ doanh số | Ghi chú                                                                                                                                                                                                                                                                                                                             |
> | :------------------ | :------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Bike & Express Siêu tốc | 70%                  |                                                                                                                                                                                                                                                                                                                                     |
> | Express 2h          | 72%                  | * Doanh số bao gồm cả các phí yêu cầu đặc biệt của dịch vụ Xanh Express (giao tận tay, phí giao hàng cồng kềnh...) <br> * Mức chia sẻ doanh số chưa bao gồm khoản khấu trừ Thuế Thu nhập cá nhân (PIT) & thuế GTGT (VAT)                                                                                                                                                                                                                                                                  |
> | Food                | 75%                  |                                                                                                                                                                                                                                                                                                                                     |

![2_Thưởng Tuần Đà Nẵng - Thái Nguyên](https://cdn.xanhsm.com/2026/03/bc37e715-2_thuong-tuan-da-nang-thai-nguyen-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TUẦN
> Áp dụng từ ngày 02/03/2026
> 
> **Khu vực áp dụng:** Đà Nẵng, Quảng Ninh, Khánh Hòa, Huế, Cần Thơ, Bắc Ninh, Thanh Hóa, Thái Nguyên
> 
> | MỨC ĐIỂM THƯỞNG       | MỨC THƯỞNG     | ĐIỀU KIỆN NHẬN THƯỞNG                        |
> | :-------------------- | :------------- | :------------------------------------------- |
> | 600 - dưới 900 điểm   | 150.000 VNĐ    |                                              |
> | 900 - dưới 1200 điểm  | 300.000 VNĐ    |                                              |
> | 1200 - dưới 1600 điểm | 700.000 VNĐ    | • Ngày vận doanh >= 5 ngày/tuần              |
> | Từ 1600 điểm trở lên  | 1.000.000 VNĐ  | • Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến >=90% |

![3_Bảng quy đổi điểm](https://cdn.xanhsm.com/2026/03/1faadc2e-3_bang-quy-doi-diem-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # XANH SM
> ## CHÍNH SÁCH VẬN DOANH DÀNH CHO BÁC TÀI XANH BIKE
> 
> ### BẢNG QUY ĐỔI ĐIỂM THƯỞNG
> 
> | Dịch vụ             | 6h00-8h59 | 11h00-13h59 | 16h00-18h59 | 9h00-10h59, 14h00-15h59, 19h00-21h59, 22h00-5h59 |
> | :------------------ | :-------- | :---------- | :---------- | :----------------------------------------------- |
> | Xanh SM Bike        | 10        | 5           | 10          | 5                                                |
> | Xanh Express siêu tốc | 5         | 10          | 5           | 5                                                |
> | Xanh Express 2h     | 10        | 20          | 10          | 10                                               |
> | Xanh SM Ngon        | 15        | 30          | 30          | 15                                               |
> 
> **Lưu ý:**
> * ! Bổ sung điểm thưởng khung giờ 22h00 - 5h59
> * Đơn giao hàng đa điểm được tính theo số điểm giao
> ```

![4_Quy dinh truc tuyen](https://cdn.xanhsm.com/2026/03/22a4baec-4_quy-dinh-truc-tuyen-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH VẬN DOANH DÀNH CHO BÁC TÀI XANH BIKE
> 
> ## QUY ĐỊNH TRỰC TUYẾN & TỶ LỆ VẬN HÀNH
> 
> | Tiêu chí                  | Nội dung                                                                                                                                                                                                                                                                                                                                                                  |
> | :------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
> | **Quy định trực tuyến**  | - Cảnh báo nếu Đối tác không trực tuyến/không phát sinh chuyến xe trong **02 ngày liên tiếp.**<br>- Công ty sẽ tiến hành **thu hồi xe** và **thu phí sử dụng xe** nếu **05 ngày liên tiếp** Đối tác **không trực tuyến/không phát sinh chuyến xe** mà không có lý do hợp lệ.<br>- Áp dụng phí sử dụng xe đối với các ngày không vận doanh vượt quy định, cụ thể: Thu phí sử dụng xe **50.000 VNĐ/ngày** từ ngày không vận doanh thứ 5 trở đi/tháng. |
> | **Quy định tỷ lệ vận hành** | - Trường hợp Đối tác Tài xế có **tỷ lệ chấp nhận chuyến dưới 70%**: Hệ thống sẽ mặc định bật tính năng "Nhận chuyến tự động" tới 23h59 của ngày vận doanh đó.                                                                                                                                                                                                         |

Mọi thắc mắc về chính sách mới giải đápTẠI ĐÂY.

Cùng Green SM bứt tốc, tăng trưởng thu nhập và hoạt động năng suất Bác Tài nhé.

Trân trọng,

Đội ngũ Green SM Bike.
