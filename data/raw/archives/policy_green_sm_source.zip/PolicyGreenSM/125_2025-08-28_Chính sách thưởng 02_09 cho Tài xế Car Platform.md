# Chính sách thưởng 02/09 cho Tài xế Car Platform

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-2-9-car-plf](https://www.greensm.com/vn-vi/news/thuong-2-9-car-plf)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm tiếp thêm động lực cho hành trình vận doanh trong dịp Quốc khánh 02/09, Green SM triển khai chương trình thưởng đặc biệt dành riêng cho Bác tài Car Platform trên toàn quốc:

🎉 Thưởng nóng200.000 VNĐkhi hoạt động xuyên suốt 4 ngày lễ🎉 Thưởng thêm đến8.000 VNĐcho mỗichuyến xehoàn thành

Cùng xem chi tiết ngay sau đây nhé:

![thưởng 2/9 platform](https://cdn.xanhsm.com/2025/08/ec9df25a-250829_platform-761x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> ✓ XANH SM
> 
> ⭐ ĐẠI LỄ 02/09 ⭐
> Thưởng nóng 200.000VNĐ
> và 8.000VNĐ/chuyến xe
> 
> Đối tượng áp dụng: Bác tài Car Platform trên toàn quốc
> Thời gian áp dụng: Từ ngày 30/08 đến hết ngày 02/09/2025
> 
> Chi tiết mức thưởng
> 
> Thưởng 200.000VNĐ/4 ngày (30/08 - 02/09)
> 
> **Điều kiện**
> *   Hoàn thành tối thiểu 7 chuyến xe/ngày liên tục trong 4 ngày
> *   Tỷ lệ nhận và hoàn thành chuyến trong ngày đạt từ 85% trở lên
> 
> Thưởng lên đến 8.000VNĐ/chuyến xe
> 
> | Số chuyến xe hoàn thành trong ngày | Mức thưởng       |
> | :-------------------------------- | :--------------- |
> | Từ 12 đến 15 chuyến xe           | 5.000VNĐ/chuyến  |
> | Từ 16 chuyến xe trở lên          | 8.000VNĐ/chuyến  |
> 
> **Điều kiện**
> *   Doanh số tối thiểu của các cuốc xe hoàn thành trong ngày đạt từ 50.000 VNĐ trở lên
> *   Tỷ lệ nhận và hoàn thành chuyến trong ngày đạt từ 85% trở lên
> 
> **Hình thức trả thưởng:** Thưởng sẽ được cộng trực tiếp vào Ví Tài xế vào ngày 09/09/2025
> ```

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM
