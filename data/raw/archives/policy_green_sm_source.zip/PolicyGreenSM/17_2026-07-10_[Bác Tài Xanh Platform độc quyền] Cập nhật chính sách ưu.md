# [Bác Tài Xanh Platform độc quyền] Cập nhật chính sách ưu đãi sạc xe mới

- **Ngày đăng:** 2026-07-10
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/bac-tai-xanh-platform-doc-quyen-cap-nhat-chinh-sach-uu-dai-sac-xe-moi-nhat-july-2026](https://www.greensm.com/vn-vi/news/bac-tai-xanh-platform-doc-quyen-cap-nhat-chinh-sach-uu-dai-sac-xe-moi-nhat-july-2026)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Kể từ ngày 13/07/2026, chính sách ưu đãi sạc xe dành cho Bác Tài Xanh Platform độc quyền sẽ có những điều chỉnh mới. Việc điều chỉnh nhằm khuyến khích Bác Tài Xanh luôn nỗ lực vận doanh tốt để từ đó đạt hiệu quả công việc và gia tăng cơ hội thu nhập cao cùng Green SM.

Các điểm điều chỉnh trong chính sách lần này, bao gồm:

- Điều kiện xác định thế nào là Đối Tác Tài Xế Platform độc quyền

- Điều kiện vận doanh áp dụng

- Thêm 01 khung giờ miễn phí sạc xe trong “ngày T”

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/07/94779dfd-bang-chinh-sach-uu-dai-sac-xe-danh-cho-btx-plf-doc-quyen-646x1024.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Cập nhật chính sách ưu đãi sạc xe
> dành cho Bác Tài Xanh Platform độc quyền
> 
> ## ĐỐI TƯỢNG ÁP DỤNG
> 
> Bác Tài Xanh được hưởng chính sách được xác định là:
> 
> | Đối tác Tài xế Platform chạy độc quyền trên ứng dụng Green SM | Điều kiện xác định Đối tác Tài xế chạy độc quyền: - Tỉ lệ hủy chuyến ≤ 10%/tuần - Tỉ lệ bỏ trôi chuyến ≤ 15%/tuần - Số giờ online/tuần ≥ 50 tiếng |
> |---|---|
> | Đăng ký tham gia Chính sách Ưu đãi sạc xe | Thực hiện việc mua xe và xuất hóa đơn từ ngày 10/02/2026 trở đi |
> 
> ## ĐIỀU KIỆN VẬN DOANH ÁP DỤNG
> 
> | KHU VỰC | ĐIỀU KIỆN CHÍNH SÁCH “ƯU ĐÃI SẠC XE" |
> |---|---|
> | Hà Nội <br/> Tp. Hồ Chí Minh <br/> (Theo địa giới hành chính cũ) | Thỏa mãn 01 trong 02 điều kiện: <br/> ✔ Số cuốc hoàn thành ngày T-1 ≥ 09 chuyến/ngày, hoặc <br/> ✔ Doanh số chuyến xe ngày T-1 ≥ 900.000đ/ngày |
> | Các tỉnh thành còn lại <br/> (Theo địa giới hành chính cũ) | Thỏa mãn 01 trong 02 điều kiện: <br/> ✔ Số cuốc hoàn thành ngày T-1 ≥ 07 chuyến/ngày, hoặc <br/> ✔ Doanh số chuyến xe ngày T-1 ≥ 700.000đ/ngày |
> 
> ## CHI TIẾT CHÍNH SÁCH
> 
> | | Dòng xe EC Van & Minio | Đối với các dòng xe khác |
> |---|---|---|
> | Đạt điều kiện <br/> "ngày T-1" sẽ được <br/> miễn phí sạc <br/> trong "ngày T" | Áp dụng từ lần sạc thứ 21 <br/> trở đi trong tháng | Áp dụng từ lần sạc thứ 11 <br/> trở đi trong tháng |
> 
> Lưu ý: Số lần sạc trong tháng được tính từ ngày 26 tháng trước đến ngày 25 tháng kế tiếp
> 
> ## CHÍNH SÁCH “MIỄN PHÍ SẠC XE" TRONG TUẦN T ÁP DỤNG NHƯ SAU
> 
> | THỜI GIAN | MIỄN CHI PHÍ SẠC XE |
> |---|---|
> | Thứ 2 tới thứ 5 | Trong các khung giờ: <br/> - 22h00 - 6h00 (ngày hôm sau) <br/> - 09h00 - 11h00 <br/> - 14h00 - 16h00 |
> | Từ thứ 6 đến chủ nhật | Trong các khung giờ: <br/> - 23h00 - 6h00 (ngày hôm sau) <br/> - 09h00 - 11h00 <br/> - 14h00 - 16h00 |
> ```

Lưu ý:

Áp dụng từngày 01/09/2026, Bác Tài Xanh đang vận doanh dịch vụ Green Mini sẽ được hưởng chính sách ưu đãi sạc xe như sau:

- Đối với Bác Tài Xanh Car Platform sử dụng dòng xe Minio xuất hóa đơntrướcngày 01/09/2026: ưu đãi áp dụng từ lần sạc thứ 21 trở đi trong tháng (áp dụng theo kỳ tính cước bắt đầu từ 26/03/2026).

- Đối với Bác Tài Xanh Car Platform sử dụng dòng xe Minio xuất hóa đơntừ ngày01/09/2026: ưu đãi áp dụng từ lần sạc thứ 11 trở đi trong tháng.

Green SM khuyến khích Bác Tài Xanh tăng cường hoạt động để đáp ứng các điều kiện, từ đó có thể tận dụng tối đa lợi ích mà chương trình thưởng đem lại:

💙 Tối ưu vận doanh với kế hoạch hoạt động phù hợp, đặc biệt tận dụng các khung cao điểm trong ngày để đáp ứng tối đa nhu cầu của Khách hàng.

💙Duy trì tỷ lệ nhận chuyến & hoàn thành chuyến, cũng như thời gian online ở mức cao nhất nhằm thỏa mãn các điều kiện chính sách, từ đó tận dụng tối đa lợi ích từ các chính sách.

💙 Hạn chế hủy chuyến và luôn sẵn sàng nhận chuyến khi hệ thống phân bổ.

💙 Lan tỏa và chia sẻ thông tin chương trình thưởng tới các Bác Tài Xanh khác trong cộng đồng.

Mọi thắc mắc về chính sách, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Mến chúc Bác Tài Xanh luôn vận doanh an toàn & hiệu quả!

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
