# Thể lệ chương trình “Hào khí Việt Nam – Sức Xanh lan tỏa”

- **Ngày đăng:** 2025-04-01
- **Chuyên mục:** Tài xế Green SM Bike, Tài xế Green SM Car, Ưu đãi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/the-le-chuong-trinh-hao-khi-viet-nam-suc-xanh-lan-toa](https://www.greensm.com/vn-vi/news/the-le-chuong-trinh-hao-khi-viet-nam-suc-xanh-lan-toa)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Chào mừng kỷ niệm 50 năm thống nhất đất nước và 80 năm Quốc khánh nước Cộng hòa Xã hội Chủ nghĩa Việt Nam, Green SM phát động chương trình tri ân khách hàng lớn nhất từ trước đến nay “Hào khí Việt Nam – Sức Xanh lan tỏa”, nhằm tôn vinh những đóng góp của khách hàng và tài xế trong việc bảo vệ môi trường và phát triển bền vững.

Chương trình là lời tri ân sâu sắc gửi tới khách hàng và tài xế đã chung tay tạo ra những tác động tích cực tới môi trường. Tổng giá trị giải thưởng lên đến hơn 16 tỷ đồng, với 34 chiếc xe điện VinFast VF 3 và hàng nghìn phần quà hấp dẫn.

*Please refer to the English version of T&Chere.

![Thể lệ chương trình “Hào khí Việt Nam – Sức Xanh lan tỏa”](https://cdn.xanhsm.com/2025/04/ed95e06f-auvn_xanhsm_kvhe_horizontal-master-jpeg-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là toàn bộ văn bản, số liệu, tiêu đề và bảng biểu được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> # XANH SM
> 
> ## ĐI XE XANH TRÚNG XE VF3
> 
> HÀO KHÍ VIỆT NAM, SỨC XANH LAN TỎA
> 
> ### 4.037 Giải Thưởng
> 
> ### Quỹ Thưởng Hơn 16 TỶ
> 
> ### Giải Đặc Biệt 34 Xe VF3
> 
> **Vòng quay may mắn bao gồm:**
> *   VOUCHER VINWONDERS
> *   Ô TÔ ĐIỆN VINFAST VF 3
> *   VOUCHER VINPEARL
> *   VOUCHER MUA XE VINFAST GREEN
> 
> **THỜI GIAN:** 01.04 - 02.09.2025
> 
> (*) Áp dụng có điều khoản và điều kiện, chi tiết truy cập www.xanhsm.com
> 
> **THAM GIA NGAY**

### Thời gian diễn ra:

01/04/2025 – 02/09/2025

### Đối tượng áp dụng:

Khách hàng sử dụng, và tài xế cung cấp các dịch vụ Green SM Car, Green SM Premium, Green SM Bike (bao gồm Green SM Bike Plus), và Green SM Express.

### Phạm vi áp dụng:

Tại các tỉnh, thành phố có triển khai dịch vụ của Green SM, bao gồm Hà Nội, TP.HCM, Đà Nẵng, Bắc Ninh, Hà Nam, Hà Tĩnh, Hải Dương, Hòa Bình, Thừa Thiên Huế, Hưng Yên, Lạng Sơn, Lào Cai, Nam Định, Ninh Bình, Phú Thọ, Quảng Bình, Quảng Ninh, Trà Vinh, Thái Bình, Thái Nguyên, Thanh Hóa, Vĩnh Phúc, Bến Tre, Bình Dương, Bình Phước, Cần Thơ, Đồng Nai, Gia Lai, Khánh Hòa, Phú Quốc, Phú Yên, Quảng Nam, Quảng Ngãi, Tây Ninh, Bà Rịa – Vũng Tàu, Kon Tum, Lâm Đồng, Tuyên Quang, Ninh Thuận, Yên Bái, Bạc Liêu, Sóc Trăng, Tiền Giang, An Giang, Đồng Tháp, Bình Thuận, Vĩnh Long, Quảng Trị, Bắc Giang, Long An, Hà Giang.

### Cách thức tham gia:

1. Nhận mã dự thưởng:

Đối với Khách hàng:

- Nhận 01 mã dự thưởng mỗi khi hoàn thành 3 chuyến Green SM Premium hoặc Green SM Car có chi phí tối thiểu 70.000 đồng/chuyến;

- Nhận 01 mã dự thưởng mỗi khi hoàn thành 6 chuyến Green SM Bike hoặc Green SM Express có chi phí tối thiểu 30.000 đồng/chuyến.

*Chương trình không áp dụng cho CBNV đang làm việc tại GSM.*Chi phí tối thiểu được tính là số tiền khách hàng thanh toán cho mỗi chuyến xe, sau khi đã trừ khuyến mại, phụ phí, bảo hiểm và các ưu đãi khác (có bao gồm VAT).

Đối với Bác tài Xanh:

- Nhận 01 mã dự thưởng mỗi khi hoàn thành 50 chuyến Green SM Premium hoặc Green SM Car có doanh thu tối thiểu 70.000 đồng/chuyến;

- Nhận 01 mã dự thưởng mỗi khi hoàn thành 80 chuyến Green SM Bike hoặc Green SM Express có doanh thu tối thiểu 30.000 đồng/chuyến.

*Doanh thu tối thiểu được tính là số tiền khách hàng thanh toán cho mỗi chuyến xe, sau khi đã trừ khuyến mại, phụ phí, bảo hiểm và các ưu đãi khác (có bao gồm VAT).

2. Quay số may mắn:

Green SM sẽ gửi mã dự thưởng trong tin nhắn ứng dụng Green SM, ứng dụng Tài xế Green SM trong vòng 24 giờ sau khi hoàn thành số chuyến xe.

- Với Khách hàng: là các mã số ngẫu nhiên (“Mã Số”) gồm 15 ký tự, dưới dạng HKVNCARKH + XXXXXX đối với khách hàng sử dụng dịch vụ Green SM Car, Green SM Premium và HKVNBIKEKH + XXXXXX đối với khách hàng sử dụng dịch vụ Green SM Bike, Green SM Bike Plus (X là các ký tự sinh ra ngẫu nhiên từ A – Z và 0 – 9). Mã số sẽ được gửi đến Tài khoản Green SM của Khách hàng khi hoàn thành điều kiện về chuyến đi.

- Với Tài xế: là các mã số ngẫu nhiên (“Mã Số”) gồm 15 ký tự, dưới dạng HKVNCARTX + XXXXXX đối với tài xế hoàn thành chuyến đi Green SM Car, Green SM Premium và HKVNBIKETX + XXXXXX đối với tài xế hoàn thành chuyến đi Green SM Bike, Green SM Bike Plus (X là các ký tự sinh ra ngẫu nhiên từ A – Z và 0 – 9), được gửi đến Tài khoản Tài xế Green SM của Tài xế khi hoàn thành điều kiện về chuyến đi.

- Tổng số lượng mã phát hành: 400.000.000 mã, bao gồm 100.000.000 mã cho mỗi loại mã dự thưởng.

Green SM thực hiện Vòng quay may mắn dựa trên mã số và dữ liệu khách hàng hợp lệ của hệ thống, lựa chọn trực tiếp người trúng giải trên các phiên Livestream trênFanpage Green SMvàFanpage Bác Tài Xanh.

Đặc biệt, vào phiên quay số đặc biệt diễn ra đúng vào dịp Quốc Khánh 02/09/2025, Green SM sẽ trao tặng 08 ô tô điện VinFast VF 3, trong đó 05 xe dành cho khách hàng và 03 xe dành cho tài xế may mắn nhất.

Lưu ý:

- Các mã dự thưởng phát sinh từ 00h01 Thứ 2 tới 24h00 đêm Chủ Nhật hàng tuần sẽ được tổng hợp và tổ chức quay số cho giải thưởng tuần vào 12h00 trưa Thứ 4 của tuần kế tiếp.

- Các khách hàng/tài xế chưa đủ điều kiện số chuyến để quy đổi mã dự thưởng ở tuần hiện tại sẽ được tích lũy sang tuần tiếp theo để nhận mã dự thưởng.

- Các mã dự thưởng đã được quay số ở tuần trước đó mà không trúng thưởng sẽ không được sử dụng để quay số ở tuần tiếp theo.

3. Nhận thưởng:

Với các giải thưởng hiện vật: Bộ phận CSKH của Green SM sẽ gọi điện từ số 1900 2088 để mời khách hàng/tài xế đến trao giải trong vòng 30 ngày kể từ thời điểm trúng thưởng.

Với các giải thưởng không hiện vật: Khách hàng/tài xế nhận thông báo trúng thưởng qua tin nhắn trong mục Thông báo của ứng dụng Green SM trong vòng 30 ngày kể từ thời điểm trúng thưởng.

### Cơ cấu giải thưởng:

Tổng giá trị giải thưởng lên đến hơn 16 tỷ đồng.

| Giải thưởng | Nội dung giải | Giá trị(VNĐ) | Số lượng giải/đợt |
| --- | --- | --- | --- |
| Giải thưởng tuần(21 đợt) | Giải thưởng tháng(5 đợt) | Giải đặc biệt 2/9(1 đợt) |
| Khách hàng | Bác tài Xanh | Bác tài Xanh | Khách hàng | Bác tài Xanh |
| Giải Đặc biệt | Ô tô điện VinFast VF 3 | 299.000.000 | 1 |  | 1 | 5 | 3 |
| Giải Nhất | Voucher nghỉ dưỡng 3N2Đ tại Vinpearl toàn quốc (thời hạn sử dụng đến hết 23/12/2025) | 8.000.000 | 5 | 3 |  | 10 | 5 |
| Giải Nhì | Voucher mua xe VinFast Green (áp dụng đến hết 31/12/2025 khi mua xe trên nền tảng Green SM Platform) | 5.000.000 | 5 | 5 |  | 10 | 10 |
| Giải Ba | Cặp vé vui chơi tại VinWonders trên toàn quốc (thời hạn sử dụng đến hết 23/12/2025) | 1.900.000 | 50 | 10 |  | 80 | 50 |
| Giải Khuyến khích | Gói Hội viên (thời hạn sử dụng trong vòng 30 ngày kể từ ngày nhận thưởng), bao gồm:– 5 mã ưu đãi 20% (lên đến 30.000 VNĐ cho Green SM Car)– 5 mã ưu đãi 25% (lên tới 30.000 VNĐ cho Green SM Bike) | 300.000 | 100 |  |  | 100 |  |

*Tổng giá trị giải thưởng so với tổng giá trị hàng hóa được khuyến mại bằng 50%

### Thời gian tổ chức Livestream Quay số may mắn:

| STT | Ngày quay số | Nội dung quay số |
| --- | --- | --- |
| 1 | Thứ 4 – 09/04/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 01/04/2025 (Thứ 2) tới hết 24h00 đêm ngày 06/04/2025 (Chủ Nhật) |
| 2 | Thứ 4 – 16/04/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 07/04/2025 (Thứ 2) tới hết 24h00 đêm ngày 13/04/2025 (Chủ Nhật) |
| 3 | Thứ 4 – 23/04/2025 | Giải tuần: Quay các mã dự thưởng tuần 00h01 ngày 14/04/2025 (Thứ 2) tới hết 24h00 đêm ngày 20/04/2025 (Chủ Nhật) |
| 4 | Thứ 4 – 30/04/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 21/04/2025 (Thứ 2) tới hết 24h00 đêm ngày 27/04/2025 (Chủ Nhật)Giải đặc biệt tháng (tài xế): Quay các mã dự thưởng của tài xế từ 00h01 ngày 01/04/2025 tới hết 24h00 đêm ngày 25/04/2025 |
| 5 | Thứ 4 – 07/05/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 28/04/2025 (Thứ 2) tới hết 24h00 đêm ngày 04/05/2025 (Chủ Nhật) |
| 6 | Thứ 4 – 14/05/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 05/05/2025 (Thứ 2) tới hết 24h00 đêm ngày 11/05/2025 (Chủ Nhật) |
| 7 | Thứ 4 – 21/05/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 12/05/2025 (Thứ 2) tới hết 24h00 đêm ngày 18/05/2025 (Chủ Nhật) |
| 8 | Thứ 4 – 28/05/2025 | Giải tuần: Quay các mã dự thưởng của Khách hàng từ 00h01 ngày 19/05/2025 (Thứ 2) tới hết 24h00 đêm ngày 25/05/2025 (Chủ Nhật)Giải đặc biệt tháng (tài xế): Quay các mã dự thưởng của tài xế từ 00h01 ngày 26/04/2025 tới hết 24h00 đêm ngày 25/05/2025 |
| 9 | Thứ 4 – 04/06/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 26/05/2025 (Thứ 2) tới hết 24h00 đêm ngày 01/06/2025 (Chủ Nhật) |
| 10 | Thứ 4 – 11/06/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 02/06/2025 (Thứ 2) tới hết 24h00 đêm ngày 08/06/2025 (Chủ Nhật) |
| 11 | Thứ 4 – 18/06/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 09/06/2025 (Thứ 2) tới hết 24h00 đêm ngày 15/06/2025 (Chủ Nhật) |
| 12 | Thứ 4 – 25/06/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 16/06/2025 (Thứ 2) tới hết 24h00 đêm ngày 22/06/2025 (Chủ Nhật)Giải đặc biệt tháng (tài xế): Quay các mã dự thưởng của tài xế từ 00h01 ngày 26/05/2025 tới hết 24h00 đêm ngày 23/06/2025 (loại bỏ các mã đã trúng giải thưởng tuần) |
| 13 | Thứ 4 – 02/07/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 23/06/2025 (Thứ 2) tới hết 24h00 đêm ngày 29/06/2025 (Chủ Nhật) |
| 14 | Thứ 4 – 09/07/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 30/06/2025 (Thứ 2) tới hết 24h00 đêm ngày 06/07/2025 (Chủ Nhật) |
| 15 | Thứ 4 – 16/07/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 07/07/2025 (Thứ 2) tới hết 24h00 đêm ngày 13/07/2025 (Chủ Nhật) |
| 16 | Thứ 4 – 23/07/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 14/07/2025 (Thứ 2) tới hết 24h00 đêm ngày 20/07/2025 (Chủ Nhật) |
| 17 | Thứ 4 – 30/07/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 21/07/2025 (Thứ 2) tới hết 24h00 đêm ngày 27/07/2025 (Chủ Nhật)Giải đặc biệt tháng (tài xế): Quay các mã dự thưởng của tài xế từ 00h01 ngày 24/06/2025 (Thứ 2) tới hết 24h00 đêm ngày 25/07/2025 (Chủ Nhật) |
| 18 | Thứ 4 – 06/08/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 28/07/2025 (Thứ 2) tới hết 24h00 đêm ngày 03/08/2025 (Chủ Nhật) |
| 19 | Thứ 4 – 13/08/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 04/08/2025 (Thứ 2) tới hết 24h00 đêm ngày 10/08/2025 (Chủ Nhật) |
| 20 | Thứ 4 – 20/08/2025 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 11/08/2025 (Thứ 2) tới hết 24h00 đêm ngày 17/08/2025 (Chủ Nhật) |
| 21 | Thứ 4 – 27/08/2026 | Giải tuần: Quay các mã dự thưởng tuần từ 00h01 ngày 11/08/2025 (Thứ 2) tới hết 24h00 đêm ngày 17/08/2025 (Chủ Nhật)Giải đặc biệt tháng (tài xế): Quay các mã dự thưởng của tài xế từ 00h01 ngày 11/08/2025 (Thứ 2) tới hết 24h00 đêm ngày 17/08/2025 (Chủ Nhật) |
| 22 | Quốc Khánh 02/09/2025 | Quay TOÀN BỘ mã dự thưởng của Khách hàng; tài xế từ 00h01 ngày 01/04/2025 tới hết 24h00 đêm ngày 31/08/2025 (không bao gồm mã dự thưởng của khách hàng và tài xế đã trúng thưởng giải nhất trước đó) |

Điều kiện, điều khoản tham gia chương trình:

- Khách hàng/tài xế trúng thưởng cần tới địa chỉ trao giải là Đại lý xe VinFast hoặc văn phòng công ty Green SM tại các tỉnh mà Green SM quy định. Khi nhận giải, khách hàng cần xuất trình căn cước công dân, mã số dự thưởng, thông báo trúng thưởng được gửi qua tin nhắn thông báo. Trong trường hợp khách hàng không tới nhận thưởng mà không liên hệ với ban tổ chức thông báo lý do bất khả năng, giải thưởng sẽ bị hủy. Khách hàng phải tự chi trả chi phí đi lại, lưu trú khi tới nhận giải thưởng.

- Bằng việc tham gia Chương trình này, Khách hàng/tài xế chấp nhận tất cả các điều khoản và điều kiện của Chương trình được liệt kê trong Thể lệ Chương trình và các nội dung thay đổi liên quan đến Chương trình này (nếu có).

- Giải thưởng không được quy đổi thành tiền mặt và Khách hàng/tài xế không được phép quy đổi hoặc chuyển nhượng, chuyển giao giải thưởng, tiền thưởng cho bất kỳ một bên thứ ba nào,Khách hàng/tài xế sẽ phải thực hiện thủ tục nộp thuế TNCN và thực hiện thủ tục đăng ký xe theo quy định của pháp luật.

- Green SM có toàn quyền từ chối trao thưởng/thu hồi một phần hoặc toàn bộ (các) khoản khuyến mại cho bất kỳ khách hàng/tài xế nào khi Green SM phát hiện khách hàng/tài xế cung cấp thông tin không hợp lệ, không rõ ràng, không đầy đủ thông tin mạo danh về Chương trình làm ảnh hưởng uy tín thương hiệu của Green SM hoặc có các hành vi gian lận do Green SM phát hiện.

- Trong trường hợp xảy ra tranh chấp liên quan đến Chương trình này, Green SM có trách nhiệm trực tiếp giải quyết. Nếu không thỏa thuận được tranh chấp sẽ được xử lý theo quy định của pháp luật.

- Green SM không chịu trách nhiệm trong trường hợp không liên lạc được với Khách hàng trúng thưởng qua số điện thoại mà khách hàng đã đăng ký và trường hợp Khách hàng trúng thưởng đã được Green SM thông báo nhưng không sử dụng giải thưởng theo quy định.

- Khách hàng/tài xế trúng thưởng cần ký cam kết cho phép Green SM sử dụng hình ảnh, thông tin cá nhân để phục vụ cho các hoạt động truyền thông trên các phương tiện thông tin đại chúng và kênh truyền thông thương hiệu Green SM.

Để được tư vấn chi tiết hoặc hỗ trợ, vui lòng liên hệ:▫ Hotline CSKH: 1900 2097▫ Email: cskh@xanhsm.com
