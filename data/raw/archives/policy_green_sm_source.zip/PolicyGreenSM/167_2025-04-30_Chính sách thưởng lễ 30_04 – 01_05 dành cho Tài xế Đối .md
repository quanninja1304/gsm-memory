# Chính sách thưởng lễ 30/04 – 01/05 dành cho Tài xế Đối tác Tài xế Xanh

- **Ngày đăng:** 2025-04-30
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-dai-le-tai-xe-doi-tac-2025](https://www.greensm.com/vn-vi/news/thuong-dai-le-tai-xe-doi-tac-2025)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm thể hiện sự quan tâm của Công ty dành cho các Đối tác Tài xế Xanh tham gia phục vụ khách hàng trong dịp Lễ Giải phóng miền Nam và Quốc tế Lao động 2025, Green SM triển khaiChính sách thưởng đặc biệtdành riêng cho Tài xế Đối tác.

Cùng xem chi tiết ngay sau đây nhé:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/dc3b72cf-20250429_chinhsachtxdt-995x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THƯỞNG LỄ 30/04 – 01/05 DÀNH CHO ĐỐI TÁC TÀI XẾ XANH
> 
> **Đối tượng áp dụng:** Tài xế Đối tác tại Hà Nội và TP. HCM tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** 02 ngày từ 30/04 - 01/05/2025
> **Điều kiện áp dụng:** Tỷ lệ nhận và hoàn thành chuyến ≥ 85%
> 
> ## Mức thưởng
> 
> Tỷ lệ thưởng trách nhiệm và doanh số **giờ thấp điểm** tăng thêm **10%** so với ngày thường
> 
> | Mức Doanh số ngày (VNĐ)   | Tỷ lệ thưởng trách nhiệm và doanh số |
> | :------------------------ | :---------------------------------- |
> |                           | Giờ thấp điểm | Giờ cao điểm |
> | Dưới 1.000.000            | 53%          | 57%          |
> | Từ 1.000.000 - < 1.300.000 | 58%          | 63%          |
> | Từ 1.300.000 - < 1.600.000 | 63%          | 69%          |
> | Từ 1.600.000 - < 2.100.000 | 68%          | 72%          |
> | Từ 2.100.000 trở lên      | 74%          | 75%          |
> 
> **Lưu ý:**
> * Bác tài sẽ nhận chia sẻ doanh số **43%** ngay sau khi hoàn thành cuốc xe.
> * Khoản tiền chênh lệch sẽ được thanh toán vào **Ví tài xế** khi đạt các mốc doanh số.
> ```

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
