# [GREEN SM BIKE] BẢO HIỂM VẬT CHẤT, SÁT CÁNH BẢO VỆ TRÊN MỌI HÀNH TRÌNH

- **Ngày đăng:** 2024-03-08
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/bao-hiem-vat-chat-sat-canh-bao-ve-tren-moi-hanh-trinh](https://www.greensm.com/vn-vi/news/bao-hiem-vat-chat-sat-canh-bao-ve-tren-moi-hanh-trinh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Quý Đối tác Tài xế thân mến,

Thấu hiểu nhu cầu cần được hỗ trợ của Đối tác khi gặp những sự cố liên quan tới xe cộ hoặc va chạm, Green SM Bike chính thức triển khai chương trình Bảo hiểm vật chất mô tô – xe máy.

Bảo hiểm vật chất mô tô – xe máy là bảo hiểm bảo vệ toàn diện xe máy điện (mà Green SM Bike cung cấp) khi phát sinh rủi ro, chi trả và hỗ trợ dịch vụ sửa chữa. Đây là thành quả hợp tác giữa Green SM Bike và BIC – Tổng Công ty Bảo hiểm BIDV, sát cánh bảo vệ trên mọi hành trình và cùng Green SM Bike kiến tạo một môi trường làm việc an tâm – an toàn – tin cậy cho Đối tác Tài xế.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/03/ef2803ff-bhvc_bai-1-1024x1024.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # XANHSM
> ## BẢO HIỂM VẬT CHẤT
> ## SÁT CÁNH BẢO VỆ
> ## TRÊN MỌI HÀNH TRÌNH
> ```

Với sự ra mắt của bảo hiểm vật chất, Đối tác Tài xế sẽ được nhận những quyền lợi sau:

✅ 100% Đối tác Tài xế được hỗ trợ tham gia bảo hiểm,không phải đóng thêm bất kỳ khoản phí nào.

✅ Được hỗ trợ chi trả chi phí sửa chữa/bồi thường khi gặp sự cố trong chuyến xe do thiên tai, tai nạn bất ngờ… khi mang xe qua sửa chữa tại hệ thống xưởng dịch vụ của Vin3S (đã được BIC bảo lãnh).

✅ Được nhận bồi thường bảo hiểm mỗi khi xảy ra sự cố (đảm bảo cung cấp đầy đủ hồ sơ).

Green SM Biketin rằng chương trình bảo hiểm vật chất sẽ giúp các Đối tác Tài xế thêm vững tâm trên mọi hành trình di chuyển và góp phần xây dựng cộng đồng tài xế Xanh ngày càng lớn mạnh – văn minh – chuyên nghiệp.

Trân trọng,

Đội ngũ Green SM Bike.
