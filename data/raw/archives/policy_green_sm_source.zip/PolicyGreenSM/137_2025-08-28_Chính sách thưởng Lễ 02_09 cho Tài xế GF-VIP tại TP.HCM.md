# Chính sách thưởng Lễ 02/09 cho Tài xế GF-VIP tại TP.HCM, Hà Nội và Đà Nẵng

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-2-9-gfvip-tai-ha-noi-tphcm-da-nang](https://www.greensm.com/vn-vi/news/thuong-2-9-gfvip-tai-ha-noi-tphcm-da-nang)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Dịp lễ Quốc khánh 02/09 là lúc nhu cầu di chuyển tăng vọt – cũng chính là“thời điểm vàng”để Bác tài Green SM tăng tốc thu nhập và rinh thêm thưởng hấp dẫn! Trong 4 ngày cao điểm lễ, Green SM triển khaichính sáchdành riêng cho các Bác tài vận doanh:👉Đối tượng áp dụng: Tài xế GF-VIP tại các Depot Hà Nội 1, 2, 3; Hồ Chí Minh 1, 2, 6, 7 và Đà Nẵng 1👉Thời gian áp dụng:Từ30/08 – 02/09/2025👉Nội dung chính sách: Tỷ lệthưởng trách nhiệmvà doanh sốđược điều chỉnhtăng thêmso với ngày thường👉Chi tiết mức thưởng: Bác tài vui lòng xem trong hình ảnh đính kèm

![thưởng 2/9 GF VIP Hà Nội TPHCM Đà Nẵng](https://cdn.xanhsm.com/2025/08/b9f6fa7f-250829-gfviphn123hcm1267dn1-818x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ ĐẠI LỄ QUỐC KHÁNH 02/09
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Depot Hà Nội 1, 2, 3; Hồ Chí Minh 1, 2, 6, 7 và Đà Nẵng 1 tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** 04 ngày từ ngày 30/08 đến ngày 02/09/2025
> 
> **Nội dung chính sách**
> Tỷ lệ thưởng trách nhiệm và doanh số được điều chỉnh tăng thêm lên đến **10%** so với ngày thường
> 
> **GF VIP**
> 
> | Mức | Doanh số (VNĐ/ngày) | Tỷ lệ chia sẻ ngày 30 - 31/08 | Tỷ lệ chia sẻ ngày 01 - 02/09 |
> |---|---|---|---|
> | Mức 0 | Dưới 900.000 | 30% | 35% |
> | Mức 1 | Từ 900.000 đến dưới 1.200.000 | 38% | 43% |
> | Mức 2 | Từ 1.200.000 đến dưới 1.500.000 | 45% | 50% |
> | Mức 3 | Từ 1.500.000 đến dưới 2.000.000 | 50% | 55% |
> | Mức 4 | Từ 2.000.000 trở lên | 55% | 60% |
> 
> **Ghi chú**
> * Depot Hà Nội 1, 2, 3: các Depot trực thuộc Hà Nội
> * Depot Hồ Chí Minh 1, 2, 6, 7: các Depot trực thuộc TP. Hồ Chí Minh cũ, không bao gồm Bình Dương và Bà Rịa - Vũng Tàu cũ
> * Depot Đà Nẵng 1: Depot trực thuộc Đà Nẵng cũ, không bao gồm Quảng Nam cũ

⚡ Sẵn sàng bứt tốc đại lễ cùng Green SM – càng chạy nhiều, càng nhận chia sẻ cao!

Mến chúc các Bác tài vận hành an toàn và hiệu quả!

Trân trọng,Đội ngũ Green SM
