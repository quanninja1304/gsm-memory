# Cập Nhật Chính Sách Vận Doanh Mới Dành Cho Bác Tài Xanh Bike

- **Ngày đăng:** 2026-02-25
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-van-doanh-moi-danh-cho-bac-tai-xanh-bike](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-van-doanh-moi-danh-cho-bac-tai-xanh-bike)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh Bike thân mến,

Với mong muốn hỗ trợ Đối tác Tài xế tiếp tục vận doanh hiệu quả, linh hoạt thời gian và đảm bảo quyền lợi trong quá trình hoạt động,Green SM Bikexin thông báo đến Đối tác về việc cập nhật chính sách vận doanh mới,áp dụng từ ngày 23/02/2026 trên toàn quốc. Như sau:

- Áp dụng mức khoándoanh số tối thiểu theo tuầnvận doanh, thay thế mức khoán doanh số theo ngày

- Không áp dụng hình thức xử phạtkhitỷ lệ nhận chuyến và tỷ lệ hoàn thành chuyến <=70%

👉 Toàn bộ nội dung chi tiết, Đối tác Tài xế vui lòng tham khảo trong ảnh bên dưới:

![250226_Quy dinh doanh so toi thieu](https://cdn.xanhsm.com/2026/02/4ec90c0b-250226_quy-dinh-doanh-so-toi-thieu-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> XANH SM
> 
> Áp dụng từ ngày 23/02/2026
> 
> **CHÍNH SÁCH DOANH SỐ TỐI THIỂU DÀNH CHO TÀI XẾ XANH SM BIKE**
> 
> | Khu vực                                                                                             | Mức khoán doanh số tối thiểu | Mức xử phạt                                                                                                                                                             |
> | :-------------------------------------------------------------------------------------------------- | :-------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Hà Nội                                                                                              | 1.400.000 VNĐ /tuần         | Trong trường hợp **không đạt** mức doanh số tối thiểu, Đối tác Tài xế sẽ bị truy thu **20% phần Doanh số khoán chưa đạt** bằng hình thức Trừ Ví tài xế |
> | TP.Hồ Chí Minh (bao gồm Bình Dương), Đồng Nai                                                      | 1.100.000 VNĐ /tuần         |                                                                                                                                                                         |
> | Đà Nẵng                                                                                             | 1.000.000 VNĐ /tuần         |                                                                                                                                                                         |
> | Quảng Ninh, Hải Phòng, Nghệ An, Huế, Khánh Hòa, TP.Hồ Chí Minh (khu vực Bà Rịa - Vũng Tàu cũ) | 500.000 VNĐ /tuần           |                                                                                                                                                                         |
> ```

![250226_Quy dinh van doanh](https://cdn.xanhsm.com/2026/02/a5938e45-250226_quy-dinh-van-doanh-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH QUẢN LÝ VẬN DOANH DÀNH CHO TÀI XẾ XANH SM BIKE
> 
> ## QUY ĐỊNH TRỰC TUYẾN & TỶ LỆ VẬN HÀNH
> 
> | Tiêu chí             | Nội dung                                                                                                                                                                                                                                                                                                                      |
> | -------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Quy định trực tuyến** | - Cảnh báo nếu Đối tác không trực tuyến/không phát sinh chuyến xe trong 02 ngày liên tiếp. <br> - Công ty sẽ tiến hành thu hồi xe và thu phí sử dụng xe nếu 05 ngày liên tiếp Đối tác không trực tuyến/không phát sinh chuyến xe mà không có lý do hợp lệ. <br> - Áp dụng phí sử dụng xe đối với các ngày không vận doanh vượt quy định, cụ thể: Thu phí sử dụng xe 50.000 VNĐ/ngày từ ngày không vận doanh thứ 5 trở đi/tháng. |
> | **Quy định tỷ lệ vận hành** | - Trường hợp Đối tác Tài xế có tỷ lệ chấp nhận chuyến dưới 50%: Hệ thống sẽ mặc định bật tính năng "Nhận chuyến tự động" tới 23h59 của ngày vận doanh đó.                                                                                                                                                                |

Nếu Đối tác có bất kỳ thắc mắc nào cần hỗ trợ, vui lòng gửi về “Trung Tâm hỗ trợ” tại mục “Tổng quan” trên ứng dụng Tài xế để được hỗ trợ xử lý.

Xin cảm ơn và chúc Đối tác Tài xế vận doanh an toàn – hiệu quả – thu nhập vượt trội!

Trân trọng,

Đội ngũ Green SM Bike.

GÓC GIẢI ĐÁP

| Câu hỏi | Trả lời |
| --- | --- |
| Doanh số tuần được tính thế nào? | Mức doanh số tối thiểu được tính trên tổng doanh số trong 01 tuần vận doanh, thay vì tính riêng từng ngày như trước đây |
| Tôi nghỉ 1–2 ngày trong tuần có ảnh hưởng không? | Tài xế vẫn cần đảm bảo tổng doanh số tối thiểu của cả tuần để tránh bị xử phạt. Có thể chủ động tăng vận doanh vào các ngày còn lại để bù doanh số. Lưu ý đảm bảo số ngày vận doanh tối thiểu để được nhận thưởng tuần. |
| Trường hợp không đạt mức khoán doanh số tuần, tài xế sẽ bị truy thu như thế nào? | Trường hợp không đạt mức khoán doanh số tuần, Đối tác Tài xế sẽ bị truy thu20% phần doanh số chưa đạtbằng hình thức cấn trừ Ví tài xế. |
