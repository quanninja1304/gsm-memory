# Giải đáp thắc mắc khi ứng tuyển tài xế Taxi Green SM

- **Ngày đăng:** 2023-03-21
- **Chuyên mục:** Cộng đồng
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cau-hoi-thuong-gap-khi-ung-tuyen-tai-xe-taxi-dien-gsm](https://www.greensm.com/vn-vi/news/cau-hoi-thuong-gap-khi-ung-tuyen-tai-xe-taxi-dien-gsm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Giải đáp những câu hỏi thường gặp khi ứng tuyển tài xế Taxi Green SM với các thông tin chi tiết về chế độ đãi ngộ nhân viên và quy định dịch vụ nhằm mang đến trải nghiệm tốt nhất cho khách hàng.

![Hình ảnh minh họa](https://lh6.googleusercontent.com/4LerSf3K88-4ak-vPILHRQZ_iHb6TRELOyqj3yNhdycdR9uKs1JzUy01VjRG1FA_SP4MEQc9YiYq1hWnkbkMukRi0GYa9NyYSXirbbBlVIRJr7zstqvgOqFEjMY3LYuXnmyaJcdOM94Lb76O1xglvVs)

Chế độ lương thưởng, phúc lợi, quy định về quản lý và vận hành xe điện được các lái xe quan tâm khi ứng tuyển tài xế taxi điện GSM

## Chế độ phúc lợi của tài xế Taxi Green SM

Khi trở thành tài xế taxi điện Green SM, lái xe được hưởng lương cứng lên đến 11 triệu đồng + hoa hồng lên đến 25% tổng doanh thu tháng.

Cụ thể, phần thu nhập chưa tính hoa hồng bao gồm:

- Lương cố định: 7 triệu đồng (bao gồm bảo hiểm xã hội, bảo hiểm y tế, bảo hiểm thất nghiệp theo quy định pháp luật về quyền của người lao động)

- Thưởng theo đánh giá của khách hàng: 2 triệu đồng (tính theo số sao tài xế nhận được từ đánh giá của khách hàng sử dụng dịch vụ taxi điện)

- Hỗ trợ chi phí thuộc đường: 2 triệu đồng (tối đa 6 tháng và sẽ thay đổi theo tình hình kinh doanh)

Như vậy, để có thể hưởng 100% thu nhập, tài xế Taxi Green SM cần lưu ý khoản thưởng theo mức đánh giá của khách hàng. Đặc biệt, công ty cũng sẽ chi trả đủ 100% lương cố định cho tất cả các tài xế trong thời gian thử việc.

![Hình ảnh minh họa](https://lh6.googleusercontent.com/sCcGvcbVWMcxBbxqYGXnIQk0378JEtzg_4JDoSsp9jyXeFdG_QAmKlNse88RzvuJcDW1Zz1vyMmoU4OsA2-diRJzafcA7TwsrK2UcF0LIqWxTb3GjR4dO-CIHbwxKt9VHTfMwLwhZAV1rx4t_SbO8UI)

Tài xế Taxi Green SM được hỗ trợ đủ 100% lương cố định trong thời gian thử việc

Ngoài ra, Taxi Green SM có tổ chức tham quan du lịch và thưởng lương tháng thứ 13 theo hiệu quả kinh doanh của Công ty. Lương và các chế độ chính sách sẽ được tính khi tài xế chính thức nhận việc.

Khi gia nhập cộng đồng tài xế Taxi Green SM, lái xe sẽ được đào tạo không mất phí về kiến thức sản phẩm, tiêu chuẩn dịch vụ của công ty. Ngoài ra, tài xế cần nộp lý lịch tư pháp mẫu số 02 trong vòng 01 tháng kể từ ngày nhận việc, hoặc gửi lại nhân sự giấy hẹn nhận kết quả (nếu làm online).

## Quy định về giao nhận và cọc xe

Công ty không thu cọc xe, tài xế chỉ cần cọc phụ phí trách nhiệm 8 triệu đồng và không phải thanh toán bất cứ khoản tiền nào khác. Khoản phụ phí trách nhiệm này sẽ được hoàn lại khi lái xe chấm dứt hợp đồng lao động với Taxi Green SM.

Lái xe có thể lựa chọn hình thức như sau:

- Một tài xế nhận một xe

- Hai tài xế nhận chung một xe

![Hình ảnh minh họa](https://lh6.googleusercontent.com/NAZDEz1LVcebPXYXpAGamdQ_YD888m6a6IF4EXalHuQydUfn1XYiVLAmQczS2yJrCBbVdx4Ef8u7MCCJWWz40UkqNhUIgqLo6iDUFsx_aDs_lN0AOqC-egDgfUQHDtwyr9Gc1rt9yR-YpYeZwGaHbdY)

Tài xế Taxi Green SM có thể lựa chọn nhận một xe riêng hoặc hai tài xế nhận chung một xe

## Quy định về quản lý và vận hành xe

Chi phí bảo dưỡng định kỳ xe sẽ do công ty thanh toán. Ngoài ra, Taxi Green SM cũng có quy chế hỗ trợ sửa chữa khi va chạm giao thông, tùy theo nguyên nhân và tinh thần hợp tác giải quyết của tài xế. Cụ thể:

- Với sự cố nhỏ (va chạm, xước, móp,..): Tài xế tự thanh toán.

- Với các sự cố lớn (giữ xe): Chuyên viên của Bộ phận chuyên môn sẽ đi cùng để xác nhận chi phí và xử lý lấy xe ra theo từng trường hợp. Tài xế thanh toán khoản tiền theo xác nhận của Chuyên viên.

Trong quá trình vận hành, xe có lắp mắt thần và một số thiết bị kiểm soát. Tài xế nộp doanh thu qua tài khoản ngân hàng ngay khi hết ca làm việc. Ngoài ra, trong thời gian chờ phương tiện sửa chữa tại xưởng, lái xe sẽ được hưởng lương nếu công ty không thể sắp xếp được xe.

Trên đây là giải đáp về các câu hỏi thường gặp khi ứng tuyển tài xế taxi điện Taxi Green SM. Điều này giúp lái xe hiểu rõ hơn về chế độ đãi ngộ, phúc lợi và quy định khi tham gia cộng đồng tài xế Taxi Green SM.

Lái xe quan tâm và mong muốn gia nhập cộng đồng tài xế Taxi Green SM vui lòng điền form đăng ký ứng tuyển tại Hà Nội:TẠI ĐÂY.

- Email:td-gsm@gsm.net.vn

Ngoài ra, hãy theo dõi thêm các thông tin về Công ty GSM – Taxi Green SM tạiFanpage chính thứcvàCộng Đồng Tài Xế Green SM – GSM.
