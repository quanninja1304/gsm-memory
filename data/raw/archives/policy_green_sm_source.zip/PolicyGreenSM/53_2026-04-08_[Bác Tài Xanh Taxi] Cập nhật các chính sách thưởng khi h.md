# [Bác Tài Xanh Taxi] Cập nhật các chính sách thưởng khi hoàn thành chuyến xe có điểm đón tại phố cổ Hội An

- **Ngày đăng:** 2026-04-08
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-khi-hoan-thanh-chuyen-xe-co-diem-don-tai-pho-co-hoi-an-08-04-2026](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-khi-hoan-thanh-chuyen-xe-co-diem-don-tai-pho-co-hoi-an-08-04-2026)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Green SM cập nhật tới Bác Tài Xanh những điểm mới trong chính sách thưởng khi hoàn thành chuyến xe có điểm đón tại phố cổHội An, cụ thể như sau:

• Thời gian áp dụng:Từ 08/04/2026 tới khi có thông báo mới nhất• Đối tượng áp dụng:Bác Tài Xanh Taxi• Khu vực áp dụng:Áp dụng đối với các chuyến xe có điểm đón tại phố cổ Hội An

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/04/207ac91f-080426-hoi-an-thumb-1-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản trích xuất từ hình ảnh theo định dạng Markdown tiếng Việt:
> 
> **BÁC TÀI XANH**
> 
> **CẬP NHẬT CHÍNH SÁCH THƯỞNG KHI HOÀN THÀNH CHUYẾN XE CÓ ĐIỂM ĐÓN TẠI PHỐ CỔ HỘI AN**
> 
> Phố cổ Hội An
> 
> **Thời gian áp dụng**
> Từ 08/04/2026
> tới khi có thông báo mới nhất
> 
> *Áp dụng có điều khoản và điều kiện

CHI TIẾT CÁC CHÍNH SÁCH THƯỞNG

1.Chính sách thưởng cá nhân: Thưởng thêm tới 10.000đ/chuyến xe

–Thưởng thêm 7.000đ/chuyến xekhi đạt tối thiểu từ02 chuyến xecó điểm đón tại Phố cổ Hội An trong ngày trở lên–Thưởng thêm 10.000đ/chuyến xekhi đạt tối thiểu từ05 chuyến xecó điểm đón tại Phố cổ Hội An trong ngày trở lên

Điều kiện áp dụng:

• Tỷ lệ nhận & hoàn thành chuyến xe/ngày≥ 90%• Trung bình doanh số các chuyến xe trong ngày≥ 50.000đ

Ví dụ: Bác Tài Xanh hoàn thành được 05 chuyến xe có điểm đón tại Phố cổ Hội An và thỏa mãn đồng thời 2 điều kiện áp dụng => Mức thưởng nhận được = 10.000đ x 5 = 50.000đ

2. Chính sách thưởng tổ đội:  Thưởng thêm tới 25.000đ/chuyến xe

100 Bác Tài Xanh đăng ký tham gia tổ đội với Đội xe chuyên nhận các chuyến xe có điểm đón tại Phố cổ Hội An sẽ có cơ hội nhận thưởng thêm tới 25.000đ/chuyến xe, cụ thể như sau:

– Thưởng thêm 15.000đ/chuyến xekhi đạt tối thiểu từ03 chuyến xecó điểm đón tại Phố cổ Hội An trong ngày trở lên– Thưởng thêm 25.000đ/chuyến xekhi đạt tối thiểu từ05 chuyến xecó điểm đón tại Phố cổ Hội An trong ngày trở lên

Điều kiện áp dụng:

• Tỷ lệ nhận & hoàn thành chuyến xe/ngày≥ 90%• Trung bình doanh số các chuyến xe trong ngày≥ 50.000đ• Trong trường hợp không hoàn thành tối thiểu 03 chuyến xe có điểm đón tại Phố cổ Hội An trong ngày, Green SM sẽ tiến hành khấu trừ tự động 30.000đ trên tổng thu nhập.

Lưu ý chung cho các chính sách thưởng:

• Tiền thưởng được chuyển vào Ví tài xế vào Thứ 5 của tuần kế tiếp.• Áp dụng đồng thời với các chương trình thưởng hiện hữu khác.• Bác Tài Xanh sẽ chỉ được tham gia 1 trong 2 chính sách thưởng nêu trên.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
