# Cập nhật chính sách ưu đãi sạc xe mới dành cho Bác Tài Xanh 

- **Ngày đăng:** 2026-06-06
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-uu-dai-sac-xe-moi-danh-cho-bac-tai-xanh-2026](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-uu-dai-sac-xe-moi-danh-cho-bac-tai-xanh-2026)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Thấu hiểu nỗ lực mỗi ngày của đội ngũ Bác Tài Xanh (BTX), đồng thời mong muốn tiếp thêm động lực để các BTX hoạt động chăm chỉ, hiệu quả và gia tăng thu nhập, Green SM triển khai chính sách Ưu đãi sạc xe với các nội dung cụ thể như sau:

- Đối tượng áp dụng: BTX Taxi/ BTX Green Van/ BTX thuộc nhóm “Đối tác Tài xế sử dụng xe thuê”đang vận doanhtrong thời gian chính sách có hiệu lực, sử dụng xe vận doanh thuộc sở hữu của Green SM vàđã đăng ký tham gia chính sách ưu đãi sạc xe trước đó. (Áp dụng đối với xe thuộc sở hữu của Green SM đã mua và xuất hóa đơn từ ngày 10/02/2026 trở đi)

- Khu vực áp dụng: toàn quốc

- Thời gian áp dụng: Từ ngày 20/04/2026 tới khi có thông báo mới nhất

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/9156af6f-200426_chinh-sach-sac-xe-01-2-1024x556.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CHI TIẾT CHÍNH SÁCH
> 
> | Bác Tài Xanh | Dòng xe | Chính sách ưu đãi sạc xe trong tuần T |
> |---|---|---|
> | Thuộc danh sách "Đối tượng áp dụng" | Lượt sạc áp dụng trong tháng (*) | Khung giờ ưu đãi phí |
> | | | Miễn phí | Giảm giá 50% |
> | | Các dòng xe còn lại | Từ lần sạc thứ 11 trở đi | • Thứ 2 - Thứ 5: 22h00 - 06h00<br>• Thứ 6 - Chủ Nhật: 23h00 - 06h00 | Khung giờ còn lại |
> | | Dòng xe thuộc dịch vụ Green Mini & Green Van | Từ lần sạc thứ 21 trở đi | • Thứ 2 - Thứ 5: 14h00 - 16h00, 22h00 - 06h00<br>• Thứ 6 - Chủ Nhật: 14h00 - 16h00, 23h00 - 06h00 | Khung giờ còn lại |
> 
> Số lần sạc trong tháng được tính từ ngày 26 tháng trước đến ngày 25 tháng kế tiếp

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/20f8e88d-200426_chinh-sach-sac-xe-02-2-1024x329.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> ## ĐIỀU KIỆN ÁP DỤNG
> 
> BTX sẽ được hưởng chính sách ưu đãi sạc xe trong tuần T nếu đồng thời đáp ứng đầy đủ các điều kiện sau trong tuần T-1
> 
> | Điều kiện 1               | Điều kiện 2                          | Điều kiện 3              | Điều kiện 4                   |
> | :----------------------- | :----------------------------------- | :----------------------- | :---------------------------- |
> | Online tối thiểu          | Số giờ online trung bình tối thiểu | Tỉ lệ nhận chuyến          | Tỉ lệ hoàn thành chuyến        |
> | **06 ngày/tuần**           | **08 tiếng/ngày**                    | **≥ 85%/tuần**           | **≥ 85%/tuần**                |
> ```

Lưu ý: Đối với BTX thuộc nhóm Đối tác Tài xế sử dụng xe thuê(đã mua và xuất hóa đơn trước ngày 10/02/2026)và có đăng ký chính sách ưu đãi sạc xe:Áp dụng theo chính sách ưu đãi sạc xe của VinFast quy định đối với các xe mua trước 10/02/2026.

Áp dụngtừ ngày 01/09/2026, Bác Tài Xanh đang vận doanh dịch vụ Green Mini sẽ được hưởng chính sách ưu đãi sạc xe như sau:

- Đối với Bác Tài Xanh sử dụng dòng xe Minio xuất hóa đơntrướcngày 01/09/2026: ưu đãi áp dụng từ lần sạc thứ 21 trở đi trong tháng

- Đối với Bác Tài Xanh sử dụng dòng xe Minio xuất hóa đơntừ ngày01/09/2026: ưu đãi áp dụng từ lần sạc thứ 11 trở đi trong tháng.

- Đối với Bác Tài Xanh Taxi vận doanh dịch vụ Green Mini gia nhậptừ 01/08/2026 – 30/09/2026: được hưởng chính sách ưu đãi sạc xe trong toàn bộ khung giờ (không áp dụng về điều kiện vận doanh). Chi phí sạc thuộc phạm vi ưu đãi của chính sách sẽ được đối soát và hoàn vào ví Tài xế định kỳ hàng tháng.

Green SM khuyến khích BTX tăng cường hoạt động để đáp ứng các điều kiện từ đó có thể tận dụng tối đa lợi ích mà chính sách trên đem lại:

💙 Luôn vận doanh trong các khung giờ cao điểm ban ngày để tận dụng tối đa nhu cầu sử dụng dịch vụ của Khách hàng.💙Duy trì tỷ lệ nhận chuyến & hoàn thành chuyến, cũng như thời gian online ở mức cao nhất nhằm thỏa mãn các điều kiện chính sách, từ đó tận dụng tối đa lợi ích từ các chính sách.💙 Hạn chế hủy chuyến và luôn sẵn sàng nhận chuyến tối đa khi hệ thống phân bổ.💙 Lan tỏa và chia sẻ thông tin chương trình thưởng tới các Bác Tài Xanh khác trong cộng đồng.

Mọi thắc mắc về chính sách, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
