# Chính sách bán xe Herio Green / Nerio Green từ GREEN SM

- **Ngày đăng:** 2025-02-17
- **Chuyên mục:** Công ty, Uncategorized, Ưu đãi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-ban-xe-tu-xanh-sm](https://www.greensm.com/vn-vi/news/chinh-sach-ban-xe-tu-xanh-sm)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Ngày 12.12.2024, Green SM áp dụng chính sách đặc biệt cho các tài xế tham gia Green SM Platform có cơ hội sở hữu ngay xe VinFast để tự vận doanh chỉ với 48 triệu đồng và nhận chia sẻ doanh số lên tới 85% từ hệ thống.

![nerio-green](https://cdn.xanhsm.com/2025/02/59d2c116-nerio-green-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> NERIO GREEN

Đây là chương trình kết nối của bộ ba thương hiệu “VinFast – Green SM – VinDT” tiếp nối chiến dịch “Chung tay vì một Việt Nam xanh” giúp cho nhiều người có thêm cơ hội sở hữu xe sở hữu VinFast, nhận bằng từ VinDT, và sinh lời cùng Green SM

![Herio-Green](https://cdn.xanhsm.com/2025/02/835feb9a-herio-green-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> HERO GREEN
> ```

Muaxe VinFast trực tiếp từ Green SM và tham gia vận doanh cùng Green SM Platform, đối tác tài xế sẽ được nhận nhiều chính sách hấpdẫn, bao gồm:

1. Chính sách giá:Áp dụng theo giá bán nền và các ưu đãi của VinFast

2. Chính sách hỗ trợ lãi suất dành cho khách hàng vay vốn ngân hàng:

| Nội dung | Các mức ưu đãi tại ngân hàng |
| --- | --- |
| BIDV | TP Bank | VP Bank |
| Tỉ lệ vay Ngân hàng | 70% | 90% | 90% |
| Mức lãi suất cố định trong 05 năm | 5,5% | 6,5% | 6,5% |

3. Chính sách chia sẻ doanh số khi tham gia Green SM Platform:

| Thời gian mua xe | Mức chia sẻ doanh số | Thời gian hiệu lực |
| --- | --- | --- |
| Đối tác tài xế mua xe trực tiếp qua Green SM từ 01/01/2025 đến 30/06/2025 | 85% | Đến 31/12/2025 |
| 80% | Đến 31/12/2027 |

4. Chính sách thưởng vận doanh tại Green SM Platform:

4.1.Chương trình thi đua hội nhập:Thưởng tới 1.000.000 VNĐ/tháng trong năm đầu tiên, dành cho đối tác tài xế mua xe trực tiếp từ Green SM và hoàn thành từ 100 cuốc xe/tháng có doanh số không thấp hơn 100.000VNĐ/cuốc xe.

4.2.Chương trình thưởng vận doanh dành cho đối với tài xế không nhận hỗ trợ lãi suất vay vốn ngân hàng:

- Thưởng gia nhập vận doanh: 5.000.000 VNĐ sau khi kích hoạt tài khoản Green SM Platform

- Thưởng hoạt động vận doanh: 2.500.000 VNĐ/tháng nếu đạt 200 cuốc xe/tháng; áp dụng cho 06 tháng đầu vận doanh.

5. Chính sách hỗ trợ học bằng lái xe

- Chi phí học bằng lái xe: 16.000.000 VNĐ. Đối tác tài xế chỉ cần trả trước 50%, phần còn lại được cấn trừ dần vào doanh thu của đối tác tài xế trong vòng 12 tháng.

- Chỉ áp dụng cho đối tác tài xế mua xe trực tiếp từ Green SM và tham gia vận doanh Green SM Platform.

ĐẶT CỌC NGAY
