# Chính sách thu nhập và thưởng trách nhiệm doanh số Tài xế Xanh Premium tại các Depot/HUB còn lại

- **Ngày đăng:** 2025-10-04
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-premuim-tai-cac-depot-con-lai](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-premuim-tai-cac-depot-con-lai)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Với mục đích hỗ trợ Bác tài quản lý thu nhập một cách minh bạch và chủ động hơn, Green SM xin thông báo về việc cập nhậtChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấmcôngmới.

👉 Thời gian áp dụng:Từ 04/10/2025cho đến khi có thông báo mới

👉 Chi tiết chính sách: Bác tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/3b8152c6-1premium_depot_hub-conlai-723x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CẬP NHẬT CHÍNH SÁCH THU NHẬP VÀ THƯỞNG TRÁCH NHIỆM DOANH SỐ
> 
> *   **Đối tượng áp dụng:** Tài xế Taxi tại các Depot/HUB còn lại
> *   **Thời gian áp dụng:** Từ ngày 04/10/2025 đến khi có thông báo mới
> 
> ## Nội dung chính sách
> 
> Cập nhật mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công
> 
> ## THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> 
> **Xanh SM Premium**
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ |
> | :---- | :---------------------------- | :------------ |
> | Mức 0 | Dưới 500.000                  | 26%           |
> | Mức 1 | Từ 500.000 đến dưới 700.000  | 33%           |
> | Mức 2 | Từ 700.000 đến dưới 900.000  | 38%           |
> | Mức 3 | Từ 900.000 đến dưới 1.100.000 | 43%           |
> | Mức 4 | Từ 1.100.000 đến dưới 1.300.000 | 46%           |
> | Mức 5 | Từ 1.300.000 trở lên          | 49%           |
> 
> **Ghi chú**
> 
> Áp dụng các Depot/HUB còn lại (ngoại trừ Depot Hồ Chí Minh 1, 2, 5, 6, 7, 8; Quảng Ninh 1, 2, 3; Hà Nội 3; Đà Nẵng 1, 2; Khánh Hòa 1, 2; Huế 1; Quảng Trị 2; Đồng Nai 1, 2; Tây Ninh 1, 2; Hưng Yên 1; Bắc Ninh 1, An Giang 1; Ninh Bình 1; Đồng Tháp 1)
> 
> ## TIÊU CHUẨN CHẤM CÔNG
> 
> **Xanh SM Premium**
> 
> | Tháng áp dụng         | Khu vực áp dụng (Depot/HUB) | Tiêu chí               | Từ T2 - T5  | Từ T6 - CN, ngày Lễ, Tết | Từ T2 - CN, ngày Lễ, Tết |
> | :-------------------- | :-------------------------- | :--------------------- | :---------- | :----------------------- | :----------------------- |
> |                       |                             | Tỷ lệ nhận cuốc        | 85%         |                          | 80%                      |
> |                       |                             | Tỷ lệ hoàn thành cuốc  | 85%         |                          | 85%                      |
> | 3, 4, 5, 6, 7, 8, 9, 12 | Cần Thơ 1                   |                        | Từ 800.000  | Từ 900.000               | Từ 1.000.000             |
> | 10, 11                |                             |                        | Từ 720.000  | Từ 810.000               | Từ 900.000               |
> | 5, 6, 7, 8, 9, 12     | Vĩnh Long 1                 |                        | Từ 650.000  | Từ 750.000               | Từ 1.000.000             |
> | 3, 4, 10, 11          |                             |                        | Từ 585.000  | Từ 675.000               | Từ 900.000               |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/ecd9f8b0-2premium_depot_hub-conlai-784x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> | | | Doanh số (VNĐ/ngày) | | |
> |---|---|---|---|---|
> | 5, 6, 7, 8, 9, 12 | Vĩnh Long 2 | Từ 600.000 | Từ 700.000 | Từ 1.000.000 |
> | 3, 4, 10, 11 | | Từ 540.000 | Từ 630.000 | Từ 900.000 |
> | 3, 4, 5, 10, 11, 12 | Hưng Yên 2 | Từ 500.000 | Từ 600.000 | Từ 1.000.000 |
> | 6, 7, 8, 9 | | Từ 450.000 | Từ 540.000 | Từ 900.000 |
> | 3, 4, 5, 6, 7, 8, 11, 12 | Hải Phòng 1 | Từ 600.000 | Từ 700.000 | Từ 1.000.000 |
> | 9, 10 | | Từ 540.000 | Từ 630.000 | Từ 900.000 |
> | 3, 4, 8, 10, 11, 12 | Phú Thọ 1 | Từ 600.000 | Từ 600.000 | Từ 1.000.000 |
> | 5, 6, 7, 9 | | Từ 540.000 | Từ 540.000 | Từ 900.000 |
> | 3, 4, 5, 6, 7, 8, 9, 12 | Lào Cai 1 | Từ 600.000 | Từ 700.000 | Từ 1.000.000 |
> | 10, 11 | | Từ 540.000 | Từ 630.000 | Từ 900.000 |
> | 3, 4, 5, 6, 7, 8, 12 | Ninh Bình 3 | Từ 500.000 | Từ 600.000 | Từ 1.000.000 |
> | 9, 10, 11 | | Từ 450.000 | Từ 540.000 | Từ 900.000 |
> | 3, 4, 8, 10, 12 | Ninh Bình 2 | Từ 600.000 | Từ 650.000 | Từ 1.000.000 |
> | 5, 6, 7, 9 | | Từ 540.000 | Từ 585.000 | Từ 900.000 |
> | 3, 4, 8, 9, 10, 11, 12 | Thái Nguyên 1 | Từ 600.000 | Từ 650.000 | Từ 1.000.000 |
> | 5, 6, 7 | | Từ 540.000 | Từ 585.000 | Từ 900.000 |
> | 4, 5, 6, 7, 8, 11, 12 | Thanh Hóa 1 | Từ 600.000 | Từ 700.000 | Từ 1.000.000 |
> | 3, 9, 10 | | Từ 540.000 | Từ 630.000 | Từ 900.000 |
> | 3, 10, 11, 12 | Tuyên Quang 1 | Từ 400.000 | Từ 400.000 | Từ 1.000.000 |
> | 4, 5, 6, 7, 8, 9 | | Từ 360.000 | Từ 360.000 | Từ 900.000 |
> | 5, 6, 7, 8, 12 | Quảng Trị 1 | Từ 600.000 | Từ 650.000 | Từ 1.000.000 |
> | 3, 4, 9, 10, 11 | | Từ 540.000 | Từ 585.000 | Từ 900.000 |
> | 4, 5, 6, 7, 8, 9, 12 | Gia Lai 1 | Từ 750.000 | Từ 750.000 | Từ 1.000.000 |
> | 3, 10, 11 | | Từ 675.000 | Từ 675.000 | Từ 900.000 |
> | 5, 6, 7, 8, 12 | Quảng Ngãi 1 | Từ 600.000 | Từ 600.000 | Từ 1.000.000 |
> | 3, 4, 9, 10, 11 | | Từ 540.000 | Từ 540.000 | Từ 900.000 |
> | 5, 6, 7, 8, 12 | Quảng Ngãi 2 | Từ 600.000 | Từ 600.000 | Từ 1.000.000 |
> | 3, 4, 9, 10, 11 | | Từ 540.000 | Từ 540.000 | Từ 900.000 |

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Trân trọng,Đội ngũ Green SM.
