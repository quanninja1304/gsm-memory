# Tài xế Green SM an tâm gắn bó khi có tháng lương 13 như nhân viên văn phòng

- **Ngày đăng:** 2025-10-05
- **Chuyên mục:** Báo chí, Uncategorized
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tai-xe-xanh-sm-an-tam-gan-bo-khi-co-thang-luong-13-nhu-nhan-vien-van-phong](https://www.greensm.com/vn-vi/news/tai-xe-xanh-sm-an-tam-gan-bo-khi-co-thang-luong-13-nhu-nhan-vien-van-phong)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Lần đầu tiên trong ngành gọi xe công nghệ tại Việt Nam, tài xế được nhận lương tháng 13 cùng thưởng Tết – chế độ vốn chỉ quen thuộc với nhân viên văn phòng.

Chạy xe công nghệ cho các hãng nhiều năm, bác tài Đình Huy (TP.HCM) chưa từng nghĩ mình sẽ có lương tháng 13.“Cả năm chạy xe rong ruổi, điều mong nhất là Tết có thêm khoản lo cho gia đình. Nghe tin có lương tháng 13 và thưởng Tết, tôi thấy an tâm hơn nhiều. Công sức bỏ ra được ghi nhận, mình càng có động lực gắn bó”, bác tài gia nhập Green SM từ đầu năm nay chia sẻ. Với mức thu nhập như hiện tại, khoản thưởng cuối năm có thể giúp anh tăng thêm hơn 8 triệu đồng, đủ để mua sắm Tết cho cả nhà.

Theo chính sách mới công bố, tài xế Green SM ký hợp đồng và làm việc liên tục đủ ba tháng tính đến 31/12 sẽ được nhận tháng lương thứ 13, kèm 2 triệu đồng tiền thưởng Tết. Đây là bước đi đột phá trong ngành, khi nghề tài xế công nghệ vốn gắn với thu nhập theo chuyến, ít phúc lợi và thiếu ổn định. Chế độ này mang đến niềm vui và tạo sự yên tâm cho hàng nghìn tài xế đang và sẽ gắn bó với Green SM.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/561508de-250926_gsm_pr_btx-chinh-sach-luong-thang-13-qua-tet_anh-1-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> CÔNG TY CỔ PHẦN DI CHUYỂN XANH VÀ THÔNG MINH GSM
> XANH SM
> CAR
> XANH SM
> 1900 2088

Tài xế Green SM được nhận lương tháng 13 cùng thưởng Tết

Bên cạnh lương tháng 13 và thưởng Tết, Green SM còn đưa ra loạt quyền lợi vượt trội cho tài xế. Mức thu nhập tối thiểu được bảo đảm ở mức 600.000 đồng mỗi ngày, thưởng nóng lên tới 4 triệu đồng, miễn phí sạc đêm, hỗ trợ 50% chi phí sạc ban ngày và đóng đầy đủ bảo hiểm bắt buộc cho tài xế. Những phúc lợi này trước nay chỉ gắn với nhân viên văn phòng, nay đã được áp dụng cho lực lượng tài xế, đánh dấu bước nâng chuẩn quan trọng trong ngành dịch vụ vận tải.

Anh Minh Tính, 26 tuổi, hiện đang chạy Green SM tại Hà Nội cho biết, những chính sách toàn diện trên khiến anh yên tâm làm việc và phấn đấu.“Ban đầu tôi chỉ coi đây là công việc tạm thời. Nhưng khi gắn bó, tôi thấy nghề tài xế không chỉ mang lại thu nhập ổn định mà còn có cơ hội phát triển, rèn luyện thêm kỹ năng phục vụ. Công ty còn mở lộ trình thăng tiến để tài xế có thể ứng tuyển lên Giám sát vận hành, Đội trưởng đội xe, Trưởng phòng vận hành, thậm chí Giám đốc miền. Quan trọng nhất là nghề tài xế được coi trọng và có tương lai”, anh Tính nói.

Trong bối cảnh hàng trăm nghìn người coi tài xế công nghệ là kế sinh nhai, việc Green SM tiên phong đưa ra chế độ lương thưởng và phúc lợi đầy đủ có thể coi là bước đi chiến lược. Chính sách này không chỉ giúp tuyển dụng nhanh và ổn định lực lượng tài xế trong giai đoạn mở rộng, mà còn đáp ứng đúng kỳ vọng của các bác tài: được bảo đảm an sinh, được công nhận giá trị và có niềm tin để gắn bó lâu dài.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/5bddbae6-250926_gsm_pr_btx-chinh-sach-luong-thang-13-qua-tet_anh-2-1024x683.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> - XANH SM
> - TAXI
> - SMART SOLUTIONS
> - 1900 2088
> - 50H - 621.74
> ```

Bác tài Xanh yên tâm làm việc với chế độ lương thưởng và phúc lợi đầy đủ

Các chuyên gia trong lĩnh vực lao động nhận định, chính sách của Green SM không chỉ hỗ trợ tài xế về tài chính mà còn góp phần chuyên nghiệp hóa nghề lái xe công nghệ, đưa công việc này thoát khỏi định kiến là nghề thời vụ. Khi người lao động có an sinh ổn định, họ sẽ toàn tâm phục vụ khách hàng, đồng thời xóa bỏ định kiến nghề tài xế là nghề “tạm bợ”, kiếm ăn qua ngày.

Trong bối cảnh hàng trăm nghìn người đang coi chạy xe là kế sinh nhai, bước đi tiên phong này của Green SM được xem là chiến lược kép, vừa thu hút và giữ chân tài xế, vừa nâng tầm nghề nghiệp, mở ra chuẩn mực mới cho ngành gọi xe tại Việt Nam.
