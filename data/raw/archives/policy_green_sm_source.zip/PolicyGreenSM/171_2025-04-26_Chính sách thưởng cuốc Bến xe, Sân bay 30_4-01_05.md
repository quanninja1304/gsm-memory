# Chính sách thưởng cuốc Bến xe, Sân bay 30/4-01/05

- **Ngày đăng:** 2025-04-26
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-cuoc-ben-xe-san-bay](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-cuoc-ben-xe-san-bay)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Kỳ nghỉ lễ 30/4 – 1/5 kéo dài là thời điểm hàng triệu người dân di chuyển về quê, đi du lịch… khiếncác khu vực bến xe và sân bay trở thành điểm nóngvề nhu cầu đi lại.Nhằm giúp Bác tài nắm bắt cơ hội này đểgia tăng thu nhập, Green SM triển khaichính sách thưởng đặc biệttại cácbến xevàsân bay Tân Sơn Nhất!

📌 Chi tiết mức thưởng và điều kiện áp dụng như sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/569622cb-20250404_chinhsachthuong-02-856x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Chính sách thưởng
> 
> ## Vào dịp lễ 30/4 - 1/5
> 
> **Đối tượng áp dụng:** Tài xế Taxi, Tài xế Car Platform, Tài xế Đối tác Green Car tại Hà Nội, Đà Nẵng và TP.HCM
> 
> ## Nội dung chính sách
> 
> | Hạng mục           | Chính sách tại các bến xe                                                                         | Chính sách tại sân bay Tân Sơn Nhất                                                                                                                                                             |
> | :----------------- | :----------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
> | **Thời gian áp dụng** | Ngày 3/5 và 4/5                                                                                  | Từ 30/4 - 4/5                                                                                                                                                                               |
> | **Mức thưởng**      | Thưởng 15.000 VNĐ/cuốc xe hoàn thành từ 2h - 6h sáng có điểm đón tại các bến xe                    | Thưởng 25.000 VNĐ/cuốc xe hoàn thành có điểm đón tại sân bay                                                                                                                               |
> | **Điều kiện thưởng** | Áp dụng tại các bến xe: 1/ Hà Nội: Giáp Bát, Nước Ngầm, Mỹ Đình, Gia Lâm 2/ Đà Nẵng: Bến xe Trung tâm Đà Nẵng 3/ TP.HCM: An Sương, Miền Đông, Miền Tây, Bến Tàu | Tỷ lệ nhận và hoàn thành chuyến trung bình/ngày đạt ≥ 85% (tính trên tổng các cuốc xe có điểm đón tại sân bay Tân Sơn Nhất) |
> 
> **Lưu ý:** Tiền thưởng sẽ được cộng trực tiếp vào Ví Tài xế vào Thứ 5 của tuần kế tiếp.
> ```

Mọi thắc mắc, Bác tài vui lòng liên hệ Đội xe để được hỗ trợ kịp thời.Mến chúc các Bác tài vận doanh hiệu quả và tận hưởng trọn vẹn ưu đãi từ chính sách!

Trân trọng,Đội ngũ Green SM.
