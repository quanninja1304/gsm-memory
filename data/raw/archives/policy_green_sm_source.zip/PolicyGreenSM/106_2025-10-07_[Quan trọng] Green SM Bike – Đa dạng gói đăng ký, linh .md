# [Quan trọng] Green SM Bike – Đa dạng gói đăng ký, linh hoạt thời gian chạy

- **Ngày đăng:** 2025-10-07
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/xanh-sm-bike-da-dang-goi-dang-ky-linh-hoat-thoi-gian-chay](https://www.greensm.com/vn-vi/news/xanh-sm-bike-da-dang-goi-dang-ky-linh-hoat-thoi-gian-chay)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Với mong muốn luôn đồng hành cùng Đối tác Tài xế trên hành trình phát triển bền vững, vận doanh hiệu quả trong giai đoạn phát triển sắp tới, Green SM Bike ra mắt các chương trình mới, Tài Xế Bike được chia thành các nhóm đối tượng để hưởng chính sách tương ứng.

- Khu vực và thời gian áp dụng: Tất cả các khu vực tuyển dụng Tài xế Green SM Bike.

- Thời gian áp dụng: Từ ngày15/11/2025đến khi có thông báo mới nhất

### 1. Các gói tài xế Green SM Bike và tiêu chí

Tùy theo năng lực, hoàn cảnh của bản thân các bài tài có thể lựa chọn để đăng ký các chương trình phù hợp với các tiêu chí tham khảo bao gồm:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/25f25c8a-chinh-sach-01-1024x652.png)

> **[Nội dung trích xuất từ ảnh]:**
> # TIÊU CHÍ CÁC NHÓM TÀI XẾ
> 
> | Nhóm tài xế | Nguồn tuyển đầu vào | Nhóm tài xế full-time | Nhóm tài xế Partime |
> |---|---|---|---|
> | | | Dài hạn | Dài hạn | Ngắn hạn | Ngắn hạn | Dài hạn | Dài hạn | Ngắn hạn | Ngắn hạn |
> | | | Tài xế chuyên nghiệp | Tài xế xe ôm truyền thống | Tài xế lao động chuyển ngành | Tài xế quân nhân xuất ngũ | Tài xế học sinh sinh viên | Tài xế nội trợ | Tài xế thanh niên tự do | Tài xế lao động tự do |
> | **Tiêu chí tham khảo** | **Số cuốc/ngày** | 23 | 15 | 17 | 15 | 8 | 6 | 14 | 10 |
> | | **Thời gian online tối thiểu /ngày(h)** | 9 | 7 | 8 | 7 | 4.5 | 4 | 6.5 | 5.5 |
> | | **Số ngày vận doanh/tháng** | 27 | 26 | 22 | 25 | 18 | 17 | 24 | 20 |

- Tài xế Full-time Dài hạn: Tài xế chuyên nghiệp, Tài xế xe ôm truyền thống

- Tài xế Full-time Ngắn hạn: Lao động chuyển ngành, Quân nhân xuất ngũ

- Tài xế Part-time Dài hạn: Học sinh – sinh viên, Nội trợ

- Tài xế Part-time Ngắn hạn: Thanh niên tự do, Lao động tự do

Lưu ý:

- Đối Tác Tài xế được phép thay đổi nhóm đã đăng ký tối đa 01 lần trước ngày Chủ Nhật của tuần mà tài xế có cuốc đầu tiên để phù hợp với khả năng.

- Tiêu chí tham khảo, dựa theo mục tiêu vận doanh kỳ vọng từng thời điểm

### 2. Chương trình thưởng nóng vận doanh

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/b3cd36c3-chinh-sach-02-1024x652.png)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG NÓNG THI ĐUA VẬN DOANH
> 
> **KHU VỰC**: Hà Nội, Đà Nẵng, Tp.Hồ Chí Minh, Bình Dương, Đồng Nai (theo địa phận hành chính cũ)
> 
> | | |
> |---|---|
> | **Tài xế Full - time (Dài hạn)** | **Thưởng nóng 1.000.000 VNĐ** <br> Khi hoàn thành 250 cuốc trong vòng 30 ngày kể từ ngày Tài xế có cuốc đầu tiên |
> | | **Thưởng nóng 1.500.000 VNĐ** <br> Khi hoàn thành 350 cuốc trong vòng 30 ngày kể từ ngày Tài xế có cuốc đầu tiên |
> | **Tài xế Part - time (Dài hạn)** | **Thưởng nóng 500.000 VNĐ** <br> Khi hoàn thành 150 cuốc trong vòng 30 ngày kể từ ngày Tài xế có cuốc đầu tiên |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/6e62b14c-image-4-1024x653.png)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG NÓNG THI ĐUA VẬN DOANH
> 
> **KHU VỰC**: Bà Rịa - Vũng Tàu (cũ), Quảng Ninh, Hải Phòng, Nghệ An, Huế, Khánh Hòa
> 
> | Loại Tài xế | Thưởng | Điều kiện |
> | :------------------ | :----------------------------- | :---------------------------------------------------------------------------------- |
> | **Tài xế Full - time** (Dài hạn) | **Thưởng nóng 500.000 VNĐ** | Khi hoàn thành 100 cuốc trong vòng 30 ngày kể từ ngày Tài xế có cuốc đầu tiên |
> | | **Thưởng nóng 1.000.000 VNĐ** | Khi hoàn thành 150 cuốc trong vòng 30 ngày kể từ ngày Tài xế có cuốc đầu tiên |
> | **Tài xế Part - time** (Dài hạn) | **Thưởng nóng 300.000 VNĐ** | Khi hoàn thành 50 cuốc trong vòng 30 ngày kể từ ngày Tài xế có cuốc đầu tiên |

### 3. Chương trình đảm bảo thu nhập

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/ce987913-chinh-sach-04-1024x652.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # BÁC TÀI XANH
> 
> ## CHƯƠNG TRÌNH ĐẢM BẢO THU NHẬP
> 
> **KHU VỰC:** Hà Nội, Đà Nẵng, Tp.Hồ Chí Minh, Bình Dương, Đồng Nai (theo địa phận hành chính cũ)
> 
> | Tài xế Full - time (Ngắn hạn) | ĐẢM BẢO THU NHẬP **2.500.000 VNĐ/Tuần.** Trong 04 tuần đầu với tài xế mới |
> |---|---|
> | | **Điều kiện** |
> | | - Hoàn thành tối thiểu 15 cuốc/ngày x 6 ngày/tuần |
> | | - Tỷ lệ nhận chuyến và tỷ lệ hoàn thành chuyến >= 90% |
> ```

![Green SM Bike - Đa dạng gói đăng ký, linh hoạt thời gian chạy](https://cdn.xanhsm.com/2025/10/6e62b14c-image-1-1024x653.png)

> **[Nội dung trích xuất từ ảnh]:**
> # BÁC TÀI XANH
> ## CHƯƠNG TRÌNH ĐẢM BẢO THU NHẬP
> 
> **KHU VỰC:** Bà Rịa - Vũng Tàu (cũ), Quảng Ninh, Hải Phòng, Nghệ An, Huế, Khánh Hòa
> 
> | | |
> |---|---|
> | **Tài xế Full - time (Ngắn hạn)** | **ĐẢM BẢO THU NHẬP 1.800.000 VNĐ/Tuần.**<br>Trong 04 tuần đầu với tài xế mới |
> | | **Điều kiện** |
> | | - Hoàn thành tối thiểu 15 cuốc/ngày x 6 ngày/tuần |
> | | - Tỷ lệ nhận chuyến và tỷ lệ hoàn thành chuyến >= 90% |

### 4. Chương trình tăng chiết khấu

![Green SM Bike - Đa dạng gói đăng ký, linh hoạt thời gian chạy](https://cdn.xanhsm.com/2025/10/6e62b14c-image-5-1024x653.png)

> **[Nội dung trích xuất từ ảnh]:**
> # BÁC TÀI XANH
> ## CHƯƠNG TRÌNH TĂNG CHIẾT KHẤU CHO TÀI XẾ
> 
> | Tài xế Part - time (Ngắn hạn) | **Thưởng 1,5% GMV các cuốc**                                                                                                                                                                                                                                      |
> | ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> |                               | **Điều kiện**                                                                                                                                                                                                                                    |
> |                               | - Trong 4 tuần đầu tiên kể từ ngày có cuốc đầu tiên<br> - Tỷ lệ nhận chuyến và tỷ lệ hoàn thành chuyến >= 85% |

### 5. Chương trình MIỄN KHOÁN DOANH SỐ

Đối với tất cả các tài xế part-time sẽ được miễn khoán doanh số trong vòng 90 ngày đầu kể từ ngày phát xe. Trong trường hợp tài xế được phát xe trước ngày khai trương thị trường, tình từ ngày khai trương thị trường.

### 6. Chính sách cọc đầu vào mới

Nhằm hỗ trợ Tài xế thuận tiện đăng ký, giảm gánh nặng tài chính, trong thời gian từ ngày 18/09/2025 đến ngày 15/11/2025, Green SM giảm mức cọc đầu vào cho toàn bộ Tài Xế mức cọc đầu vào (đóng phí cọc lần đầu tiên) là 1.000.000 VNĐ.

Riêng nhóm sinh viên được áp dụng mức cọc lần đầu là 500.000 VNĐ, lưu ý cần phải có thẻ sinh viên còn thời hạn để được ghi nhận.

### 7. Chương trình miễn phí đồng phục

Tài xế được miễn phí bộ đồng phục trị giá 510.000 VNĐ bao gồm 2 Mũ bảo hiểm, áo khoác đồng phục, áo mưa Green SM Bike

Lưu ý: Trong trường hợp Tài xế thanh lý hợp đồng trong vòng 06 tháng sau khi tuyển dụng, Tài xế cần thanh toán toàn bộ giá trị bộ đồng phục tương đương 510.000 VNĐ)

### 8. Chương trình hỗ trợ hồ sơ – thủ tục:

Nới lỏng các điều kiện hồ sơ: Áp dụng thay thế LLTP số 02 thành LLTP số 01 áp dụng từ ngày 01/10/2025.

– LLTP số 01 không có án tích hoặc không vi phạm các án tích ở Phụ Lục 02, được cấp trong vòng 6 tháng.

– Chấp nhận bản gốc hoặc bản điện tử tích hợp trên VNeID định danh mức 2.

– Các giấy tờ thay thế LLTP số 01 trong vòng 60 ngày kể từ ngày kích hoạt tài khoản:

- Biên lai bưu điện/ Giấy hẹn còn hạn của STP/ LLTP số 01 không vi phạm án tích ở Phụ Lục 02.

- Hỗ trợ tiếp nhận LLTP có án tích dưới 3 năm với điều kiện không vi phạm các lỗi trong Phụ Lục 02.

Trong thời gian tới, Green SM sẽ tiếp tục theo dõi, đánh giá hiệu quả chính sách để có điều chỉnh phù hợp với nhu cầu thực tiễn và cam kết đồng hành cùng Đối tác trên hành trình tăng trưởng bền vững.

👉 Ứng tuyển Green SM Bike:TẠI ĐÂY
