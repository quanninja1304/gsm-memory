# Cập nhật chính sách thưởng dành cho Tài xế Taxi

- **Ngày đăng:** 2025-03-25
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-danh-cho-tai-xe-taxi](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-danh-cho-tai-xe-taxi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm ghi nhận sự cống hiến của Bác tài, từ ngày26/02/2025, Green SM chính thức cập nhậtchính sách thưởng hấp dẫn, áp dụng trên toàn quốc vớithưởng ý thức chất lượng công việcvàthưởng thâm niên, cụ thể như sau:✅Thưởng ý thức chất lượng công việc– dành cho Tài xế Xanh Premium đạt tiêu chí đánh giá sao cao.✅Thưởng thâm niên– áp dụng cho Bác tài gắn bó lâu dài, lên đến1.000.000 VNĐ/tháng.

📌Chi tiết mức thưởng và điều kiện áp dụngnhư sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/03/41054e8b-20250325_chinhsachmoi-762x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> # CẬP NHẬT CHÍNH SÁCH THƯỞNG DÀNH CHO TÀI XẾ TAXI
> 
> **Đối tượng áp dụng:** Tài xế Taxi trên toàn quốc
> **Thời gian áp dụng:** Từ ngày 26/02/2025 cho đến khi có thông báo mới
> 
> ## Chi tiết các khoản thưởng
> 
> | Tỉnh/Thành phố | Thưởng ý thức chất lượng công việc (VNĐ/tháng) | Thưởng thâm niên (VNĐ/tháng)                                      |
> |:----------------|:-----------------------------------------------|:---------------------------------|:---------------------------------|:---------------------------------|
> |                 | Áp dụng cho Tài xế Xanh Premium (*)            | Thâm niên Từ 6 - < 9 tháng     | Thâm niên Từ 9 - < 12 tháng    | Thâm niên Từ 12 tháng trở lên   |
> | Vùng I          | 1.340.000                                      | 500.000                          | 700.000                          | 1.000.000                        |
> | Vùng II         | 1.090.000                                      | 400.000                          | 700.000                          | 900.000                          |
> | Vùng III        | 940.000                                        | 400.000                          | 600.000                          | 800.000                          |
> 
> (*) **Tiêu chí xét thưởng ý thức chất lượng công việc cho Tài xế Xanh Premium**
> 
> | Tiêu chí xét thưởng | Mức mục tiêu (tháng)                             | Mức thưởng tháng                  |
> |:-------------------|:-------------------------------------------------|:----------------------------------|
> | Dịch vụ Tốt        | Điểm chấm sao trong tháng trung bình đạt từ 4,85 trở lên | 100% thưởng ý thức chất lượng công việc |
> 
> ## Lưu ý:
> * Thưởng thâm niên và thưởng ý thức chất lượng công việc tính theo ngày công hưởng lương.
> * Thưởng thâm niên không áp dụng với Tài xế nghỉ việc trong tháng.
> * Tài xế được thưởng thâm niên khi đạt từ 22 công hưởng lương/tháng.
> * Thâm niên của Tài xế Taxi được xác định từ ngày vào Công ty đến ngày bắt đầu kỳ lương hàng tháng.
> * Tài xế Xanh Premium có cuốc xe dưới 4* sẽ bị xử lý theo quy định Nội bộ chung.
> * **Điểm cập nhật mới:** Kể từ ngày 26/03/2025, tỷ lệ nhận cuốc và tỷ lệ hoàn thành cuốc không tính các cuốc nối chuyến.
> 
> ## Phân loại tỉnh/thành phố theo vùng
> 
> |                 |                                                                                                                                              |
> |:----------------|:---------------------------------------------------------------------------------------------------------------------------------------------|
> | **Vùng I**      | Bà Rịa-Vũng Tàu, Bình Dương, Đồng Nai, Hà Nội, TP. Hồ Chí Minh, Long An, Quảng Ninh                                                       |
> | **Vùng II**     | Bắc Ninh, Bến Tre, Bình Phước, Cần Thơ, Đà Nẵng, Hải Dương, Hòa Bình, Huế, Hưng Yên, Lào Cai, Nam Định, Ninh Bình, Nha Trang, Phú Quốc, Quảng Bình, Quảng Nam, Tây Ninh, Tiền Giang, Thái Bình, Thái Nguyên, Thanh Hóa, Trà Vinh |
> | **Vùng III**    | Gia Lai, Hà Giang, Hà Nam, Kon Tum, Phú Yên, Quảng Ngãi, Quảng Trị                                                                           |

💰 Hãy duy trì chất lượng dịch vụ và đồng hành cùng Green SM để nhận thưởng ngay!

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được giải đáp.

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
