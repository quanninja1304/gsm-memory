# Cập Nhật Chính Sách Thu Nhập Và Vận Doanh – Vững Vàng Thu Nhập Cùng Green SM

- **Ngày đăng:** 2026-08-15
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thu-nhap-van-doanh-tai-da-nang-quang-ninh-hue-khanh-hoa-can-tho-bac-ninh-thanh-hoa-thai-nguyen](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thu-nhap-van-doanh-tai-da-nang-quang-ninh-hue-khanh-hoa-can-tho-bac-ninh-thanh-hoa-thai-nguyen)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Green SMcập nhật đến Bác Tài những thay đổi mới nhất vềchính sách thưởng tuần và chính sách vận doanh, áp dụng từ ngày 17/08/2026, để Bác Tài thuận tiện theo dõi và chủ động kế hoạch vận doanh. như sau:

- Thời gian áp dụng:Từ ngày 17/08/2026 cho đến khi có thông báo mới

- Đối tượng áp dụng:Bác Tài Xanh Bike

- Khu vực áp dụng:Đà Nẵng, Quảng Ninh, Thành phố Huế, Khánh Hòa, Cần Thơ, Bắc Ninh, Thanh Hóa, Thái Nguyên, Hưng Yên, Ninh Bình, Gia Lai

Nội dung cập nhật:

- Cập nhật điều chỉnh các mốc thưởng tuần theo chính sách mới.

Chi tiết chính sách:

![Cập Nhật Chính Sách Thu Nhập Và Vận Doanh](https://cdn.xanhsm.com/2026/07/10bd711f-1-4-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản đã được trích xuất và định dạng Markdown:
> 
> # CHÍNH SÁCH THU NHẬP DÀNH CHO BÁC TÀI XANH BIKE
> 
> Áp dụng toàn quốc từ ngày 17/08/2026
> 
> **TỔNG THU NHẬP** = Chia sẻ doanh số (1) + Thưởng tuần (2) + Thưởng khác (nếu có) (3)
> 
> ## (1) Chia sẻ doanh số
> 
> | Dịch vụ             | Mức chia sẻ doanh số | Ghi chú                                                                                                                                                                                                                                                                                                 |
> | :------------------ | :------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
> | Bike, Express Siêu tốc | 70%                  | - Doanh số bao gồm cả các phí yêu cầu đặc biệt của dịch vụ Green Express (giao tận tay, phí giao hàng cồng kềnh...) <br> - Mức chia sẻ doanh số chưa bao gồm khoản khấu trừ Thuế Thu nhập cá nhân (PIT) & thuế GTGT (VAT) |
> | Express 2h & Express 4h | 72%                  |                                                                                                                                                                                                                                                                                                         |
> | Food                | 75%                  |                                                                                                                                                                                                                                                                                                         |

![Cập Nhật Chính Sách Thu Nhập Và Vận Doanh](https://cdn.xanhsm.com/2026/07/3882b676-2-4-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TUẦN
> 
> Áp dụng từ ngày 17/08/2026
> 
> Khu vực áp dụng: Đà Nẵng, Quảng Ninh, Thành phố Huế, Khánh Hòa, Cần Thơ, Bắc Ninh, Thanh Hóa, Thái Nguyên, Hưng Yên, Ninh Bình, Gia Lai
> 
> | MỨC ĐIỂM THƯỞNG   | MỨC THƯỞNG       | ĐIỀU KIỆN NHẬN THƯỞNG                                                                                                                                              |
> | :---------------- | :--------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | 700 - dưới 950 điểm | 150.000 VNĐ      | - Ngày vận doanh >= 5 ngày/tuần trong đó có 1 ngày thứ 7 hoặc CN<br>- Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến >=90%<br>- Có lượt đánh giá trung bình >4.85* |
> | 950 - dưới 1250 điểm | 300.000 VNĐ      |                                                                                                                                                                    |
> | 1250 - dưới 1650 điểm | 700.000 VNĐ      |                                                                                                                                                                    |
> | Từ 1650 điểm trở lên | 1.000.000 VNĐ    |                                                                                                                                                                    |

![Cập Nhật Chính Sách Thu Nhập Và Vận Doanh](https://cdn.xanhsm.com/2026/07/96ff06a7-3-6-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> ✓GREEN SM
> **CHÍNH SÁCH VẬN DOANH**
> **DÀNH CHO BÁC TÀI XANH BIKE**
> 
> Áp dụng từ ngày 17/08/2026
> 
> **BẢNG QUY ĐỔI ĐIỂM THƯỞNG**
> 
> | Dịch vụ             | 6h00-8h59 | 9h00-10h59 | 11h00-13h59 | 14h00-14h59 | 16h00-18h59 | 15h00-15h59, 19h00-5h59 |
> | :------------------ | :-------- | :--------- | :---------- | :---------- | :---------- | :----------------------- |
> | Green SM Bike       | 10        | 5          | 5           | 5           | 10          | 5                        |
> | Green Express siêu tốc | 5         | 5          | 10          | 5           | 5           | 5                        |
> | Green Express 2h    | 10        | 10         | 15          | 15          | 10          | 10                       |
> | Green Express 4h    | 15        | 15         | 15          | 15          | 10          | 10                       |
> | Green SM Food       | 15        | 15         | 25          | 15          | 25          | 15                       |
> 
> ⚠️ Đơn giao hàng đa điểm được tính theo số điểm giao
> ```

![Cập Nhật Chính Sách Thu Nhập Và Vận Doanh](https://cdn.xanhsm.com/2026/07/4012f062-4-2-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> Áp dụng từ ngày 17/08/2026
> 
> **CHÍNH SÁCH DOANH SỐ TỐI THIỂU**
> **DÀNH CHO BÁC TÀI XANH BIKE**
> 
> | Khu vực                                                                        | Mức khoán doanh số tối thiểu | Mức truy thu                                                                                                                                                             |
> | :----------------------------------------------------------------------------- | :---------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Đà Nẵng                                                                        | 1.200.000 VNĐ /tuần           | Trong trường hợp **không đạt** mức doanh số tối thiểu, Đối tác Tài xế sẽ bị truy thu **25%** phần Doanh số khoán chưa đạt bằng hình thức Trừ Ví tài xế |
> | Quảng Ninh, Hải Phòng, Nghệ An, Huế, Khánh Hòa, TP.Hồ Chí Minh (khu vực Bà Rịa - Vũng Tàu cũ) | 800.000 VNĐ /tuần             |                                                                                                                                                                          |
> ```

![Cập Nhật Chính Sách Thu Nhập Và Vận Doanh](https://cdn.xanhsm.com/2026/07/32908316-5-1-1-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH VẬN DOANH DÀNH CHO BÁC TÀI XANH BIKE
> 
> ## QUY ĐỊNH TRỰC TUYẾN & TỶ LỆ VẬN HÀNH
> 
> | Tiêu chí                 | Nội dung                                                                                                                                                                                                                                                                                                            |
> | :----------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
> | **Quy định trực tuyến** | - Cảnh báo nếu Đối tác không trực tuyến/không phát sinh chuyến xe trong 02 ngày liên tiếp.<br>- Công ty sẽ tiến hành thu hồi xe và thu phí sử dụng xe nếu 05 ngày liên tiếp Đối tác không trực tuyến/không phát sinh chuyến xe mà không có lý do hợp lệ.<br>- Áp dụng phí sử dụng xe đối với các ngày không vận doanh vượt quy định, cụ thể: Thu phí sử dụng xe 50.000 VNĐ/ngày từ ngày không vận doanh thứ 5 trở đi/tháng. |
> | **Quy định tỷ lệ vận hành** | - Trường hợp Đối tác Tài xế có tỷ lệ chấp nhận chuyến dưới 70%: Hệ thống sẽ mặc định bật tính năng “Nhận chuyến tự động” tới 23h59 của ngày vận doanh đó.                                                                                                                                                              |

Cùng Green SM bứt tốc, gia tăng thu nhập và vận doanh năng suất, Bác Tài nhé!

GÓC GIẢI ĐÁP

| Câu hỏi | Giải đáp |
| --- | --- |
| Khung giờ cao điểm được tính như thế nào? | Khung giờ cao điểm được quy đổi thành mốc điểm thưởng 5-10-15-25 theo từng dịch vụ nhằm giúp Đối tác Tài xế chủ động sắp xếp thời gian hoạt động phù hợp. |
| Chuyến Bike/giao hàng đa điểm được tính mấy điểm? | Chương trình thưởng sẽ tính theo số điểm giao hoàn thành của chuyến xe. |
| Cuốc xe giờ cao điểm/thấp điểm sẽ dựa vào thời gian nhận chuyến hay hoàn thành chuyến? | Điểm thưởng được tính theo thời gian khách hàng đặt chuyến. |
| Doanh số chia sẻ chiết khấu với Công ty đã loại trừ khoản tiền Thuế VAT này chưa? | Doanh số dùng để tính chia sẻ là doanh số trước khi trừ khuyến mại/chiết khấu; phần VAT được tính theo quy định hiện hành. |
| Tiền thưởng tuần được cộng vào đâu và khi nào tôi nhận được? | Tiền thưởng tuần sẽ được ghi nhận theo chu kỳ xét thưởng của chương trình vào thứ 3 tuần tiếp theo. Bác Tài theo dõi chi tiết tại mục thưởng trên ứng dụng tài xế. |
| Điểm sao đánh giá trung bình tuần được tính như thế nào? Mức điểm đánh giá tối thiểu để nhận được thưởng tuần? | Để đủ điều kiện xét thưởng tuần, Bác Tài cần đạt điểm sao đánh giá trung bình tuần từ Khách hàng >4,85*.Điểm sao đánh giá trung bình tuần được tính dựa trên các chuyến xe có phát sinh đánh giá trong tuần, từ Thứ Hai đến hết Chủ Nhật.Ngoài điều kiện về điểm đánh giá sao, Bác Tài cần đáp ứng các điều kiện vận doanh theo khu vực:– Tỷ lệ nhận chuyến và tỷ lệ hoàn thành chuyến từ 90% trở lên.Bác Tài cần đáp ứng đầy đủ các điều kiện trên để được xét thưởng tuần. |
| Điểm đánh giá sao được tính trong khoảng thời gian nào? Có cộng dồn qua các tuần không? | Điểm sao trung bình được tính theo từng tuần (từ Thứ Hai đến Chủ Nhật). Mỗi tuần được xét độc lập, không cộng dồn điểm của tuần trước sang tuần sau. Vì vậy một tuần bị thấp sẽ không kéo dài ảnh hưởng nếu tuần sau Bác Tài cải thiện. |
| Khách hàng không bấm đánh giá thì tôi có bị tính 0 sao không? | Không. Chỉ những chuyến có phát sinh đánh giá mới được tính. Các chuyến khách bỏ qua, không đánh giá sẽ không làm giảm điểm trung bình của Bác Tài. |
| Vì sao điểm sao của tôi thay đổi sau mỗi chuyến? | Điểm trung bình tuần được cập nhật liên tục theo các đánh giá mới phát sinh trong tuần. Càng nhiều chuyến được đánh giá 5 sao, điểm trung bình càng ổn định và ít bị ảnh hưởng bởi một vài đánh giá thấp phát sinh. |
| Làm thế nào để giữ và cải thiện điểm sao trên 4,85? | Một vài thói quen nhỏ giúp Bác Tài dễ dàng đạt đánh giá cao từ khách hàng:– Luôn bật nhận chuyến tự động để tránh trôi chuyến– Chủ động liên hệ khách hàng xác nhận điểm đón– Chào hỏi thân thiện, xác nhận đúng tên khách và điểm đến trước khi khởi hành.– Giữ xe và mũ bảo hiểm sạch sẽ, gọn gàng; lái xe an toàn, đúng luật giao thông.– Đi đúng lộ trình ứng dụng gợi ý; nếu muốn thay đổi lộ trình, Bác Tài nên trao đổi trước với khách.– Chủ động liên hệ khi khó tìm điểm đón; giữ thái độ bình tĩnh, lịch sự khi kẹt xe hoặc thời tiết xấu.– Với chuyến giao hàng: bảo quản hàng cẩn thận, giao đúng – đủ, cập nhật trạng thái kịp thời.Mẹo: Phần lớn khách hàng có xu hướng đánh giá 5 sao khi trải nghiệm tốt, nên chỉ cần phục vụ ổn định, Bác Tài hoàn toàn có thể giữ điểm cao. |

Mến chúc Bác Tài vận doanh thuận lợi và nhiều sức khỏe!

Trân trọng,Đội ngũ Green SM.
