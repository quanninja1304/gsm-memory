# Chính sách thưởng 02/09 cho Tài xế GF-VIP Khánh Hòa

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-2-9-gfvip-khanh-hoa](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-2-9-gfvip-khanh-hoa)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Dịp lễ Quốc khánh 02/09 là lúc nhu cầu di chuyển tăng vọt – cũng chính là“thời điểm vàng”để Bác tài Green SM tăng tốc thu nhập và rinh thêm thưởng hấp dẫn! Trong 4 ngày cao điểm lễ, Green SM triển khaichính sáchdành riêng cho các Bác tài vận doanh:👉Đối tượng áp dụng: Tài xế GF-VIP tại các Depot/HUB Khánh Hòa 1, 2👉Thời gian áp dụng:Từ30/08 – 02/09/2025👉Nội dung chính sách: Tỷ lệthưởng trách nhiệmvà doanh sốđược điều chỉnhtăng thêmso với ngày thường👉Chi tiết mức thưởng: Bác tài vui lòng xem trong hình ảnh đính kèm

![thưởng 2/9 GF VIP Khánh Hoà](https://cdn.xanhsm.com/2025/08/2042177a-250829-kh12-884x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> # ĐẠI LỄ QUỐC KHÁNH 02/09
> 
> **Đối tượng áp dụng:** Tài xế Taxi trực thuộc Depot/HUB Khánh Hòa 1, 2 tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** 04 ngày từ ngày 30/08 đến ngày 02/09/2025
> 
> ## Nội dung chính sách
> Tỷ lệ thưởng trách nhiệm và doanh số được điều chỉnh tăng thêm lên đến **10%** so với ngày thường
> 
> ## GF VIP
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ ngày 30 - 31/08 | Tỷ lệ chia sẻ ngày 01 - 02/09 |
> | :---- | :---------------------------- | :--------------------------- | :--------------------------- |
> | Mức 0 | Dưới 700.000                  | 30%                          | 35%                          |
> | Mức 1 | Từ 700.000 đến dưới 1.050.000 | 35%                          | 40%                          |
> | Mức 2 | Từ 1.050.000 đến dưới 1.300.000 | 43%                          | 48%                          |
> | Mức 3 | Từ 1.300.000 đến dưới 1.700.000 | 50%                          | 55%                          |
> | Mức 4 | Từ 1.700.000 trở lên          | 55%                          | 60%                          |
> 
> ## Ghi chú
> * Depot/HUB Khánh Hòa 1, 2: các Depot/HUB trực thuộc Khánh Hòa cũ

⚡ Sẵn sàng bứt tốc đại lễ cùng Green SM – càng chạy nhiều, càng nhận chia sẻ cao!

Mến chúc các Bác tài vận hành an toàn và hiệu quả!

Trân trọng,Đội ngũ Green SM
