# Cập nhật quy định vận doanh dành cho Bác Tài GF-VIP

- **Ngày đăng:** 2025-12-05
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/quy-dinh-gf-vip](https://www.greensm.com/vn-vi/news/quy-dinh-gf-vip)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Nhằm khẳng định đẳng cấp, trải nghiệm của Khách hàng GF-VIP và giúp Bác Tàichủ động hơn trong kế hoạch vận doanh, tối ưu thu nhập, Green SM sẽcập nhật quy định vận doanh dành riêng cho Bác Tài GF-VIPtừ ngày05/12/2025.

Các cập nhật chính sách nhằm đảm bảo các Bác tài tuân thủ tiêu chuẩn dịch vụ và luôn cố gắng để nâng cao doanh số, cụ thể:

- Tỷ lệ nhận và hoàn thành chuyến đạt từ 95% trở lên, giúp thể hiện sự chuyên nghiệp, uy tín và tinh thần sẵn sàng phục vụ Khách hàng của Bác Tài GF-VIP

- Doanh số mục tiêu mỗi ngàycho từng khu vực để Bác Tàibiết rõ “mốc cần chinh phục”và dễ theo dõi hiệu quả vận doanh của mình

✨Điểm đặc biệt mang lại thêm lợi ích cho Bác Tài:Một số Bác Tài sẽ được áp dụng doanh số tối thiểu bằng 85% mức doanh số khoán.

![Chính sách GF VIP](https://cdn.xanhsm.com/2025/12/fe9b6318-251225_gfvip-1024x445.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Cập nhật quy định vận doanh dành cho Bác Tài GF VIP
> (Áp dụng từ ngày 05/12/2025)
> 
> ## Đối tượng áp dụng
> *   Bác Tài GF VIP tại Hà Nội, TP.HCM, Đà Nẵng và Khánh Hòa (theo địa giới hành chính cũ)
> 
> ## Điều kiện
> *   Tỷ lệ nhận và hoàn thành chuyến ≥95%
> ```

![Quy định GF VIP](https://cdn.xanhsm.com/2025/12/882025f7-251204_gfvip-02-1024x810.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất từ hình ảnh ở định dạng Markdown:
> 
> ## Doanh số tối thiểu mỗi ngày Bác Tài cần đạt được:
> 
> | Khu vực (theo địa giới hành chính cũ) | Doanh số tối thiểu mỗi ngày |
> |---|---|
> | Hà Nội, TP.HCM | 400.000 VNĐ/ngày |
> | Đà Nẵng, Khánh Hòa | 300.000 VNĐ/ngày |
> 
> ### Đặc biệt
> 
> *   Bác Tài chuyên chạy tuyến Phường/Xã sẽ được áp dụng doanh số tối thiểu bằng **85%** mức doanh số tại khu vực đó (danh sách Bác Tài do Công ty chỉ định)
> *   Bác Tài tái tuyển được áp dụng doanh số tối thiểu bằng **85%** mức doanh số của quy định nêu trên trong **06** tháng đầu tiên kể từ ngày tái tuyển

Mến chúc Bác Tài vận doanh an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
