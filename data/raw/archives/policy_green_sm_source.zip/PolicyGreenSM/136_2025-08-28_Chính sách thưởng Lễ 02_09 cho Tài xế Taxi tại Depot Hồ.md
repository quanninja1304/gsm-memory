# Chính sách thưởng Lễ 02/09 cho Tài xế Taxi tại Depot Hồ Chí Minh 5 và Quảng Ninh 1, 2, 3

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Cẩm nang tài xế, GSM Parent Category Vi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-2-9-1](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-2-9-1)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Dịp lễ Quốc khánh 02/09 là lúc nhu cầu di chuyển tăng vọt – cũng chính là“thời điểm vàng”để Bác tài Green SM tăng tốc thu nhập và rinh thêm thưởng hấp dẫn! Trong 4 ngày cao điểm lễ, Green SM triển khaichính sáchdành riêng cho các Bác tài vận doanh:👉Đối tượng áp dụng: Tài xế Taxi Green SM tại các Depot/HUB Hồ Chí Minh 5 và Quảng Ninh 1, 2, 3👉Thời gian áp dụng:Từ30/08 – 02/09/2025👉Nội dung chính sách: Tỷ lệthưởng trách nhiệmvà doanh sốđược điều chỉnhtăng thêmso với ngày thường👉Chi tiết mức thưởng: Bác tài vui lòng xem trong hình ảnh đính kèm

![Chính sách thưởng Lễ 02/09 cho Tài xế Taxi tại Depot Hồ Chí Minh 5 và Quảng Ninh 1, 2, 3](https://cdn.xanhsm.com/2025/08/28497806-250828-hcm5qn123-660x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ ĐẠI LỄ QUỐC KHÁNH 02/09
> 
> **Đối tượng áp dụng:** Tài xế Taxi trực thuộc Depot/HUB Hồ Chí Minh 5; Quảng Ninh 1, 2, 3 tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** 04 ngày từ ngày 30/08 đến ngày 02/09/2025
> 
> **Nội dung chính sách**
> Tỷ lệ thưởng trách nhiệm và doanh số được điều chỉnh tăng thêm lên đến 12% so với ngày thường
> 
> ## Xanh SM Car
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ ngày 30 - 31/08 Hồ Chí Minh 5 | Tỷ lệ chia sẻ ngày 30 - 31/08 Quảng Ninh 1,2,3 | Tỷ lệ chia sẻ ngày 01 - 02/09 Hồ Chí Minh 5 | Tỷ lệ chia sẻ ngày 01 - 02/09 Quảng Ninh 1,2,3 |
> |-------|-------------------------------|---------------------------------------------|-----------------------------------------------|---------------------------------------------|-----------------------------------------------|
> | Mức 0 | Dưới 850.000                  | 30%                                         | 28%                                           | 35%                                         | 33%                                           |
> | Mức 1 | Từ 850.000 đến dưới 1.150.000  | 38%                                         | 38%                                           | 43%                                         | 43%                                           |
> | Mức 2 | Từ 1.150.000 đến dưới 1.650.000| 42%                                         | 42%                                           | 47%                                         | 47%                                           |
> | Mức 3 | Từ 1.650.000 đến dưới 2.100.000| 51%                                         | 52%                                           | 56%                                         | 57%                                           |
> | Mức 4 | Từ 2.100.000 trở lên          | 53%                                         | 55%                                           | 58%                                         | 60%                                           |
> 
> ## Xanh SM Premium
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ ngày 30 - 31/08 Hồ Chí Minh 5 | Tỷ lệ chia sẻ ngày 30 - 31/08 Quảng Ninh 1,2,3 | Tỷ lệ chia sẻ ngày 01 - 02/09 Hồ Chí Minh 5 | Tỷ lệ chia sẻ ngày 01 - 02/09 Quảng Ninh 1,2,3 |
> |-------|-------------------------------|---------------------------------------------|-----------------------------------------------|---------------------------------------------|-----------------------------------------------|
> | Mức 0 | Dưới 750.000                  | 30%                                         | 28%                                           | 35%                                         | 33%                                           |
> | Mức 1 | Từ 750.000 đến dưới 1.050.000  | 35%                                         | 35%                                           | 40%                                         | 40%                                           |
> | Mức 2 | Từ 1.050.000 đến dưới 1.400.000| 42%                                         | 41%                                           | 47%                                         | 46%                                           |
> | Mức 3 | Từ 1.400.000 đến dưới 1.900.000| 50%                                         | 50%                                           | 55%                                         | 55%                                           |
> | Mức 4 | Từ 1.900.000 trở lên          | 53%                                         | 52%                                           | 58%                                         | 57%                                           |
> 
> **Ghi chú**
> * Depot Hồ Chí Minh 5: Depot trực thuộc Bà Rịa - Vũng Tàu cũ
> * Depot/HUB Quảng Ninh 1, 2, 3: các Depot/HUB trực thuộc Quảng Ninh

⚡ Sẵn sàng bứt tốc đại lễ cùng Green SM – càng chạy nhiều, càng nhận chia sẻ cao!

Mến chúc các Bác tài vận hành an toàn và hiệu quả!

Trân trọng,Đội ngũ Green SM
