# Chính sách thưởng giờ cao điểm tại TP.HCM ngày 27/04

- **Ngày đăng:** 2025-04-27
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-gio-cao-diem-ngay-27-04-tphcm](https://www.greensm.com/vn-vi/news/thuong-gio-cao-diem-ngay-27-04-tphcm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm hỗ trợ Bác tài Taxi tại TP.HCM gia tăng thu nhập trong dịp cao điểm cuối tuần trước thềm Lễ Giải phóng miền Nam 30/04 và Quốc tế Lao động 01/05/2025, chương trìnhthưởng giờ cao điểmsẽ được triển khai vào ngày27/04/2025!

👥Đối tượng áp dụng:Tài xế Taxi trực thuộc các Depot tại TP.HCM

🕐Thời gian áp dụng:09:00 – 11:59 | 17:00 – 18:5­9 | 21:00 – 23:59

⭐Nội dung chính sách:Trong các khung giờ trên, Bác tài sẽ đượcthưởng thêm 10%chia sẻ, tổng chia sẻ có thể lên đến72%tùy theo doanh số đạt được.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/f43bab0a-20250427_hcmchihsach-1024x946.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH THƯỞNG GIỜ CAO ĐIỂM TẠI TP.HCM NGÀY 27/04
> 
> **Đối tượng áp dụng:** Tài xế Taxi trực thuộc các Depot tại TP.HCM
> **Thời gian áp dụng:** 09:00 – 11:59 | 17:00 – 18:59 | 21:00 – 23:59
> 
> ## Nội dung chính sách
> 
> | Xanh Car | | | Xanh Premium | | |
> |---|---|---|---|---|---|
> | **Mức** | **Mốc Doanh số ngày (VNĐ)** | **Thưởng thêm chia sẻ** | **Tổng chia sẻ** | **Mức** | **Mốc Doanh số ngày (VNĐ)** | **Thưởng thêm chia sẻ** | **Tổng chia sẻ** |
> | Mức 0 | Dưới 1.000.000 | | 43% | Mức 0 | Dưới 900.000 | | 42% |
> | Mức 1 | Từ 1.000.000 đến 1.300.000 | | 49% | Mức 1 | Từ 900.000 đến 1.200.000 | | 51% |
> | Mức 2 | Từ 1.300.000 đến 1.600.000 | 10% | 55% | Mức 2 | Từ 1.200.000 đến 1.500.000 | 10% | 60% |
> | Mức 3 | Từ 1.600.000 đến 2.100.000 | | 62% | Mức 3 | Từ 1.500.000 đến 2.000.000 | | 69% |
> | Mức 4 | Trên 2.100.000 | | 70% | Mức 4 | Trên 2.000.000 | | 72% |
> 
> **Ví dụ:** Tài xế Green Car tại TP.HCM có cuốc xe lúc 17h, với tổng doanh số trong ngày đạt 1.200.000₫ (thuộc mức 1), sẽ nhận mức chia sẻ 49% cho cuốc xe này.

Càng vận doanh vào khung giờ vàng – càng tăng cao thu nhập cùng Xanh!

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được giải đáp.

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM.
