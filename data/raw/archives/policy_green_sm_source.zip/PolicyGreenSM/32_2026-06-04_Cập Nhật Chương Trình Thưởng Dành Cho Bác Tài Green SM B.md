# Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike (cập nhật đến ngày 01/06/2026) 

- **Ngày đăng:** 2026-06-04
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chuong-trinh-thuong-danh-cho-bac-tai-green-sm-bike](https://www.greensm.com/vn-vi/news/cap-nhat-chuong-trinh-thuong-danh-cho-bac-tai-green-sm-bike)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến!

Nhằm hỗ trợ tối ưu hiệu quả vận doanh và bứt phá thu nhập hơn mỗi ngày,Green SMhiện đang triển khai nhiều chương trình thưởng hấp dẫn dành cho Bác Tài. Từ thưởng theo chuyến, thưởng khung giờ cao điểm đến các chính sách hỗ trợ vận doanh  xuyên suốt — tất cả đều giúp Bác Tài tăng thêm thu nhập khi hoạt động hiệu quả cùng Green SM.

Dưới đây là tổng hợp các chương trình thưởng và chính sách hỗ trợ thu nhập đang áp dụng dành cho Bác Tài trong tháng 6!

I. CHƯƠNG TRÌNH THƯỞNG GREEN BIKE

A.Thưởng cuốc điểm vàng

Chương trình giúp Bác Tài nhận cuốc tốt hơn, tăng thu nhập nhanh hơn tại các khu vực “hot” trong giờ tan tầm.

- Thời gian áp dụng:Từ ngày 04/05/2026 (Đang áp dụng).

- Khung giờ áp dụng:Từ 16h00 – 19h59 (Thứ 2 đến Thứ 6 hàng tuần).

- Đối tượng áp dụng:Bác Tài Xanh Bike tại Hà Nội và TP.HCM (cũ).

![Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike](https://cdn.xanhsm.com/2026/06/3134ced9-2-4.png)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG THÊM MỖI CUỐC TẠI “ĐIỂM VÀNG”
> 
> Dành cho Bác Tài Xanh Bike khu vực Hà Nội, TPHCM (cũ)
> 
> Chính sách thưởng “điểm vàng”
> 
> | Mức thưởng | Áp dụng                 | Điều kiện                                 |
> | :---------- | :---------------------- | :---------------------------------------- |
> | 8.000đ/cuốc | Bác Tài đăng ký phân ca | Khung giờ áp dụng: 16:00-19:59, từ T2 - T6 |
> |             |                         | Khu vực áp dụng: Trong danh sách quy định |
> |             |                         | Tỷ lệ nhận chuyến >=90%                  |
> | 4.000đ/cuốc | Bác Tài chưa đăng ký phân ca | Tỷ lệ hoàn thành chuyến >=95%            |
> 
> Danh sách “tọa độ vàng”
> 
> | Khu vực Hà Nội                         | Khu vực TPHCM (cũ)           |
> | :------------------------------------- | :--------------------------- |
> | * Toà nhà ICD                          | * Bến Thành Tower            |
> | * Times City                           | * Sonatus Building           |
> | * Tòa nhà Century Tower                | * Sunwah Tower               |
> | * Tòa nhà TNR Tower - Vincom Nguyễn Chí Thanh | * Vietcombank Tower          |
> | * New Center Building                  | * The Metropolitan Building  |
> | * Capital Tower                        | * MB Sunny Tower             |
> | * BRG Tower                            | * Bitexco Tower              |
> | * Lotte Center Hà Nội                  | * Building                   |
> | * Kinh Đô Building                     | * Hà Đô South Building       |
> | * Royal City                           | * Hà Phan Building           |
> | * Indochina Plaza Hanoi                | * Friendship Tower           |
> | * Tòa nhà Vietbank                     | * AB Tower                   |
> | * HQ Building                          | * Empress Tower              |
> | * Viễn Đông Building                   | * TNR Tower                  |
> | * Milhomes 30 Nguyễn Hồng              | * Toà Nhà Lim Tower          |
> | * Tòa nhà Eurowindow Số 2 Tôn Thất Tùng (HICCI) | * AP Tower                   |
> | * Tòa nhà VAD Building                 | * Vincom Center              |
> | * Capital Building, 41 Hai Bà Trưng    | * Central Tower              |
> | * Tòa nhà Mai Linh                     | * Horizon Tower              |
> | * Keangnam Hanoi Landmark Tower        | * Glory Tower                |
> | **Danh sách các quận**                 | **Danh sách các quận**       |
> | * Nam Từ Liêm                          | * Quận 1                     |
> | * Hai Bà Trưng                         | * Quận Bình Thạnh            |
> | * Ba Đình                              | * Quận 7                     |
> | * Cầu Giấy                             |                              |
> | * Hoàn Kiếm                            |                              |
> | * Đống Đa                              |                              |
> | * Thanh Xuân                           |                              |
> 
> (*) Trường hợp Bác Tài đã đăng ký phân ca 16:00-19:59 nhưng không hoạt động, Công ty sẽ truy thu 30,000 VNĐ/tài xế do không hoạt động theo ca

Xem thêm chi tiết chương trình thưởngTẠI ĐÂY

B. Tích điểm nhận thưởng hàng tuần:

Chạy càng nhiều, tích điểm càng cao, thưởng tuần về túi đều đặn.

| Khu vực áp dụng: Hà Nội, TP.HCM (bao gồm Bình Dương cũ), Đồng Nai. | Khu vực áp dụng: Hải Phòng, Nghệ An, Hồ Chí Minh (khu vực Bà Rịa – Vũng Tàu cũ), Long An, Tây Ninh, Bình Định, Bình Thuận, Ninh Thuận, Đăk Lăk. | Khu vực áp dụng: Đà Nẵng, Quảng Ninh, Thành phố Huế, Khánh Hòa, Cần Thơ, Bắc Ninh, Thanh Hóa, Thái Nguyên, Hưng Yên, Ninh Bình, Gia Lai. |
| --- | --- | --- |
| Thời gian áp dụng:đang áp dụng cho đến khi có thông báo mới |
| Chi tiết chương trìnhXEM TẠI ĐÂY | Chi tiết chương trìnhXEM TẠI ĐÂY | Chi tiết chương trìnhXEM TẠI ĐÂY |

![Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike](https://cdn.xanhsm.com/2026/06/50365259-3-2-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # GREEN SM
> 
> ## THƯỞNG TUẦN
> 
> **Áp dụng từ ngày 04/05/2026**
> 
> **Khu vực áp dụng:** Hà Nội, TP.Hồ Chí Minh (bao gồm HCM & Bình Dương), Đồng Nai
> 
> | MỨC ĐIỂM THƯỞNG     | MỨC THƯỞNG CẤP 1 (vận doanh 4 ngày/tuần trong đó có 1 ngày thứ 7 hoặc CN) | MỨC THƯỞNG CẤP 2 (vận doanh >=5 ngày/tuần trong đó có 1 ngày thứ 7 hoặc CN) |
> | :------------------ | :------------------------------------------------------------------------ | :------------------------------------------------------------------------- |
> | 400 - dưới 550 điểm  |                                                                           | 150.000 VNĐ                                                                |
> | 550 - dưới 700 điểm  | 110.000 VNĐ                                                               | 200.000 VNĐ                                                                |
> | 700 - dưới 850 điểm  | 140.000 VNĐ                                                               | 300.000 VNĐ                                                                |
> | 850 - dưới 1.100 điểm | 220.000 VNĐ                                                               | 550.000 VNĐ                                                                |
> | 1.100 - dưới 1.400 điểm | 440.000 VNĐ                                                               | 850.000 VNĐ                                                                |
> | 1.400 - dưới 1.500 điểm | 670.000 VNĐ                                                               | 1.400.000 VNĐ                                                              |
> | >= 1.500 điểm       | 840.000 VNĐ                                                               | 1.600.000 VNĐ                                                              |
> 
> | Khu vực                               | Điều kiện áp dụng                    | Mức thưởng cấp 1 | Mức thưởng cấp 2 |
> | :------------------------------------ | :----------------------------------- | :--------------- | :--------------- |
> | Hà Nội                                | Tỷ lệ nhận chuyến, hoàn thành chuyến | >= 85%           | >= 85%           |
> | TP.Hồ Chí Minh (bao gồm Bình Dương), Đồng Nai | Tỷ lệ nhận chuyến, hoàn thành chuyến | >= 90%           | >= 90%           |

![Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike](https://cdn.xanhsm.com/2026/06/c38e5281-4-3-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TUẦN
> Áp dụng từ ngày 21/05/2026
> 
> Khu vực áp dụng: Hải Phòng, Nghệ An, Hồ Chí Minh (khu vực Bà Rịa - Vũng Tàu cũ), Long An, Tây Ninh, Bình Định, Bình Thuận, Ninh Thuận, Đăk Lăk
> 
> | MỨC ĐIỂM THƯỞNG   | MỨC THƯỞNG   | ĐIỀU KIỆN NHẬN THƯỞNG                                                               |
> | :---------------- | :----------- | :---------------------------------------------------------------------------------- |
> | 300 - dưới 600 điểm | 120.000 VNĐ  |                                                                                     |
> | 600 - dưới 1000 điểm | 300.000 VNĐ  | - Ngày vận doanh >= 5 ngày/tuần trong đó có 1 ngày thứ 7 hoặc CN                    |
> | 1000 - dưới 1300 điểm | 600.000 VNĐ  | - Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến >=90%                                  |
> | Từ 1300 điểm trở lên | 900.000 VNĐ  |                                                                                     |

![Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike](https://cdn.xanhsm.com/2026/06/05df69f4-5-1-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # THƯỞNG TUẦN
> 
> **Áp dụng từ ngày 21/05/2026**
> 
> **Khu vực áp dụng:** Đà Nẵng, Quảng Ninh, Huế, Khánh Hòa, Cần Thơ, Bắc Ninh, Thanh Hóa, Thái Nguyên, Hưng Yên, Ninh Bình, Gia Lai
> 
> | MỨC ĐIỂM THƯỞNG | MỨC THƯỞNG | ĐIỀU KIỆN NHẬN THƯỞNG |
> |---|---|---|
> | 600 - dưới 900 điểm | 150.000 VNĐ | • Ngày vận doanh >= 5 ngày/tuần trong đó có 1 ngày thứ 7 hoặc CN |
> | 900 - dưới 1200 điểm | 300.000 VNĐ | • Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến >=90% |
> | 1200 - dưới 1600 điểm | 700.000 VNĐ | |
> | Từ 1600 điểm trở lên | 1.000.000 VNĐ | |
> ```

C. Thưởng nóng Lễ hội Pháo hoa Quốc tế Đà Nẵng 2026

Nhằm hỗ trợ Bác Tài đón đầu nhu cầu di chuyển tăng cao trong mùa lễ hội, Green SM thưởng nóng dành cho các cuốc xe đủ điều kiện tại khu vực diễn ra Lễ hội Pháo hoa Quốc tế Đà Nẵng 2026.

- Thời gian áp dụng:Từ 30/05/2026 đến 11/07/2026 (khung giờ 20h00 – 01h00 sáng hôm sau trong các đêm diễn ra lễ hội)

- Đối tượng áp dụng:Bác Tài Bike và Bike Platform tại Đà Nẵng

![Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike](https://cdn.xanhsm.com/2026/06/99ec7696-6-1-1024x1024.png)

> **[Nội dung trích xuất từ ảnh]:**
> # GREEN SM
> 
> ## THƯỞNG NÓNG ĐẾN 15.000Đ TRÊN 1 CHUYẾN XE TẠI LỄ HỘI PHÁO HOA QUỐC TẾ TẠI ĐÀ NẴNG NĂM 2026
> 
> | Tiêu đề | Nội dung |
> |---|---|
> | **Đối tượng áp dụng** | Bác Tài Xanh Bike và Bike Platform |
> | **Thời gian áp dụng** | Từ 20h00 tới 01h00 sáng ngày kế tiếp<br>Áp dụng trong 06 đêm diễn bắn pháo hoa (dự kiến) của lễ hội, bao gồm:<br>• 30/05/2026: Đêm khai mạc – Thiên Nhiên<br>• 06/06/2026: Đêm 2 – Di Sản<br>• 13/06/2026: Đêm 3 – Văn Hóa<br>• 20/06/2026: Đêm 4 – Sáng Tạo<br>• 27/06/2026: Đêm 5 – Tầm Nhìn<br>• 11/07/2026: Đêm chung kết – Những chân trời kết nối |
> | **Địa điểm tổ chức** | Dọc bờ sông Hàn - Đà Nẵng |
> | **Cơ chế thưởng** |
> | Số chuyến hoàn thành có điểm đón tại sự kiện | Mức thưởng |
> | 01 chuyến đầu tiên | **10.000đ/chuyến** |
> | Từ chuyến thứ 02 trở lên | **15.000đ/chuyến** |
> | **Điều kiện áp dụng** | Khi thỏa mãn điều kiện giá trị cuốc xe từ **35.000đ** trở lên |

II. CHƯƠNG TRÌNH THƯỞNG GREEN EXPRESS

A. Thưởng thêm theo km/ đơn “Green Express 2H không ghép được đơn”

Cơ hội gia tăng thu nhập vượt trội dành riêng cho các chuyến giao hàng Green Express 2H không ghép được đơn.

- Thời gian áp dụng:Từ 28/05/2026 đến hết 21/06/2026.

- Đối tượng áp dụng:Bác Tài Xanh Bike, Bike Platform, Bike Thuê xe sở hữu (RTO).

- Khu vực áp dụng:Hà Nội và TP.HCM (cũ).

![Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike](https://cdn.xanhsm.com/2026/06/a33e5758-7-1024x644.png)

> **[Nội dung trích xuất từ ảnh]:**
> # ĐƠN EXPRESS 2H CÓ THÊM THƯỞNG
> ## CHẠY CÀNG NHIỀU – THU NHẬP CÀNG TĂNG
> 
> **GREEN SM**
> 
> **Từ ngày 28/05 - 21/06/2026**
> 
> **Bật app canh đơn ngay hôm nay!**
> 
> Bác Tài Xanh tại Hà Nội & TP.HCM (cũ) hoàn thành đơn Green Express 2H sẽ nhận thêm thường theo quãng đường:
> 
> | Quãng đường      | Thưởng thêm       |
> | :---------------- | :---------------- |
> | **8KM ĐẦU**       | **1.000₫/km**     |
> | Từ km thứ 9 trở đi | **500đ/km**       |
> 
> **ĐẶC BIỆT**
> Bác tài có thể "THƯỞNG CHỒNG THƯỞNG" khi vừa nhận thưởng đơn Express 2H, vừa tích lũy điểm thưởng theo khung giờ áp dụng.

B. Hỗ trợ cước phí Express Doanh Nghiệp:

Chính sách bảo vệ quyền lợi tối đa cho Bác Tài, hỗ trợ bù cước phí khi gặp sự cố lỗi sai lệch định vị đối với các đơn hàng thuộc khối Doanh nghiệp.

Thời gian áp dụng:Từ 27/05/2026

Đối tượng áp dụng:Bác Tài Xanh Bike, Bike Platform, Bike Thuê xe sở hữu (RTO).

Dịch vụ áp dụng:Tất cả đơn Express doanh nghiệp 1H, 2H (Shopee, Long Châu, Capichi, Jollibee…)

XEM CHI TIẾTTẠI ĐÂY

![Cập Nhật Chương Trình Thưởng Dành Cho Bác Tài Green SM Bike](https://cdn.xanhsm.com/2026/06/8c80aa60-8-1024x644.png)

> **[Nội dung trích xuất từ ảnh]:**
> # TIN VUI CHO BÁC TÀI XANH
> ## HỖ TRỢ CƯỚC SAI LỆCH ĐỊNH VỊ
> 
> **Từ ngày 27/05/2026**
> 
> Bác Tài sẽ được hỗ trợ cước phí khi phải di chuyển thêm do điểm giao hàng trên ứng dụng bị sai lệch so với điểm giao hàng thực tế.
> 
> | | |
> |---|---|
> | **Đối tượng và phạm vi áp dụng** | Bác Tài Xanh Bike, Bike Platform, Bike thuê xe sở hữu (RTO) |
> | | Đơn hàng áp dụng: Tất cả đơn **Express** doanh nghiệp 1H, 2H (Shopee, Long Châu, Capichi, Jollibee,...) |
> | **Mức hỗ trợ** | Sai lệch **trên 1km**: hỗ trợ **5.000đ/km**, tối đa **15.000đ/ đơn** |
> | | Sai lệch **dưới 1km**: **KHÔNG HỖ TRỢ** |
> | **Công thức** | Số tiền hỗ trợ = X (km) x 5.000đ |
> | | Trong đó X (km) là khoảng cách thực tế Bác Tài phải di chuyển thêm, tính từ điểm giao trên app đến điểm giao thực tế |

Chúc các Bác Tài Xanh một tháng mới nhiều năng lượng, nhận thật nhiều cuốc tốt, tối ưu hiệu quả vận doanh và gia tăng thu nhập cùng Green SM!
