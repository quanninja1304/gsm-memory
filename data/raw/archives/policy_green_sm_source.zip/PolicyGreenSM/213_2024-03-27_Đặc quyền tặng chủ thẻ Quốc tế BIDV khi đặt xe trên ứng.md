# Đặc quyền tặng chủ thẻ Quốc tế BIDV khi đặt xe trên ứng dụng Green SM

- **Ngày đăng:** 2024-03-27
- **Chuyên mục:** Ưu đãi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/dac-quyen-tang-chu-the-quoc-te-bidv-khi-dat-xe-tren-ung-dung-xanh-sm](https://www.greensm.com/vn-vi/news/dac-quyen-tang-chu-the-quoc-te-bidv-khi-dat-xe-tren-ung-dung-xanh-sm)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Cùng thẻ Quốc tế BIDV mở ra những đặc quyền ưu đãi, trải nghiệm những hành trình Xanh bằng xe thuần điện không tiếng ồn, không phát thải.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2024/04/25d296dc-2403_bidv-website-1024x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> ## ĐI XANH SM TIẾT KIỆM VỚI THẺ QUỐC TẾ BIDV
> ### GIẢM TỚI 50% TRÊN APP XANH SM
> 
> **Văn bản phụ trên hình ảnh:**
> *   BIDV
> *   50%
> *   17:17
> *   Chào Bạn mới,
> *   BIDV
> *   \*\*\*\* \*\*\*\* \*\*\*\* 5177
> *   hàng, thẻ doanh nghiệp sai chuyển đi
> *   \*\*\*\* \*\*\*\* \*\*\*\* 5177
> *   MASTERCARD
> *   \*\*\*\* \*\*\*\* \*\*\*\* 3487
> 
> **Số liệu:**
> *   50%
> *   17:17
> *   5177
> *   3487

1. Đi xe Xanh ưu đãi nửa giá:

- Ưu đãi 50% (lên tới 50.000 VNĐ) áp dụng cho dịch vụ Green SM Taxi và Green SM Luxury;

- Ưu đãi 50% (lên tới 30.000 VNĐ) áp dụng cho dịch vụ Green SM Bike và Xanh Express.

2. Ưu đãi không giới hạn đặt xe Xanh:

- Giảm 15% cho Green SM Luxury và Green SM Taxi;

- Giảm 8% cho dịch vụ Xanh Express.

Điều kiện, điều khoản áp dụng:

- Tặng 90 mã mỗi ngày, áp dụng từ nay đến hết 15/06/2024;

- Áp dụng khi thanh toán bằng thẻ Quốc tế BIDV có đầu BIN: 511957, 517453, 517107, 411153, 428695, 515110, 356592, 530515, 476632, 402460.

Hướng dẫn cách thêm phương thức thanh toán với thẻ Quốc tế BIDV:Bước 1:Mở ứng dụng Green SM > vào mục Tài khoản > Thanh toán;Bước 2:Chọn Thêm phương thức thanh toán;Bước 3:Nhập thông tin Thẻ tín dụng Quốc tế BIDV và làm theo các bước hướng dẫn của ngân hàng;*Lưu ý: Tài khoản của bạn sẽ bị trừ 1.000 VNĐ cho lần đầu tiên thêm thẻ. Số tiền này sẽ được hoàn trả lại vào tài khoản sau khi bạn thêm thẻ thành công;Bước 4:Tiến hành gọi xe và lựa chọn Phương thức thanh toán bằng thẻ Quốc tế BIDV.

Để được tư vấn chi tiết hoặc hỗ trợ, vui lòng liên hệ:• Hotline CSKH: 1900 2097• Email: cskh@xanhsm.com
