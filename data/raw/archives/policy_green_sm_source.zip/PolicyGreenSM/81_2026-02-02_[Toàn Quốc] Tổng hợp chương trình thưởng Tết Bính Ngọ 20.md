# [Toàn Quốc] Tổng hợp chương trình thưởng Tết Bính Ngọ 2026

- **Ngày đăng:** 2026-02-02
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-tet-binh-ngo-txtx-toan-quoc](https://www.greensm.com/vn-vi/news/thuong-tet-binh-ngo-txtx-toan-quoc)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

![Thưởng Tết Nguyên Đán Bính Ngọ](https://cdn.xanhsm.com/2026/02/0646cc75-260131_taxivan-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # MÃ ĐÁO KHAI XUÂN
> 
> # Chương trình Thưởng Tết 2026
> 
> VXANH SM
> ```

Bác Tài Xanh thân mến,

Green SM kính chúc Quý Bác Tài và gia đình một mùa Tết Bính Ngọ tràn đầy sức khỏe, bình an và lộc xuân như ý.

Bước vào hành trình mới, Green SM mang đến không khí Tết rộn ràng cùng nhiều chính sách thưởng hấp dẫn dành riêng cho đội ngũ tài xế – những người đã miệt mài đồng hành trong suốt năm qua.

Năm 2026, ngoài lương tháng 13 và quà Tết truyền thống, Green SM triển khai thêm loạt chương trình thưởng giúp Bác Tài vận doanh vững vàng và đón lộc đầy tay trong suốt mùa Tết. Hãy cùng khám phá các chương trình chi tiết ngay bên dưới.

1. Chính sách tặng “Quà Tết Âm Lịch”

Green SM kính chúc Quý Bác Tài và gia đình một mùa Tết Bính Ngọ tràn đầy sức khỏe, bình an và lộc xuân như ý.Bước vào hành trình mới, Green SM mang đến không khí Tết rộn ràng cùng nhiều chính sách thưởng hấp dẫn dành riêng cho đội ngũ tài xế – những người đã miệt mài đồng hành trong suốt năm qua.

| Đối tượng áp dụng | Nhóm 1 | Nhóm 2 |
| --- | --- | --- |
| Bác Tài Xanh gia nhập Green SM trước ngày 01/10/25 và đã ký Hợp đồng lao động chính thức | Bác Tài Xanh gia nhập Green SM từ ngày 01/10/2025 tới 05/02/2026 |
| Giá trị quà Tết | Quà Tết mức 2.000.000đ/Bác Tài Xanh | Quà Tết mức 300.000đ/Bác Tài Xanh |
| Khu vực áp dụng | Toàn quốc |
| Thời gian trao tặng | Dự kiến 10/02/2026 |

2. Chương trình “Chuyến Xe Đoàn Viên“

| TẶNG 3.000 CHUYẾN XE KHỨ HỒI TRỊ GIÁ 1.000.000Đ |
| --- |
| Điều kiện áp dụng | Áp dụng đồng thời:1. Chọn lọc 3.000 Bác Tài Xanh có doanh số xếp hạng cao nhất trong chiến dịch thi đua từ ngày 01/02/2026 – 14/02/2026, với doanh số tối thiểu như sau• Đối với khu vực Hà Nội & Tp. Hồ Chí Minh: từ 25.000.000đ/ giai đoạn thi đua• Đối với khu vực tỉnh/thành phố còn lại: từ 18.000.000đ/ giai đoạn thi đua2. Bác Tài Xanh có đăng ký và vận doanh tối thiểu 03 ngày trong giai đoạn từ 16/02/2026 (29 ÂL) đến 20/02/2026 (Mùng 4 Tết)3. Số lượng phân bổ:• Hà Nội và Tp. Hồ Chí Minh: 2.200 suất• Các tỉnh còn lại: 800 suất |
| Đối tượng áp dụng | Bác Tài Xanh Taxi hoạt động trên toàn quốc |

3. Chương trình “Lì xì may mắn”

Lì xì luôn là biểu tượng của lộc đầu năm, mang theo lời chúc may mắn để cả năm hanh thông. Hòa trong không khí rộn ràng của Tết Bính Ngọ 2026, bên cạnh hàng loạt chương trình thưởng hấp dẫn, Green SM dành tặng các Bác Tài “cơn mưa lộc xuân” từ chương trình Lì Xì May Mắn. Thông tin chi tiết như sau:

| LÌ XÌ MAY MẮN LỘC XUÂN TRỊ GIÁ 200.000Đ |
| --- |
| Đối tượng áp dụng | Bác Tài Xanh Taxi hoạt động trên toàn quốc |
| Thời gian trao tặng Lì Xì | Mùng 01 Tết Bính Ngọ (Tức 17/02) |
| Điều kiện áp dụng | – Bác Tài Xanh Taxi đã đăng ký và tham gia vận doanh từ Mùng 1 (17/2) đến Mùng 3 Tết (19/2)– Và đảm bảo tổng doanh thu phát sinh trong 03 ngày trên đạt từ 3.000.000đ |

Lưu ý: Trong trường hợp Bác Tài Xanh Taxi không đạt chỉ tiêu nêu trên, Lì Xì May Mắn Lộc Xuân sẽ được thu hồi vào kỳ chi trả lương/thưởng tiếp theo.

4. Chương trình “Thưởng chuyến Xanh Liên Tỉnh”

| THƯỞNG TOUR 150% & THƯỞNG SỐ KHÁCH 350%<So với ngày thường> |
| --- |
| Đối tượng áp dụng | Toàn bộ Bác Tài Xanh Taxi chạy dịch vụ Xanh Liên Tỉnh |
| Thời gian áp dụng | Từ 15/2 (28 ÂL) đến 22/2/2026 (Mùng 6 Tết) |
| Phạm vi áp dụng | Áp dụng với các chuyến xe Xanh Liên Tỉnh |
| Lưu ý khác | Tiền thưởng sẽ được cộng trực tiếp vào Ví Tài xế trước ngày 28/02 |

5. Chương trình “Thưởng chia sẻ doanh số ngày Tết”

| Mức thưởng chia sẻ doanh số (áp dụng nguyên ngày) | Khu vực Hà Nội & Tp. Hồ Chí Minh (Theo địa giới hành chính cũ) | Các tỉnh còn lại |
| --- | --- | --- |
| Áp dụng mức thưởngChia sẻ doanh số theo khung giờ cao điểm | Thưởng thêm 10%Chia sẻ doanh số so với ngày thường |
| Đối tượng áp dụng | Bác Tài Xanh Taxi |
| Thời gian áp dụng | Từ 16/02 (29 ÂL) tới 20/02 (Mùng 4 Tết) |
| Dịch vụ áp dụng | Xanh Car, Green Mini, Xanh Premium, Xanh Limo và GF VIP |
| Khu vực áp dụng | Toàn quốc |
| Điều kiện đạt thưởng | Tỷ lệ nhận chuyến và tỷ lệ hoàn thành chuyến theo ngày đạttừ 85%trở lên. |

6. Chương trình hỗ trợ Bác Tài Xanh mang phương tiện về địa phương vận doanh ngày Tết

| Bác Tài Xanh được sử dụng xe miễn phí để di chuyển 02 chiềuVề địa phương đã đăng ký hoạt động trong dịp Tết |
| --- |
| Đối tượng áp dụng | Bác Tài Xanh Taxi hoạt động trên toàn quốc |
| Thời gian áp dụng | Từ 16/2 (29 ÂL) đến 20/2/2026 (Mùng 4 Tết) |
| Điều kiện áp dụng | – Bác Tài Xanh Taxi cam kết vận doanh tối thiểu 3/5 ngày Tết– Cần đạt điều kiện về mức khoán công việc tối thiểu/ngày cho TXTX vào ngày lễ tại Chính sách Thu nhập cho TXTX |
| Lưu ý khác | – Phạm vi di chuyển không vượt quá 250km/chiều, bao gồm 01 chiều đi và 01 chiều về.Chỉ được di chuyển 02 chiều về địa phương cùng người thân, không được phép di chuyển với mục đích kinh doanh.– Trong trường hợp Bác Tài Xanh Taxi không đạt các điều kiện nêu trên, việc thu phí theo mức sẽ được áp dụng dựa trên chính sách do Green SM ban hành. |

Cảm ơn tất cả các Bác Tài Xanh đã đồng hành và phát triển cùng Green SM trong năm 2025. Mến chúc Bác Tài Xanh và gia đình một năm mới sung túc, bình an, sức khỏe dồi dào và vạn sự như ý!

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
