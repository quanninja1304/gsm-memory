# [Cập nhật mới] Điều chỉnh chính sách thu nhập của dịch vụ Green SM Mini

- **Ngày đăng:** 2026-04-16
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-moi-dieu-chinh-chinh-sach-thu-nhap-cua-dich-vu-green-sm-mini-042026](https://www.greensm.com/vn-vi/news/cap-nhat-moi-dieu-chinh-chinh-sach-thu-nhap-cua-dich-vu-green-sm-mini-042026)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm mở rộng cơ hội bứt phá vận doanh và thu nhập mỗi ngày cho Bác Tài Xanh Green SM Mini, chính sách thu nhập của dịch vụ sẽ có những điều chỉnh mới, áp dụng từ 20/04/2026.

Với điều chỉnh mới, Bác Tài Xanh hãy tận dụng tối đa chính sách thu nhập, kết hợp với một kế hoạch vận doanh phù hợp để đạt thu nhập tương xứng nhé! Khám phá ngay sau đây:

THÔNG TIN CHUNG:

- Đối tượng áp dụng:Bác Tài Xanh đang hoạt động dịch vụ Green SM Mini

- Thời gian áp dụng:Kể từ 20/04/2026 tới khi có thông báo mới nhất

- Khu vực áp dụng:Các khu vực đang khai thác dịch vụ Green SM Mini

CHI TIẾT ĐIỀU CHỈNH:

A. Tỷ lệ thưởng trách nhiệm doanh số:

Tăng tỷ lệ thưởng trách nhiệm doanh số lên tới 51% tại các khu vực khai thác dịch vụ Green SM mini

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/04/4bc7c56d-260415_bangsolieu-01-1024x900.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Tỷ lệ thưởng doanh số/ngày
> 
> ## Khu vực Hà Nội/ TP. Hồ Chí Minh (theo địa giới hành chính cũ)
> 
> | Mức | Doanh số/ngày             | Tỷ lệ thưởng Chuyến xe thường | Tỷ lệ thưởng Chuyến xe hoàn thành trong khung giờ cao điểm (*) |
> |-----|---------------------------|------------------------------|---------------------------------------------------------------|
> | Mức 0 | Dưới 700,000₫             | 25%                          | 28%                                                           |
> | Mức 1 | Từ 700,000₫ đến 900,000₫ | 30%                          | 35%                                                           |
> | Mức 2 | Từ 900,000₫ đến 1,100,000₫| 34%                          | 39%                                                           |
> | Mức 3 | Từ 1,100,000₫ đến 1,300,000₫| 38%                          | 44%                                                           |
> | Mức 4 | Từ 1,300,000₫ đến 1,500,000₫| 42%                          | 47%                                                           |
> | Mức 5 | Từ 1,500,000đ trở lên     | 46%                          | 51%                                                           |
> 
> ## Các tỉnh/thành phố còn lại
> 
> | Mức | Doanh số/ngày             | Tỷ lệ thưởng |
> |-----|---------------------------|--------------|
> | Mức 0 | Dưới 600,000₫             | 25%          |
> | Mức 1 | Từ 600,000₫ đến 800,000₫ | 30%          |
> | Mức 2 | Từ 800,000₫ đến 1,000,000₫| 34%          |
> | Mức 3 | Từ 1,000,000₫ đến 1,200,000₫| 38%          |
> | Mức 4 | Từ 1,200,000₫ đến 1,400,000₫| 42%          |
> | Mức 5 | Từ 1,400,000đ trở lên     | 46%          |
> 
> ## (*) Khung giờ cao điểm được xác định cụ thể như sau:
> 
> | Tỉnh/ thành phố                           | Từ thứ 2 đến thứ 6 | Thứ 7, chủ nhật  |
> |-------------------------------------------|--------------------|------------------|
> | Hà Nội, Tp. Hồ Chí Minh (Theo địa giới hành chính cũ) | 06:00 - 08:59 <br> 16:00 - 21:59 | 09:00 - 11:59 <br> 17:00 - 23:59 |

B. Chính sách “Thưởng vận doanh tuần” & “Đảm bảo thu nhập”:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/04/39d9c1c0-260420_bang-900x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Chính sách "Thưởng vận doanh tuần"
> 
> **Mức thưởng vận doanh tuần:** 550,000đ/tuần
> 
> | Tiêu chí | Điều kiện |
> |---|---|
> | Tỷ lệ nhận chuyến trung bình/tuần | ≥ 85% |
> | Tỷ lệ hoàn thành chuyến trung bình/tuần | ≥ 85% |
> | Hoàn thành tối thiểu | 50 chuyến xe/tuần |
> 
> **Lưu ý:**
> * Tiền thưởng sẽ được chuyển vào Ví Tài xế trong tuần T+1 khi đạt điều kiện thưởng
> * Thời gian tính thưởng tuần được tính từ 0h00 thứ hai tới 23h59 chủ nhật hằng tuần
> 
> # Chính sách "Đảm bảo thu nhập"
> 
> **Mức Đảm bảo thu nhập:** 600,000đ/ngày
> 
> **Thời gian áp dụng:** Trong 03 tháng đầu kể từ ngày Bác Tài Xanh hoạt động dịch vụ Green SM Mini
> 
> ## Điều kiện áp dụng chung
> 
> | Tiêu chí | Điều kiện |
> |---|---|
> | Tỷ lệ nhận chuyến tối thiểu | từ 90% |
> | Tỷ lệ hoàn thành chuyến tối thiểu | từ 90% |
> | Đảm bảo | 100% tuân thủ lệnh phân ca của Đội xe |
> | Thời gian online | ≥ 08 tiếng/ngày |
> | Trung bình doanh số các chuyến xe trong ngày | đạt từ 40,000đ trở lên |
> 
> ## Điều kiện áp dụng riêng
> 
> | Khu vực | Điều kiện |
> |---|---|
> | **Đối với Hà Nội & Tp. Hồ Chí Minh** (theo địa giới hành chính cũ) | Hoàn thành tối thiểu từ 08 chuyến/ngày |
> | **Đối với các tỉnh/thành phố còn lại** | Hoàn thành tối thiểu từ 06 chuyến/ngày |

Để tận dụng cơ hội gia tăng thu nhập, Green SM khuyến khích Bác Tài Xanh:

- Tăng cường vận doanh bằng cách: bắt đầu ca vận doanh từ sớm (đặc biệt trong các khung giờ cao điểm) tại các khu vực có nhu cầu cao (trung tâm thành phố, trung tâm thương mại, tòa nhà văn phòng…) để sớm đạt mốc chuyến xe yêu cầu, từ đó khai thác tối đa cơ hội từ chương trình thưởng.

- Nhận và hoàn thành tất cả chuyến xe được phân bổ để đảm bảo đạt điều kiện và tối đa việc nhận thưởng từ chương trình.

- Lan tỏa và chia sẻ thông tin chương trình thưởng tới các Bác Tài Xanh khác trong cộng đồng.

Mọi thắc mắc về chính sách, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
