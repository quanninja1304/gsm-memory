# Chính sách thu nhập và thưởng trách nhiệm doanh số Tài xế Xanh Premium tại Khánh Hòa 1, 2; Huế 1; Quảng Trị 2; Đà Nẵng 2

- **Ngày đăng:** 2025-10-04
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-premium-khanhhoa-hue-quangtri2-danang2](https://www.greensm.com/vn-vi/news/chinh-sach-thu-nhap-xanh-premium-khanhhoa-hue-quangtri2-danang2)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Với mục đích hỗ trợ Bác tài quản lý thu nhập một cách minh bạch và chủ động hơn, Green SM xin thông báo về việc cập nhậtChính sách thu nhập với tỷ lệ chia sẻ doanh số và tiêu chuẩn chấmcôngmới.

👉 Thời gian áp dụng:Từ 04/10/2025cho đến khi có thông báo mới

👉 Chi tiết chính sách: Bác tài vui lòng xem trong hình ảnh đính kèm.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/10/f00ee003-xanh-pre_kh12_hue1_qt2_dnang2-591x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # CẬP NHẬT CHÍNH SÁCH THU NHẬP VÀ THƯỞNG TRÁCH NHIỆM DOANH SỐ
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Depot Khánh Hòa 1, 2; Huế 1; Quảng Trị 2; Đà Nẵng 2
> **Thời gian áp dụng:** Từ ngày 04/10/2025 đến khi có thông báo mới
> 
> ## Nội dung chính sách
> Cập nhật mức thưởng trách nhiệm doanh số và tiêu chuẩn chấm công
> 
> ## THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ
> **Xanh SM Premium**
> 
> | Mức   | Doanh số (VNĐ/ngày)           | Tỷ lệ chia sẻ |
> | :---- | :---------------------------- | :------------ |
> | Mức 0 | Dưới 700.000                  | 26%           |
> | Mức 1 | Từ 700.000 đến dưới 950.000    | 33%           |
> | Mức 2 | Từ 950.000 đến dưới 1.200.000  | 38%           |
> | Mức 3 | Từ 1.200.000 đến dưới 1.450.000 | 43%           |
> | Mức 4 | Từ 1.450.000 đến dưới 1.700.000 | 46%           |
> | Mức 5 | Từ 1.700.000 trở lên          | 49%           |
> 
> ## TIÊU CHUẨN CHẤM CÔNG
> **Xanh SM Premium**
> 
> | Tháng áp dụng | Khu vực áp dụng (Depot/HUB) | Tiêu chí            | Từ T2 - T5 | Từ T6 - CN, ngày Lễ, Tết | Từ T2 - CN, ngày Lễ, Tết |
> | :------------ | :-------------------------- | :------------------ | :--------- | :----------------------- | :----------------------- |
> |               |                             | Tỷ lệ nhận cuốc     | 85%        | 80%                      | 80%                      |
> |               |                             | Tỷ lệ hoàn thành cuốc | 85%        | 85%                      | 85%                      |
> | 4,5,6,7,8     | Khánh Hòa 1, 2             |                     | Từ 600.000 | Từ 700.000               | Từ 1.000.000             |
> | 3, 9, 10, 11, 12 |                           |                     | Từ 540.000 | Từ 630.000               | Từ 900.000               |
> | 4, 5, 6, 7, 8, 12 | Huế 1                     |                     | Từ 600.000 | Từ 700.000               | Từ 1.000.000             |
> | 3, 9, 10, 11  |                           | Doanh số (VNĐ/ngày) | Từ 540.000 | Từ 630.000               | Từ 900.000               |
> | 5, 6, 7, 8, 12 | Quảng Trị 2                |                     | Từ 500.000 | Từ 600.000               | Từ 1.000.000             |
> | 3, 4, 9, 10, 11 |                           |                     | Từ 450.000 | Từ 540.000               | Từ 900.000               |
> | 3, 5, 6, 7, 8, 9, 12 | Đà Nẵng 2                 |                     | Từ 600.000 | Từ 600.000               | Từ 1.000.000             |
> | 4, 10, 11     |                           |                     | Từ 540.000 | Từ 540.000               | Từ 900.000               |

Mọi thắc mắc Bác tài vui lòng liên hệ Đội xe để được hỗ trợ.

Trân trọng,Đội ngũ Green SM.
