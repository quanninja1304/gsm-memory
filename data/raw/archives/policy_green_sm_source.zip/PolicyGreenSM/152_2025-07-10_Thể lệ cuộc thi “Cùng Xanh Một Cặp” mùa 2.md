# Thể lệ cuộc thi “Cùng Xanh Một Cặp” mùa 2

- **Ngày đăng:** 2025-07-10
- **Chuyên mục:** Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cung-xanh-mot-cap](https://www.greensm.com/vn-vi/news/cung-xanh-mot-cap)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Nhằm tạo nên một sân chơi thi đua sôi nổi, gắn kết và tiếp thêm động lực tăng trưởng doanh thu trong mùa hè vận doanh đầy sôi động, Green SM chính thức khởi động chương trình “CÙNG XANH MỘT CẶP” mùa 2.

Chương trình là cơ hội để các Bác Tài Xanh mới cùng Bác Tài Xanh Cao Cấp bắt cặp đồng hành, hỗ trợ nhau trong hành trình vận doanh, cùng chinh phục mục tiêu thu nhập bứt phá trong những tháng hè cao điểm. Với cơ chế thi đua hấp dẫn và những phần thưởng giá trị, “CÙNG XANH MỘT CẶP” không chỉ lan tỏa tinh thần đồng đội mà còn thúc đẩy các Bác Tài nâng cao hiệu suất, gia tăng sự gắn bó cùng đại gia đình Green SM.

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/07/bbe150b6-cung-xanh-mot-cap-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất từ hình ảnh, định dạng theo Markdown:
> 
> ```markdown
> BÁC TÀI
> XANH
> 
> CÙNG XANH
> MỘT CẶP
> mùa 2
> 
> Tổng giải thưởng:
> 200.000.000VNĐ
> 
> Bác tài Xanh Cùng Xanh Một Cặp mùa 2
> #XanhSM
> 
> Bác tài Xanh Cùng Xanh Một Cặp mùa 2
> #XanhSM
> 
> Tham gia ngay
> ```

Chương trình “Cùng Xanh Một Cặp” với giải thưởng lên đến 200 triệu đồng (Nguồn: Green SM)

## 1. Đối tượng mục tiêu

Chương trình dành cho các cặp đôi thi đua bao gồm Bác Tài Xanh Mới và Bác Tài Xanh Cao Cấp, được ghép cặp để cùng tham gia xuyên suốt thời gian diễn ra cuộc thi. Cụ thể:

- Bác Tài Xanh Cao Cấp: Là những Bác Tài đã ký hợp đồng lao động chính thức với Green SM.

- Bác Tài Xanh Mới: Là những Bác Tài bắt đầu chính thức hoạt động tại Green SM từ ngày 30/06/2025 trở đi. Các Bác Tài Xanh Mới sẽ được ghép cặp cùng Bác Tài Cao Cấp theo từng tuần, đảm bảo sự đồng hành và hỗ trợ hiệu quả trong quá trình thi đua.

## 2. Phạm vi tổ chức

Phân theo từng khu vực cụ thể:

- Khu vực 01: Hà Nội

- Khu vực 02: TP. Hồ Chí Minh

- Khu vực 03: Miền Bắc

- Khu vực 04: Miền Trung

- Khu vực 05: Miền Nam

## 3. Hình thức tham gia

Với cách thức tham gia vô cùng đơn giản, đừng bỏ lỡ cơ hội đồng hành và tham gia cũng Green SM trong mùa hè này.

### 3.1. Cách thức tham gia:

- Mỗi cặp đôi Tài xế sẽ tham gia chương trình trong 3 tuần, chia làm 2 giai đoạn:

- Tuần 1: Onboard, ghép cặp và làm quen.

- Tuần 2 & 3: Thi đua chính thức dựa trên doanh thu vận doanh.

- Danh sách đăng ký sẽ được chốt vào Thứ Bảy hằng tuần, và chương trình sẽ bắt đầu vào Chủ Nhật tuần kế tiếp.

### 3.2. Quy định ghép cặp

- Bác Tài Xanh Cao Cấp: Được phép tham gia nhiều đợt, nhưng mỗi đợt chỉ được ghép cặp với 01 Bác Tài Xanh Mới.

- Bác Tài Xanh Mới: Chỉ được tham gia 01 đợt duy nhất trong suốt mùa thi.

- Mỗi Bác Tài (Mới và Cao Cấp) chỉ được tham gia một cặp thi đua tại một thời điểm, không được thi đua song song hay lặp lại trong cùng một giai đoạn.

- Việc ghép cặp do Khối Vận hành Green SM thực hiện, đảm bảo khách quan và phù hợp.

### 3.3. Thời gian tổ chức:

Chương trình diễn ra từ 07/07/2025 đến 16/08/2025, gồm 4 đợt thi đua như sau:

| Đợt | Thời gian ghép đôi | Thời gian thi đua |
| --- | --- | --- |
| Đợt 1 | 06/07 – 12/07 | 13/07 – 26/07 |
| Đợt 2 | 13/07 – 19/07 | 20/07 – 02/08 |
| Đợt 3 | 20/07 – 26/07 | 27/07 – 09/08 |
| Đợt 4 | 27/07 – 02/08 | 03/08 – 16/08 |

## 4. Cơ cấu giải thưởng

- 01 giải chung cuộc toàn quốc tri giá 10.000.000VNĐ

- Chi tiết các giải thưởng mỗi đợt khác như sau:

### Hà Nội

| Giải thưởng | Đơn vị | Số lượng giải thưởng | Giá trị giải thưởng (VNĐ) |
| --- | --- | --- | --- |
| Giải Nhất | Giải | 1 | 3.000.000 |
| Giải Nhì | Giải | 2 | 1.000.000 |
| Giải Ba | Giải | 11 | 500.000 |
| TỔNG – HÀ NỘI | 14 |

### TP. Hồ Chí Minh

| Giải thưởng | Đơn vị | Số lượng giải thưởng | Giá trị giải thưởng (VNĐ) |
| --- | --- | --- | --- |
| Giải Nhất | Giải | 1 | 3.000.000 |
| Giải Nhì | Giải | 3 | 1.000.000 |
| Giải Ba | Giải | 18 | 500.000 |
| TỔNG – TP.HỒ CHÍ MINH | 22 |

### Miền Bắc

| Giải thưởng | Đơn vị | Số lượng giải thưởng | Giá trị giải thưởng (VNĐ) |
| --- | --- | --- | --- |
| Giải Nhất | Giải | 1 | 3.000.000 |
| Giải Nhì | Giải | 1 | 1.000.000 |
| Giải Ba | Giải | 8 | 500.000 |
| TỔNG – MIỀN BẮC | 10 |

### Miền Trung

| Giải thưởng | Đơn vị | Số lượng giải thưởng | Giá trị giải thưởng (VNĐ) |
| --- | --- | --- | --- |
| Giải Nhất | Giải | 1 | 3.000.000 |
| Giải Nhì | Giải | 1 | 1.000.000 |
| Giải Ba | Giải | 6 | 500.000 |
| TỔNG – MIỀN TRUNG | 8 |

### Miền Nam

| Giải thưởng | Đơn vị | Số lượng giải thưởng | Giá trị giải thưởng (VNĐ) |
| --- | --- | --- | --- |
| Giải Nhất | Giải | 1 | 3.000.000 |
| Giải Nhì | Giải | 1 | 1.000.000 |
| Giải Ba | Giải | 6 | 500.000 |
| TỔNG – MIỀN NAM | 8 |

## 5. Cách thức trả thưởng

Các giải thưởng sẽ chia đều cho mỗi Bác Tài Xanh.

Đối với giải Đặc Biệt, Nhất, Nhì. Giải thưởng sẽ được Topup vào ví BTX theo từng giai đoạn theo tỉ lệ:

- 19/09: 50%

- 19/10: 30%

- 19/11: 20%

Đối với giải Ba : sẽ Topup trực tiếp tiền vào ví BTX.

## 6. Điều kiện nhận thưởng

- Đối với khu vực Hà Nội và TP.Hồ Chí Minh: Mỗi Bác Tài Xanh Car đạt tối thiểu 80 cuốc/tuần

- Đối với các khu vực còn lại: Mỗi Bác Tài Xanh Car đạt tối thiểu 70 cuốc/tuần

- Tài xế không vi phạm quy định nội bộ của công ty trong thời gian diễn ra chương trình.

- Quyết định của Green SM là quyết định cuối cùng.

Hãy cùng Green SM lan tỏa tinh thần đồng hành, thi đua tích cực và cùng nhau chinh phục những cột mốc doanh thu rực rỡ trong mùa hè vận doanh đầy sôi động!

- Xem ngay danh sách ghép cặp đợt 1 (06/07 – 26/07) tại đây:Link

- Xem ngay danh sách ghép cặp đợt 2 (13/07 – 02/08) tại đây:Link

- Xem ngay danh sách ghép cặp đợt 3 (20/07 – 09/08) tại đây:Link

- Xem ngay danh sách ghép cặp đợt 4 (27/07 – 16/08) tại đây:Link
