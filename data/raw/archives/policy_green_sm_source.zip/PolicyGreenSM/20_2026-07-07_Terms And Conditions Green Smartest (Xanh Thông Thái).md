# Terms And Conditions Green Smartest (Xanh Thông Thái)

- **Ngày đăng:** 2026-07-07
- **Chuyên mục:** Blog (VN-EN)
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/green-smartest-terms-conditions](https://www.greensm.com/vn-vi/news/green-smartest-terms-conditions)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Không

---

Article 1. Scope and Subjects of Application

1.1. These Terms and Conditions govern participation in the Green Smartest Program organized by Green and Smart Mobility Joint Stock Company (“Green SM”) on the Green SM Application.

1.2. By checking the confirmation box and clicking the “Play Now” button, users confirm their consent to allow Green SM to collect and process their personal data solely for the purpose of operating the Program in accordance with the Program Rules; and concurrently commit to bearing full responsibility for the information provided.

1.3. These Terms and Conditions shall be governed by the laws of Vietnam. Green SM reserves the right to amend or supplement the Terms and Conditions during the Program period and shall notify such changes on the Green SM Application or via other appropriate means prior to application, unless otherwise prescribed by law.

1.4. Officers and employees of Green and Smart Mobility Joint Stock Company (Green SM) are only permitted to participate in the Program for the purpose of experiencing the game, answering questions, and being considered for Titles/Certificates of Merit. However, to ensure fairness, the accounts of these Participants will not be recorded on the Leaderboard by the system, and they shall not be eligible to redeem or receive any rewards under the Program Rules.

1.5. The Program is implemented nationwide for customers eligible to use the Green SM application; certain rewards may be subject to specific geographical scopes as stipulated in Article 8.

Article 2. Subjects and Conditions of Participation

2.1. The Program applies to customers holding valid Green SM accounts who log into the Program, agree to the Terms and Conditions contained within the Program Rules, and satisfy the conditions stipulated by Green SM. In cases where the participant is under 18 years of age, consent from a parent or legal guardian is required. Green SM reserves the right to reject or cancel results if the participant is found to not meet the eligibility conditions.

2.2. Green SM reserves the right to reject, suspend, or cancel the Participant’s right to participate, their results, or their right to receive rewards if it discovers inaccurate information, signs of fraud, the use of multiple accounts, exploitation of system errors, or acts that affect the fairness of the Program.

2.3. A Participant’s participation in the Program shall not automatically give rise to any entitlement to rewards. The right to receive rewards only arises when the Participant fully meets the Program’s conditions and does not violate any provisions of these Rules.

2.4. Green SM reserves the right to require the Participant to provide information or undergo verification when necessary to record results, award prizes, or resolve complaints.

Article 3. Program Timeline

3.1. The Program shall be conducted from 20 July 2026 to 11 October 2026 (inclusive of the gift redemption period). The Program is divided into separate phases, each referred to as a “Semester”, with each Semester lasting for two (02) weeks. The schedule for each Semester is as follows:

- Semester I: from July 20, 2026 to August 02, 2026

- Semester II: from August 03, 2026 to August 16, 2026

- Semester III: from August 17, 2026 to August 30, 2026

- Semester IV: from August 31, 2026 to September 13, 2026

- Semester V: from September 14, 2026 to September 27, 2026

Scores, rankings, and titles of each Semester are recorded independently and shall not be accumulated to the subsequent Semester, unless otherwise notified by Green SM. The Certificate of Merit from the previous Semester may only be redeemed for rewards in the immediately following Semester.3.2. All timelines of the Program are determined based on the recorded data on the Green SM system.

3.3. Green SM reserves the right to adjust the timeline, suspend, terminate, or modify the Program’s content when necessary or upon the request of a competent authority, and shall notify such changes on the Green SM Application in accordance with regulations.

Article 4. Mechanism of Participation

4.1. To participate in the Program, the Participant must log into their Green SM account and provide their Full Name, School, and Class following the system’s instructions for the purpose of participation and program/game operation. The collection, storage, and processing of data are conducted based on the Participant’s consent and other legal grounds (if any) regarding personal data protection. Participants have the right to request access to, correction of, or deletion of their data, or to withdraw their consent at any time (By contacting the Green SM Customer Support Hotline: 1555; or via the Support Center section on the Green SM Application). Green SM will receive and process the Participant’s requests within the time limit prescribed by law.

4.2. The Participant is solely responsible for the accuracy of the provided information. Green SM assumes no liability for unrecorded benefits arising from inaccurate information, violations of fine customs and traditions or Vietnamese law, ineligible accounts, or the Participant’s failure to strictly follow instructions.

4.3. Successful participation in the Program does not guarantee that the Participant’s results will be recorded or that any rewards will be granted. The Participant’s scores, titles, and benefits are determined according to the participation, point accumulation, and reward mechanisms of the Program. Simultaneously, the use of Green SM services is solely to accumulate playing turns in the Program; the receipt of rewards is determined based on the results of participating in the Program under these Rules.

Article 5. Participation and Point Accumulation Mechanism

5.1. Upon providing full information and agreeing to these Terms and Conditions, the Participant shall be granted playing turns according to the following rules:

- Every day, the participant is granted 05 free playing turns after successfully logging into the Program (check-in mission). These turns are non-cumulative, valid only on the day of receipt, and will be reset to 0 at 00:00:00 of the following day.

- Completing eKYC: adds 05 turns (applicable only once during the entire Program).

- Completing any 01 trip/order under Green Car/Premium/Limo/GF-VIP, Green Bike/Bike Plus, Green Food, Green Express services: adds 03 turns per trip or order with a “Completed” status. These playing turns do not expire during the Program Timeline(as detailed in Clause 3.1, Article 3 of these Rules)and may be accumulated for use.

5.2. Each turn is used to answer one (01) question. A correct answer earns 10 points; an incorrect answer earns no points and results in the loss of that turn.

5.3. Scores are automatically recorded by the Green SM system and serve as the basis for determining titles, rankings, and benefits of the Participant in each Semester.

5.4. Green SM reserves the right to refuse the recording of turns, scores, or to adjust results if it detects invalid transactions, fraudulent acts, system errors, or other circumstances affecting the fairness of the Program.

5.5. Results, scores, titles, and rankings of Participants are determined solely based on the number of correct answers and cumulative scores during participation; the Program does not use lucky draws, lotteries, random drawings, or any element of chance to determine winners.

Article 6. Titles and Certificates of Merit

6.1. At the end of each Semester, the Participant is evaluated for a title based on scoring milestones and shall only be awarded the one (01) highest title achieved in each Semester. Title and scoring milestone system:

- School Rookie (Tân Binh Học Đường): from 150 to 700 points

- Quiz Master (Cao Thủ Giải Đố): from 710 to 1,030 points

- Academic Champion (Học Bá Toàn Năng): from 1,040 points and above

6.2. Upon completion of data reconciliation, the Participant will receive an electronic Certificate of Merit corresponding to the achieved title. Result notifications will be sent via the notification channel in the Green SM Application immediately after data reconciliation for each Semester.

6.3. The Certificate of Merit is valid only within the scope of the Program for reward redemption as stipulated in Article 8; it holds no legal value and may not be transferred, sold, exchanged for cash, or used for other purposes.

6.4. Green SM reserves the right to revoke titles or Certificates of Merit if the Participant is found to violate the Terms and Conditions or commit fraudulent acts.

Article 7. Leaderboard and Top 100 Rewards

7.1. In each Semester, the Green SM system automatically records the Participant’s scores and rankings.

7.2. The one hundred (100) Participants with the highest scores in each Semester will receive the Top 100 reward as stipulated in Article 8.5.

7.3. In the event of a tie in points, the ranking shall be determined based on Green SM system data (based on the total time answering questions or the earliest time the score was achieved).

7.4. The Top 100 reward is credited directly to the eligible Participant’s account and cannot be exchanged for cash or transferred.

7.5. The right to receive the Top 100 reward is independent of the right to redeem rewards via the Certificate of Merit.

Article 8. Reward Structure and Redemption Mechanism

8.1. Participants who achieve a title may use their electronic Certificate of Merit to redeem rewards according to the following mechanism:

Academic Champion (choose maximum 01 out of 03 rewards): 01-month Green Bike Membership Package; or 25% off Green SM Bike/Green SM Bike Plus Voucher, up to VND 15,000; or 25% off Green SM Bike/Green SM Bike Plus Voucher, up to VND 10,000.

Quiz Master (choose maximum 01 out of 02 rewards): 25% off Green SM Bike/Green SM Bike Plus Voucher, up to VND 15,000; or 25% off Green SM Bike/Green SM Bike Plus Voucher, up to VND 10,000.

School Rookie: 25% off Green SM Bike/Green SM Bike Plus Voucher, up to VND 10,000.

8.2. In each Semester, each Certificate of Merit may only be redeemed for one (01) reward corresponding to the achieved title. Redemption period:

- Semester I Certificate: redemption from August 03, 2026 to August 16, 2026

- Semester II Certificate: redemption from August 17, 2026 to August 30, 2026

- Semester III Certificate: redemption from August 31, 2026 to September 13, 2026

- Semester IV Certificate: redemption from September 14, 2026 to September 27, 2026

- Semester V Certificate: redemption from September 28, 2026 to October 11, 2026

8.3. For rewards redeemed from electronic Certificates of Merit, customers must redeem rewards through the Green SM Application on a “First Come – First Served” basis until the reward quantity of each type is depleted in each Semester or the redemption period expires, whichever comes first. Upon successful redemption, the system automatically sends the reward to the customer’s account. Each electronic Certificate of Merit may only be used to redeem a reward one (01) time and cannot be exchanged for cash or transferred in any form. After the redemption period expires or the rewards for each Semester are fully distributed, unused electronic Certificates of Merit will automatically become invalid, all unexercised redemption rights will terminate, and Green SM assumes no responsibility for extending, reissuing, or converting them into other forms.

8.4. Rewards may not be exchanged for cash, transferred, or refunded. The use of Vouchers, membership packages, or other promotional offers following successful redemption is subject to the applicable conditions of each reward type as follows:

- 01-month Green Bike Subscription Package: valid only in Hanoi City and Ho Chi Minh City.

- 25% off Green SM Bike/Green SM Bike Plus Voucher (up to VND 15,000 and up to VND 10,000): valid in Hanoi, Ho Chi Minh, Da Nang, Quang Nam, Ba Ria – Vung Tau, Khanh Hoa, Quang Ninh, Thua Thien Hue, Hai Phong, Dong Nai, Binh Duong, Nghe An, Bac Ninh, Long An, Thanh Hoa, Tay Ninh, Thai Nguyen, Can Tho, Hung Yen, Ha Tinh, Ninh Binh, Binh Dinh, Binh Thuan, Nha Trang, Dak Lak, Gia Lai.

8.5. Top 100 Reward: The Top 100 Participants with the highest scores in each Semester will receive a reward valued at VND 50,000, credited directly to the Participant’s E-Green Card within 45 days from the end of the respective Semester. Players will be notified of the reward allocation via the notification channel on the Green SM Application.

8.6. Green SM reserves the right to replace rewards with items of equivalent value or to adjust the redemption mechanism when necessary and shall provide notification in accordance with regulations, provided that such changes do not adversely affect the rights and benefits of customers who participated in the Program prior to such amendment.

8.7 Reward Quantity:

| Prize Structure | Reward | Number of prizes in 01 semester | Total number of prizes across 05 semesters |
| --- | --- | --- | --- |
| Top 100 Reward | Reward credited directly to E-Green Card: VND 50,000 | 100 | 500 |
| Redemption Reward 1 | 01-month Green Bike Subscription Package | 25.000 | 125.000 |
| Redemption Reward 2 | 25% off Green SM Bike/Bike Plus Voucher (up to VND 15,000) | 50.000 | 250.000 |
| Redemption Reward 3 | 25% off Green SM Bike/Bike Plus Voucher (up to VND 10,000) | 10.000 | 50.000 |
| Total: |  | 85.100 | 425.500 |

Article 9. Collection and Processing of Personal Data

9.1. Green SM collects and processes the Participant’s personal data, including Full Name, School, and Class (mentioned in section 4.1), to operate the Program, record and display results, award prizes, resolve complaints, prevent fraud, and fulfill obligations as prescribed by law. Green SM retains personal data during the Program period and for the necessary duration to resolve complaints, fulfill legal obligations, or comply with legal provisions; subsequently, the data will be deleted or anonymized, unless the law requires longer retention.

9.2. The processing of personal data is conducted based on the Participant’s consent and other legal grounds (if any), these Terms and Conditions, and Green SM’s Personal Data Protection Policy (available at:https://www.greensm.com/vn-vi/terms-policies/privacy-notice).

9.3. The Participant holds rights regarding personal data as prescribed by law. In the event the Participant withdraws consent or requests data deletion, causing Green SM to lose the legal basis or technical capability to continue operating the Program, Green SM may terminate participation or be unable to continue providing the benefits arising from the Program.

Article 10. Sharing of Program Information

10.1. The Participant may voluntarily share their titles, Certificates of Merit, leaderboard rankings, or achievements through features provided by Green SM.

10.2. Such sharing is entirely voluntary. The Participant assumes sole responsibility for content made public on third-party platforms; Green SM assumes no responsibility for disputes arising from such sharing.

Article 11. Prohibited Acts and Handling of Violations

11.1. The Participant is strictly prohibited from engaging in fraud, falsifying information, using multiple accounts, exploiting system errors, using automated tools, scripts, bots, or other means to interfere with the Program, transferring benefits, or committing any acts that affect the fairness and normal operation of the Program.

11.2. Upon detecting violations, Green SM reserves the right to refuse to record results; revoke playing turns, scores, titles, Certificates of Merit, or rewards; suspend or terminate the right to participate in the Program; and apply necessary measures in accordance with the law.

11.3. Data recorded on the Green SM system shall serve as the basis for verifying and handling violations, as well as resolving disputes.

Article 12. Rights and Responsibilities of Green SM

12.1. Green SM is responsible for organizing the Program, recording results, awarding prizes in accordance with these Terms and Conditions, and protecting the Participant’s personal data as prescribed by law.

12.2. Green SM reserves the right to verify information, rectify system errors, replace rewards with items of equivalent value, amend the Terms and Conditions, or adjust the Program when necessary, and shall provide notification in accordance with regulations.

12.3. Green SM assumes no liability for unrecorded benefits arising from acts or omissions of the Participant, devices, networks, force majeure events, or causes beyond Green SM’s reasonable control.

Article 13. Complaints and Program Termination

13.1. The Participant has the right to submit complaints related to the Program to Green SM via the Customer Support Hotline 1555 or the Support Center channel on the Green SM Application within a period of 30 (thirty) days from the date the complained incident occurs. Beyond the aforementioned period, Green SM reserves the right to refuse to receive the complaint, unless otherwise prescribed by law.

13.2. Green SM shall base its resolution of complaints on system data and related information. Data recorded on the Green SM system shall constitute the primary basis for consideration to the extent permitted by law. The maximum time limit for resolving complaints is 30 (thirty) working days from the date of receiving complete information and related documents; in complex cases, this time limit may be extended but shall not exceed an additional 30 (thirty) working days, and Green SM will notify the Participant.

13.3. Green SM reserves the right to suspend or terminate the Program upon the request of a competent authority, in the event of force majeure, or when necessary to ensure the Program’s operation, and shall provide notification in accordance with regulations.

Article 14. General Provisions

14.1. These Terms and Conditions shall take effect from the time the Program is launched on the Green SM Application.

14.2. Green SM reserves the right to amend or supplement these Terms and Conditions to comply with legal regulations or operational requirements, and shall provide prior notification before application, unless otherwise prescribed by law.

14.3. If one or several provisions become invalid or unenforceable, the remaining provisions shall remain in full force and effect.

14.4. These Terms and Conditions are drafted in Vietnamese. Any matters not covered by these Terms and Conditions shall be governed by Vietnamese law and Green SM’s Conditions of Use and Personal Data Protection Policy at the following links:https://www.greensm.com/vn-vi/terms-policies/generalandhttps://www.greensm.com/vn-vi/terms-policies/privacy-notice.

Article 15. Contact Information

For any inquiries, feedback, or complaints related to the Program, Participants may contact:

- Organizing Entity: Green and Smart Mobility Joint Stock Company (Green SM)

- Customer Support Hotline: 1555

- Support Channel: Support Center section on the Green SM Application
