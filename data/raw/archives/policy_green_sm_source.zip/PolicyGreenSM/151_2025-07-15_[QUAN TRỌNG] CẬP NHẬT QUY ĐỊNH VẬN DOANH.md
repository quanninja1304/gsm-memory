# [QUAN TRỌNG] CẬP NHẬT QUY ĐỊNH VẬN DOANH

- **Ngày đăng:** 2025-07-15
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-quy-dinh-van-doanh](https://www.greensm.com/vn-vi/news/cap-nhat-quy-dinh-van-doanh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Đối tác Tài xế thân mến,

Việc duy trì hoạt động đều đặn mỗi ngày không chỉ giúp Đối tác Tài xế tối ưu thu nhập cá nhân, mà còn góp phần lan tỏa giá trị Xanh đến cộng đồng. Với mong muốn thúc đẩy tinh thần vận doanh, góp thêm nhiều chuyến xe Xanh cho môi trường, Green SM xin thông báo nội dung cập nhật về quy định vận doanh như sau:

- Đối tượng áp dụng: Đối tác Tài xế Green SM Bike

- Thời gian áp dụng:Từ ngày 15/07/2025

Nội dung chi tiết:

1. Trường hợp Đối tác Tài xế có tỷ lệ chấp nhận chuyến dưới 50%: Hệ thống sẽ mặc định bật tính năng “Nhận chuyến tự động” tới 23h59 của ngày vận doanh đó.

2. Trường hợp Đối tác Tài xế có tỷ lệ hoàn thành chuyến và/hoặc tỷ lệ chấp nhận chuyến <70% sẽ bị xử phạt như sau:

- Đối với tệp tài xế đạt trung bình 5 đơn/ngày (*) trở lên: Áp dụng mức phạt 100.000 VNĐ/tuần nếu vi phạm 03 ngày/tuần.

- Đối với tệp tài xế đạt trung bình dưới 5 đơn/ngày (*): Áp dụng mức phạt 200.000 VNĐ/tuần nếu vi phạm 03 ngày/tuần. Trường hợp vi phạm 03 lần (tuần) liên tiếp, Công ty sẽ tiến hành khóa tài khoản & thu hồi xe.

Lưu ý:

- Số đơn trung bình được tính trên ngày vận doanh/tuần

- Hình thức thu phạt: Trừ ví tài xế (thứ 3 hàng tuần)

(*) Số đơn trung bình được tính trên ngày vận doanh/tuần

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/06/829a9ea4-1507_hinh-anh-chinh-sach-bike-1.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CẬP NHẬT QUY ĐỊNH VẬN DOANH
> 
> **Đối tượng áp dụng:** Đối tác Tài xế Xanh SM Bike
> **Thời gian áp dụng:** Từ ngày 15/07/2025
> **Khu vực áp dụng:** Toàn quốc
> 
> **Nội dung chi tiết**
> 
> | Đối tượng | Tính năng áp dụng |
> |---|---|
> | Trường hợp Đối tác Tài xế có tỷ lệ chấp nhận chuyến dưới 50% | Mặc định bật tính năng "Nhận chuyến tự động" tới 23h59 của ngày vận doanh đó |
> 
> | Mức vi phạm | Đối tượng | Mức xử phạt |
> |---|---|---|
> | Trường hợp Đối tác Tài xế có tỷ lệ chấp nhận chuyến dưới 70% | Tệp tài xế đạt trung bình 5 đơn/ngày trở lên (*) | Trừ ví 100.000 VNĐ/tuần nếu vi phạm 03 ngày/tuần |
> | | Tệp tài xế đạt trung bình dưới 5 đơn/ngày (*) | Trừ ví 200.000 VNĐ/tuần nếu vi phạm 03 ngày/tuần |
> | | | Khóa tài khoản & thu hồi phương tiện nếu vi phạm 3 lần (tuần) liên tiếp |
> 
> **Hình thức thu phạt:** Trừ ví tài xế (thứ 3 hàng tuần)
> **(*)** Số đơn trung bình được tính trên ngày vận doanh/tuần

🎯 Kính mong Đối tác Tài xế chủ động theo dõi tỷ lệ vận hành hằng ngày và duy trì hiệu suất ổn định nhằm đảm bảo quyền lợi, tối ưu thu nhập và thúc đẩy hiệu suất vận doanh cao cùng Green SM.

Trân trọng,

Đội ngũ Green SM Bike.
