# [GREEN SM BIKE] Chính Sách Tết 2026: Linh Hoạt Vận Doanh, Tết Vui An Lành

- **Ngày đăng:** 2026-02-03
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/xanh-sm-bike-chinh-sach-tet-linh-hoat-van-doanh-tet-vui-an-lanh](https://www.greensm.com/vn-vi/news/xanh-sm-bike-chinh-sach-tet-linh-hoat-van-doanh-tet-vui-an-lanh)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh Bike thân mến,

Green SM Bikekính chúc Bác Tài và gia đình một mùa Tết Bính Ngọ tràn đầy sức khỏe, bình an và lộc xuân như ý.

Nhằm hỗ trợ Bác Tài an tâm đón Tết và linh hoạt lựa chọn thời điểm quay lại vận doanh để gia tăng thu nhập đầu năm, Green SM Bike xin gửi đến Bác Tài chính sách vận doanh dịp Tết 2026.

Chi tiết vui lòng tham khảo ảnh bên dưới:

![030226_Chính sách Tết Bike 2026](https://cdn.xanhsm.com/2026/02/47751b57-030226_chinh-sach-tet-bike-2026-1024x690.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH TẾT 2026
> 
> Linh hoạt vận doanh, Tết vui an lành
> 
> | Thời gian | Nội dung chính sách | Phạm vi |
> |---|---|---|
> | **16/02/2026 (29 ÂL)** đến **20/02/2026 (Mùng 4)** | - Không áp dụng khoán doanh số tối thiểu <br> - Không áp dụng thu phí sử dụng xe | Toàn quốc |
> | **14/02/2026 (27 ÂL)** đến **23/02/2026 (Mùng 7)** | - Không áp dụng thu hồi xe nếu 10 ngày liên tiếp không vận doanh, bao gồm 05 ngày Tết | Toàn quốc |

Kính chúc Bác Tài một mùa Tết 2026Bình an – Đủ đầyvà sẽ có thật nhiều chuyến xe đầu năm đầy lộc 🌱

Trân trọng,

Đội ngũ Green SM Bike

GÓC GIẢI ĐÁP

| Câu hỏi | Trả lời |
| --- | --- |
| Tài xế nghỉ ngoài thời gian trên cần cung cấp thông tin qua kênh nào? | Trường hợp có nhu cầu tạm dừng vận doanh dài ngày, Bác Tài vui lòng gửi thông tin tại mục “Đăng ký nghỉ đột xuất” trên Ứng dụng Tài xế. |
| Chính sách này có hiệu lực đến khi nào? | – Chính sách “Không áp dụng doanh số tối thiểu” & “Không thu phí sử dụng xe” áp dụng từ ngày 16/2 – 20/2 (tức 29/12 – 04/01 âm lịch)– Chính sách “Không thu hồi xe nếu 10 ngày liên tiếp không vận doanh” áp dụng từ ngày 14/2 – 23/2 (tức 27/12 – 07/01 âm lịch)Sau thời gian trên, áp dụng theo các chính sách/quy định thông thường. |
| Trường hợp tài xế đã tạm dừng vận doanh 4 ngày/tháng theo quy định, tài xế có được hưởng chính sách vận doanh tết không? | Có. Đối tác Tài xế được hưởng 4 ngày không vận doanh hợp lệ/tháng & quyền lợi theo chính sách vận doanh Tết. |
