# Bộ Quy tắc Ứng xử dành cho nhóm “Đối tác Tài xế sử dụng xe thuê” từ ngày 09/09/2026

- **Ngày đăng:** 2026-09-11
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/bo-quy-tac-ung-xu-danh-cho-nhom-doi-tac-tai-xe-su-dung-xe-thue-tu-ngay-09-09-2026](https://www.greensm.com/vn-vi/news/bo-quy-tac-ung-xu-danh-cho-nhom-doi-tac-tai-xe-su-dung-xe-thue-tu-ngay-09-09-2026)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/09/bf4e97aa-thumb.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Bộ Quy tắc ứng xử dành cho Đối tác Tài xế sử dụng xe thuê(*)
> 
> (*) Áp dụng theo các điều khoản được quy định
> 
> <img src="https://example.com/green_sm_logo.png" alt="GREEN SM Logo" width="100"/>
> ```

Bác Tài Xanh thân mến,

Trong hành trình phát triển và giữ vữngchất lượng dịch vụ 5 Sao, mỗi Bác Tài Xanh chính là một nhân tố quan trọng góp phần xây dựng hình ảnh và uy tín của Green SM trong mắt Khách hàng thông qua những chuyến xe Xanh mỗi ngày.

Nhằm đảm bảo sự đồng bộ trong quy chuẩn vận hành, Green SM chính thức cập nhật Bộ Quy tắc Ứng xử (QTUX) dành cho nhóm“Đối tác Tài xế sử dụng xe thuê” (*). Bộ quy tắc mới được áp dụng từ ngày 09/09/2026, thay thế cho Bộ QTUX hiện hành.

I. NGUYÊN TẮC CHUNG1. TUYÊN NGÔN VĂN HÓA1.1. Tầm nhìn:Đẩy nhanh quá trình chuyển đổi giao thông xanh, bền vững của thế giới.1.2. Sứ mệnh:Tạo ra một giải pháp giao thông xanh, tiện lợi và bền vững.1.3. Giá trị cốt lõi:Công nghệ – Văn minh – Tin cậy.1.4. Văn hoá:Kỷ luật – Chuyên nghiệp – Tận tâm.2. TIÊU CHÍ HỢP TÁC2.1. Công bằng, minh bạch, thượng tôn kỷ luật.2.2. Văn minh, tôn trọng, hợp tác.2.3. Doanh thu chia sẻ cạnh tranh.2.4. Xây dựng và duy trì dịch vụ 05 sao để cung cấp dịch vụ tốt nhất cho Khách hàng.

II. QUY TẮC ỨNG XỬ1. ĐỐI VỚI KHÁCH HÀNG:1.1. Cung cấp dịch vụ chuyên nghiệp cho Khách hàng đảm bảo Tiêu chuẩn dịch vụ Green SM.1.2. Tôn trọng quyền riêng tư và bảo mật thông tin của Khách hàng.1.3. Đảm bảo an toàn tuyệt đối cho Khách hàng (cả về thể chất và tinh thần).2. ĐỐI VỚI BẢN THÂN ĐỐI TÁC TÀI XẾ2.1. Trung thực trong quá trình kinh doanh trên nền tảng Green SM Platform và cung cấp dịch vụ cho Khách hàng.2.2. Thực hiện đúng các quy trình /hướng dẫn thực hiện, Tiêu chuẩn dịch vụ Green SM trong quá trình kinh doanh trên nền tảng Green SM Platform và cung cấp Dịch vụ cho Khách hàng.2.3. Tuyệt đối tuân thủ quy định pháp luật trong quá trình kinh doanh và cung cấp dịch vụ.3. ĐỐI VỚI TÀI KHOẢN ỨNG DỤNG VÀ TÀI SẢN/THIẾT BỊ ĐƯỢC GREEN SM CUNG CẤP3.1. Sử dụng tài khoản ứng dụng đúng mục đích và hướng dẫn/yêu cầu của Green SM.3.2. Bảo quản và giữ gìn các tài sản/thiết bị được Green SM cung cấp theo thỏa thuận với Green SM và quy định pháp luật.III. BIỆN PHÁP XỬ LÝ KHI KHÔNG ĐẢM BẢO QUY TẮC ỨNG XỬ1. Nhóm 1: Các lỗi đặc biệt nghiêm trọng1.1. Nhóm 1a

| STT | Các hành vi không đảm bảo quy tắc ứng xử | Biện pháp xử lý |
| --- | --- | --- |
| 1 | Có hành vi vi phạm pháp luật bao gồm nhưng không giới hạn:– Tàng trữ/vận chuyển, sử dụng ma túy/vũ khí trên xe với bất kỳ mục đích nào.– Sử dụng xe vào mục đích vi phạm pháp luật; chống đối người thi hành công vụ.– Vi phạm pháp luật về an toàn giao thông gây hậu quả nghiêm trọng (tai nạn, va chạm,…).– Không hỗ trợ Khách hàng khi xảy ra tai nạn/sự cố.Thông đồng, bao che hoặc tiếp tay cho hành vi trên. | Chấm dứt tài khoản kinh doanh vĩnh viễn, đồng thời yêu cầu bồi hoàn toàn bộ chi phí bồi thường thiệt hại mà Green SM đã thanh toán thay cho Khách hàng/Bên thứ ba (nếu có) do hành vi của Đối tác Tài xế gây ra. |
| 2 | Tự ý thay thế, đánh tráo pin, linh kiện chính không đúng thiết kế ban đầu của phương tiện hoặc can thiệp vào thiết bị, hệ thống, dữ liệu vận hành của xe dưới bất kỳ hình thức nào nhằm làm sai lệch dữ liệu, che giấu hoặc né tránh việc phát hiện. |
| 3 | Phát ngôn, lan truyền, đăng tải, lôi kéo, kích động đám đông hoặc cung cấp thông tin sai lệch, xuyên tạc, gây ảnh hưởng tiêu cực đến hình ảnh, uy tín, hoạt động của Green SM dưới bất kỳ hình thức nào; hoặc cố ý tiết lộ, sao chép, chuyển giao, phát tán thông tin tài liệu, dữ liệu kinh doanh, bí mật thương mại hoặc tài liệu mật của SM cho bên thứ ba, trực tiếp hoặc gián tiếp, bằng bất kỳ hình thức nào. | Chấm dứt tài khoản kinh doanh vĩnh viễn. |
| 4 | Không thông báo ngay cho Green SM ngay khi xảy ra tai nạn, sự cố liên quan đến phương tiện và/hoặc trốn tránh trách nhiệm, không phối hợp xử lý theo quy định. |
| 5 | Thực hiện các hành vi, nói hoặc nhắn tin/gọi điện xúc phạm, quấy rối Khách hàng; hoặc phân biệt đối xử (về chủng tộc, tôn giáo, quốc tịch, vùng miền, ngoại hình, giới tính, tuổi tác…) hay có thái độ/hành vi không đúng mực với Khách hàng hoặc đối tượng khác khi có sự hiện diện của Khách hàng. | Chấm dứt tài khoản kinh doanh vĩnh viễn và/hoặc giảm doanh thu chia sẻ số tiền 10.000.000 đồng bằng cách trừ Ví, đồng thời yêu cầu bồi hoàn toàn bộ số tiền gian lận hoặc chi phí bồi thường thiệt hại mà Green SM đã thanh toán thay cho Khách hàng/Bên thứ ba do hành vi của Đối tác Tài xế gây ra. Nếu đăng tải thông tin sai sự thật hoặc tiêu cực về Green SM, ngoài các chế tài trên, Đối tác Tài xế phải thực hiện đính chính và xin lỗi Green SM. Nếu có dấu hiệu vi phạm pháp luật, chuyển cơ quan chức năng xử lý. |
| 6 | Tái diễn lần 4 đối với các hành vi thuộc lỗi Nhóm 2. |
| 7 | Thực hiện các hành vi tại mục số (1), lỗi Nhóm 1b khi số tiền trục lợi lớn hơn 500.000 đồng/lần. |

1.2.  Nhóm 1b

| STT | Các hành vi không đảm bảo quy tắc ứng xử | Biện pháp xử lý |
| --- | --- | --- |
| 1 | Gian lận, lợi dụng chính sách phụ phí/chương trình thưởng/khuyến mãi của Green SM với số tiền trục lợi nhỏ hơn 500.000 đồng/lần bao gồm nhưng không giới hạn:– Tạo nhiều tài khoản khách hàng hoặc can thiệp vào hệ thống/ứng dụng SM nhằm trục lợi hoặc gây ảnh hưởng đến hệ thống, chất lượng dịch vụ cung cấp cho Khách hàng/Đối tác/Tài xế.– Phối hợp hoặc thông đồng với người khác để tạo chuyến xe ảo, tách cuốc dài thành nhiều cuốc ngắn, tạo cuốc giả mạo sử dụng hình thức thanh toán không tiền mặt (thẻ, ví điện tử…).– Hủy chuyến nhưng vẫn chở khách; chở khách nhưng không tạo chuyến; cố ý thao tác sai cuốc tour nhằm trục lợi.– Chuyển nhượng, chuyển giao, cho thuê lại phương tiện, cho người khác điều khiển xe, sử dụng trang thiết bị trên xe và/hoặc cho người khác sử dụng tài khoản của mình dưới bất kỳ hình thức nào.– Môi giới, chuyển Khách hàng cho tài xế khác phục vụ hoặc nhận Khách hàng do môi giới từ tài xế khác.– Cố ý không hoàn trả tài sản của Khách hàng, tự mình hoặc phối hợp với người khác yêu cầu Khách hàng trả tiền chuộc để nhận lại tài sản, và/hoặc không cung cấp thông tin trung thực khi SM liên hệ xác minh về tài sản của Khách hàng. | Chấm dứt tài khoản kinh doanh vĩnh viễn và/hoặc giảm doanh thu chia sẻ số tiền 5.000.000 đồng bằng cách trừ Ví, đồng thời yêu cầu bồi hoàn toàn bộ số tiền gian lận hoặc chi phí bồi thường thiệt hại mà Green SM đã thanh toán thay cho Khách hàng/Bên thứ ba do hành vi của Đối tác Tài xế gây ra nếu vi phạm lần 1, số tiền 8.000.000 đồng bằng cách trừ Ví, đồng thời yêu cầu bồi hoàn toàn bộ số tiền gian lận hoặc chi phí bồi thường thiệt hại mà Green SM đã thanh toán thay cho Khách hàng/Bên thứ ba do hành vi của Đối tác Tài xế gây ra.Nếu đăng tải thông tin sai sự thật hoặc tiêu cực về Green SM, ngoài các chế tài trên, Đối tác Tài xế phải thực hiện đính chính và xin lỗi Green SM. Nếu có dấu hiệu vi phạm pháp luật, chuyển cơ quan chức năng xử lý. |
| 2 | Cung cấp hoặc sử dụng giấy tờ giả mạo (giấy phép lái xe, CCCD, LLTP, …) |
| 3 | Sử dụng rượu, bia, thuốc lá hoặc các chất kích thích khác trong quá trình điều khiển phương tiện khi tham gia vận doanh. |
| 4 | Sử dụng phương tiện không trùng khớp với thông tin đăng ký trên tài khoản khi tham gia vận doanh. |
| 5 | Khai thác, sử dụng, tiết lộ, quay, chụp, thu âm, phát tán hình ảnh, thông tin, dữ liệu của Khách hàng không đúng với cam kết về bảo mật/quyền riêng tư đã thỏa thuận với Khách hành và quy định pháp luật; bao gồm nhưng không giới hạn việc sử dụng cho mục đích cá nhân hoặc ngoài phạm vi cung cấp dịch vụ cho Khách hàng, gây ảnh hưởng đến quyền lợi của Khách hàng hoặc uy tín, hình ảnh của Green SM. |
| 6 | Bất hợp tác, chống đối hoặc thể hiện thái độ tiêu cực trong quá trình cung cấp dịch vụ, kinh doanh trên nền tảng, trao đổi, phối hợp với Green SM (bao gồm việc không phối hợp giải quyết các sự cố, các lỗi, các sự vụ phát sinh với Khách hàng hoặc không phối hợp/tôn trọng quyền kiểm tra, kiểm soát của Green SM theo điều kiện kinh doanh trên nền tảng Green SM platform…) |
| 7 | Phát ngôn, đăng tải hoặc chia sẻ thông tin không chính xác, mang tính suy diễn, bình luận tiêu cực trên mạng xã hội, diễn đàn, hội nhóm…gây ảnh hưởng đến hình ảnh hoặc uy tín các cán bộ nhân viên của Green SM hoặc Tập Đoàn Vingroup. |
| 8 | Thực hiện các hành vi bị Khách hàng phản ánh (thông qua các kênh Tổng đài CSKH Green SM, Hòm thư Thanh tra Green SM, KHBM Green SM, VHP Green SM …) từ 05 lần trở lên (bao gồm các trường hợp có bằng chứng hoặc không có bằng chứng) trong vòng 30 ngày. |
| 9 | Sử dụng đồng phục, hình ảnh, nhãn hiệu hoặc các dấu hiệu nhận diện thương hiệu của Green SM cho mục đích cá nhân hoặc ngoài phạm vi hợp tác gây ảnh hưởng đến hình ảnh, uy tín của Green SM. |
| 10 | Thực hiện bảo dưỡng, sửa chữa phương tiện tại các cơ sở, trạm dịch vụ không thuộc danh mục các cơ sở do nhà sản xuất chỉ định hoặc không được nhà sản xuất ủy quyền. |
| 11 | Tái diễn lần 4 đối với các hành vi thuộc lỗi Nhóm 3. |
| 12 | Thực hiện hành vi lỗi Nhóm 2 nhưng bị Khách hàng tố cáo, gây ảnh hưởng đến hình ảnh và uy tín của Green SM, khiến Green SM phải bồi thường cho Khách hàng. |
| 13 | Chấm dứt hành trình hoặc yêu cầu Khách hàng xuống xe giữa đường trái với yêu cầu đã xác nhận, khi Khách hàng không yêu cầu, không có lý do chính đáng và/hoặc không thông báo kịp thời cho bộ phận hỗ trợ Green SM.Lưu ý: Việc thông báo kịp thời chỉ là một trong các tiêu chí xem xét, Green SM sẽ đánh giá toàn bộ bối cảnh và mức độ của sự việc. |
| 14 | Mang theo, trưng bày hoặc sử dụng bất kỳ vật dụng, thiết bị nào có thể hiện dấu hiệu nhận diện của đơn vị khác hoạt động trong cùng lĩnh vực với Green SM trong quá trình cung cấp dịch vụ cho Khách hàng thông qua ứng dụng Green SM. |

2. Nhóm 2: Các lỗi nghiêm trọng:

| STT | Các hành vi không đảm bảo quy tắc ứng xử | Biện pháp xử lý |
| --- | --- | --- |
| 1 | – Yêu cầu/gợi ý Khách hàng: thanh toán thêm cước, bo/tip, trả phí cầu đường cao hơn thực tế, và các khoản tiền không đúng theo quy định. Không trả lại tiền thừa cho Khách hàng.– Nhắn tin/gọi điện làm phiền Khách hàng. | Giảm doanh thu chia sẻ bằng cách trừ ví lũy tiến số tiền:– Lần 1: 1.000.000 đồng;– Lần 2: 3.000.000 đồng;– Lần 3: 5.000.000 đồng;Đồng thời yêu cầu bồi hoàn toàn bộ số tiền gian lận (nếu có). |
| 2 | Vi phạm pháp luật về giao thông đường bộ và an ninh trật tự khác như: che biển kiểm soát, vượt đèn đỏ, vượt giới hạn tốc độ, lấn làn, đi ngược chiều, sử dụng điện thoại khi đang di chuyển… |
| 3 | Thực hiện hành vi bị Khách hàng phản ánh liên tục từ 3 lần trở lên trong vòng 07 ngày (áp dụng đối với trường hợp chưa có bằng chứng rõ ràng). |
| 4 | Đỗ xe chiếm dụng trụ sạc khi phương tiện không thực hiện sạc hoặc đã sạc xong | Giảm doanh thu chia sẻ bằng cách trừ ví lũy tiến số tiền: 1.000.000 đồng/lần. |
| 5 | Nhận chuyến xe nhưng không đón Khách hàng theo yêu cầu dịch vụ đã xác nhận, sau đó tự hủy chuyến hoặc yêu cầu Khách hàng hủy gây ảnh hưởng chất lượng dịch vụ và/hoặc hình ảnh của Green SM. | Giảm doanh thu chia sẻ bằng cách trừ ví lũy tiến số tiền:• Vi phạm lần 1: trừ thưởng theo mức độ vi phạm/tuần như sau:✓ Mức 1: TX hủy 1-5 cuốc/ tuần trừ thưởng 1.000.000 đồng.✓ Mức 2: TX hủy trên 5 cuốc/ tuần trừ thưởng 2.000.000 đồng.• Vi phạm lần 2: trừ thưởng 3.000.000 đồng.• Vi phạm từ lần 3 trở lên trừ thưởng 5.000.000 đồng/lần |
| 6 | Gian lận lý do hủy cuốc, bao gồm nhưng không giới hạn ở các lý do sau: điểm đón sai khó tiếp cận, khách hàng không có mặt, gọi điện khách hàng không nghe máy… |
| 7 | Trả Khách hàng sai điểm đến so với yêu cầu dịch vụ đã xác nhận mà không được Khách hàng đồng ý hoặc thực hiện chuyến xe không đúng lộ trình tối ưu gây ảnh hưởng chất lượng dịch vụ và/hoặc hình ảnh Công ty. |
| 8 | Không đảm bảo các điều kiện về nhận diện như trang phục, thẻ tên, tác phong, diện mạo. | Giảm doanh thu chia sẻ bằng cách trừ ví 500.000 đồng/lần. |
| 9 | Không tuân thủ/thực hiện bảo dưỡng phương tiện theo kế hoạch hoặc thông báo của Bộ phận Quản lý Phương tiện (QLPT) và Depot. | Giảm doanh thu chia sẻ bằng cách trừ ví:• 500.000 đồng/lần (không gây hậu quả)• 2.000.000 đồng/lần (Có gây hậu quả và chịu hoàn toàn chi phí khắc phục) |
| 10 | Để xảy ra va chạm hoặc tai nạn giao thông do lỗi chủ quan, không tuân thủ quy định an toàn và các nguyên tắc vận hành phương tiện. | Áp dụng hình thức khấu trừ ví để điều chỉnh giảm doanh thu chia sẻ; mức giảm được áp dụng tương đương với chính sách dành cho tài xế cơ hữu. |
| 11 | Không tuân thủ lịch kiểm tra xe đã được Depot thông báo, không đưa phương tiện về Depot để thực hiện kiểm tra theo quy định. | Giảm doanh thu chia sẻ bằng cách trừ ví lũy tiến số tiền:• Lần 1: Trừ ví 500.000 đồng;• Lần 2: Trừ ví 1.000.000 đồng;• Lần 3: Trừ ví 2.000.000 đồng |

3. Nhóm 3: Các lỗi nhỏ

| STT | Các hành vi không đảm bảo quy tắc ứng xử | Biện pháp xử lý |
| --- | --- | --- |
| 1 | Có thái độ không thân thiện với Khách hàng mức độ nhẹ: to tiếng, thô lỗ,… | Giảm doanh thu chia sẻ bằng cách trừ ví lũy tiến số tiền:– Lần 1: Trừ ví 150.000 đồng;– Lần 2: Trừ ví 300.000 đồng;– Lần 3: Trừ ví 450.000 đồng. |
| 2 | Thực hiện các hành vi không đảm bảo tiêu chuẩn dịch vụ của Đối tác Tài xế Green SM (từ chối/bỏ trôi cuốc xe, đánh giá sao thấp…) |
| 3 | Thao tác sai trên App Driver khi thực hiện chuyến xe, bao gồm việc làm chênh lệch quãng đường di chuyển, cố ý kéo dài thời gian hoàn thành không thông báo kịp thời cho bộ phận hỗ trợ Green SM.Lưu ý: Việc thông báo kịp thời chỉ là một trong các tiêu chí xem xét; Green SM sẽ đánh giá toàn bộ bối cảnh và mức độ sự việc. |
| 4 | Không thực hiện theo đúng hướng dẫn, chỉ dẫn tại các điểm đậu đỗ của Green SM. |
| 5 | Không tham gia các buổi hướng dẫn, trao đổi và không đạt các bài kiểm tra do GSM tổ chức để nâng cao và cải thiện chất lượng Dịch vụ theo thông báo của Green SM. |

4. Nhóm 4: Các lỗi khác

| STT | Các hành vi không đảm bảo quy tắc ứng xử | Biện pháp xử lý |
| --- | --- | --- |
| 1 | Không đảm bảo trang phục lịch sự, phù hợp khi đến nhận xe và làm việc tại văn phòng Depot (ví dụ: mặc quần đùi, áo ba lỗ, dép lê, trang phục không phù hợp với môi trường làm việc) | Tạm thời ngừng việc giao xe cho đến khi tài xế thực hiện đúng quy định về tác phong và diện mạo |
| 2 | Sử dụng xe thuê của GSM nhưng không đảm bảo tiêu chuẩn hoặc không đúng điều kiện kinh doanh trên Nền tảng Green SM Platform, bao gồm việc phương tiện không đáp ứng tiêu chuẩn an toàn theo quy định của pháp luật hoặc không sử dụng đúng xe đã thuê của GSM để vận doanh trên nền tảng của GSM. | Tạm khóa tài khoản kinh doanh cho đến khi làm rõ trách nhiệm và phương án xử lý |
| 3 | Không chấp hành việc xử lý phạt nguội đúng thời hạn hoặc có hành vi trì hoãn, kéo dài thời gian hoàn tất nghĩa vụ nộp phạt theo quy định. | Tạm khóa tài khoản kinh doanh và khóa sạc trên hệ thống đối với tài xế chưa hoàn tất xử lý phạt nguội hoặc chưa đưa ra phương án xử lý phù hợp theo quy định. |
| 4 | Không phối hợp bổ sung giấy tờ hợp lệ khi có yêu cầu: Bằng lái xe, đăng kiểm, phù hiệu hợp đồng, tem phản quang, các giấy tờ khác… bị hết hạn hoặc bị thu hồi bởi Cơ quan Nhà nước. | Tạm khóa tài khoản kinh doanh cho đến khi làm rõ trách nhiệm và phương án xử lý |
| 5 | Không phản hồi/trì hoãn quá 24 giờ các cuộc gọi/email/thông báo liên hệ của Green SM từ 03 lần trở lên trong việc cung cấp thông tin, dữ liệu, hình ảnh liên quan đến các chuyến xe bị nghi ngờ có dấu hiệu gian lận hoặc các sự vụ liên quan đến khiếu nại Khách Hàng. |
| 6 | Không thực hiện đầy đủ nghĩa vụ tài chính với Green SM (tính từ ngày Green SM gửi thông báo). | Đối trừ nghĩa vụ tài chính mà Đối tác Tài xế phải thực hiện với Green SM vào Ví số tiền tương ứng. Nếu sau 07 ngày làm việc Đối tác Tài xế vẫn không thực hiện, hành vi này sẽ được chuyển sang lỗi Nhóm 1a – Chấm dứt tài khoản kinh doanh vĩnh viễn. |
| 7 | Thực hiện các hành vi khác nhưng có thể gây ảnh hưởng đến hình ảnh, chất lượng dịch vụ hoặc quyền lợi của Green SM và Khách hàng. | Tùy theo tính chất và mức độ sự việc, Green SM có thể áp dụng các chế tài xử lý từ cảnh cáo hoặc chấm dứt tài khoản kinh doanh vĩnh viễn. |

Bộ QTUX mới cónhiều điểm cập nhật quan trọng, vì vậy rất mong Bác Tài Xanhdành thời gian đọc kỹvàtuân thủ đúng quy định, để quá trình vận doanh diễn ra an toàn và hiệu quả hơn.

Mọi thắc mắc, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác Tài Xanh hoạt động an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.

“(*) Xe/Phương tiện của Green SM”
