# Tổng hợp Chính sách chia sẻ doanh số Car Platform

- **Ngày đăng:** 2025-02-17
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tong-hop-chinh-sach-chia-se-doanh-so-car-platform](https://www.greensm.com/vn-vi/news/tong-hop-chinh-sach-chia-se-doanh-so-car-platform)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Để đảm bảo thông tin tỷ lệ chiết khấu cho từng nhóm Tài Xế Car Platform được rõ ràng và minh bạch, Green SM xin cập nhật lại thông tin về các chính sách chia sẻ doanh số dành cho các Bác Tài đang áp dụng theo từng giai đoạn.

🔹Chi tiết chính sách:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/02/20250217-1-958x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # TỔNG HỢP CHÍNH SÁCH CHIA SẺ DOANH SỐ CAR PLATFORM
> 
> | Đối tượng Tài xế | Giai đoạn | Tỉ lệ chia sẻ | Ghi chú |
> |---|---|---|---|
> | Không mua xe qua Xanh SM | Ký hợp đồng với Xanh SM Platform chậm nhất ngày 31/12/2024 | Từ 01/06/2024 đến hết 31/05/2025 | 87% |
> | | | Từ 01/06/2025 đến hết 31/12/2025 | 85% |
> | | | Từ 01/01/2026 đến hết 31/03/2027 | 80% |
> | | Ký hợp đồng với Xanh SM Platform từ 01/01/2025 | Từ 01/01/2025 đến hết 15/02/2025 | 80% | Nhằm tri ân và hỗ trợ Tài xế trong giai đoạn cao điểm Tết nên vẫn duy trì mức chia sẻ 87% |
> | | | Từ 16/02/2025 đến hết 31/03/2027 | 80% | |
> | Mua xe qua Xanh SM | Mua xe trực tiếp qua Xanh SM từ 01/01/2025 đến hết 30/06/2025 | Từ 01/01/2025 đến hết 31/12/2025 | 85% | |
> | | | Từ 01/01/2026 đến hết 31/12/2027 | 80% | |

💙 Green SM Platform cam kết luôn đồng hành và mang lại những giá trị ưu đãi tốt nhất để hỗ trợ Bác tài trong quá trình vận doanh!

Mến chúc Bác tài hoạt động an toàn và hiệu quả.

Trân trọng,Đội ngũ Green SM Platform.
