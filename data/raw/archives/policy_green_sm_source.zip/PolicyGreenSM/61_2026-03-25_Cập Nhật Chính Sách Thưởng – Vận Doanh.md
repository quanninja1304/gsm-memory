# Cập Nhật Chính Sách Thưởng – Vận Doanh

- **Ngày đăng:** 2026-03-25
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-van-doanh-cho-tai-xe-xanh-sm-bike](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-van-doanh-cho-tai-xe-xanh-sm-bike)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh Bike ơi!

Cơ hội tăng thu nhập đã chính thức bắt đầu với nhiều thay đổi về chính sách cực kì hấp dẫn. Cùng khám phá ngay các nội dung chi tiết bên dưới:

✅ CHÍNH SÁCH THƯỞNG

📌 Bổ sung mốc thưởng tuần hấp dẫn lên đến 1.600.000đ/tuần

✅ CHÍNH SÁCH VẬN DOANH

📌 Điều chỉnh mốc khoán doanh số/tuần

⏰ Thời gian áp dụng: 23/03/2026

📍 Khu vực áp dụng:Hà Nội, TP.HCM (bao gồm Bình Dương cũ) Đồng Nai

📌Lưu ý:

Áp dụng tự động nhận chuyến khi tỷ lệ nhận chuyến< 70%

Chi tiết chính sách

![CẬP NHẬT CHÍNH SÁCH THƯỞNG - VẬN DOANH](https://cdn.xanhsm.com/2026/03/9f1b1bfb-cstx-1.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH SÁCH THU NHẬP DÀNH CHO BÁC TÀI XANH BIKE
> 
> Áp dụng toàn quốc từ ngày 23/03/2026
> 
> **TỔNG THU NHẬP = Chia sẻ doanh số (1) + Thưởng tuần (2) + Thưởng khác (nếu có) (3)**
> 
> ---
> 
> **(1) Chia sẻ doanh số**
> 
> | Dịch vụ             | Mức chia sẻ doanh số | Ghi chú                                                                                                                                                             |
> | :------------------ | :-------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
> | Bike & Express Siêu tốc | 70%                   | * Doanh số bao gồm cả các phí yêu cầu đặc biệt của dịch vụ Xanh Express (giao tận tay, phí giao hàng cồng kềnh...)                                                  |
> | Express 2h          | 72%                   | * Mức chia sẻ doanh số chưa bao gồm khoản khấu trừ Thuế Thu nhập cá nhân (PIT) & thuế GTGT (VAT)                                                                  |
> | Food                | 75%                   |                                                                                                                                                                     |
> ```

![Ảnh 2_Chinh sach thưởng](https://cdn.xanhsm.com/2026/03/4186dd17-anh-2_chinh-sach-thuong-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> 
> **Khu vực áp dụng:** Hà Nội, TP.Hồ Chí Minh (bao gồm HCM & Bình Dương), Đồng Nai
> 
> # THƯỞNG TUẦN
> **Áp dụng từ ngày:** 23/03/2026
> 
> | MỨC ĐIỂM THƯỞNG   | MỨC THƯỞNG CẤP 1 (vận doanh 4 ngày/tuần) | MỨC THƯỞNG CẤP 2 (vận doanh >=5 ngày/tuần) |
> | :---------------- | :--------------------------------------- | :--------------------------------------- |
> | 400 - dưới 550 điểm |                                          | 150.000 VNĐ                              |
> | 550 - dưới 700 điểm | 160.000 VNĐ                              | 200.000 VNĐ                              |
> | 700 - dưới 850 điểm | 200.000 VNĐ                              | 300.000 VNĐ                              |
> | 850 - dưới 1.100 điểm| 320.000 VNĐ                              | 550.000 VNĐ                              |
> | 1.100 - dưới 1.400 điểm| 640.000 VNĐ                              | 850.000 VNĐ                              |
> | 1.400 - dưới 1.500 điểm| 960.000 VNĐ                              | 1.400.000 VNĐ                            |
> | >= 1.500 điểm     | 1.200.000 VNĐ                            | 1.600.000 VNĐ                            |
> 
> | Khu vực                               | Điều kiện áp dụng                    | Mức thưởng cấp 1 | Mức thưởng cấp 2 |
> | :------------------------------------ | :----------------------------------- | :--------------- | :--------------- |
> | Hà Nội                                | Tỷ lệ nhận chuyến, hoàn thành chuyến | >= 85%           | >= 85%           |
> | TP.Hồ Chí Minh (bao gồm Bình Dương), Đồng Nai | Tỷ lệ nhận chuyến, hoàn thành chuyến | >= 90%           | >= 90%           |

![Ảnh 3_Bang quy doi diem](https://cdn.xanhsm.com/2026/03/301d7a63-anh-3_bang-quy-doi-diem-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # XANH SM
> 
> ## CHÍNH SÁCH VẬN DOANH DÀNH CHO BÁC TÀI XANH BIKE
> 
> ### BẢNG QUY ĐỔI ĐIỂM THƯỞNG
> 
> | Dịch vụ             | 6h00-8h59 | 11h00-13h59 | 16h00-18h59 | 9h00-10h59, 14h00-15h59, 19h00-21h59, 22h00-5h59 |
> | :------------------ | :-------- | :---------- | :---------- | :----------------------------------------------- |
> | Xanh SM Bike        | 10        | 5           | 10          | 5                                                |
> | Xanh Express siêu tốc | 5         | 10          | 5           | 5                                                |
> | Xanh Express 2h     | 10        | 20          | 10          | 10                                               |
> | Xanh SM Ngon        | 15        | 30          | 30          | 15                                               |
> 
> **Lưu ý:**
> * Bổ sung điểm thưởng khung giờ 22h00 - 5h59
> * Đơn giao hàng đa điểm được tính theo số điểm giao
> ```

![Ảnh 4_Chính sách khoán DS](https://cdn.xanhsm.com/2026/03/4039b231-anh-4_chinh-sach-khoan-ds-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH DOANH SỐ TỐI THIỂU DÀNH CHO BÁC TÀI XANH BIKE
> 
> Áp dụng từ ngày 23/03/2026
> 
> | Khu vực                                                                 | Mức khoán doanh số tối thiểu | Mức truy thu                                                                                                                                                                             |
> | :---------------------------------------------------------------------- | :--------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Hà Nội                                                                  | 1.600.000 VNĐ/tuần           |                                                                                                                                                                                         |
> | TP.Hồ Chí Minh (bao gồm Bình Dương), Đồng Nai                          | 1.500.000 VNĐ/tuần           | Trong trường hợp **không đạt** mức doanh số tối thiểu, Đối tác Tài xế sẽ bị truy thu **20% phần Doanh số khoán chưa đạt** bằng hình thức Trừ Ví tài xế |
> | Đà Nẵng                                                                 | 1.200.000 VNĐ/tuần           |                                                                                                                                                                                         |
> | Quảng Ninh, Hải Phòng, Nghệ An, Huế, Khánh Hòa, TP.Hồ Chí Minh (khu vực Bà Rịa - Vũng Tàu cũ) | 800.000 VNĐ/tuần             |                                                                                                                                                                                         |

![Ảnh 5_Quy dinh truc tuyen](https://cdn.xanhsm.com/2026/03/e0a1d05f-anh-5_quy-dinh-truc-tuyen-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH VẬN DOANH DÀNH CHO BÁC TÀI XANH BIKE
> 
> ## QUY ĐỊNH TRỰC TUYẾN & TỶ LỆ VẬN HÀNH
> 
> | Tiêu chí                 | Nội dung                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
> | :----------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Quy định trực tuyến     | - Cảnh báo nếu Đối tác không trực tuyến/không phát sinh chuyến xe trong **02 ngày liên tiếp**. <br> - Công ty sẽ tiến hành **thu hồi xe** và **thu phí sử dụng xe** nếu **05 ngày liên tiếp** Đối tác không trực tuyến/ không phát sinh chuyến xe mà **không có lý do hợp lệ**. <br> - Áp dụng phí sử dụng xe đối với các ngày không vận doanh vượt quy định, cụ thể: Thu phí sử dụng xe **50.000 VNĐ/ngày** từ ngày không vận doanh thứ 5 trở đi/tháng.                                                                                                                                                                     |
> | Quy định tỷ lệ vận hành | - Trường hợp Đối tác Tài xế có tỷ lệ chấp nhận chuyến dưới **70%**: Hệ thống sẽ mặc định bật tính năng “Nhận chuyến tự động" tới 23h59 của ngày vận doanh đó. |

Mọi thắc mắc về chính sách mới giải đáp TẠI ĐÂY.

Cùng Green SM bứt tốc, tăng trưởng thu nhập và hoạt động năng suất Bác Tài nhé.

Trân trọng,

Đội ngũ Green SM Bike
