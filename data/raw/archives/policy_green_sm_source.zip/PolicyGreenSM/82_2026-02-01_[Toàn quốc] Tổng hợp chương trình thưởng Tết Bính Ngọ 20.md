# [Toàn quốc] Tổng hợp chương trình thưởng Tết Bính Ngọ 2026 dành cho Bác Tài Xanh Van

- **Ngày đăng:** 2026-02-01
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-tet-binh-ngo-txvan](https://www.greensm.com/vn-vi/news/thuong-tet-binh-ngo-txvan)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

![Thưởng Tết Nguyên Đán Bính Ngọ_HN và HCM](https://cdn.xanhsm.com/2026/02/0646cc75-260131_taxivan-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Mã Đào Khai Xuân
> # Chương trình Thưởng Tết 2026
> 
> **Logo:**
> * VXANH SM
> 
> **Hình ảnh:**
> * Một người đàn ông mặc áo xanh dương có logo VXANH SM, đang cười và giơ nắm đấm.
> * Một phong bì lì xì màu đỏ có hình bông hoa vàng.
> * Một chiếc ô tô màu xanh ngọc và trắng có logo VXANH SM.
> * Một chiếc xe tải nhỏ màu xanh ngọc và vàng.
> * Tiền vàng và hoa mai/đào trang trí.
> 
> **Văn bản phụ trên ô tô:**
> * 1900 2088

Bác Tài Xanh thân mến,

Green SM xin gửi lời chúc Tết Bính Ngọ an lành – Thịnh vượng đến toàn thể Bác Tài và Gia đình.

Trong tinh thần khởi đầu mới, Green SM mang đến một mùa Tết trọn vẹn niềm vui với nhiều chính sách thưởng hấp dẫn dành riêng cho đội ngũ Bác Tài Xanh đã nỗ lực cống hiến trong năm.

Tết năm nay, Green SM mang đến loạt thưởng hấp dẫn để anh em Bác Tài vận doanh thật tốt và “Mã đáo khai xuân” ngay từ những ngày đầu năm. Hãy xem ngay các chương trình bên dưới để nắm cơ hội nhận thưởng nhé cụ thể.

1. Chương trình “Thưởng tăng cường vận doanh Tết”:

| THƯỞNG THÊM 10% DOANH SỐ<SO VỚI NGÀY THƯỜNG> |
| --- |
| Khu vực áp dụng | Toàn quốc |
| Đối tượng áp dụng | Bác Tài Xanh Van |
| Thời gian áp dụng | Từ 16/02 (29 Âm lịch) đến 20/02/2026 (Mùng 4 Tết) |
| Điều kiện đạt thưởng | Tỷ lệ nhận và hoàn thành chuyến trung bình ngày đạt từ 85% trở lên |

2. Chương trình “Thưởng quà đầu xuân”

| THƯỞNG 300.000Đ |
| --- |
| Khu vực áp dụng | Toàn quốc |
| Đối tượng áp dụng | Bác Tài Xanh Van gia nhập Công ty từ ngày 01/10/2025 đến 05/02/2026 |
| Thời gian chi thưởng | Dự kiến vào ngày 10/02/2026 |

Chương trình thưởng hấp dẫn dịp Tết đã SẴN SÀNG! Bác Tài Xanh cùng lên dây cót để Tết này bứt phá doanh thu và nhận thưởng đầy ví nhé!

Mến chúc Bác Tài Xanh và gia đình một năm mới sung túc, bình an, sức khỏe dồi dào và vạn sự như ý!

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
