# [Cập nhật mới] Điều chỉnh chính sách thu nhập mới của dịch vụ GF-VIP

- **Ngày đăng:** 2026-03-24
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/dieu-chinh-chinh-sach-gfvip-24-03-2026](https://www.greensm.com/vn-vi/news/dieu-chinh-chinh-sach-gfvip-24-03-2026)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Hiện nay, dịch vụ GF-VIP đã được mở rộng và tăng khả năng tiếp cận đến nhiều phân khúc khách hàng tại Hà Nội & Tp. Hồ Chí Minh. Nhằm đảm bảo chất lượng và độ phủ của dịch vụ, Green SM triển khai chính sách thu nhập GF-VIP mớiáp dụng từ ngày 26/03/2026. Với mong muốn gia tăng thu nhập mỗi ngày của Bác Tài Xanh, Green SM khuyến khích Bác Tài Xanh:

- Gia tăng số giờ vận doanh để tận dụng tối đa lợi ích từ các chính sách “thưởng doanh số cao” & “đảm bảo thu nhập”

- Tập trung vận doanh tại các khu vực có nhu cầu cao như: bến xe, sân bay, trung tâm thương mại, khách sạn cao cấp .v.v.

- Tích cực hoạt động trong khung giờ cao điểm

Khám phá ngay chính sách thu nhập GF-VIP mới để không bỏ lỡ cơ hội bứt phá thu nhập ngay sau đây:

CHI TIẾT ĐIỀU CHỈNH:

Đối tượng áp dụng: Bác Tài Xanh đang hoạt động dịch vụ GF-VIP tại Hà Nội & Tp. Hồ Chí Minh

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/03/12492b52-260324_gfvip-574x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Chính sách "Lương cơ bản"
> 
> Với điều chỉnh mới, Bác Tài Xanh được yêu cầu mức khoán công việc tối thiểu mỗi ngày như sau:
> 
> | Tỉnh/thành                     | Từ Thứ hai đến Thứ năm | Từ Thứ sáu đến Chủ nhật |
> | :----------------------------- | :--------------------- | :---------------------- |
> | Hà Nội / Tp. Hồ Chí Minh (theo địa giới hành chính cũ) | 600,000₫               | 700,000₫                |
> 
> **Lưu ý về điều kiện:**
> * Tỷ lệ nhận chuyến & hoàn thành chuyến trong ngày đạt từ 95%
> * Bác Tài Xanh cần tuân thủ 100% lệnh điều phối của Đội xe thuộc các Depot:
>   * Tại Tp. Hồ Chí Minh: Depot HCM 1,6,7
>   * Tại Hà Nội: Depot HN 1,2,3
> 
> # Chính sách "Thưởng doanh số cao"
> 
> Khu vực Hà Nội/ Tp. Hồ Chí Minh (theo địa giới hành chính cũ)
> 
> | Mức   | Doanh số/tháng          | Mức thưởng   |
> | :---- | :---------------------- | :----------- |
> | Mức 1 | Dưới 11 triệu đồng      | /            |
> | Mức 2 | Từ 11 - 14 triệu đồng   | 2,800,000₫   |
> | Mức 3 | Từ 14 - 17 triệu đồng   | 3,300,000₫   |
> | Mức 4 | Từ 17 - 21 triệu đồng   | 3,800,000₫   |
> | Mức 5 | Từ 21 - 24 triệu đồng   | 4,300,000₫   |
> | Mức 6 | Từ 24 triệu đồng trở lên | 4,800,000₫   |
> 
> # Chính sách "Đảm bảo thu nhập"
> 
> | Nội dung                       | Chi tiết                                                                                                                                                                                                                                                                                                                                           |
> | :----------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | Phạm vi áp dụng                | Hà Nội, Tp. Hồ Chí Minh (theo địa giới hành chính cũ)                                                                                                                                                                                                                                                                                                |
> | Thời gian áp dụng              | * Trong 02 tháng kể từ ngày Bác Tài Xanh chuyển sang hoạt động dịch vụ GF VIP <br> * Hiệu lực: từ 26/03/2026                                                                                                                                                                                                                                        |
> | Mức đảm bảo thu nhập           | Đảm bảo thu nhập tối thiểu 700,000đ/ngày                                                                                                                                                                                                                                                                                                          |
> | Điều kiện được hưởng đảm bảo thu nhập | * Hoàn thành tối thiểu 6 chuyến/ngày <br> * Trung bình doanh số các chuyến xe trong ngày đạt từ 100,000₫ trở lên <br> * Tỷ lệ nhận chuyến trung bình/ngày đạt từ 90% <br> * Tỷ lệ hoàn thành chuyến trung bình/ngày đạt từ 90% |

Mọi thắc mắc về chính sách, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ giải đáp.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
