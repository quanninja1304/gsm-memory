# Tài xế xe ô tô điện cần bằng cấp gì? Quy định về GPLX mới nhất mà các bác tài cần biết

- **Ngày đăng:** 2025-08-28
- **Chuyên mục:** Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tai-xe-o-to-dien-can-bang-cap-gi](https://www.greensm.com/vn-vi/news/tai-xe-o-to-dien-can-bang-cap-gi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Trong bối cảnh xe ô tô điện ngày càng phổ biến tại Việt Nam, nhiều bác tài băn khoăn: “Lái xe điện có cần bằng cấp riêng hay chỉ cần giấy phép lái xe như xe xăng, xe dầu?”. Thực tế, pháp luật Việt Nam đã có những quy định rất rõ ràng về giấy phép lái xe (GPLX) đối với loại phương tiện này. Bài viết dưới đây sẽ giúp bạn hiểu rõ tài xế xe ô tô điện cần bằng cấp gì, quy định mới nhất về GPLX đặc biệt sau ngày 1/1/2025.

## 1. Tài xế ô tô điện cần bằng lái xe loại gì?

Việc sử dụng ô tô điện ngày càng trở nên phổ biến, kéo theo nhiều thắc mắc về các loại bằng lái cần thiết. Câu trả lời phụ thuộc vào thời điểm bạn thi bằng và loại xe bạn điều khiển, cụ thể như sau:

![Tài xế ô tô điện cần bằng lái xe loại nào?](https://cdn.xanhsm.com/2025/09/42124606-image-1024x576.png)

Tài xế ô tô điện cần bằng lái xe loại nào?

Trước ngày 1/1/2025: Bằng B1 hoặc B2

Trước khi Luật Trật tự An toàn Giao thông Đường bộ 2024 có hiệu lực, ô tô điện được xem như một loại xe ô tô thông thường. Vì vậy, người lái xe ô tô điện cần có bằng lái xe hạng B1 hoặc B2, tùy thuộc vào loại xe.

- Bằng lái xe hạng B1 số tự động:Được cấp cho người không hành nghề lái xe, cho phép điều khiển ô tô số tự động (bao gồm cả ô tô điện) chở người đến 9 chỗ ngồi, ô tô tải có trọng tải thiết kế dưới 3.500 kg.

- Bằng lái xe hạng B2:Được cấp cho người hành nghề lái xe, cho phép điều khiển ô tô chuyên dùng có trọng tải thiết kế dưới 3.500 kg và các loại xe được quy định cho hạng B1.

Từ ngày 1/1/2025: Bằng lái xe hạng B (mới)

TheoThông tư 35/2024/TT-BGTVT(có hiệu lực từ ngày 1/1/2025), hệ thống giấy phép lái xe đã có nhiều thay đổi lớn. Hạng B1 và B2 sẽ được gộp chung thànhhạng B.

- Giấy phép lái xe hạng B:Được cấp cho người lái ô tô chở người đến 8 chỗ (không kể chỗ của người lái), xe ô tô tải và ô tô chuyên dùng có khối lượng toàn bộ theo thiết kế đến 3.500 kg.

- Học lái xe bằng ô tô điện:Từ 1/1/2025, ô tô điện sẽ được bổ sung vào chương trình đào tạo và sát hạch GPLX. Nếu bạn học và thi bằng lái xe bằng ô tô điện hoặc xe số tự động, trên GPLX hạng B của bạn sẽ có một chú thích: “Cấp cho người chỉ được điều khiển ô tô số tự động, baogồm cả ô tô điện.” Điều này có nghĩa là bạn sẽ không được phép điều khiển xe số sàn.

Có thể nói, sự thay đổi này giúp đơn giản hóa hệ thống bằng lái xe và phù hợp hơn với xu hướng phát triển của xe điện.

## 2. Những quy định mới về Giấy phép lái xe

Ngoài việc gộp hạng B1 và B2, các quy định mới về GPLX còn có nhiều điểm đáng chú ý khác mà tài xế cần nắm rõ, điển hình như sau:

![Cập nhật quy định mới về giấy phép lái xe](https://cdn.xanhsm.com/2025/09/42124606-image-2-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> - Văn bản:
>   - XANH SM
>   - AIRBAG
> ```

Cập nhật quy định mới về giấy phép lái xe

### 2.1. Tài xế ô tô điện sẽ có GPLX riêng

Như đã đề cập ở trên, GPLX hạng B được cấp cho người học và thi bằng ô tô điện sẽ có chú thích rõ ràng. Đây là điểm khác biệt quan trọng mà tài xế cần lưu ý. Với chú thích này, người lái xe sẽ biết chính xác loại phương tiện mình được phép điều khiển, tránh vi phạm luật giao thông. Bằng này có mã số là B.01.

Nếu GPLX của bạn được cấp trước ngày 1/1/2025 và còn thời hạn, bạn vẫn được tiếp tục sử dụng bình thường cho đến khi hết hạn. Khi cần đổi hoặc cấp lại, bạn sẽ được đổi sang GPLX hạng B mới. Cụ thể, bằng B2 cũ sẽ được đổi sang bằng B hoặc hạng C1 mới.

### 2.2. Quy định về kiểm tra hoàn thành khóa đào tạo đối với lái xe điện

TheoThông tư 35/2024/TT-BGTVT, việc kiểm tra hoàn thành khóa đào tạo GPLX đã được siết chặt hơn. Các bạn sẽ phải trải qua một kỳ kiểm tra lý thuyết và thực hành tại cơ sở đào tạo trước khi được đăng ký dự thi sát hạch.

#### Kiểm tra lý thuyết

Bạn phải tham gia bài kiểm tra lý thuyết với nội dung liên quan đến các môn học đã được đào tạo. Bài kiểm tra này gồm các câu hỏi về:

- Pháp luật giao thông đường bộ:Các quy tắc, biển báo và quy định cần tuân thủ khi lái xe.

- Cấu tạo xe và sửa chữa cơ bản:Nắm được các bộ phận chính của xe ô tô điện và cách xử lý các sự cố đơn giản.

- Đạo đức, văn hóa giao thông:Hiểu rõ trách nhiệm của người lái xe, cách ứng xử văn minh và phòng tránh tác hại của rượu, bia.

- Kỹ năng lái xe:Các kỹ thuật cơ bản khi điều khiển phương tiện.

- Mô phỏng tình huống:Xử lý các tình huống giao thông thực tế qua phần mềm mô phỏng.

Để đạt yêu cầu, bạn cần đạt điểm từ 5 trở lên trên thang điểm 10.

#### Kiểm tra thực hành

Sau khi vượt qua phần lý thuyết, bạn sẽ tiếp tục với bài kiểm tra thực hành. Đây là bước quan trọng để đánh giá khả năng lái xe của bạn.

- Bạn sẽ thực hiện các bài thi liên hoàn như: xuất phát, dừng xe nhường đường cho người đi bộ, dừng và khởi hành xe ngang dốc, ghép xe vào nơi đỗ…

- Đồng thời sẽ được kiểm tra khả năng lái xe an toàn trên đường, bao gồm các kỹ năng tăng số, giảm số và xử lý tình huống thực tế.

Để đủ điều kiện kiểm tra, bạn phải đáp ứng yêu cầu về thời gian học lý thuyết (tối thiểu 70%), số km học thực hành trên sân tập (tối thiểu 50% tổng số km) và trên đường (tối thiểu 50% thời gian học).

#### Điều kiện hoàn thành khóa đào tạo

Một người được công nhận hoàn thành khóa đào tạo khi đạt được điểm yêu cầu ở tất cả các bài kiểm tra lý thuyết và thực hành. Nếu sau một năm kể từ lần kiểm tra đầu tiên mà bạn vẫn chưa đủ điều kiện, họ sẽ phải đăng ký đào tạo lại từ đầu.

Quy định này đảm bảo rằng mỗi tài xế đều được trang bị đầy đủ kiến thức và kỹ năng cần thiết để lái xe an toàn, góp phần giảm thiểu rủi ro trên đường và nâng cao chất lượng lái xe tại Việt Nam.

Đặc biệt, đối với người học lái xe điện và xe số tự động:Thời gian đào tạo theo quy định là 203 giờ.

## 3. Điều kiện và hồ sơ đăng ký thi bằng lái xe hạng B

Để sở hữu GPLX hạng B, người đăng ký cần đáp ứng các điều kiện về độ tuổi, sức khỏe và chuẩn bị đầy đủ hồ sơ theo quy định.

### 3.1. Điều kiện dự thi

- Độ tuổi:Đủ 18 tuổi trở lên (tính đến ngày dự sát hạch).

- Sức khỏe:Có sức khỏe tốt, phù hợp với loại xe và công việc lái xe. Bạn sẽ phải khám sức khỏe tại các cơ sở y tế đủ tiêu chuẩn.

- Hoàn thành khóa đào tạo:Bạn phải hoàn thành đầy đủ nội dung, chương trình đào tạo theo quy định và được cơ sở đào tạo lái xe xác nhận.

- Lý lịch:Có lý lịch tư pháp rõ ràng, không có tiền án, tiền sự.

### 3.2. Hồ sơ đăng ký thi

TheoĐiều 29, Thông tư 35/2024/TT-BGTVT, hồ sơ đăng ký thi GPLX lần đầu bao gồm:

- Đơn đề nghị học, sát hạch:Mẫu đơn theo quy định.

- Giấy tờ tùy thân:Bản sao hoặc bản sao điện tử được chứng thực từ bản chính của một trong các loại giấy tờ sau: Thẻ căn cước công dân, hộ chiếu. Đối với người nước ngoài, cần có thẻ tạm trú, thẻ thường trú, chứng minh thư ngoại giao hoặc chứng minh thư công vụ.

- Chứng chỉ hoàn thành khóa đào tạo:Chứng chỉ sơ cấp hoặc xác nhận hoàn thành khóa đào tạo lái xe.

- Giấy khám sức khỏe:Giấy khám sức khỏe của người lái xe còn hiệu lực, được cấp bởi cơ sở khám chữa bệnh đủ tiêu chuẩn.

- Ảnh thẻ:2 ảnh 3×4 (tùy theo yêu cầu của từng trung tâm).

![Tài xế Green SM car cần bằng lái xe loại nào?](https://cdn.xanhsm.com/2025/09/42124606-image-1.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> KHÔNG_CÓ_CHỮ
> ```

Tài xế Green SM car cần bằng lái xe loại nào?

## 4. Tài xế Green SM Car cần bằng lái gì?

Đối với những ai đang có ý định gia nhập đội ngũ tài xế Green SM Car, việc nắm rõ yêu cầu về GPLX là vô cùng cần thiết. Một số yêu cầu của Green SM như sau:

- Yêu cầu bằng lái:Tài xế Green SM cần có GPLX hạng B2 trở lên để điều khiển xe điện.

- Lý lịch:Độ tuổi từ 18 – 65, có lý lịch tư pháp rõ ràng.

- Kinh nghiệm và kỹ năng:Thông thạo địa lý khu vực, tác phong chuyên nghiệp. Có kinh nghiệm làm việc tại các hãng xe công nghệ, taxi truyền thống là một lợi thế.

Trở thành tài xế Green SM không chỉ là cơ hội việc làm hấp dẫn, thu nhập lên đến 25 triệu đồng/tháng mà còn giảm thải ô nhiễm môi trường, thúc đẩy giao thông xanh tại Việt Nam. Để gia nhập cộng đồng Green SM Car, bạn hãy nhanh tayđăng ký Green SM Car.

Đăng ký Tài xế Green SM Car khu vực Hà Nội: Tp.Hồ Chí Minh:TẠI ĐÂY

Đăng ký Tài xế Green SM Car khu vực các tỉnh:TẠI ĐÂY

## Kết luận

Với những thay đổi trong luật giao thông từ năm 2025, việc sở hữuGPLX hạng Btrở thành điều kiện bắt buộc để hành nghề lái taxi, bao gồm cả taxi điện. Các tài xế, đặc biệt là những người có ý định chuyển sang tài xế Green SM car, cần nắm rõ những quy định mới này để đảm bảo tuân thủ pháp luật và có một hành trình an toàn.
