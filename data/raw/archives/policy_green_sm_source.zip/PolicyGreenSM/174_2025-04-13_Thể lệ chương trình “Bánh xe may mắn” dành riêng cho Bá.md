# Thể lệ chương trình “Bánh xe may mắn” dành riêng cho Bác Tài Xanh

- **Ngày đăng:** 2025-04-13
- **Chuyên mục:** Tài xế Green SM Car, Uncategorized
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/the-le-chuong-trinh-banh-xe-may-man-danh-rieng-cho-bac-tai-xanh](https://www.greensm.com/vn-vi/news/the-le-chuong-trinh-banh-xe-may-man-danh-rieng-cho-bac-tai-xanh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Với mong muốn mang đến thêm niềm vui và sự khích lệ cho những nỗ lực mỗi ngày của đội ngũ Bác Tài Xanh, từ ngày 20/03 đến hết ngày 20/04/2025, Green SM triển khai chương trình “Bánh xe may mắn” – quay là trúng, quà về liền tay!

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/dcb2bd82-banh-xe-may-man-1200x675-1-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> XANH SM
> * **Bánh Xe May Mắn**
> * Mỗi cuốc xe phát sinh có giá trị trung bình cuốc xe từ **100.000đ** trở lên sẽ nhận được **01** mã quay thưởng. Thời gian từ **20/03** đến **20/04/2025**.
> * Bác tài có thể xem lượt quay số từ ngày **10/04** và bắt đầu vòng quay vào ngày **14/04/2025**.
> 
> **THAM GIA NGAY**
> 
> **Giải thưởng:**
> * **Giải Đặc Biệt:** **20 TRIỆU ĐỒNG**
> * **Giải Nhất:** **VinFast VF 3**
> * **Giải Nhì:** **VinFast VF 5**
> * **Giải Ba:** VOUCHER VINPEARL **2.500.000đ**
> * **Giải Khuyến Khích:** **50.000đ**
> * **Chúc bạn may mắn lần sau**
> ```

### 1. Thời gian diễn ra chương trình:

Từ 20/03 đến 20/04/2025

### 2. Đối tượng tham gia:

Tài xế Taxi Green SM

### 3. Cách thức tham gia:

- Tài xế mới gia nhập Green SM trong thời gian diễn ra chương trình được tặng 5 mã quay thưởng.

- Trong thời gian diễn ra chương trình, với mỗi cuốc xe có giá trị trung bình từ 100.000 đồng trở lên, Bác tài sẽ nhận được 01 mã quay thưởng.

- Bắt đầu từ ngày 10/04/2025, Bác tài có thể kiểm tra số lượt quay ngay trên App Green SM Driver

- Từ ngày 14/04/2025, Bác tài chính thức có thể tham gia quay thưởng với Bánh Xe May Mắn.

### 4. Cơ cấu giải thưởng:

- 03 Giải Đặc biệt – trị giá 20 triệu đồng sẽ được Top-up vào Ví TX

- 05 Giải Nhất – trị giá 15 triệu đồng – 01 suất cọc Limo Green (không hoàn trả, có thể chuyển nhượng)

- 05 Giải Nhì – trị giá 7 triệu đồng – 01 suất cọc Minio Green (không hoàn trả, có thể chuyển nhượng)

- 12 Giải Ba – trị giá 2,5 triệu đồng – 01 đêm nghỉ Vinpearl tiêu chuẩn dành cho 02 người

- 2.000 Giải Khuyến khích – trị giá 50.000 đồng sẽ được Top-up vào Ví TX

Kính chúc các Bác Tài luôn vững tay lái – nhiều cuốc xe – trúng thật nhiều quà!
