# [GREEN SM BIKE] Cập nhật chính sách thưởng tết – đón năm mới thêm xanh

- **Ngày đăng:** 2025-01-22
- **Chuyên mục:** Cẩm nang tài xế, Cộng đồng
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-tet-don-nam-moi-them-xanh](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-tet-don-nam-moi-them-xanh)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Quý Đối tác Tài xế thân mến,

Mừng đón năm mới xuân phơi phới, Green SM Bike xin thông báo cập nhật một số thay đổi quan trọng về chuỗi chương trình thưởng Tết. Với sự thay đổi này, Quý Đối tác Tài xế có cơ hội nhận mức thưởng hấp dẫn hơn và điều kiện nhận thưởng vô cùng dễ dàng, hãy cùng Green SM khám phá ngay các chương trình thưởng sau 🎉

## 1. Chuỗi chương trình thưởng tết

🌸 Chương trình “Tăng Chuyến – Nhận Thưởng”

- Thời gian áp dụng:  từ ngày 24/01/2025 đến ngày 07/02/2025 (Tương ứng từ ngày 25 Tháng Chạp đến ngày Mùng 10 Tết Âm lịch)

🌸 Chương trình  “Lì xì lộc xuân – Ất Tỵ sum vầy”

- 350 Đối tác Tài xếđạt doanh thu cao nhất trong5 ngàyTừ ngày 28/01/2025 đến ngày 01/02/2025 (tương ứng từ ngày 29 Tháng Chạp đến mùng 4 Tết âm lịch)nhận thêm Lì xì 300.000VND.

🎯Chi tiết về chương trình và điều kiện nhận thưởng:Vui lòng tham khảo hình ảnh bên dưới:

![2201_CS thưởng tết (1)](https://cdn.xanhsm.com/2025/01/460b5cef-2201_cs-thuong-tet-1-1024x1024.png)

> **[Nội dung trích xuất từ ảnh]:**
> # LÌ XÌ LỘC XUÂN ẤT TỴ SUM VẦY
> 
> *   **Tặng Lì xì 300,000 VNĐ/tài xế khi đạt đồng thời các điều kiện sau**
>     *   Vận doanh ít nhất **03 ngày** trong thời gian diễn ra chương trình thưởng
>     *   Đạt Top **350 tài xế** đạt doanh thu cao nhất trong **05 ngày** (*)
>     *   Tỷ lệ nhận chuyến và tỷ lệ hoàn thành chuyến >= **90%**
> 
> *   **Thời gian áp dụng:** Từ ngày 28/01/2025 đến ngày 01/02/2025 (tương ứng từ ngày 29 Tháng Chạp đến mùng 4 Tết âm lịch)
> 
> *   **Khu vực áp dụng:** Hà Nội, Đà Nẵng, và Thành phố Hồ Chí Minh
> 
> *   **Đối tượng áp dụng:** Đối tác Tài xế Xanh SM Bike/Xanh SM Bike Platform
> 
> (*) 200 TX tại Hà Nội, 100 TX tại TP. Hồ Chí Minh và 50 TX tại Đà Nẵng

![2201_CS thưởng tết (2)](https://cdn.xanhsm.com/2025/01/9f8c21f7-2201_cs-thuong-tet-2-721x1024.png)

> **[Nội dung trích xuất từ ảnh]:**
> # TĂNG CHUYẾN NHẬN THƯỞNG
> 
> ## Từ 24-27/01/2025
> 
> | Số chuyến/ngày         | Mức thưởng         |
> | :--------------------- | :----------------- |
> | Từ chuyến thứ 10 trở lên | 3.000 VNĐ/chuyến |
> | Từ chuyến thứ 20 trở lên | 5.000 VNĐ/chuyến |
> 
> **Khu vực áp dụng:** Hà Nội
> **Điều kiện nhận thưởng:**
> * Tài xế trực tuyến vận doanh trong thời gian diễn ra chương trình thường
> * Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến >=90%
> 
> ## Từ 28/01-01/02/2025
> 
> | Số chuyến/ngày         | Mức thưởng         |
> | :--------------------- | :----------------- |
> | Từ chuyến thứ 08 trở lên | 5.000 VNĐ/chuyến |
> | Từ chuyến thứ 12 trở lên | 8.000 VNĐ/chuyến |
> 
> **Khu vực áp dụng:** Hà Nội, Đà Nẵng, TP.Hồ Chí Minh
> **Điều kiện nhận thưởng:**
> * Tài xế trực tuyến vận doanh trong thời gian diễn ra chương trình thường
> * Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến >=90%
> 
> ## Từ 02-07/02/2025
> 
> | Số chuyến/ngày         | Mức thưởng         |
> | :--------------------- | :----------------- |
> | Từ chuyến thứ 14 trở lên | 3.000 VNĐ/chuyến |
> | Từ chuyến thứ 20 trở lên | 5.000 VNĐ/chuyến |
> 
> **Khu vực áp dụng:** Hà Nội
> **Điều kiện nhận thưởng:**
> * Tài xế trực tuyến vận doanh trong thời gian diễn ra chương trình thường
> * Tỷ lệ nhận chuyến, tỷ lệ hoàn thành chuyến >=90%

## 2. Chính sách hoạt động dịp Tết Nguyên đán 2025:

- Green SM Bike sẽ tiến hànhthu phí sử dụng xenếu Đối táckhông hoạt động vận doanh phát sinh chuyếntrong các ngày từ 22/01/2025 đến ngày 27/012025 (tương ứng từ ngày 23/12/2024 đến ngày 28/12/2024 âm lịch) và từ ngày 02/02/2025 đến ngày 07/02/2025 (tương ứng từ ngày 05/01/2025 đến ngày 10/01/2025 âm lịch).

- Green SM Bike sẽkhông thu phí sử dụng xevàkhông áp dụng mức khoán doanh sốtối thiểungày vận doanh trong các ngày 28/01/2025 đến ngày 01/02/2025 (tương ứng từ ngày 29/12/2024 đến ngày 04/01/2025 âm lịch).

Lưu ý:

Trong khoảng thời gian từ ngày 22/01/2025 đến 07/02/2025 (tương ứng từ ngày 23/12/2024 đến ngày 10/01/2025 âm lịch):

- Green SM Bike sẽkhông áp dụng chính sách đăng ký nghỉ phép.

- Green SM Bike sẽKhông áp dụng thu hồi xe nếu 03 ngày liên tiếp không vận doanh.

- Đối với các trường hợp Đối táchoàn trả xe thanh lý hợp đồngGreen SM Bike sẽkhông hỗ trợ việc đăng ký tái tuyển.

![CẬP NHẬT CHÍNH SÁCH THƯỞNG TẾT - ĐÓN NĂM MỚI THÊM XANH](https://cdn.xanhsm.com/2025/01/d3358d8a-image.png)

> **[Nội dung trích xuất từ ảnh]:**
> # CHÍNH SÁCH HOẠT ĐỘNG DỊP TẾT NGUYÊN ĐÁN 2025
> 
> | Thời gian                   | Thu phí sử dụng xe (Áp dụng: Toàn quốc)             | Doanh số tối thiểu (Áp dụng: Hà Nội)        |
> | :-------------------------- | :-------------------------------------------------- | :---------------------------------------- |
> | Từ 22-27/01/2025 (23-28/12 âm lịch) | 50.000 vnđ/ngày không phát sinh cuốc xe      | 250.000 vnđ/ngày vận doanh                |
> | Từ 28/01-01/02/2025 (29/12-04/01 âm lịch) | Không áp dụng                               | Không áp dụng                             |
> | Từ 02-07/02/2025 (05-10/01 âm lịch) | 50.000 vnđ/ngày không phát sinh cuốc xe      | 250.000 vnđ/ngày vận doanh                |
> 
> **Lưu ý:**
> Xanh SM Bike sẽ không áp dụng thu hồi xe nếu 03 ngày liên tiếp không vận doanh trong khoảng thời gian từ ngày 22/01/2025 đến 07/02/2025 (tức ngày 23/12/2024 đến ngày 10/01/2025 âm lịch).

Kính chúc Quý Đối tác Tài xế một mùa Tết an lành, thu nhập tăng nhanh cùng Green SM Bike!

Trân trọng,

Đội ngũ Green SM Bike
