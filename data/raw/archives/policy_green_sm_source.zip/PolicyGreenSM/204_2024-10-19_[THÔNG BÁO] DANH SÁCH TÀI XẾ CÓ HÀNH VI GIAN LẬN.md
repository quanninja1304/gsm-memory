# [THÔNG BÁO] DANH SÁCH TÀI XẾ CÓ HÀNH VI GIAN LẬN

- **Ngày đăng:** 2024-10-19
- **Chuyên mục:** Tài xế Green SM Bike, Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thong-bao-danh-sach-tai-xe-co-hanh-vi-gian-lan](https://www.greensm.com/vn-vi/news/thong-bao-danh-sach-tai-xe-co-hanh-vi-gian-lan)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

Các Bác Tài thân mến,

Gian lận là hành vi vi phạm nghiêm trọng quy định của GSM, sẽ phải chịu hình thức xử lý nghiêm khắc nhất của GSM, và có thể bị xem xét xử lý hình sự như sau:

- Chấm dứt Hợp đồng, truy thu toàn bộ số tiền gian lận (nếu có), yêu cầu bồi thường thiệt hại, đồng thời trừ thưởng theo Quy định của GSM;

- Nghiêm cấm tái tuyển dụng;

- Công bố danh sách trên website và bản tin của Công ty;

- Trường hợp nghiêm trọng, trình báo Cơ quan Công an để xem xét truy cứu trách nhiệm hình sự theo một trong các tội danh sau: Tội lừa đảo chiếm đoạt tài sản (Khoản 1 Điều 174 Bộ luật Hình sự 2015) hoặc Tội lạm dụng tín nhiệm chiếm đoạt tài sản (khoản 1 Điều 175 Bộ luật Hình sự 2015), với hình phạt không giam giữ đến 03 năm hoặc phạt tù từ 06 tháng đến 03 năm.

Kèm theo Thông báo danh sách các Tài xế/ Đối tác đã bị phát hiện, xử lý trong tháng 09/2024 do có hành vi gian lận trong quá trình vận doanh:

- Lỗi Nhóm 1 – Tổng số: 502 Tài xế/Đối tác theodanh sách chi tiết tại PL01;

- Lỗi Nhóm 2 – Tổng số: 2.615 Tài xế/Đối tác theodanh sách chi tiết tại PL02.

Để thể hiện trách nhiệm công dân với đất nước và trách nhiệm cá nhân với bản thân và gia đình cũng như với GSM, GSM yêu cầu các Bác Tài chấp hành nghiêm chỉnh các quy định đã được phổ biến/đào tạo.

Hãy chung tay xây dựng Cộng đồng Tài xế văn minh, chuyên nghiệp!Trân trọng,Đội ngũ Green SM
