# Lái taxi cần bằng gì? Luật mới 2025 & hướng dẫn thi bằng lái xe hạng B

- **Ngày đăng:** 2023-06-26
- **Chuyên mục:** Cộng đồng
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/lai-taxi-can-bang-gi](https://www.greensm.com/vn-vi/news/lai-taxi-can-bang-gi)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Lái taxi cần bằng gìtheo quy định mới nhất năm 2025? Từ ngày 1/1/2025, hệ thống bằng lái xe ở Việt Nam có sự thay đổi lớn. Bằng lái xe B2 chính thức bị loại bỏ, thay vào đó, tài xế taxi sẽ cần bằng lái xe hạng B trở lên để hành nghề. Đây là một thay đổi quan trọng mà tất cả những ai đang có ý định trở thành tài xế taxi cần nắm rõ.

## Lái taxi cần bằng lái xe hạng B, cập nhật từ 1/1/2025

Trước đây, để lái taxi, tài xế cần có giấy phép lái xe hạng B2, cho phép điều khiển xe ô tô chở người đến 9 chỗ ngồi; xe ô tô tải, máy kéo có trọng tải dưới 3.500 kg. Tuy nhiên, theo quy định mới, người lái taxi sẽ cần có bằng B.

![Từ 1/1/2025 lái taxi cần bằng lái xe hạng B để hành nghề (Ảnh: Sưu tầm Internet)](https://cdn.xanhsm.com/2025/03/68a5b101-lai-taxi-can-bang-gi-1.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> **BỘ GTVT**
> 
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
> Độc lập - Tự do - Hạnh phúc
> 
> **GIẤY PHÉP LÁI XE**
> 
> Số:
> 
> * Họ tên:
> * Ngày sinh:
> * Quốc tịch:
> * Nơi cư trú:
> 
> Hạng:
> 
> Có giá trị đến:
> ```

Từ 1/1/2025 lái taxi cần bằng lái xe hạng B để hành nghề (Ảnh: Sưu tầm Internet)

Điểm d, khoản 1, Điều 57,Luật trật tự, an toàn giao thông đường bộ 2024về Giấy phép lái xe nêu rõ: “hạng B được cấp cho người lái xe ô tô chở người đến 08 chỗ (không kể chỗ của người lái xe); xe ô tô tải và ô tô chuyên dùng có khối lượng toàn bộ theo thiết kế đến 3.500 kg; các loại xe ô tô quy định cho giấy phép lái xe hạng B kéo rơ moóc có khối lượng toàn bộ theo thiết kế đến 750 kg”.

## Bằng B2 có còn giá trị không? Cách đổi bằng lái xe theo luật mới

Nếu bạn thắc mắcbằng B2 theo quy định cũ có còn được sử dụng không?thì câu trả lời là có nếu bằng lái xe được cấp trước ngày 1/1/2025 và còn thời hạn sử dụng.

Theo Điều 89, Luật trật tự, an toàn giao thông đường bộ 2024 về Quy định chuyển tiếp, giấy phép lái xe được cấp trước ngày Luật này có hiệu lực thi hành được tiếp tục sử dụng theo thời hạn ghi trên giấy phép lái xe.

![Tài xế có bằng B2 cũ có thể tiếp tục sử dụng đến khi hết hạn (Ảnh: Sưu tầm Internet)](https://cdn.xanhsm.com/2025/03/4d9c4b6b-lai-taxi-can-bang-gi-2.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
> Độc lập - Tự do - Hạnh phúc
> GIẤY PHÉP LÁI XE/DRIVER'S LICENSE
> BỘ GTVT
> MOT
> 
> Số No:
> Họ tên/Full name
> Ngày sinh/Date of Birth
> Quốc tịch/Nationality
> Nơi cư trú/Address
> P. Lê Đại Hành,
> VIỆT NAM
> Hà Nội ngày 11 tháng 10 năm/year 2013
> T/L GIÁM ĐỐC SỞ
> TRƯỞNG PHÒNG QLVT
> NGUYỄN ĐÌNH NGHĨA
> Có giá trị đến/Expires: 11/10/2023
> 
> ---
> 
> CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
> Độc lập - Tự do - Hạnh phúc
> GIẤY PHÉP LÁI XE/DRIVER'S LICENSE
> BỘ GTVT
> MOT
> 
> Số No:
> Họ tên/Full name
> Ngày sinh/Date of Birth
> Quốc tịch/Nationality
> Nơi cư trú/Address
> P. Kiều Hồng, Q. Đ
> VIỆT NAM
> Hà Nội ngày
> Hang/Class: B1
> Có giá trị đến/Expires: 06/07/2043
> 
> ---
> 
> CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
> Độc lập - Tự do - Hạnh phúc
> GIẤY PHÉP LÁI XE/DRIVER'S LICENSE
> BỘ GTVT
> MOT
> 
> Số No:
> Họ tên/Full name
> Ngày sinh/Date of Birth
> Quốc tịch/Nationality
> Nơi cư trú/Address
> X. Kim Chung, H. Diên
> VIỆT NAM
> Thái Bình
> Hà Nội ngày
> Hang/Class: B2
> Có giá trị đến/Expires: 29/09/2028

Tài xế có bằng B2 cũ có thể tiếp tục sử dụng đến khi hết hạn (Ảnh: Sưu tầm Internet)

Như vậy, tài xế có bằng lái xe hạng B2 được cấp trước ngày 1/1/2025 vẫn còn thời hạn thì vẫn được tiếp tục sử dụng với hiệu lực như sau (nếu chưa thực hiện đổi, cấp lại theo quy định mới): “Giấy phép lái xe hạng B2 cấp cho người hành nghề lái xe được tiếp tục điều khiển xe ô tô chở người đến 08 chỗ (không kể chỗ của người lái xe); xe ô tô tải, máy kéo có trọng tải dưới 3.500 kg”.

Trường hợp tài xế có nhu cầu đổi, cấp lại giấy phép lái xe từ ngày 01/01/2025, giấy phép lái xe hạng B1, B2 được đổi, cấp lại sang giấy phép lái xe hạng B hoặc hạng C1 mới.

## Tài xế taxi Green SM cần bằng gì? Cơ hội lái taxi điện thu nhập cao

Để gia nhập đội ngũ Green SM, tài xế cần có bằng lái xe hạng B trở lên. Ngoài ra, tài xế cũng cần đáp ứng một số yêu cầu sau:

- Độ tuổi từ 18-65, có lý lịch tư pháp rõ ràng.

- Thông thạo địa lý khu vực.

- Tác phong chuyên nghiệp.

- Có kinh nghiệm làm việc tại các hãng xe công nghệ, taxi truyền thống, lái xe hợp đồng là một lợi thế.

![Green SM tuyển dụng tài xế taxi có bằng lái xe hạng B trở lên (Ảnh: Green SM)](https://cdn.xanhsm.com/2025/03/71a21695-lai-taxi-can-bang-gi-3-1024x691.png)

> **[Nội dung trích xuất từ ảnh]:**
> # GIA NHẬP ĐỘI NGŨ BÁC TÀI XANH
> 
> ## Thu nhập lên đến **25 TRIỆU/THÁNG**
> 
> **ỨNG TUYỂN NGAY**
> 
> (QR code)
> 
> ### Logo: BÁC TÀI XANH
> 
> ### Hình ảnh xe:
> *   NERIO GREEN
> *   HERIO GREEN

Green SM tuyển dụng tài xế taxi có bằng lái xe hạng B trở lên (Ảnh: Green SM)

Green SM đang tuyển dụng tài xế taxi trên toàn quốc! Nếu bạn mong muốn một công việc ổn định, thu nhập hấp dẫn từ 15-25 triệu/tháng, đây chính là cơ hội dành cho bạn. Ứng tuyển ngay vị trítài xế taxi Green SMvà cùng chúng tôi nhân rộng mô hình giao thông xanh.

## Điều kiện và hồ sơ đăng ký thi bằng lái xe hạng B

Để thi bằng lái xe hạng B, người lái taxi cần đáp ứng yêu cầu về độ tuổi, sức khoẻ và nộp đầy đủ hồ sơ dự thi theo quy định hiện hành.

### Điều kiện được dự thi sát hạch bằng lái xe hạng B

Người lái xe muốn dự sát hạch lái xe và được cấp bằng lái xe hạng B cần đáp ứng các điều kiện như sau:

- Đủ 18 tuổi trở lên (tính đến ngày dự sát hạch lái xe).

- Có sức khỏe phù hợp với loại xe, công dụng của xe. (Bộ trưởng Bộ Y tế chủ trì, phối hợp với Bộ trưởng Bộ Giao thông vận tải quy định về tiêu chuẩn sức khỏe của người lái xe, việc khám sức khỏe định kỳ đối với người lái xe ô tô và quy định về cơ sở y tế khám sức khỏe của người lái xe).

- Học đủ nội dung, chương trình đào tạo theo quy định; được cơ đào tạo lái xe xét hoàn thành khóa đào tạo lái xe theo mẫu quy định tại Phụ lục XXIII ban hành kèm theo Thông tư 35/2024/TT-BGTVT.

- Người dự sát hạch phải có tên trong danh sách học viên của báo cáo 1 đối với người dự sát hạch lần đầu.

![Người đủ 18 tuổi trở lên được cấp giấy phép lái xe hạng B (Ảnh: Green SM)](https://cdn.xanhsm.com/2025/03/e825bba0-lai-taxi-can-bang-gi-4.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> KHÔNG_CÓ_CHỮ

Người đủ 18 tuổi trở lên được cấp giấy phép lái xe hạng B (Ảnh: Green SM)

### Hồ sơ đăng ký thi bằng lái xe hạng B cho tài xế taxi

Theo Điều 29 về Hồ sơ dự sát hạch lái xe tạiThông tư 35/2024/TT-BGTVT, đối với người lái xe lần đầu muốn dự thi sát hạch thì cơ sở đào tạo lái xe lập 01 bộ hồ sơ, gửi trực tiếp tại Sở Giao thông vận tải, bao gồm:

- Đơn đề nghị học, sát hạch để cấp giấy phép lái xe theo mẫu quy định tại Phụ lục XI ban hành kèm theo Thông tư.

- Bản sao hoặc bản sao điện tử được chứng thực từ bản chính hoặc bản sao điện tử được cấp từ sổ gốc một trong các giấy tờ sau: thẻ tạm trú, thẻ thường trú, chứng minh thư ngoại giao, chứng minh thư công vụ (đối với người nước ngoài).

- Chứng chỉ sơ cấp hoặc chứng chỉ đào tạo hoặc xác nhận hoàn thành khóa đào tạo.

- Danh sách đề nghị sát hạch của cơ sở đào tạo lái xe có tên của người dự sát hạch

- Giấy khám sức khỏe của người lái xe do cơ sở khám bệnh, chữa bệnh đủ tiêu chuẩn theo quy định của pháp luật về khám bệnh, chữa bệnh cấp còn hiệu lực.

## Quy trình thi bằng lái xe hạng B cho tài xế taxi

Quy trình sát hạch lái xe hạng B bao gồm 3 vòng thi gồm sát hạch lý thuyết, mô phỏng và thi thực hành. Cụ thể như sau:

### Sát hạch lý thuyết

Phần thi lý thuyết bằng lái xe hạng B có nội dung câu hỏi liên quan đến quy định của pháp luật về trật tự, an toàn giao thông đường bộ, kỹ thuật lái xe; cấu tạo và sửa chữa thông thường; đạo đức người lái xe, văn hóa giao thông và phòng chống tác hại của rượu, bia khi tham gia giao thông, kỹ năng phòng cháy, chữa cháy và cứu nạn, cứu hộ.

- Số câu hỏi trắc nghiệm: 30 câu

- Thời gian làm bài: 20 phút

- Cách tính điểm: Mỗi câu hỏi được tính 1 điểm, trong đó có 1 câu điểm liệt.

- Điểm đạt: 27/30.

(Lưu ý, thí sinh trả lời sai câu điểm liệt sẽ không đạt nội dung sát hạch lý thuyết).

### Sát hạch mô phỏng các tình huống giao thông trên máy tính

Ở phần thi này, các tình huống mô phỏng được chạy liên tiếp tự động, thí sinh không được lựa chọn lại đáp án cho các câu hỏi đã trả lời hoặc chưa trả lời. Khi hoàn thành bài sát hạch mô phỏng hoặc hết thời gian của câu hỏi cuối cùng, toàn bộ các câu trả lời của thí sinh (kể cả các câu hỏi chưa trả lời hết) được máy tự động chấm điểm, in ra và lưu trữ tại máy chủ.

- Số câu hỏi trắc nghiệm: 10 câu

- Thời gian làm bài: Không quá 10 phút

- Cách tính điểm: Mỗi câu hỏi có số điểm tối đa là 5 điểm và số điểm tối thiểu là 0 điểm.

- Điểm đạt: 35/50.

![Thí sinh thi sát hạch mô phỏng trên máy tính (Ảnh: laodong.vn)](https://cdn.xanhsm.com/2025/03/a330e9bc-lai-taxi-can-bang-gi-5.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> TỔNG CỤC ĐƯỜNG BỘ VIỆT NAM
> PHẦN MỀM ÔN TẬP MÔ PHÒNG CÁC TÌNH HUỐNG GIAO THÔNG
> ```

Thí sinh thi sát hạch mô phỏng trên máy tính (Ảnh: laodong.vn)

### Sát hạch thực hành

Bài thi sát hạch thực hành bằng lái xe hạng B bao gồm phần thi thực hành lái xe trong hình và thực hành lái xe trên đường.

#### Phần thi lái xe trong hình

Đối với thí sinh dự sát hạch lái xe hạng B chuyển số tự động (bao gồm cả xe ô tô điện), B số cơ khí thực hiện liên hoàn 11 bài sát hạch lái xe trong hình gồm:

1. Xuất phát

2. Dừng xe nhường đường cho người đi bộ

3. Dừng và khởi hành xe ngang dốc

4. Qua vệt bánh xe và đường vòng vuông góc

5. Qua ngã tư có tín hiệu điều khiển giao thông

6. Qua đường vòng quanh co

7. Ghép xe dọc vào nơi đỗ

8. Ghép xe ngang vào nơi đỗ

9. Tạm dừng ở chỗ có đường sắt chạy qua

10. Thay đổi số trên đường bằng

11. Kết thúc

Trong quá trình sát hạch, thí sinh phải thực hiện đúng trình tự; chấp hành quy tắc giao thông đường bộ; giữ động cơ hoạt động liên tục; tốc độ động cơ không quá 4000 vòng/phút; tốc độ xe chạy không quá 24 km/h đối với xe hạng B; nếu không thực hiện được sẽ bị trừ điểm như quy định tại các bài sát hạch.

- Thời gian thực hành: 18 phút

- Điểm đạt: 80/100

#### Phần thi lái xe trên đường

Người dự thi thực hiện bài sát hạch lái xe trên đường giao thông công cộng, dài tối thiểu 02 km, có đủ tình huống theo quy định. Thí sinh thực hiện tối thiểu 04 bài sát hạch lái xe trên đường, gồm:

1. Xuất phát

2. Tăng số, tăng tốc độ

3. Giảm số, giảm tốc độ

4. Kết thúc.

![Thí sinh cần vượt qua tối thiểu 4 bài sát hạch lái xe trên đường (Ảnh: Green SM)](https://cdn.xanhsm.com/2025/03/ec34b60e-lai-taxi-can-bang-gi-6.jpg)

Thí sinh cần vượt qua tối thiểu 4 bài sát hạch lái xe trên đường (Ảnh: Green SM)

Trên quãng đường sát hạch, bài sát hạch “tăng số, tăng tốc độ”, “giảm số, giảm tốc độ” có thể thực hiện nhiều lần, không theo thứ tự.

- Thời gian thực hành: Không có thời gian giới hạn cụ thể.

- Điểm đạt: 80/100

Thí sinh đạt hết các phần thi thì sẽ được công nhận trúng tuyển và được cấp bằng lái xe hạng B.

Với những thay đổi trong luật giao thông từ năm 2025, bằng lái xe hạng B trở thành điều kiện bắt buộc để hành nghề lái taxi. Đây cũng là câu trả lời giải đáp thắc mắclái taxi cần bằng gì. Và nếu bạn đang sở hữu bằng lái xe phù hợp hãy tận dụng cơ hội ngay để gia nhập đội ngũ tài xế taxi Green SM!
