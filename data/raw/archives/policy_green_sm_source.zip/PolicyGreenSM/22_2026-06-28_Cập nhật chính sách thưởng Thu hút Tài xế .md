# Cập nhật chính sách thưởng Thu hút Tài xế 

- **Ngày đăng:** 2026-06-28
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-thu-hut-tai-xe](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thuong-thu-hut-tai-xe)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Từ ngày 25/06/2026, Green SM cập nhật một số nội dung liên quan tới chính sách thưởng thu hút Tài xế nói chung nhằm không ngừng phát triển mạnh mẽ cộng đồng Bác Tài Xanh tinh nhuệ, chuyên nghiệp và chuẩn 5 sao.

Green SM trân trọng mời các Bác Tài Xanh dành thời gian tìm hiểu kỹ các nội dung cập nhật của chính sách, đồng thời tích cực chia sẻ thông tin đến bạn bè, người thân và các ứng viên tiềm năng để cùng chung tay xây dựng một cộng đồng tài xế chất lượng, văn minh và bền vững.

Chi tiết các nội dung cập nhật:

Dành cho Bác Tài Xanh mới| Chương trình thưởng nóng thu hút Tài xế:

Các Bác Tài Xanh mới khi gia nhập Công ty sẽ nhận được 01 mức thưởng nếu đáp ứng các điều kiện, cụ thể như sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/59a245a3-thumb-chinh-sach-thuong-thu-hut-tai-xe.png)

> **[Nội dung trích xuất từ ảnh]:**
> DRIVER
> GREEN SM
> BÁC TÀI XANH TAXI
> Cập nhật chính sách
> Thưởng thu hút Tài xế
> GREEN SM
> GREEN SM
> ✓ GREEN SM

| CHƯƠNG TRÌNH THƯỞNG NÓNG THU HÚT TÀI XẾ |
| --- |
| Depot | Hà Nội 1, 2, 3 HCM 1, 6, 7 | An Giang 1 Khánh Hòa 1, 2 Quảng Ngãi 2 | Đắk Lắk 1 (Phú Yên cũ) |
| Thờigian | Từ 25/06/2026 cho đến 31/07/2026 |
| Đốitượng | Bác Tài Xanh Taxi mới đăng ký làm việc tại các depot trên và gia nhập trong thời gian diễn ra chương trình (Không áp dụng với Bác Tài Xanh tái tuyển dụng) |
| Mứcthưởng(Trước thuế) | 3.000.000đ/Bác Tài Xanhvà nhận thưởng 01 lần vào kỳ lương | 2.100.000đ/Bác Tài Xanhvà nhận thưởng theo giai đoạn như sau:🔰 Tháng đầu tiên (30 ngày): 700.000đ🔰 Tháng thứ 2 (30 ngày tiếp theo): 700.000đ🔰 Tháng thứ 3: 700.000đ |
| Điềukiện | ✅ Hoàn thành 03 tháng đào tạo (90 ngày đầu) và ký HĐ chính thức.✅ Hoàn thành tối thiểu 200 chuyến/ tháng (30 ngày)✅ Doanh số chuyến trung bình đạt từ 80.000đ trở lên trong giai đoạn 03 tháng đào tạo (90 ngày đầu) | ✅ Hoàn thành 150 chuyến/ tháng (30 ngày)✅ Doanh số chuyến trung bình đạt từ 70.000 đ trở lên theo từng tháng của mốc chi thưởng. | ✅ Bác Tài Xanh hoàn thành 03 tháng đào tạo (90 ngày đầu) và không có thông tin ghi nhận nghỉ việc vào thời điểm chi trả thưởng.✅ Bác Tài Xanh có thẻ nghiệp vụ vận tải từ các hãng Mai Linh, Taxi Sun, Lado, Let’s go, Grab, Taxi Sao✅ Hoàn thành 200 chuyến/tháng (30 ngày) theo từng tháng của mốc chi thưởng |
| Hìnhthứcchi trả | – Kiểm tra điều kiện của từng đợt, khi Bác Tài Xanh trong thời gian diễn ra chương trình “hoàn thành 03 tháng đào tạo”– Chi thưởng vào Lương của Bác Tài Xanh trong tháng T+1 khi đạt điều kiện của tháng T– Không có thông tin nghỉ việc tại thời điểm chi trả | – Kiểm tra điều kiện của từng tháng: Tháng đầu tiên, tháng thứ 2, tháng thứ 3 để xét thưởng. Đạt thưởng tháng nào chi thưởng tháng đó với số tiền thưởng tương ứng của từng tháng.– Chi thưởng vào Ví Tài xế trong tháng T+1 khi đạt điều kiện thưởng của tháng T– Không có thông tin nghỉ việc tại thời điểm chi trả |
| Hoàntrả | Không áp dụng |

Lưu ý:

Chương trình thưởng thu hút áp dụng với khu vực Depot HCM8 sẽ tạm dừng từ 25/06/2026 cho tới khi có thông báo mới nhất.

Bên cạnh đó, các chương trình thưởng khi giới thiệu thành công Tài xế mới dành cho các Bác Tài Xanh vẫn tiếp tục được triển khai. Hãy cùng liên hệ với Đội xe để được hỗ trợ giải đáp các chương trình/chính sách hiện hữu liên quan tới thưởng thu hút nhé.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
