# Hướng dẫn phân luồng di chuyển tại sân bay Nội Bài 

- **Ngày đăng:** 2026-08-06
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/huong-dan-phan-luong-di-chuyen-tai-san-bay-noi-bai-1](https://www.greensm.com/vn-vi/news/huong-dan-phan-luong-di-chuyen-tai-san-bay-noi-bai-1)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm đảm bảo vận hành đúng quy định của Cảng HKQT Nội Bài áp dụng từ 09h00 ngày 05/08/2026, Green SM gửi tới Bác Tài Xanh hướng dẫn phân luồng di chuyển quan trọng như sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/08/a659110e-san-bay-noi-bai-2-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> DRIVER
> GREEN SM
> THÔNG BÁO MỚI
> VẬN HÀNH TẠI SÂN BAY QUỐC TẾ NỘI BÀI
> 
> GREEN SM
> GREEN SM
> GREEN SM
> 
> *Hình ảnh sân bay chỉ mang tính chất minh họa

✈️ NHÀ GA T2 (QUỐC TẾ)

✅ ĐÓN KHÁCH

– Hành khách sử dụng ứng dụng gọi xe sẽ được hướng dẫn di chuyển ra bãi đỗ P1 sử dụng dịch vụ.

– Bác Tài Xanh Green SM và các ứng dụng gọi xe công nghệ khác: được phép đỗ chờ và đón khách tại bãi P1.

– Trường hợp bãi P1 đầy, xe sẽ được điều tiết sang bãi P7 để chờ đón khách.

⛔ Không đón khách tại khu vực làn giao thông trước sảnh đến tầng 1 nhà ga T2.

✅ TRẢ KHÁCH

– Bác Tài Xanh được phép trả khách tại tầng 3 nhà ga T2 theo làn giao thông được phân luồng dành cho xe dưới 09 chỗ:

+ Hướng đi từ cầu Nhật Tân: Làn 1 (cột 1-6)

+ Hướng đi từ Cầu Thăng Long/bãi xe P4: Làn 4

– Sau khi trả khách, xe phải rời khu vực theo hướng lưu thông quy định.

⛔ Tuyệt đối không đón khách tại tầng 3 nhà ga T2.

⏱️ Thời gian dừng trả khách đối với xe dưới 09 chỗ: không quá 02 phút, lái xe không được rời khỏi phương tiện quá 02m.

✈️ NHÀ GA T1 (NỘI ĐỊA)

✅ ĐÓN KHÁCH

–  Xe dịch vụ dưới 9 chỗ/xe công nghệ (mang biển số vàng) được phép đón hành khách tại làn 3 phía trước sảnh E, nhà ga T1

– Để đảm bảo giao thông thông suốt, mỗi phương tiện chỉ được dừng đón khách tại làn 3 trong thời gian tối đa 3 phút

– Lộ trình tiếp cận: Từ đường gom Võ Văn Kiệt vào Nhà ga T1. Rẽ trái theo hướng dẫn vào khu vực bãi đỗ P2 để đón khách

⛔ Cấm rẽ phải vào khu vực bãi đỗ P1 và vào khu vực sảnh đón nhà ga T1 để đón khách.

⛔ Không được dừng/đỗ đón khách tại các làn giao thông trước nhà ga, tầng 1 nhà ga T1.

✅ TRẢ KHÁCH

– Xe công nghệ dưới 09 chỗ tiến hành trả khách từ cột 01-07 tại làn 3. (Xe đi từ hướng cầu Thăng Long lên trả khách)

– Sau khi trả khách, phương tiện phải rời nhà ga theo hướng quy định; nếu có nhu cầu vào bãi đỗ phải tiếp cận lại từ đường gom Võ Văn Kiệt.

⛔ Xe công nghệ dưới 09 chỗ không được đi vào làn 01 và làn 02 tầng 2 nhà ga T1.

⏱️ Thời gian dừng trả khách đối với xe dưới 09 chỗ: không quá 02 phút, lái xe không được rời khỏi phương tiện quá 02m.

⚠️ Lưu ý quan trọng:Đối với xe không thuộc đội sân baychỉ đón khách tại các bãi đỗ được quy định (P1/P7 đối với nhà ga T2 và P2 đối với T1). Không dừng, đỗ hoặc đón khách tại khu vực trước sảnh nhà ga ngoài phạm vi cho phép. Việc vi phạm phân luồng có thể bị lực lượng chức năng và Cảng HKQT Nội Bài xử lý theo quy định.

Mến chúc Bác Tài Xanh vận doanh an toàn & hiệu quả!

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
