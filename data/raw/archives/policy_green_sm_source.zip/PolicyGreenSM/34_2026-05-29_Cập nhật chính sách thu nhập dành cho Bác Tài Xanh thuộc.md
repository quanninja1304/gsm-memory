# Cập nhật chính sách thu nhập dành cho Bác Tài Xanh thuộc nhóm “Đối tác Tài xế sử dụng xe thuê” 

- **Ngày đăng:** 2026-05-29
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thu-nhap-danh-cho-bac-tai-xanh-thuoc-nhom-doi-tac-tai-xe-su-dung-xe-thue](https://www.greensm.com/vn-vi/news/cap-nhat-chinh-sach-thu-nhap-danh-cho-bac-tai-xanh-thuoc-nhom-doi-tac-tai-xe-su-dung-xe-thue)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,Green SM cập nhật thông tin mới nhất về chính sách thu nhập dành cho Bác Tài Xanh thuộc nhóm “Đối tác Tài xế sử dụng xe thuê”. Việc điều chỉnh nhằm tạo động lực và khuyến khích các Bác Tài Xanh luôn nỗ lực cao để đạt thu nhập đúng kỳ vọng đồng thời duy trì chất lượng dịch vụ 5 sao chuyên nghiệp – an toàn – ổn định tới Khách hàng.

Cụ thể như sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/05/7af0f82d-bang-1-chinh-sach-thu-nhap-cho-dttx-sd-xe-thue-1-1-736x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> DRIVER
> GREEN SM
> 
> | Tiêu đề         | Nội dung                                                                                                                                                                                                                                                                                                                                |
> | :-------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | **Đối tượng áp dụng** | Trong phạm vi chính sách này, đối tượng áp dụng được hiểu là các cá nhân thuộc một trong các nhóm sau, đăng ký tham gia với vai trò "Bác Tài Xanh là Đối tác Tài xế sử dụng xe thuê" (gọi chung là "Bác Tài Xanh"):<br>- Cá nhân có sở hữu xe xăng/chạy xe dịch vụ bằng xe xăng<br>- Cá nhân đã nghỉ việc tại Green SM tối thiểu 3 tháng trước ngày 30/11/2025 và không vi phạm lỗi nhóm 1<br>- Cá nhân đã đặt cọc xe theo mô hình thuê sở hữu qua Green SM Platform và đang chờ nhận xe |
> | **Thời gian áp dụng** | Từ 09/03/2026 cho đến khi có thông báo mới                                                                                                                                                                                                                                                                                              |
> | **Dòng xe áp dụng**   | VF5/Herio Green và Limo Green                                                                                                                                                                                                                                                                                                         |
> 
> **CHƯƠNG TRÌNH THƯỞNG "HIỆU QUẢ VẬN DOANH"**
> 
> Bác Tài Xanh sẽ được xét thưởng theo doanh số đạt được hoặc số chuyến hoàn thành trong tháng, kỳ xét thưởng tính từ ngày đầu tiên đến ngày cuối cùng của tháng dương lịch.
> 
> | DÒNG XE          | KHU VỰC ÁP DỤNG                                                                                                      | MỨC THƯỞNG                                                               | ĐIỀU KIỆN XÉT THƯỞNG                                                                          |
> | :--------------- | :------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------- |
> |                  | Hà Nội và Tp. Hồ Chí Minh (theo địa giới hành chính cũ)                                                              | Giảm 30% phí dịch vụ tháng tiếp theo                                     | Tổng doanh thu ≥ 25.000.000đ/tháng hoặc ≥ 250 chuyến/tháng                                   |
> |                  |                                                                                                                      | Giảm 50% phí dịch vụ tháng tiếp theo                                     | Tổng doanh thu ≥ 32.000.000đ/tháng hoặc ≥ 320 chuyến/tháng                                   |
> | **VF5/ Herio Green** |                                                                                                                      | Giảm 100% phí dịch vụ tháng tiếp theo                                    | Tổng doanh thu ≥ 45.000.000đ/tháng hoặc ≥ 450 chuyến/tháng                                   |
> |                  | Bình Dương, Bà Rịa - Vũng Tàu (theo địa giới hành chính cũ), Phú Quốc và Đà Nẵng (theo địa giới hành chính mới) | Giảm 30% phí dịch vụ tháng tiếp theo                                     | Tổng doanh thu ≥ 20.000.000đ/tháng hoặc ≥ 200 chuyến/tháng                                   |
> |                  |                                                                                                                      | Giảm 50% phí dịch vụ tháng tiếp theo                                     | Tổng doanh thu ≥ 25.600.000đ/tháng hoặc ≥ 256 chuyến/tháng                                   |
> |                  |                                                                                                                      | Giảm 100% phí dịch vụ tháng tiếp theo                                    | Tổng doanh thu ≥ 36.000.000đ/tháng hoặc ≥ 360 chuyến/tháng                                   |
> | **Limo Green**   | Hà Nội, Tp. Hồ Chí Minh, Đà Nẵng (theo địa giới hành chính mới)                                                      | Giảm 30% phí dịch vụ tháng tiếp theo                                     | Tổng doanh thu ≥ 25.000.000đ/tháng hoặc ≥ 250 chuyến/tháng                                   |
> |                  |                                                                                                                      | Giảm 50% phí dịch vụ tháng tiếp theo                                     | Tổng doanh thu ≥ 33.000.000đ/tháng hoặc ≥ 330 chuyến/tháng                                   |
> |                  |                                                                                                                      | Giảm 100% phí dịch vụ tháng tiếp theo                                    | Tổng doanh thu ≥ 46.000.000đ/tháng hoặc ≥ 460 chuyến/tháng                                   |

Chương trình gói ưu đãi giá thuê từng dòng xe:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/05/501600ee-bang-2-chinh-sach-thu-nhap-cho-dttx-sd-xe-thue-copy-1-700x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> ## CHƯƠNG TRÌNH GÓI ƯU ĐÃI GIÁ THUÊ TỪNG DÒNG XE
> 
> ### DÒNG XE: VF5/HERIO GREEN
> 
> | Hạng mục              | GÓI CƠ BẢN 13.500.000Đ | GÓI ƯU ĐÃI 12.000.000Đ |
> | :-------------------- | :--------------------- | :--------------------- |
> | Phí dịch vụ/tháng     |                        | Áp dụng phí dịch vụ tương đương Gói ưu đãi cho 500 Bác Tài Xanh đăng ký đầu tiên trong thời gian áp dụng từ 15/05-30/06/2026 |
> | **Điều kiện áp dụng** |                        | Tỷ lệ chấp nhận chuyến và hoàn thành chuyến trung bình tháng đạt ≥ 85% |
> |                       |                        | Lưu ý: Trong trường hợp Bác Tài Xanh không đáp ứng các điều kiện trên, mức phí dịch vụ sẽ được chuyển về gói cơ bản |
> | Hình thức thu tiền    | 3.375.000đ/tuần        | 3.000.000đ/tuần        |
> | Thời hạn thuê (Thời gian sử dụng xe) | 06 tháng kể từ ngày nhận xe | 06 tháng kể từ ngày nhận xe |
> | Tiền cọc (\*)         | 7.000.000đ             | 7.000.000đ             |
> | Hình thức thu cọc     | Tổng số tiền cọc được thu thành nhiều kỳ, trong đó BTXT thanh toán: <br> - 1.000.000đ khi phỏng vấn <br> - 3.000.000đ khi đào tạo & bàn giao xe <br> - 150.000đ trừ ví mỗi ngày kể từ khi bắt đầu vận doanh cho đến khi hoàn thành | Tổng số tiền cọc được thu thành nhiều kỳ, trong đó BTXT thanh toán: <br> - 1.000.000đ khi phỏng vấn <br> - 3.000.000đ khi đào tạo & bàn giao xe <br> - 150.000đ trừ ví mỗi ngày kể từ khi bắt đầu vận doanh cho đến khi hoàn thành |
> 
> ### DÒNG XE: LIMO GREEN
> 
> | Hạng mục              | GÓI CƠ BẢN 20.000.000Đ | GÓI ƯU ĐÃI 18.000.000Đ |
> | :-------------------- | :--------------------- | :--------------------- |
> | Phí dịch vụ/tháng     |                        | Áp dụng phí dịch vụ tương đương Gói ưu đãi cho 100 Bác Tài Xanh đăng ký đầu tiên trong thời gian áp dụng từ 09/03-15/05/2026 |
> | Hình thức thu tiền    | 5.000.000đ/tuần        | 4.500.000đ/tuần        |
> | Thời hạn thuê (Thời gian sử dụng xe) | 06 tháng kể từ ngày nhận xe | 06 tháng kể từ ngày nhận xe |
> | Tiền cọc (\*)         | 10.000.000đ            | 10.000.000đ            |
> 
> (\*): Áp dụng miễn phí tiền cọc cho Bác Tài Xanh đã đặt cọc mua xe/cọc xe theo mô hình thuê xe sở hữu qua Green SM Platform và đang chờ nhận xe. Trong trường hợp hủy hợp đồng, Bác Tài Xanh sẽ nhận lại được khoản tiền đã cọc trước đó.
> 
> ## MỨC KHOÁN DOANH SỐ ÁP DỤNG CHO MỖI DÒNG XE
> 
> | MỤC KHOÁN DOANH SỐ              | VF5/HERIO GREEN | LIMO GREEN |
> | :------------------------------ | :-------------- | :--------- |
> | KHOÁN DOANH SỐ TUẦN (THÁNG CAO ĐIỂM) | 6.600.000Đ      | 7.500.000Đ |
> | KHOÁN QUY ĐỔI NGÀY (THÁNG CAO ĐIỂM) | 1.100.000Đ      | 1.250.000Đ |
> | KHOÁN DOANH SỐ TUẦN (THÁNG THẤP ĐIỂM) | 5.400.000Đ      | 6.600.000Đ |
> | KHOÁN QUY ĐỔI NGÀY (THÁNG THẤP ĐIỂM) | 900.000Đ        | 1.100.000Đ |
> ```

Mọi thắc mắc vui lòng liên hệ Đội xe/Giám sát vận hành để được hỗ trợ!

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
