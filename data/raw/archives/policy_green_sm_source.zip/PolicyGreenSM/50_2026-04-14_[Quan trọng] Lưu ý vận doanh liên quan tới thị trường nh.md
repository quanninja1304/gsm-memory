# [Quan trọng] Lưu ý vận doanh liên quan tới thị trường nhượng quyền

- **Ngày đăng:** 2026-04-14
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/quan-trong-luu-y-van-doanh-lien-quan-toi-thi-truong-nhuong-quyen](https://www.greensm.com/vn-vi/news/quan-trong-luu-y-van-doanh-lien-quan-toi-thi-truong-nhuong-quyen)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/04/07d79c7c-thitruongnhuongquyen-1-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # Lưu ý vận hành liên quan tới thị trường nhượng quyền
> 
> **GREEN SM**
> ```

Bác Tài Xanh thân mến,

Nhằm đảm bảo hoạt động vận doanh tuân thủ đúng quy định và đảm bảo quyền lợi lâu dài, Green SM gửi tới Bác Tài Xanh thuộc nhóm Đối tác Tài xế sử dụng xe thuê một số thông tin quan trọng:

⚠️ Lưu ý về thị trường nhượng quyền:

- Dựa theo quy định của chính sách hiện hành, Bác Tài Xanh thuộc nhóm “Đối tác Tài Xế sử dụng xe thuê” không thực hiện triển khai vận doanh tại các thị trường nhượng quyền.

- Trường hợp di chuyển sang các thị trường nhượng quyền để vận doanh: hệ thống sẽ tự động dừng phát chuyến xe tại các khu vực này. Quy định này nhằm đảm bảo việc triển khai đúng mô hình, thống nhất phạm vi vận hành và quản lý.

✨ Danh sách các thị trường nhượng quyền(theo địa giới hành chính cũ):

| Thị trường | Miền |
| --- | --- |
| Đắk Lắk | Miền Trung (Tây Nguyên) |
| Hải Phòng | Miền Bắc |
| Vĩnh Phúc | Miền Bắc |
| Tuyên Quang | Miền Bắc |
| Phú Thọ | Miền Bắc |
| Lạng Sơn | Miền Bắc |
| Cao Bằng | Miền Bắc |
| Vĩnh Long | Miền Nam |
| Bạc Liêu | Miền Nam |
| Sóc Trăng | Miền Nam |
| Kiên Giang | Miền Nam |
| An Giang | Miền Nam |
| Cà Mau | Miền Nam |
| Lâm Đồng | Miền Trung (Tây Nguyên) |
| Bình Định | Miền Trung |
| Bình Thuận | Miền Trung |
| Sa Pa (Lào Cai) | Miền Bắc |
| Đắk Nông | Miền Trung (Tây Nguyên) |
| Bắc Giang | Miền Bắc |
| Yên Bái | Miền Bắc |
| Hà Tĩnh | Miền Trung |
| Nghệ An | Miền Trung |
| Điện Biên | Miền Bắc |
| Sơn La | Miền Bắc |

✨ Kênh liên lạc hỗ trợ từ Green SM:Vui lòng liên hệ các kênh liên lạc sau để được hỗ trợ giải đáp các thắc mắc:💙 Zalo OA:https://zalo.me/xanhplatformofficial💙 Fanpage:https://www.facebook.com/XanhPlatformOfficial

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
