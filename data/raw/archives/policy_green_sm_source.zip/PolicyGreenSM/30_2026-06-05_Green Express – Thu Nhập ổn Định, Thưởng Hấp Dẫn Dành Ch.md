# Green Express – Thu Nhập ổn Định, Thưởng Hấp Dẫn Dành Cho Bác Tài Xanh Chuyên Express

- **Ngày đăng:** 2026-06-05
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thu-nhap-on-dinh-thuong-hap-dan-danh-cho-bac-tai-xanh-chuyen-express](https://www.greensm.com/vn-vi/news/thu-nhap-on-dinh-thuong-hap-dan-danh-cho-bac-tai-xanh-chuyen-express)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến

Green Expresschính thức triển khai chính sách vận doanh hấp dẫn dành cho Bác Tài Xanh với nhiều quyền lợi nổi bật, hỗ trợ tăng thu nhập ổn định và tối ưu hiệu suất hoạt động.

I. CHÍNH SÁCH THU NHẬP

💰 Đảm bảo thu nhập lên đến450.000đ/ngày

Điều kiện áp dụng:

- Hoàn thành tối thiểu 70 điểm giao/ngày hoặc 420 điểm/tuần

- Tỷ lệ nhận chuyến & tỷ lệ giao thành công >= 80%

- Hoạt động tối thiểu 8 tiếng/ngày

- Trong trường hợp chưa đạt điều kiện tối thiểu hoặc vượt mốc 70 điểm giao/ngày:

👉 Bác Tài được hưởng mức chia sẻ6.500đ/điểmgiao thành công.

🎁 Thưởng thêm 500đ/điểm giao thành công

Điều kiện áp dụng:

- Điểm đánh giá dịch vụ từ 4.9*

- Tỷ lệ giao thành công từ 80%

- Tỷ lệ hoàn hàng dưới 5%

🛵 Khi trở thành Bác Tài chuyên Express

Bác Tài sẽ được hỗ trợ mượn công cụ vận hành như:

- Càng/Baga giao hàng

- Sọt giao hàng cỡ lớn

- Bọc sọt thương hiệu GSM

![Green Express - Thu Nhập ổn Định, Thưởng Hấp Dẫn Dành Cho Bác Tài Xanh Chuyên Express](https://cdn.xanhsm.com/2026/06/9a301717-2-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # GREEN SM
> ## GREEN EXPRESS – THU NHẬP ỔN ĐỊNH
> ### THƯỞNG HẤP DẪN DÀNH CHO BÁC TÀI XANH CHUYÊN EXPRESS
> 
> ---
> 
> ### CHÍNH SÁCH THU NHẬP
> Lên đến **450.000đ/ngày**
> 
> #### ĐIỀU KIỆN:
> *   Hoàn thành tối thiểu 70 điểm giao/ngày hoặc 420 điểm/tuần
> *   Tỷ lệ nhận chuyến & tỷ lệ giao thành công >= 80%
> *   Hoạt động tối thiểu 8 tiếng/ngày
> 
> Trong trường hợp chưa đạt điều kiện tối thiểu hoặc vượt mốc 70 điểm giao/ngày:
> *   Bác Tài được hưởng mức chia sẻ 6.500đ/điểm giao thành công.
> *   Thưởng thêm 500đ/điểm giao thành công.
> 
> ---
> 
> ### YÊU CẦU
> *   Điểm đánh giá dịch vụ từ **4.9** ⭐
> *   Tỷ lệ giao thành công từ **80%**
> *   Tỷ lệ hoàn hàng dưới **5%**
> 
> ---
> 
> ### QUYỀN LỢI
> Khi trở thành Bác Tài chuyên Express Bác Tài sẽ được hỗ trợ mượn dụng cụ vận hành như:
> *   Càng/Baga giao hàng
> *   Sọt giao hàng cỡ lớn
> *   Bọc sọt thương hiệu GSM

🚀 Đăng ký ngay:TẠI ĐÂYđể gia nhập Biệt đội Chuyên Express và tối ưu thu nhập mỗi ngày!

II. QUY TRÌNH THỰC HIỆN ĐƠN HÀNG

1. QUY TRÌNH GIAO HÀNG

Bước 1: Chấp nhận đơn & di chuyển đến Hub nhận hàng

- Nhận đơn trên ứng dụng Green SM.

- Sau khi nhận đơn, Bác Tài di chuyển đến Hub nhận hàng trong vòng 30 phút theo quy định.

Bước 2: Kiểm tra & nhận hàng tại Hub

- Xuất trình ứng dụng Tài xế cho bảo vệ hoặc nhân viên kho để nhận hàng.

- Kiểm tra kỹ số lượng hàng hóa, tình trạng kiện hàng và ngoại quan sản phẩm trước khi nhận.

- Từ chối nhận và báo ngay cho nhân viên kho nếu phát hiện kiện hàng có dấu hiệu hư hỏng, cạy mở hoặc không đảm bảo chất lượng.

- Ký xác nhận nhận hàng sau khi hoàn tất kiểm tra.

- Sắp xếp hàng hóa lên sọt giao hàng gọn gàng, đảm bảo an toàn trong quá trình vận chuyển và tuân thủ quy định giao thông.

Bước 3: Giao hàng đến người nhận

- Liên hệ khách hàng trước thời gian giao dự kiến từ 10 – 15 phút ), thông báo thời gian giao hàng dự kiến.

- Trường hợp khách không nghe máy, thực hiện tối thiểu 03 cuộc gọi và gửi tin nhắn thông báo.

- Thông báo chính xác số tiền COD cần thu (nếu có).

- Thực hiện giao hàng theo đúng ghi chú trên đơn hàng.

Đối với đơn hàng có yêu cầu (ghi chú trên đơn):

- “Không cho xem hàng”: Không cho khách xem hàng trước khi hoàn tất thanh toán và ký nhận.

- “Cho xem/đồng kiểm”: Cho khách kiểm tra hàng hóa và thực hiện quay video quá trình mở hàng theo quy định.

Bước 4: Xác nhận giao hàng thành công

- Yêu cầu khách hàng ký nhận trên tem giao hàng.

- Chụp ảnh xác thực giao hàng bao gồm hàng hóa, mã vận đơn, chữ ký người nhận và địa điểm giao hàng.

- Chỉ xác nhận giao hàng thành công sau khi đã hoàn tất việc giao hàng và thu đủ tiền COD (nếu có).

- Đối với trường hợp giao cho người nhận hộ hoặc giao tại quầy/lễ tân, cần có xác nhận từ người nhận theo quy định.

- Cập nhật trạng thái giao hàng trên ứng dụng ngay sau khi hoàn thành giao hàng.

📌 Chi tiết thao tác vui lòng tham khảo hình ảnh hướng dẫn bên dưới.

![Green Express - Thu Nhập ổn Định, Thưởng Hấp Dẫn Dành Cho Bác Tài Xanh Chuyên Express](https://cdn.xanhsm.com/2026/06/ef2abb01-3-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # QUY TRÌNH GIAO HÀNG
> 
> ## BƯỚC 1: CHẤP NHẬN ĐƠN
> *   **Mô tả:** Màn hình ứng dụng hiển thị bản đồ với các điểm giao hàng.
> *   **Chi tiết:**
>     *   Điểm 2: Địa điểm (có thể là điểm đến hoặc điểm lấy hàng).
>     *   Mã đơn hàng: (không hiển thị rõ số liệu)
>     *   Thu tổng cộng: **95.100₫** (hiển thị trên màn hình ứng dụng)
> *   **Thao tác:** Nút "Xác nhận"
> 
> ## BƯỚC 2: LẤY HÀNG TẠI KHO GHN
> *   **Mô tả:** Màn hình ứng dụng xác nhận giao hàng.
> *   **Chi tiết:**
>     *   Mã đơn hàng: **260331UXDEXJXT**
>     *   Thu tiền mặt: (có nút bật/tắt)
>     *   Thu tổng cộng: **95.100₫**
>     *   Ảnh nhận hàng (có chỗ để chụp ảnh)
>     *   Ảnh giao hàng (có chỗ để chụp ảnh)
> *   **Thao tác:** Nút "Xác nhận"
> 
> ## BƯỚC 3: GIAO HÀNG CHO NGƯỜI NHẬN
> *   **Chi tiết:**
>     *   **BÁO TRƯỚC CHO KHÁCH 10 - 15 PHÚT, GỌI ÍT NHẤT 03 LẦN VÀ NHẮN TIN NẾU KHÁCH KHÔNG NGHE MÁY.**
>     *   **THÔNG BÁO CHÍNH XÁC SỐ TIỀN THU HỘ (COD) VÀ GIAO ĐÚNG GHI CHÚ TRÊN ĐƠN.**
>     *   **QUY ĐỊNH KIỂM HÀNG:**
>         *   **KHÔNG CHO XEM HÀNG:** KHÁCH PHẢI THANH TOÁN VÀ KÝ NHẬN TRƯỚC.
>         *   **CHO XEM/ĐỒNG KIỂM:** CHO KHÁCH KIỂM TRA VÀ BẮT BUỘC QUAY VIDEO QUÁ TRÌNH MỞ HÀNG THEO ĐÚNG QUY ĐỊNH.
> 
> ## BƯỚC 4: XÁC NHẬN GIAO HÀNG THÀNH CÔNG
> *   **Mô tả:** Màn hình ứng dụng hiển thị thông báo giao hàng thành công.
> *   **Chi tiết:**
>     *   "Tuyệt vời! Bạn vừa hoàn tất đơn Xanh Express 2H"
> *   **Thao tác:** Nút "Tuyệt vời"

2. Quy trình hoàn hàng (nếu giao đơn thất bại)

Bước 1: Cập nhật giao hàng thất bại

- Cập nhật đúng lý do giao thất bại trên ứng dụng.

- Bổ sung đầy đủ bằng chứng theo quy định.

Bước 2: Hoàn trả hàng về Hub

- Mang hàng hoàn về Hub và bàn giao cho nhân viên kho.

- Xác nhận hoàn hàng trên ứng dụng.

Bước 3: Đối soát & kết thúc ca

- Kiểm tra tiền COD và hàng hoàn.

- Hoàn tất đối soát theo quy định trước khi kết thúc ca vận doanh.

📌 Chi tiết thao tác vui lòng xem tại hình ảnh hướng dẫn bên dưới.

![Quy trình hoàn hàng (nếu giao đơn thất bại)](https://cdn.xanhsm.com/2026/06/98fc4b7d-4-1024x576.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # GREEN SM
> 
> ## QUY TRÌNH HOÀN HÀNG
> 
> ### BƯỚC 1: CẬP NHẬT GIAO HÀNG THẤT BẠI
> *   CẬP NHẬT ĐÚNG LÝ DO GIAO THẤT BẠI TRÊN ỨNG DỤNG
> *   BỔ SUNG ĐẦY ĐỦ BẰNG CHỨNG THEO QUY ĐỊNH
> 
> ### BƯỚC 2: HOÀN TRẢ HÀNG VỀ HUB
> *   MANG HÀNG HOÀN VỀ HUB VÀ BÀN GIAO CHO NHÂN VIÊN KHO
> *   XÁC NHẬN HOÀN HÀNG TRÊN ỨNG DỤNG
> 
> ### BƯỚC 3: ĐỐI SOÁT & KẾT THÚC CA
> *   KIỂM TRA TIỀN COD VÀ HÀNG HOÀN
> *   HOÀN TẤT ĐỐI SOÁT THEO QUY ĐỊNH TRƯỚC KHI KẾT THÚC CA VẬN DOANH

Trân trọng,

Đội ngũ Green SM Bike
