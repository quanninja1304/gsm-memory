# Điểm Tin Vận Doanh Tuần Qua: Nhìn Lại Những Chính Sách Nổi Bật, Thưởng Mới & Cập Nhật Quan Trọng Tuần 1 Tháng 08

- **Ngày đăng:** 2026-08-12
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/diem-tin-van-doanh-tuan-1-thang-8](https://www.greensm.com/vn-vi/news/diem-tin-van-doanh-tuan-1-thang-8)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Tuần đầu tháng 08/2026khép lại với nhiều thông tin đáng chú ý dành choBác Tài Xanh, từ chính sách thu nhập, cơ hội nhận thưởng đến những cập nhật mới giúp quá trình vận doanh thuận tiện, minh bạch hơn.

Cùng Bản tin Vận doanhGreen SMđiểm lại những thông tin nổi bật để không bỏ lỡ quyền lợi và chủ động hơn trên mỗi hành trình nhé!

1. CẬP NHẬT CHÍNH SÁCH THU NHẬP DÀNH CHO BÁC TÀI XANH GREEN SM

![1. CẬP NHẬT CHÍNH SÁCH THU NHẬP DÀNH CHO BÁC TÀI XANH GREEN SM](https://cdn.xanhsm.com/2026/08/e823b23e-cap-nhat-chinh-sach-thu-nhap-btx-green-sm-bike-platform-1024x1024.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> ## CẬP NHẬT CHÍNH SÁCH THU NHẬP
> 
> ### DÀNH CHO BÁC TÀI XANH GREEN SM BIKE PLATFORM
> 
> **Áp dụng 03/08/2026**
> 
> ---
> 
> ## CHẠY CÀNG NHIỀU NHẬN THƯỞNG CÀNG LỚN
> 
> Nâng cấp thưởng tuần cho Bác Tài Bike Platform
> 
> ### Các Mốc Thưởng Tuần:
> 
> *   **600K** (Mốc mới)
> *   **400K**
> *   **200K**
> *   **100K**
> 
> ---
> 
> Bác Tài đã xem chính sách thu nhập mới nhất chưa?
> 
> Từ ngày **03/08/2026**, Green SM chính thức cập nhật chính sách thu nhập dành cho **Bác Tài Xanh Green SM Bike Platform**, với **mốc thưởng tuần mới lên đến 600.000Đ**, giúp Bác Tài có thêm cơ hội gia tăng thu nhập. Bác Tài hãy xem ngay chính sách để nắm rõ các mốc thưởng, điều kiện áp dụng, từ đó chủ động kế hoạch vận doanh và chinh phục mức thưởng hấp dẫn mỗi tuần nhé!
> 
> **BẤM VÀO ĐÂY XEM NGAY CHÍNH SÁCH THU NHẬP**
> ```

2. THỰC HIỆN NGAY BÀI ĐÀO TẠO: VẠN DẶM KỶ CƯƠNG – HÀNH TRÌNH CHUẨN CHẤT

![2. THỰC HIỆN NGAY BÀI ĐÀO TẠO: VẠN DẶM KỶ CƯƠNG - HÀNH TRÌNH CHUẨN CHẤT](https://cdn.xanhsm.com/2026/08/24d1799b-thuc-hien-ngay-bai-dao-tao-van-dam-ky-cuong-hanh-trinh-chuan-chat-1024x1024.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # GREEN SM
> 
> ## THỰC HIỆN NGAY BÀI ĐÀO TẠO
> ### VẠN DẶM KỶ CƯƠNG - HÀNH TRÌNH CHUẨN CHẤT
> 
> ---
> 
> **[Logo GREEN SM]**
> 
> **CHIẾN DỊCH BẢN LĨNH BÁC TÀI XANH**
> # VẠN DẶM KỶ CƯƠNG
> ### HÀNH TRÌNH CHUẨN CHẤT
> ⭐⭐⭐⭐⭐
> 
> ---
> 
> ## SẮP HẾT HẠN HOÀN THÀNH 02 CHUYÊN ĐỀ ĐÀO TẠO BẮT BUỘC
> 
> Bác Tài Xanh lưu ý hoàn thành 02 chuyên đề "**An toàn là chuẩn mực - 5 sao là cam kết**" và "**Hình ảnh chuyên nghiệp – Tác phong 5 sao**" trước **16/08/2026**. Bác Tài cần xem đầy đủ video và đạt từ **80 điểm** trở lên để được công nhận hoàn thành.
> 
> **Lưu ý:** không hoàn thành đúng hạn có thể bị phạt và loại khỏi danh sách nhận Thưởng tuần (nếu có).
> 
> **BẤM VÀO ĐÂY ĐỂ XEM HƯỚNG DẪN HOÀN THÀNH BÀI ĐÀO TẠO**
> ```

3. GREEN EXPRESS: THU NHẬP ỔN ĐỊNH ĐẾN 450.000Đ/NGÀY, THÊM CƠ HỘI NHẬN THƯỞNG

![3. GREEN EXPRESS: THU NHẬP ỔN ĐỊNH ĐẾN 450.000Đ/NGÀY, THÊM CƠ HỘI NHẬN THƯỞNG](https://cdn.xanhsm.com/2026/08/aff2979f-chuyen-express-1024x1024.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> GREEN SM
> 
> BÁC TÀI XANH ƠI!
> CHUYÊN EXPRESS – THU NHẬP ỔN ĐỊNH, THƯỞNG HẤP DẪN
> 
> GREEN SM
> 
> GREEN EXPRESS – THU NHẬP ỔN ĐỊNH
> THƯỞNG HẤP DẪN DÀNH CHO
> BÁC TÀI XANH CHUYÊN EXPRESS
> 
> Bác Tài đang tìm cơ hội chạy Express ổn định, thu nhập hấp dẫn?
> Green Express mang đến chính sách dành riêng cho Bác Tài chuyên giao hàng Express, với thu nhập
> đảm bảo lên đến **450.000đ/ngày*** cùng nhiều chính sách thưởng và hỗ trợ công cụ giao hàng.
> BẤM XEM NGAY CHI TIẾT CHÍNH SÁCH VÀ ĐĂNG KÝ CHUYÊN EXPRESS!
> ```

4. GREEN SM FOOD CẬP NHẬT TÍNH NĂNG XÁC MINH LÝ DO HỦY ĐƠN

![https://www.greensm.com/vn-vi/news/cap-nhat-tinh-nang-xac-minh-ly-do-huy-don-food](https://cdn.xanhsm.com/2026/08/1f8286e8-xac-minh-ly-do-huy-don-food-1024x1024.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> GREEN SM
> CẬP NHẬT TÍNH NĂNG
> XÁC MINH LÝ DO HỦY ĐƠN FOOD
> 
> GREEN SM
> GREEN SM FOOD
> CẬP NHẬT TÍNH NĂNG
> XÁC MINH LÝ DO
> HỦY ĐƠN FOOD
> 
> 12:15
> Lý do hủy đơn
> O Cửa hàng đóng cửa (tài xế báo)
> O Cửa hàng hết món (tài xế báo)
> O Chờ quá lâu (15 phút)
> O Tài xế gặp sự cố xe
> O Cửa hàng từ chối đơn
> O Tài xế không tìm thấy cửa hàng
> O Tài xế không liên hệ được khách nhận hàng
> O Lý do khác
> O Khách không có tiền thanh toán (COD)
> O Tài xế giao sai món
> O Đơn hàng bị thiếu hoặc hư hỏng
> 
> NHẬN HÀNG
> THẤT BẠI
> 
> Tính năng xác minh lý do hủy đơn food giúp các Bác Tài Xanh an tâm hơn khi xử lý những tình huống
> phát sinh trong quá trình giao đơn Food. Với tính năng mới, khi gặp trường hợp nhà hàng đóng cửa, hết
> món hoặc không tìm thấy nhà hàng, Bác Tài chỉ cần lựa chọn đúng lý do và cung cấp hình ảnh xác
> minh theo hướng dẫn để quá trình xử lý trở nên minh bạch, thuận tiện và bảo vệ quyền lợi của mình.
> XEM NGAY HƯỚNG DẪN CHI TIẾT ĐỂ VẬN DOANH ĐÚNG – AN TÂM MỖI ĐƠN FOOD!
> ```

5. TÍNH NĂNG MỚI: THAY ĐỔI THÔNG TIN GIAO HÀNG TRÊN ĐƠN GREEN EXPRESS

![5. TÍNH NĂNG MỚI: THAY ĐỔI THÔNG TIN GIAO HÀNG TRÊN ĐƠN GREEN EXPRESS](https://cdn.xanhsm.com/2026/08/1ffc9005-thay-doi-dia-diem-giao-hang-don-green-express-1024x1024.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> # TÍNH NĂNG MỚI
> ## THAY ĐỔI THÔNG TIN GIAO HÀNG TRÊN ĐƠN GREEN EXPRESS
> 
> **GREEN SM CẬP NHẬT TÍNH NĂNG**
> **THAY ĐỔI THÔNG TIN GIAO HÀNG TRÊN ĐƠN GREEN EXPRESS**
> 
> **(Hình ảnh minh họa ứng dụng điện thoại)**
> *   **Thời gian:** 12:15
> *   **Địa điểm hiển thị trên bản đồ:** Landmark 81
> *   **Thông báo pop-up:**
>     *   "Đơn hàng của bạn vừa thay đổi điểm giao hàng. Vui lòng kiểm tra thông tin tại chi tiết đơn hàng"
>     *   [Tôi đã hiểu]
> *   **Thông tin chi tiết đơn hàng:**
>     *   **Khách hàng:** Châu Lệ Hoa
>     *   **Địa chỉ:** Landmark 81, 72 Đường Lê Thánh Tôn, Phường Bến Nghé, Quận 1, Thành phố Hồ Chí Minh, Việt Nam
>     *   **Ghi chú:** Anh vào hẻm 72 rẽ trái 50m, có ngõ 3 rẽ phải
> 
> Nhằm nâng cao trải nghiệm giao hàng và giúp quá trình xử lý đơn linh hoạt hơn, từ ngày **20/07/2026** Green SM triển khai tính năng thay đổi thông tin giao hàng đối với đơn hàng **Green Express siêu tốc** (không ghép đơn).
> 
> Khi khách giao hàng thay đổi thông tin giao hàng trong quá trình đơn hàng đang được thực hiện, ứng dụng sẽ hiển thị thông báo để Bác Tài kịp thời cập nhật và tiếp tục giao hàng.
> 
> **BẤM ĐỂ XEM TÍNH NĂNG MỚI**

6. GIỚI THIỆU HỌC VIÊN NHẬN THƯỞNG ĐẾN 1.000.000Đ & HỖ TRỢ HỌC PHÍ HỌC BẰNG LÁI LÊN ĐẾN 6.000.000Đ

![6. GIỚI THIỆU HỌC VIÊN NHẬN THƯỞNG ĐẾN 1.000.000Đ & HỖ TRỢ HỌC PHÍ HỌC BẰNG LÁI LÊN ĐẾN 6.000.000Đ](https://cdn.xanhsm.com/2026/08/c889e0fe-artboard-6-826x1024.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> # GREEN SM
> 
> ## THÁNG 08 BÙNG NỔ
> ## GIỚI THIỆU HỌC VIÊN, NHẬN THƯỞNG ĐẾN 1.000.000Đ
> 
> ### GIỚI THIỆU HỌC VIÊN HỌC BẰNG LÁI XE Ô TÔ
> NHẬN THƯỞNG ĐẾN 1.000.000Đ
> 
> **HỌC VIÊN ĐẶT CỌC**
> **Nhận 300.000Đ**
> 
> **HỌC VIÊN KHAI GIẢNG**
> **Nhận 400.000Đ**
> 
> **HỌC VIÊN GIA NHẬP GREEN SM**
> **Nhận 300.000Đ**
> 
> **ĐĂNG KÝ NGAY**
> 
> **Bác Tài Xanh thân mến ơi!**
> Bác Tài có người quen đang tìm nơi học lái ô tô & đăng ký Green SM?
> Giới thiệu ngay, nhận thưởng đến **1.000.000đ**/học viên:
> *   Nhận **300.000₫** khi học viên đăng ký & đặt cọc giữ chỗ
> *   Nhận thêm **400.000₫** khi học viên tham gia khai giảng
> *   Nhận thêm **300.000₫** khi học viên tốt nghiệp và gia nhập Green SM.
> 
> **Giới thiệu càng nhiều - Ví xinh càng "Xanh"!**
> **Zalo hỗ trợ: 077971342**
> 
> ## HỌC BẰNG LÁI - CÓ VIỆC NGAY
> ## HỖ TRỢ HỌC PHÍ ĐẾN 6.000.000Đ!
> 
> ### ĐĂNG KÝ HỌC THÁNG 8
> ### ƯU ĐÃI NHÂN BA
> DÀNH CHO BÁC TÀI XANH TƯƠNG LAI
> *   HỖ TRỢ HỌC PHÍ ĐẾN 6.000.000Đ
> *   CƠ HỘI NHẬN HỌC BỔNG 50% HỌC PHÍ
> *   GIẢM THÊM HỌC PHÍ 500K/NGƯỜI (Khi đăng ký nhóm 3 người trở lên)
> 
> **ĐĂNG KÝ NGAY**
> 
> **Bác Tài Xanh đăng ký học bằng lái ô tô được:**
> *   Giảm ngay **2.000.000₫** + hỗ trợ ứng trước **4.000.000₫** học phí
> *   Giảm thêm **500.000đ**/học viên khi đăng ký nhóm từ 03 học viên
> *   Quay số may mắn tháng 08: Cơ hội nhận voucher học bổng 50%, voucher **500.000₫** thuê xe chip và nhiều quà tặng hấp dẫn.
> *   **Quyền lợi:** Đào tạo bài bản, lịch học linh hoạt, học phí minh bạch và được hỗ trợ xuyên suốt.
> *   **Điều kiện:** Cam kết trở thành Bác Tài Xanh Taxi Green SM tối thiểu **03 tháng** sau khi có bằng.
> 
> **ĐĂNG KÝ NGAY ĐỂ NHẬN HỖ TRỢ HỌC PHÍ VÀ CƠ HỘI NHẬN QUÀ THÁNG 08!**

7. CHÍNH THỨC RA MẮT BÀI HÁT: LÁI XE AN TOÀN – VẠN DẶM BÌNH AN

![7. CHÍNH THỨC RA MẮT BÀI HÁT: LÁI XE AN TOÀN - VẠN DẶM BÌNH AN](https://cdn.xanhsm.com/2026/08/29391a66-ra-mat-bai-hat-lai-xe-an-toan-van-dam-binh-an-1024x1024.jpeg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # CHÍNH THỨC RA MẮT BÀI HÁT
> ## LÁI XE AN TOÀN - VẠN DẶM BÌNH AN
> 
> **GREEN SM**
> CHÍNH THỨC RA MẮT BÀI HÁT
> ### LÁI XE AN TOÀN
> VAN DẶM BÌNH AN
> 
> Thời gian: 19:00, ngày 07/08/2026
> Các Bác Tài Xanh cùng đón chờ nhé!
> 
> Bản tin Vận doanh tuần này chính thức đem đến món quà tinh thần đặc biệt dành riêng cho các Bác Tài Xanh. Với giai điệu nhẹ nhàng đầy cuốn hút và ca từ mộc mạc, bài hát như một lời nhắc nhở ấm áp, một lời chúc bình an trên vạn dặm hành trình. Hãy cùng bật mở, thưởng thức mỗi ngày và lan tỏa giai điệu đầy tự hào này để mỗi chuyến xe Xanh luôn là một chuyến đi an toàn trọn vẹn!
> 
> **BẤM VÀO ĐÂY ĐỂ CÙNG LẮNG NGHE BÀI HÁT**
> ```
