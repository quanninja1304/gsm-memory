# Chính sách thưởng dành cho Bác tài Car Platform

- **Ngày đăng:** 2025-01-09
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-thuong-danh-cho-bac-tai-car-platform](https://www.greensm.com/vn-vi/news/chinh-sach-thuong-danh-cho-bac-tai-car-platform)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Bác tài chính là nhân tố quan trọng tạo nên sự phát triển bền vững và thành công của Green SM. Để ghi nhận những nỗ lực và tiếp thêm động lực cho hành trình vận doanh, Green SM chính thức triển khaiChính sách thưởng đặc biệtdành riêng cho Bác tài Car Platform.

🎉Hãy cùng Green SM khám phá ngay các chương trình thưởng:

- Thời gian áp dụng:Từ 13/01/2025 cho đến khi có thông báo mới.

- Đối tượng áp dụng:Bác tài Car Platform trên toàn quốc.

- Nội dung chính sách:tăng thêm đến 5%trên mức chia sẻ Doanh số hiện tại.

- Chi tiết từng chương trình:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/01/71604b81-250109_chinhsachmoicarplatform-938x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> XANH SM
> PLATFORM
> 
> CHÍNH SÁCH THƯỞNG
> DÀNH CHO BÁC TÀI CAR PLATFORM
> 
> Áp dụng: từ ngày **13/01/2025**
> Đối tượng áp dụng: **Tài xế Car Platform**
> không vi phạm Tiêu chuẩn dịch vụ của Tài xế GSM Platform
> 
> **MỨC THƯỞNG TUẦN**
> 
> | Mức thưởng | Tỷ lệ nhận cuốc | Tỷ lệ hoàn thành cuốc | Số sao trung bình tuần | Doanh số (VNĐ/tuần)         | Mức % chia sẻ thêm |
> | :-------- | :-------------- | :------------------- | :-------------------- | :-------------------------- | :----------------- |
> | Mức 1     | ≥ 80%           |                      |                       | Dưới 5.000.000              | 0%                 |
> | Mức 2     |                 | ≥ 90%                | ≥ 4.9                 | Từ 5.000.000-8.000.000      | 3%                 |
> | Mức 3     |                 |                      |                       | Từ 8.000.000-11.000.000     | 4%                 |
> | Mức 4     | ≥ 78%           |                      |                       | Từ 11.000.000 trở lên       | 5%                 |
> 
> **Lưu ý:**
> * Chương trình này sẽ **thay thế** cho Chương trình thường tuần đã được thông báo và triển khai trước đó
> * Mức thưởng không bao gồm Thuế Thu nhập cá nhân
> ```

✨ Mến chúc Bác tài hoạt động hiệu quả và có thật nhiều chuyến xe cùng Green SM!

Trân trọng,Đội ngũ Green SM Platform
