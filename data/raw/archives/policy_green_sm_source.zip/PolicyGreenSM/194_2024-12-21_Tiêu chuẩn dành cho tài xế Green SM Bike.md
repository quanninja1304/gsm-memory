# Tiêu chuẩn dành cho tài xế Green SM Bike

- **Ngày đăng:** 2024-12-21
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/tieu-chuan-danh-cho-tai-xe-xanh-sm-bike](https://www.greensm.com/vn-vi/news/tieu-chuan-danh-cho-tai-xe-xanh-sm-bike)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

I. TIÊU CHUẨN DIỆN MẠO

1. Móng tay dài tối đa 2mm. Không để lộ hình xăm trên cơ thể.

2. Mặc theo quy định của Công ty: Áo đồng phục, quần dài gọn gàng, phẳng phiu, sạch sẽ, không sờn màu.

3. Đi giày hoặc dép quai hậu tối màu, sạch sẽ. Không đi dép lê, dép tổ ong, dép đi trong nhà. Không đạp chân lên gót giày/dép. Nữ không đi giày cao gót quá 3cm.

II. TIÊU CHUẨN TÁC PHONG

4. Luôn đội mũ bảo hiểm Green SM ngay ngắn khi lái xe tham gia giao thông.

5. Tư thế lái xe thẳng lưng, ngay ngắn. Lái xe bằng 2 tay và chỉ buông 1 tay trong tình huống cần thiết.

6. Lái xe an toàn, tuân thủ luật giao thông, không cầm và sử dụng điện thoại khi lái xe. Tốc độ di chuyển phù hợp. Tuyệt đối không đánh võng, lạng lách.

7. Không hút thuốc trong xe/ khi lái xe và tại khu vực cấm. Không uống rượu/ bia, ăn/ uống, nhai/ ngậm kẹo khi lái xe. Không có các hành vi gây phản cảm (ngoáy mũi, xỉa răng, ngáp) quấy rối, sàm sỡ Khách.

III. TIÊU CHUẨN HÀNH VI PHỤC VỤ

Xác nhận chuyến

8. Trong vòng 01 phút kể từ khi nhận chuyến (trừ trường hợp nối chuyến), gọi điện, chào Khách, xác nhận địa điểm đón/điểm nhận hàng và thông báo thời gian dự kiến. Lời chào tiêu chuẩn: “Green SM xin chào”.

Đón khách hàng

9. Đón khách/nhận hàng trong vòng 5 phút. Trường hợp bất khả kháng, gọi điện xin lỗi và thông báo xin lùi thời gian hoặc đổi địa điểm đón Khách/nhận hàng

10. Dừng xe đúng luật giao thông, thuận tiện, không bắt Khách băng qua đường.

11. Nếu không thấy Khách chờ sẵn, gọi điện thông báo với Khách xe đã đến và mời Khách ra xe.

12. Mở gác chân, chào Khách và xác nhận điểm đến. Đưa mũ bảo hiểm Green SM cho Khách (khuyến khích bằng hai tay), đội cho Khách nếu cần.

13. Hỗ trợ chuyển đồ vào cốp/ treo lên móc khi Khách cần. Sắp xếp đồ gọn gàng.

14. Sắp xếp chỗ phù hợp cho Khách. Không chở quá số người cho phép theo quy định của luật giao thông.

Trong chuyến

15. Giữ xe ở tư thế vững vàng, hai tay nắm ghi đông, hai chân chống xuống đất để Khách lên xe và xin phép bắt đầu di chuyển.

16. Tạo cảm giác thân thiện với Khách. Trò chuyện nếu Khách có nhu cầu, nếu không giữ trật tự tập trung lái xe. Với Khách đặt “Chuyến xe im lặng” sau khi chào hỏi, giữ im lặng và chỉ giao tiếp trong tình huống bắt buộc.

17. Hỗ trợ che ô hoặc đưa áo mưa cho Khách khi Khách cần.

18. Khi phải liên hệ Tổng đài để giải quyết việc gấp, xin phép Khách dừng xe để gọi, âm lượng vừa đủ không làm phiền Khách.

19. Trường hợp không thể đáp ứng yêu cầu của Khách, hướng dẫn Khách gọi cho Tổng đài Chăm sóc Khách.

20. Kiểm tra loại hàng, kích thước đúng theo đơn hàng, ngoại quan nguyên vẹn và tránh các mặt hàng trong danh mục hàng hóa cấm giao.

21. Chụp ảnh hàng hóa rõ nét, đẩy đủ để xác nhận được tình trạng hàng hóa khi nhận/giao.

22. Khi có nghi ngờ về hàng hóa cấm hoặc Khách không cho kiểm tra hàng, xin phép từ chối giao hàng và tiến hành hủy đơn hàng với lý do tương ứng.

23. Nếu có người nhận trực tiếp: Giao hàng cho Khách bằng 2 tay. Nếu không có người nhận, để đúng nơi Khách yêu cầu và chụp ảnh lại gửi cho Khách.

24. Khi Khách nhận hàng từ chối nhận, cần liên lạc để báo tin với Khách gửi qua điện thoại hoặc tin nhắn trước khi quay về trả hàng.

25. Thống nhất thời gian trả hàng và tiến hành hoàn trả trong vòng 24 giờ. Thông báo cho Khách về cước phí hoàn trả bằng cước phí giao hàng (không áp dụng khuyến mãi).

26. Xác nhận thông tin đơn hàng với Khách, thông báo thời gian giao hàng dự kiến trên ứng dụng. Trường hợp không liên lạc được, đảm bảo gọi cho Khách tối thiểu 3 cuộc gọi trong vòng 15 phút.

Kết thúc chuyến

27. Thực hiện thanh toán nhanh chóng, chính xác. Không gợi ý, đòi thêm hay tự ý thu thêm tiền của Khách.

28. Dừng xe đúng luật giao thông, thuận tiện, không bắt Khách băng qua đường.

29. Đưa/hỗ trợ chuyển đồ cho Khách (nếu có). Đồng thời nhắc Khách kiểm tra đồ đạc trước khi xuống xe.

30. Cám ơn và chào Khách: “Green SM cảm ơn và hẹn gặp lại Anh/chị!” hoặc dùng câu chào phù hợp tình huống thực tế.

31. Nhận diện số điện thoại của Khách cũ và dùng tên Khách trong xưng hô một cách phù hợp trong trường hợp Khách đã được cập nhật thông tin.
