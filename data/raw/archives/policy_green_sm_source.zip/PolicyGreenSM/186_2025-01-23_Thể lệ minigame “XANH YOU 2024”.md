# Thể lệ minigame “XANH YOU 2024”

- **Ngày đăng:** 2025-01-23
- **Chuyên mục:** Cộng đồng, Ưu đãi
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/the-le-minigame-xanh-you-2024](https://www.greensm.com/vn-vi/news/the-le-minigame-xanh-you-2024)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Không

---

## 1. THỜI GIAN DIỄN RA MINIGAME:

- Ngày bắt đầu: 23.01.2025

- Ngày kết thúc: 06.02.2025

- Thời gian công bố kết quả Minigame: 10.02.2024

- Thời gian trả thưởng: 40 ngày kể từ ngày thông báo kết quả.

## 2. ĐỐI TƯỢNG, PHẠM VI VÀ CÁCH THỨC THAM GIA MINIGAME:

Đối tượng tham gia:

- Tất cả khách hàng bao gồm công dân Việt Nam hoặc công dân người nước ngoài đang cư trú trên lãnh thổ Việt Nam, có đủ năng lực hành vi dân sự theo quy định của pháp luật Việt Nam, có đăng ký tài khoản hợp lệ trên ứng dụng Green SM.

- Tất cả khách hàng sử dụng dịch vụ di chuyển của Green SM tại thị trường Việt Nam (không áp dụng với thị trường quốc tế).

Phạm vi tham gia:

- Hoạt động triển khai online trên Fanpage chính thức của Green SM trên nền tảng mạng xã hội Facebook.

Cách thức tham gia:

- Khách hàng tham gia Minigame “Xanh You 2024” bằng cách nhấn Like và bình luận một lời cảm ơn tới gia đình, bạn bè và những người thân yêu về một điều bất kỳ trong năm 2024 theo cú pháp: “Xanh You + @tên người dùng vì năm 2024 đã + [điều bản thân muốn cảm ơn]. Người dùng được nhắc tới trong bình luận (tag) sẽ tiếp tục tham gia bằng cách tag thêm một người khác và cảm ơn người ấy (lặp lại cú pháp tương tự).

Cơ chế chiến thắng:

- Khách hàng dành chiến thắng khi có bình luận sở hữu chuỗi Phản hồi theo đúng cú pháp cao nhất không ngắt quãng.

VD: Chuỗi bình luận hợp lệ:

- Bình luận 1 – Bạn A: Xanh You @B vì đã bao tui mấy cuốc xe Xanh

- Phản hồi bình luận 1 – Bạn B: Xanh You @C vì không ngại làm tài xế riêng cho mình ^^

- Phản hồi bình luận 2 – Bạn C: Xanh You @D vì đã cùng tui quyên góp quần áo cũ để tái chế bảo vệ môi trường.

- Phản hồi bình luận 3 – Bạn D: Xanh You @E vì đã cùng tham gia rất nhiều hoạt động vì môi trường trong năm nay.

- Phản hồi bình luận 4 – Bạn E: Ừa nhiều kỷ niệm đáng nhớ quá bạn ha

=> Số bình luận hợp lệ trong chuỗi được tính sẽ là 04 bình luận (Vì bị ngắt quãng bởi E – E cần cảm ơn tiếp một người bạn khác)

VD: Chuỗi bình luận không hợp lệ:

- Bình luận 1 – Bạn A: Xanh You @B vì đã bao tui mấy cuốc xe Xanh

- Phản hồi bình luận 1 – Bạn B: OK bạn.

- Phản hồi bình luận 2 – Bạn C: Xanh You @A vì đã cùng tôi quyên góp quần áo cũ để tái chế bảo vệ môi trường.

=> Số bình luận hợp lệ trong chuỗi là 1 bình luận (Vì bị ngắt quãng bởi B và chưa có Phản hồi bình luận phù hợp trước B)

VD: Chuỗi bình luận không hợp lệ:

- Bình luận 1 – Bạn A: Xanh You @B vì đã bao tui mấy cuốc xe Xanh

- Phản hồi bình luận 1 – Bạn B: Xanh You @A vì đã cùng tui thu gom rác thải, hồi sinh các con sông chết trong năm 2024.

- Phản hồi bình luận 2 – Bạn C: Xanh You @A vì đã cùng tôi quyên góp quần áo cũ để tái chế bảo vệ môi trường.

=> Số bình luận hợp lệ trong chuỗi là 2 bình luận (Vì bị ngắt quãng bởi C – C cần phải cảm ơn người bạn khác ngoài A và B)

## 3. CƠ CẤU GIẢI THƯỞNG MINIGAME:

- 01 GIẢI NHẤT: 3.000.000 VNĐ tiền mặt + Xanh Giftcard trị giá 2.000.000 VNĐ.

- 01 GIẢI NHÌ: 2.000.000 VNĐ tiền mặt + Xanh Giftcard trị giá 2.000.000 VNĐ.

- 03 GIẢI BA: Mỗi giải được tặng 01 Xanh Giftcard trị giá 1.000.000 VNĐ.

## 4. CÔNG BỐ KẾT QUẢ MINIGAME:

- Kết quả sẽ được công bố trên fanpage chính thức của Green SM.

- Ban tổ chức sẽ liên hệ trực tiếp với người chiến thắng qua tin nhắn hoặc email để xác nhận thông tin nhận giải.

## 5. PHƯƠNG THỨC TRẢ THƯỞNG

- Giải thưởng tiền mặt: Sẽ được chuyển vào tài khoản do người trúng giải gửi đến.

- Giải thưởng Xanh Giftcard: Sẽ được cộng thẳng vào Thẻ Xanh điện tử trong tài khoản khách hàng đã đăng ký trên ứng dụng Green SM.
