# Chính sách Thưởng Trách nhiệm và chia sẻ Doanh số dịp Giỗ Tỗ Hùng Vương 2025

- **Ngày đăng:** 2025-04-07
- **Chuyên mục:** Cẩm nang tài xế
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/chinh-sach-chia-se-doanh-so-gio-to-2025](https://www.greensm.com/vn-vi/news/chinh-sach-chia-se-doanh-so-gio-to-2025)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác tài thân mến,

Nhằm ghi nhận nỗ lực phục vụ khách hàng trong dịp lễ Giỗ Tổ Hùng Vương 2025, Green SM triển khaichính sách thưởng đặc biệtdành cho các Bác tài như sau:

🔹Đối tượng áp dụng:Tài xế Taxi Green SM tham gia vận doanh trong ngày 07/04/2025.🔹Nội dung chính sách:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/4224ea89-hn-dn-hcm_20250407_chinhsach1-1024x997.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM
> 
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ GIỖ TỔ HÙNG VƯƠNG
> 
> *   **Đối tượng áp dụng**: Tài xế Taxi tại Hà Nội, TP.HCM, Đà Nẵng tham gia vận doanh trong dịp lễ
> *   **Thời gian áp dụng**: ngày 07/04
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **17%** so với ngày thường.
> 
> | Xanh Car | | Xanh Premium | |
> |---|---|---|---|
> | **Mức** | **Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** | **Mức** | **Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0 | Dưới 1.000.000 | 28% | Mức 0 | Dưới 900.000 | 27% |
> | Mức 1 | Từ 1.000.000 - < 1.300.000 | 38% | Mức 1 | Từ 900.000 - < 1.200.000 | 40% |
> | Mức 2 | Từ 1.300.000 - < 1.600.000 | 48% | Mức 2 | Từ 1.200.000 - < 1.500.000 | 50% |
> | Mức 3 | Từ 1.600.000 - < 2.100.000 | 54% | Mức 3 | Từ 1.500.000 - < 2.000.000 | 60% |
> | Mức 4 | Từ 2.100.000 trở lên | 63% | Mức 4 | Từ 2.000.000 trở lên | 65% |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/a9e32fa6-quang-ninh_20250407_chinhsach-1024x997.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ GIỖ TỔ HÙNG VƯƠNG
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Quảng Ninh tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** ngày 07/04
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **14%** so với ngày thường.
> 
> | | Xanh Car | | | Xanh Premium | |
> |---|---|---|---|---|---|
> | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** | **Mức** | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0 | Dưới 850.000 | 26% | Mức 0 | Dưới 750.000 | 26% |
> | Mức 1 | Từ 850.000 - < 1.150.000 | 40% | Mức 1 | Từ 750.000 - < 1.050.000 | 37% |
> | Mức 2 | Từ 1.150.000 - < 1.650.000 | 47% | Mức 2 | Từ 1.050.000 - < 1.400.000 | 46% |
> | Mức 3 | Từ 1.650.000 - < 2.100.000 | 58% | Mức 3 | Từ 1.400.000 - < 1.900.000 | 57% |
> | Mức 4 | Từ 2.100.000 trở lên | 62% | Mức 4 | Từ 1.900.000 trở lên | 61% |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/03b84c27-khanh-hoa-hue_20250407_chinhsach-1024x997.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ GIỖ TỔ HÙNG VƯƠNG
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Khánh Hòa, Huế tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** ngày 07/04
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **14%** so với ngày thường.
> 
> | Xanh Car                 |                     | Xanh Premium             |                     |
> | :----------------------- | :------------------ | :----------------------- | :------------------ |
> | **Mức**                  | **Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** | **Mức**                  | **Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0                    | Dưới 800.000        | 26%                    | Mức 0                    | Dưới 700.000            | 26%                 |
> | Mức 1                    | Từ 800.000 - < 1.100.000 | 39%                    | Mức 1                    | Từ 700.000 - < 950.000 | 37%                 |
> | Mức 2                    | Từ 1.100.000 - < 1.600.000 | 47%                    | Mức 2                    | Từ 950.000 - < 1.300.000 | 44%                 |
> | Mức 3                    | Từ 1.600.000 - < 2.000.000 | 57%                    | Mức 3                    | Từ 1.300.000 - < 1.700.000 | 52%                 |
> | Mức 4                    | Từ 2.000.000 trở lên | 62%                    | Mức 4                    | Từ 1.700.000 trở lên   | 61%                 |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/47c59723-thanh-hoa_20250407_chinhsach-1024x995.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ GIỖ TỔ HÙNG VƯƠNG
> 
> **Đối tượng áp dụng:** Tài xế Taxi tại Thanh Hóa tham gia vận doanh trong dịp lễ
> **Thời gian áp dụng:** ngày 07/04
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **14%** so với ngày thường.
> 
> | Xanh Car                |                     | Xanh Premium            |                   |
> | :---------------------- | :------------------ | :---------------------- | :---------------- |
> | **Mức**                 | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày**  | **Mức**           | **Mức Doanh số ngày (VNĐ)** | **Cuốc xe trong ngày** |
> | Mức 0                   | Dưới 650.000        | 26%                     | Mức 0             | Dưới 500.000        | 26%                    |
> | Mức 1                   | Từ 650.000 -< 950.000 | 39%                     | Mức 1             | Từ 500.000 -< 700.000 | 42%                    |
> | Mức 2                   | Từ 950.000 -< 1.350.000 | 47%                     | Mức 2             | Từ 700.000 -< 900.000 | 51%                    |
> | Mức 3                   | Từ 1.350.000 -< 1.650.000 | 57%                     | Mức 3             | Từ 900.000 -< 1.100.000 | 57%                    |
> | Mức 4                   | Từ 1.650.000 trở lên | 62%                     | Mức 4             | Từ 1.100.000 trở lên | 61%                    |
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2025/04/d2c3d68b-cac-tinh-con-lai_20250407_chinhsach-1024x947.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản được trích xuất từ hình ảnh, định dạng Markdown tiếng Việt:
> 
> # XANH SM
> 
> # THƯỞNG TRÁCH NHIỆM VÀ DOANH SỐ DỊP LỄ GIỖ TỔ HÙNG VƯƠNG
> 
> *   **Đối tượng áp dụng:** Tài xế Taxi (Xanh Car và Xanh Premium) tham gia vận doanh trong dịp lễ
> *   **Khu vực áp dụng:** Tất cả các tỉnh, thành phố ngoại trừ: Hà Nội, TP.HCM, Đà Nẵng, Huế, Thanh Hóa, Khánh Hòa và Quảng Ninh
> *   **Thời gian áp dụng:** ngày 07/04
> 
> ## Nội dung chính sách
> 
> Tỷ lệ Thưởng Trách nhiệm và Thưởng Doanh số được điều chỉnh tăng thêm lên đến **12%** so với ngày thường.
> 
> | Mức   | Tỷ lệ chia sẻ tăng so với Chính sách ngày thường |
> | :---- | :----------------------------------------------- |
> | Mức 0 | 0%                                               |
> | Mức 1 | 5%                                               |
> | Mức 2 | 8%                                               |
> | Mức 3 | 10%                                              |
> | Mức 4 | 12%                                              |
> 
> **Ví dụ:** Bác tài hoạt động tại tỉnh A, đạt mốc doanh số **mức 2**. Ngày thường nhận **37%** chia sẻ, riêng ngày 07/04 được chia sẻ **45%** doanh số (**tăng thêm 8%**).

Mến chúc các Bác tài vận hành an toàn, hiệu quả và tận dụng tốt chính sách thưởng để gia tăng thu nhập trong dịp lễ!

Trân trọng,Đội ngũ Green SM
