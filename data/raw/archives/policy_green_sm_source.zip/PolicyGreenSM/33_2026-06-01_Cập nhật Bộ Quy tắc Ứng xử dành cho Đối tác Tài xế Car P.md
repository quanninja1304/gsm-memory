# Cập nhật Bộ Quy tắc Ứng xử dành cho Đối tác Tài xế Car Platform từ ngày 01/06/2026

- **Ngày đăng:** 2026-06-01
- **Chuyên mục:** Cẩm nang tài xế, Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-bo-quy-tac-ung-xu-danh-cho-doi-tac-tai-xe-car-platform-tu-ngay-01-06-2026](https://www.greensm.com/vn-vi/news/cap-nhat-bo-quy-tac-ung-xu-danh-cho-doi-tac-tai-xe-car-platform-tu-ngay-01-06-2026)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Trong hành trình phát triển và giữ vững chất lượng dịch vụ 5 Sao, mỗi Bác Tài Xanh chính là một nhân tố quan trọng góp phần xây dựng hình ảnh và uy tín của Green SM trong mắt Khách hàng thông qua những chuyến xe Xanh mỗi ngày.

Nhằm đảm bảo sự đồng bộ trong quy chuẩn vận hành, Green SM chính thức cập nhật Bộ Quy tắc Ứng xử (“QTUX”) dành cho Đối tác Tài xế Car Platform. Bộ quy tắc mới được áp dụng từ ngày 01/06/2026, thay thế cho Bộ QTUX hiện hành.

Việc cập nhật này không chỉ góp phần nâng cao chất lượng dịch vụ, mà còn tạo điều kiện để Bác Tài Xanh gia tăng thu nhập thông qua việc nâng cao trải nghiệm Khách hàng. Chi tiết như sau:

I. NGUYÊN TẮC CHUNG

1. TUYÊN NGÔN VĂN HÓA

1.1. Tầm nhìn: Đẩy nhanh quá trình chuyển đổi giao thông xanh, bền vững của thế giới.1.2. Sứ mệnh: Tạo ra một giải pháp giao thông xanh, tiện lợi và bền vững.1.3. Giá trị cốt lõi: Công nghệ – Văn minh – Tin cậy.1.4. Văn hoá: Kỷ luật – Chuyên nghiệp – Tận tâm.

2. TIÊU CHÍ HỢP TÁC

2.1. Công bằng, minh bạch, thượng tôn kỷ luật.2.2. Văn minh, tôn trọng, hợp tác.2.3. Mức thu nhập cạnh tranh2.4. Đối tác Tài xế Car Platform có cơ hội học tập, phát triển.

II. QUY TẮC ỨNG XỬ

1. ĐỐI VỚI KHÁCH HÀNG:

1.1. Cung cấp dịch vụ chuyên nghiệp cho Khách hàng đảm bảo Tiêu chuẩn dịch vụ Green Car Platform.1.2. Tôn trọng quyền riêng tư và bảo mật thông tin của Khách hàng.1.3. Đảm bảo an toàn tuyệt đối cho Khách hàng (cả về thể chất và tinh thần).

2. ĐỐI VỚI BẢN THÂN ĐỐI TÁC TÀI XẾ

2.1. Trung thực trong quá trình thực hiện Điều kiện kinh doanh trên nền tảng Green SM2.2. Tuân thủ đúng các quy định/hướng dẫn thực hiện, Tiêu chuẩn dịch vụ Car Platform trong quá trình hợp tác.2.3. Tuyệt đối tuân thủ quy định pháp luật trong quá trình hoạt động.

3. ĐỐI VỚI TÀI KHOẢN ỨNG DỤNG VÀ TÀI SẢN/THIẾT BỊ ĐƯỢC GREEN SM CUNG CẤP

3.1. Sử dụng tài khoản ứng dụng đúng quy định của Green SM.3.2. Bảo quản và giữ gìn các tài sản/thiết bị được Green SM cung cấp theo thỏa thuận với Green SM và quy định pháp luật.

III. CHẾ TÀI XỬ LÝ VI PHẠM QUY TẮC ỨNG XỬ

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/1cfd1597-bang-1a-cap-nhat-bo-quy-tac-ung-xu-car-platform-2-768x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> # Cập nhật Bộ Quy tắc Ứng xử dành cho Đối tác Tài xế Car Platform
> cập nhật từ ngày 01/06/2026
> 
> ## NHÓM LỖI
> 
> ### NHÓM 1A: CÁC LỖI ĐẶC BIỆT NGHIÊM TRỌNG
> 
> | CÁC HÀNH VI VI PHẠM | HÌNH THỨC XỬ LÝ |
> |---|---|
> | (1) Có hành vi vi phạm pháp luật bao gồm nhưng không giới hạn: | Chấm dứt tài khoản kinh doanh trên nền tảng Green SM vĩnh viễn |
> | * Cản trở hoặc gây rối loạn hoạt động của mạng máy tính, mạng viễn thông, phương tiện điện tử (Can thiệp, làm gián đoạn hoặc sai lệch dữ liệu hệ thống, ứng dụng, thông tin cuốc xe...). | |
> | * Tàng trữ/vận chuyển, sử dụng ma túy/vũ khí trên xe với bất kỳ mục đích nào. | |
> | * Sử dụng xe vào mục đích vi phạm pháp luật; chống đối người thi hành công vụ. | |
> | * Vi phạm pháp luật về an toàn giao thông gây hậu quả nghiêm trọng (tai nạn, va chạm...). Không hỗ trợ Khách hàng khi xảy ra tai nạn/sự cố. | |
> | * Thông đồng, bao che hoặc tiếp tay cho hành vi trên. | |
> | (2) Có hành vi phát ngôn, lan truyền, đăng tải, lôi kéo, kích động đám đông hoặc cung cấp thông tin sai lệch, xuyên tạc, gây ảnh hưởng tiêu cực đến hình ảnh, uy tín, hoạt động của Green SM dưới bất kỳ hình thức nào; hoặc cố ý tiết lộ, sao chép, chuyển giao, phát tán thông tin tài liệu nội bộ, dữ liệu kinh doanh, bí mật thương mại hoặc tài liệu mật của Green SM cho bên thứ ba, trực tiếp hoặc gián tiếp, bằng bất kỳ hình thức nào. | |
> | (3) Áp dụng với các hành vi vi phạm tại mục số (6), lỗi Nhóm 1b khi số tiền trục lợi lớn hơn 500.000đ/lần. | Chấm dứt tài khoản kinh doanh trên nền tảng Green SM vĩnh viễn và/hoặc trừ ví 10.000.000đ, đồng thời yêu cầu hoàn trả toàn bộ khoản gian lận và/hoặc chi phí bồi thường thiệt hại mà Green SM đã thanh toán thay cho Khách hàng/Bên thứ ba. |
> | (4) Có hành vi, lời nói hoặc nhắn tin/gọi điện xúc phạm, quấy rối Khách hàng; hoặc phân biệt đối xử (về chủng tộc, tôn giáo, quốc tịch, vùng miền, ngoại hình, giới tính, tuổi tác...) hay có thái độ/hành vi không đúng mực với Khách hàng hoặc đối tượng khác khi có sự hiện diện của Khách hàng. | Nếu đăng tải thông tin sai sự thật hoặc tiêu cực về Green SM, ngoài các chế tài trên, Tài xế phải thực hiện đính chính và xin lỗi Green SM. Trường hợp có dấu hiệu vi phạm pháp luật, chuyển cơ quan chức năng xử lý. |
> | (5) Vi phạm lần 4 đối với các lỗi Nhóm 2 | |

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/d736b9fa-bang-1b-cap-nhat-bo-quy-tac-ung-xu-car-platform-2-722x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> NHÓM 1B:
> CÁC LỖI ĐẶC BIỆT NGHIÊM TRỌNG
> 
> (6) Có hành vi gian lận, lợi dụng chính sách phụ phí/chương trình thưởng/khuyến mại với số tiền trục lợi nhỏ hơn 500.000đ/lần bao gồm nhưng không giới hạn:
> *   Tạo nhiều tài khoản Khách hàng hoặc can thiệp vào hệ thống/ứng dụng Green SM nhằm trục lợi hoặc gây ảnh hưởng đến hệ thống, chất lượng dịch vụ cung cấp cho Khách hàng/Đối tác/Tài xế.
> *   Phối hợp hoặc thông đồng với người khác để tạo chuyến xe ảo, tách cuốc dài thành nhiều cuốc ngắn, tạo cuốc giả mạo sử dụng hình thức thanh toán không tiền mặt (thẻ, ví điện tử).
> *   Hủy chuyến nhưng vẫn chở khách; chở Khách hàng nhưng không tạo chuyến; cố ý thao tác sai cuốc tour nhằm trục lợi.
> *   Chuyển nhượng, cho thuê hoặc cho người khác sử dụng tài khoản của mình dưới bất kỳ hình thức nào.
> *   Môi giới, chuyển Khách hàng cho tài xế khác phục vụ hoặc nhận Khách hàng do môi giới từ tài xế khác.
> *   Cố ý không hoàn trả tài sản của Khách hàng, tự mình hoặc phối hợp với người khác yêu cầu Khách hàng trả tiền chuộc để nhận lại tài sản, và/hoặc không cung cấp thông tin trung thực khi Green SM liên hệ xác minh về tài sản của Khách hàng.
> 
> (7) Cung cấp hoặc sử dụng giấy tờ giả mạo (giấy phép lái xe, CCCD, LLTP, ...)
> 
> (8) Sử dụng rượu, bia, thuốc lá hoặc các chất kích thích khác trong quá trình thực hiện chuyến xe.
> 
> (9) Sử dụng phương tiện không trùng khớp với thông tin đăng ký trên tài khoản.
> 
> (10) Khai thác, sử dụng, tiết lộ, quay, chụp, thu âm, phát tán hình ảnh, thông tin, dữ liệu của Khách hàng không đúng quy định; bao gồm nhưng không giới hạn việc sử dụng cho mục đích cá nhân hoặc ngoài phạm vi công việc, gây ảnh hưởng đến quyền lợi của Khách hàng hoặc uy tín, hình ảnh của Green SM.
> 
> (11) Có hành vi bất hợp tác, chống đối hoặc thể hiện thái độ tiêu cực trong quá trình làm việc (bao gồm việc không phối hợp giải trình các lỗi vi phạm, các sự vụ phát sinh với Khách hàng hoặc không chấp hành quyền kiểm tra, giám sát của Green SM theo quy định hợp tác, gây rối trật tự cố ý gây thương tích).
> 
> (12) Có hành vi phát ngôn, đăng tải hoặc chia sẻ thông tin không chính xác, mang tính suy diễn, bình luận tiêu cực trên mạng xã hội, diễn đàn, hội nhóm...gây ảnh hưởng đến hình ảnh hoặc uy tín cá nhân/ tập thể CBNV thuộc Công Ty hoặc Tập Đoàn.
> 
> (13) Có phản ánh từ Khách hàng (thông qua các kênh Tổng đài CSKH, Hòm thư Thanh tra, KHBM, VHP... ghi nhận) từ 03 lần trở lên (bao gồm các trường hợp có bằng chứng) hoặc 05 lần (với các trường hợp không có bằng chứng) trong vòng 30 ngày.
> 
> (14) Vi phạm lần 4 đối với các lỗi Nhóm 3.
> 
> (15) Vi phạm lỗi Nhóm 2 nhưng bị Khách hàng tố cáo, gây ảnh hưởng đến hình ảnh và uy tín của Green SM, khiến Green SM phải bồi thường cho Khách hàng.
> 
> Chấm dứt tài khoản kinh doanh trên nền tảng Green SM vĩnh viễn và/hoặc trừ ví 5.000.000₫, đồng thời yêu cầu hoàn trả toàn bộ khoản gian lận hoặc chi phí bồi thường thiệt hại mà Green SM đã thanh toán thay cho Khách hàng/Bên thứ ba.
> 
> Nếu đăng tải thông tin sai sự thật hoặc tiêu cực về Green SM, ngoài các chế tài trên, Tài xế phải thực hiện đính chính và xin lỗi Green SM. Trường hợp có dấu hiệu vi phạm pháp luật, chuyển cơ quan chức năng xử lý.
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/83ae8dad-bang-2-3-cap-nhat-bo-quy-tac-ung-xu-car-platform-2-548x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> **NHÓM 2: CÁC LỖI NGHIÊM TRỌNG**
> 
> *   **16. Có hành vi bao gồm nhưng không giới hạn:**
>     *   Yêu cầu/gợi ý Khách hàng: thanh toán thêm cước, bo/tip, trả phí cầu đường cao hơn thực tế, và các khoản tiền không đúng theo quy định. Không trả lại tiền thừa cho Khách hàng.
>     *   Nhắn tin/gọi điện làm phiền Khách hàng.
> *   **Áp dụng cơ chế xử lý lũy tiến:**
>     *   Trừ ví 1.000.000₫ khi vi phạm Lần 1
>     *   Trừ ví 3.000.000₫ khi vi phạm Lần 2
>     *   Trừ ví 5.000.000₫ khi vi phạm Lần 3
> *   Đồng thời yêu cầu hoàn trả toàn bộ số tiền gian lận (nếu có).
> *   Lỗi vi phạm tính cộng dồn trong vòng 12 tháng từ thời điểm phát sinh vi phạm lần 1, sau đó sẽ được tính lại về vi phạm lần 1.
> 
> *   **17. Có hành vi bao gồm nhưng không giới hạn:**
>     *   Chấm dứt hành trình/yêu cầu Khách hàng xuống xe giữa đường khi Khách hàng không yêu cầu mà không có lý do chính đáng/không thông báo kịp thời cho bộ phận hỗ trợ Green SM.
>     *   **Lưu ý:** Việc thông báo kịp thời chỉ là một trong các tiêu chí xem xét, Green SM sẽ đánh giá toàn bộ bối cảnh và mức độ vi phạm để quyết định hình thức xử lý.
>     *   Vi phạm Luật An toàn Giao thông khác: che biển kiểm soát, vượt đèn đỏ, vượt giới hạn tốc độ, lấn làn, đi ngược chiều, sử dụng điện thoại khi đang di chuyển.
> *   **18. Mang bất kỳ vật dụng thiết bị nào có thể hiện dấu hiệu nhận diện của đơn vị khác hoạt động trong cùng Lĩnh vực với Green SM khi đang cung cấp dịch vụ cho Khách hàng thông qua ứng dụng Green SM.**
> *   **19. Có phản ánh từ Khách hàng liên tục một lỗi từ 02 lần trở lên (bao gồm các trường hợp có bằng chứng) hoặc 03 lần (với các trường hợp không có bằng chứng) trong vòng 07 ngày.**
> 
> *   **Áp dụng cơ chế xử lý lũy tiến:**
>     *   Trừ ví 1.000.000₫ khi vi phạm Lần 1
>     *   Trừ ví 2.000.000₫ khi vi phạm Lần 2
>     *   Trừ ví 3.000.000₫ khi vi phạm Lần 3
> *   Lỗi vi phạm tính cộng dồn trong vòng 12 tháng từ thời điểm phát sinh vi phạm lần 1, sau đó sẽ được tính lại về vi phạm lần 1.
> 
> **NHÓM 3: CÁC LỖI NHỎ**
> 
> *   **20. Nhận chuyến xe nhưng không đón Khách hàng, sau đó tự hủy hoặc yêu cầu Khách hàng hủy.**
> *   **21. Có thái độ không thân thiện với Khách hàng mức độ nhẹ: to tiếng, thô lỗ.**
> *   **22. Trả Khách hàng sai điểm đến mà không được sự đồng ý của Khách hàng hoặc thực hiện chuyến xe không đúng lộ trình tối ưu.**
> *   **23. Không tuân thủ đúng quy định tiêu chuẩn dịch vụ dành cho Đối tác Tài xế Car Platform (từ chối/bỏ trôi, đánh giá sao thấp).**
> *   **24. Thao tác sai trên App Driver khi thực hiện chuyến xe, bao gồm việc làm chênh lệch quãng đường di chuyển, cố ý kéo dài thời gian hoàn thành không thông báo kịp thời cho bộ phận hỗ trợ Green SM.**
>     *   **Lưu ý:** Việc thông báo kịp thời chỉ là một trong các tiêu chí xem xét: Green SM sẽ đánh giá toàn bộ bối cảnh và mức độ vi phạm để quyết định hình thức xử lý.
> *   **25. Không tuân thủ hiệu lệnh, quy định tại các điểm đậu đỗ của Green SM.**
> *   **26. Có hành vi thực hiện chuyến xe không đúng quy trình hoặc hướng dẫn nghiệp vụ của Green SM gây ảnh hưởng đến Khách hàng, bao gồm nhưng không giới hạn các trường hợp: không thực hiện đúng quy trình xác nhận/thống nhất với Khách hàng khi phát sinh thay đổi điểm đón, điểm trả hoặc lộ trình di chuyển; không thực hiện đúng hướng dẫn hỗ trợ Khách hàng liên quan đến thanh toán, hóa đơn hoặc các yêu cầu phát sinh trong chuyến xe; không thực hiện đúng quy trình xử lý các tình huống phát sinh trong quá trình thực hiện chuyến xe theo hướng dẫn của Green SM.**
> *   **27. Không tham gia các buổi đào tạo/kiểm tra theo thông báo của Green SM; Không đạt yêu cầu các bài kiểm tra đánh giá liên quan đến tiêu chuẩn vận hành, chất lượng dịch vụ và quy định hợp tác sau khi đã được nhắc nhở/yêu cầu bổ sung.**
> *   **28. Không tuân thủ đúng quy định về tác phong, diện mạo dành cho Đối tác Tài xế Car Platform.**
> 
> *   **Áp dụng cơ chế xử lý lũy tiến:**
>     *   Trừ ví 150.000₫ khi vi phạm Lần 1
>     *   Trừ ví 300.000₫ khi vi phạm Lần 2
>     *   Trừ ví 450.000₫ khi vi phạm Lần 3
> *   Lỗi vi phạm tính cộng dồn trong vòng 12 tháng từ thời điểm phát sinh vi phạm lần 1, sau đó sẽ được tính lại về vi phạm lần 1.
> *   Trừ ví 500.000đ/lần vi phạm.
> ```

![Hình ảnh minh họa](https://cdn.xanhsm.com/2026/06/996e3e0d-bang-4-cap-nhat-bo-quy-tac-ung-xu-car-platform-2-861x1024.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> NHÓM 4:
> CÁC HÀNH VI KHÁC
> 
> (29) Sử dụng phương tiện không đảm bảo tiêu chuẩn hoặc không đúng quy định hợp tác với Green SM, bao gồm việc phương tiện không đáp ứng tiêu chuẩn an toàn theo quy định của pháp luật hoặc không sử dụng đúng xe đã đăng ký hợp tác với Green SM.
> 
> (30) Không phối hợp bổ sung giấy tờ hợp lệ khi có yêu cầu: Bằng lái xe, đăng kiểm, phù hiệu hợp đồng, tem phản quang, các giấy tờ khác bị hết hạn hoặc bị thu hồi bởi Cơ quan Nhà nước.
> 
> (31) Green SM không liên hệ được với Đối tác Tài Xế từ 03 lần trở lên qua các thông tin, phương tiện liên lạc mà Đối tác Tài Xế đã cung cấp hoặc đối tác tài xế không phản hồi/trì hoãn quá 24 giờ trong việc cung cấp thông tin, dữ liệu, hình ảnh liên quan đến các chuyến xe bị nghi ngờ có dấu hiệu gian lận hoặc các sự vụ liên quan đến khiếu nại Khách hàng.
> 
> (32) Không hoàn thành các khóa đào tạo bắt buộc theo thời hạn quy định được Green SM thông báo.
> 
> (33) Không thực hiện đầy đủ nghĩa vụ tài chính với Green SM theo quy định (tính từ ngày Green SM gửi thông báo).
> Số tiền tương ứng sẽ được trừ trực tiếp từ ví của Đối tác Tài xế. Nếu sau 07 ngày làm việc vẫn không hoàn tất nghĩa vụ, hành vi này sẽ được chuyển sang lỗi Nhóm 1A - Chấm dứt tài khoản kinh doanh trên nền tảng Green SM vĩnh viễn
> 
> (34) Đối với các hành vi chưa được quy định cụ thể trong Bộ Quy tắc ứng xử nhưng có thể gây ảnh hưởng đến hình ảnh, chất lượng dịch vụ hoặc quyền lợi của Green SM và Khách hàng, Green SM được quyền xem xét, quyết định hình thức xử lý phù hợp theo từng trường hợp cụ thể.
> Tùy theo tính chất và mức độ vi phạm, Green SM có thể áp dụng các hình thức xử lý từ cảnh cáo đến chấm dứt tài khoản kinh doanh trên nền tảng Green SM vĩnh viễn, theo phê duyệt riêng của CBLĐ có thẩm quyền, cho các hành vi có thể chưa được quy định trong bộ Quy Tắc Ứng Xử, chất lượng dịch vụ hoặc quyền lợi của Green SM, Khách hàng.
> 
> **Tạm khóa tài khoản** cho đến khi làm rõ trách nhiệm và phương án xử lý
> ```

Bộ QTUX mới có nhiều điểm cập nhật quan trọng, vì vậy rất mong Bác Tài Xanh dành thời gian đọc kỹ và tuân thủ đúng quy định, để quá trình vận doanh diễn ra an toàn và hiệu quả hơn.

Mọi thắc mắc, Bác Tài Xanh vui lòng liên hệ Đội xe để được hỗ trợ.

Mến chúc Bác Tài Xanh vận doanh an toàn và hiệu quả.

Trân trọng,Khối Đồng hành & Phát triển Bác Tài Xanh.
