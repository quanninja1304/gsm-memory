# Cập nhật tính năng: Xác minh lý do hủy đơn Food & nâng cao hiệu suất hoạt động Bác Tài

- **Ngày đăng:** 2026-08-06
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/cap-nhat-tinh-nang-xac-minh-ly-do-huy-don-food](https://www.greensm.com/vn-vi/news/cap-nhat-tinh-nang-xac-minh-ly-do-huy-don-food)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Bác Tài Xanh thân mến,

Nhằm đảm bảo tính minh bạch trong quá trình xử lý hủy đơn Food và bảo vệ quyền lợi của Bác Tài khi khai báo đúng thực tế,Green SMtriển khai chính sách xác minh lý do hủy đơn Food đối với một số trường hợp hủy đơn như sau:

1. Điều kiện áp dụng:

– Dịch vụ áp dụng:Green SM Food.

– Hình thức xử lý:Ghi nhận Bác Tài hủy sai lý do và cảnh báo vi phạm. Nếu tiếp tục vi phạm sẽ bị xử lý theo như Quy tắc ứng xử

– Chính sách áp dụng khi Bác Tài hủy đơn với 03 lý do sau:

- Nhà hàng đóng cửa.

- Nhà hàng hết món.

- Không tìm thấy Nhà hàng.

2. Quy trình xử lý:

– Bước 1: Chọn đúng lý do hủy đơn

Bác Tài lựa chọn đúng một trong ba lý do hủy đơn thuộc phạm vi áp dụng của chính sách.

![Cập nhật tính năng: Xác minh lý do hủy đơn Food & nâng cao hiệu suất hoạt động Bác Tài](https://cdn.xanhsm.com/2026/08/2907b407-1-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> # GREEN SM
> 
> ## BƯỚC 1: CHỌN ĐÚNG LÝ DO HỦY ĐƠN
> 
> |   Ứng dụng 1 (Trái) | Ứng dụng 2 (Giữa) | Ứng dụng 3 (Phải) |
> | :------------------ | :---------------- | :---------------- |
> | **Lý do hủy đơn**   | **Lý do hủy đơn** | **Lý do hủy đơn** |
> | - Cửa hàng đóng cửa (tài xế báo) | - Cửa hàng đóng cửa (tài xế báo) | - Cửa hàng đóng cửa (tài xế báo) |
> | - Chờ quá lâu (>15 phút) | - Cửa hàng hết món (tài xế báo) | - Cửa hàng hết món (tài xế báo) |
> | - Tài xế gặp sự cố xe | - Chờ quá lâu (>15 phút) | - Chờ quá lâu (>15 phút) |
> | - Cửa hàng từ chối đơn | - Tài xế gặp sự cố xe | - Tài xế gặp sự cố xe |
> | - Tài xế không tìm thấy cửa hàng | - Cửa hàng từ chối đơn | - Cửa hàng từ chối đơn |
> | - Tài xế không liên hệ được khách nhận hàng | - Tài xế không tìm thấy cửa hàng | - Tài xế không tìm thấy cửa hàng |
> | - Lý do khác | - Tài xế không liên hệ được khách nhận hàng | - Lý do khác |
> | - Khách không có tiền thanh toán (COD) | - Lý do khác | - Khách không có tiền thanh toán (COD) |
> | - Tài xế giao sai món | - Khách không có tiền thanh toán (COD) | - Tài xế giao sai món |
> | - Đơn hàng bị thiếu hoặc hư hỏng | - Tài xế giao sai món | - Đơn hàng bị thiếu hoặc hư hỏng |
> | **Tiếp tục**       | - Đơn hàng bị thiếu hoặc hư hỏng | **Tiếp tục**       |
> |                     | **Tiếp tục**      |                   |
> 
> **Bác Tài lựa chọn đúng một trong ba lý do hủy đơn thuộc phạm vi áp dụng của chính sách**
> ```

– Bước 2: Bổ sung thông tin và hình ảnh xác minh

Tùy theo từng trường hợp, Bác Tài cần cung cấp thông tin và hình ảnh theo yêu cầu:

- Nhà hàng đóng cửa: Chụp ảnh cửa hàng đang đóng.

- Nhà hàng hết món: Chọn món đã hết trong danh sách và chụp ảnh xác minh đã đến nhà hàng hoặc ảnh thể hiện định vị tại nhà hàng để hệ thống làm căn cứ xác minh.

- Không tìm thấy Nhà hàng: Chọn tình huống phù hợp (đã liên hệ Nhà hàng hay chưa) và chụp ảnh khu vực tìm kiếm.

Lưu ý: Chụp tối thiểu 1 ảnh và tối đa 3 ảnh (hình ảnh rõ nét, thấy địa chỉ)

![Cập nhật tính năng: Xác minh lý do hủy đơn Food & nâng cao hiệu suất hoạt động Bác Tài](https://cdn.xanhsm.com/2026/08/6be766ff-2-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> Dưới đây là văn bản trích xuất từ hình ảnh theo định dạng Markdown tiếng Việt:
> 
> # BƯỚC 2: BỔ SUNG THÔNG TIN VÀ HÌNH ẢNH XÁC MINH
> 
> Tùy theo từng trường hợp, Bác Tài cần cung cấp thông tin và hình ảnh theo yêu cầu:
> 
> *   **Nhà hàng đóng cửa:** Chụp ảnh cửa hàng đang đóng.
> *   **Nhà hàng hết món:** Chọn món đã hết và chụp ảnh xác minh.
> *   **Không tìm thấy Nhà hàng:** Chọn tình huống phù hợp (đã liên hệ Nhà hàng hay chưa) và chụp ảnh khu vực tìm kiếm.
> 
> **Mô tả các giao diện điện thoại:**
> 
> **Giao diện 1: Xác nhận hủy đơn (trường hợp Nhà hàng đóng cửa)**
> 
> *   **Tiêu đề:** Xác nhận hủy đơn
> *   **Nội dung:** Upload bằng chứng hủy đơn hợp lệ\*
>     *   "Cung cấp ảnh và bằng chứng hợp lệ để hoàn thành hủy đơn một cách hợp lệ. Tài xế không trung thực sẽ bị xử lý theo Quy tắc Ứng xử"
> *   **Nút:** Chụp ảnh
> *   **Nút:** Tôi đã hiểu
> 
> **Giao diện 2: Xác nhận hủy đơn (trường hợp Nhà hàng hết món)**
> 
> *   **Tiêu đề:** Xác nhận hủy đơn
> *   **Câu hỏi:** Món ăn nào mà nhà hàng đang thiếu?
>     *   **Lựa chọn:** Tất cả các món
>     *   **Lựa chọn:** Trà Sữa Trân Châu Đường Đen (50% Đường 50% Đá Ngọt)
>     *   **Lựa chọn:** Phở bò tái nạm (Bạc xỉu, không hành)
>     *   **Lựa chọn:** Cơm tấm sườn bì chả
>     *   **Lựa chọn:** Topping
>     *   **Lựa chọn:** Thạch Rau Câu
> *   **Nội dung:** Upload bằng chứng hủy đơn hợp lệ\*
>     *   "Cung cấp ảnh và bằng chứng hợp lệ để hoàn thành hủy đơn một cách hợp lệ. Tài xế không trung thực sẽ bị xử lý theo Quy tắc Ứng xử"
> *   **Nút:** Chụp ảnh
> *   **Nút:** Tôi đã hiểu
> 
> **Giao diện 3: Xác nhận hủy đơn (trường hợp Không tìm thấy Nhà hàng)**
> 
> *   **Tiêu đề:** Xác nhận hủy đơn
> *   **Câu hỏi:** Anh chị đã tìm/gọi điện cho nhà hàng chưa?
>     *   **Lựa chọn:** Nhà hàng nghe máy và hướng dẫn, nhưng vẫn không tìm thấy
>     *   **Lựa chọn:** Nhà hàng không bắt máy
> *   **Nội dung:** Upload bằng chứng hủy đơn hợp lệ\*
>     *   "Cung cấp ảnh và bằng chứng hợp lệ để hoàn thành hủy đơn một cách hợp lệ. Tài xế không trung thực sẽ bị xử lý theo Quy tắc Ứng xử"
> *   **Nút:** Chụp ảnh
> *   **Nút:** Tôi đã hiểu

Bước 3: Xác nhận thông tin trạng thái Nhà hàng/Món

Sau khi nhận được yêu cầu, Nhà hàng có trách nhiệm phản hồi yêu cầu trong vòng 15 phút .

- Nhà hàng xác nhận trạng thái hiện tại của nhà hàng hoặc món tại cửa hàng. Trong trường hợp Nhà hàng không phản hồi trong thời gian quy định: Tài khoản của Bác Tài vẫn hoạt động bình thường.

- Nhà hàng phản hồi thông tin không trùng khớp ly do Bác Tài phản ánh – khai báo không đúng thực tế: Hệ thống sẽ ghi nhận và xử lý theo Quy tắc ứng xử dành cho Bác Tài.

Bước 4: Xử lý trường hợp khai báo không đúng thực tế

Sau khi chính sách chính thức có hiệu lực, trường hợp Bác Tài khai báo không đúng thực tế sau khi được xác thực sẽ bị xử lý theo Bộ quy tắc ứng xử.

3. Lưu ý dành cho Bác Tài

Để đảm bảo quyền lợi của mình, Quý Bác Tài vui lòng:

- Chỉ lựa chọn lý do hủy đơn đúng với tình huống thực tế.

- Cung cấp hình ảnh rõ ràng, đúng hiện trường theo yêu cầu của hệ thống.

- Thực hiện đúng quy trình để quá trình xác minh diễn ra nhanh chóng và minh bạch.

Việc khai báo đúng thực tế và cung cấp đầy đủ bằng chứng không chỉ giúp bảo vệ quyền lợi của Bác Tài, mà còn góp phần nâng cao chất lượng vận doanh, hạn chế các trường hợp Nhà hàng đóng cửa, hết món hoặc chưa cập nhật trạng thái trên hệ thống, từ đó mang đến trải nghiệm tốt hơn cho Khách hàng, Nhà hàng và Bác Tài.

Trân trọng,

Đội ngũ Green SM Bike

GÓC GIẢI ĐÁP

| Câu hỏi | Trả lời |
| --- | --- |
| Chính sách này áp dụng cho dịch vụ và trường hợp nào? | Áp dụng cho dịch vụFoodvới 03 lý do hủy:Nhà hàng đóng cửa, Nhà hàng hết món, Không tìm thấy nhà hàng. Các lý do hủy khác giữ nguyên quy trình hiện tại. |
| Huỷ đơn Food với 1 trong 3 lý do đề cập ở trên có ảnh hưởng đến tổng tỉ lệ hoàn thành chuyến của bạn không? | Có thể. Dựa trên trạng thái thực tế của Cửa hàng/Món và xác thực của Green SM. Tỉ lệ hoàn thành chuyến của Tài xế có thể ở 2 trường hợp sau:+ Trường hợp 1: Tài xế hủy đơn Food không đúng với tình trạng thực tế của cửa hàng sẽ ảnh hưởng tỉ lệ hoàn thành chuyến và có thể ảnh hưởng đến các chương trình thưởng (có điều kiện áp dụng % hiệu suất).+ Trường hợp 2: Tài xế hủy hợp lệ sẽ không bị tính tỉ lệ hoàn thành chuyến và không bị ảnh hưởng đến vận doanh |
| Tôi hủy vì quán đóng cửa/hết món thật thì có tài khoản có bị ảnh hưởng không? | Không. Nếu Nhà hàng xác nhận đúng như lý do bạn cung cấp hoặc không phản hồi trong vòng 15 phút, tài khoản sẽ không bị ảnh hưởng. Bác Tài chỉ cần cung cấp hình ảnh bằng chứng rõ ràng. |
| Vì sao tôi phải chụp ảnh khi hủy? | Hình ảnh là căn cứ xác minh khách quan, giúp bảo vệ Bác Tài khi khai báo đúng thực tế, đồng thời hỗ trợ hệ thống rà soát các Nhà hàng đóng cửa hoặc hết món để hạn chế phát sinh đơn tương tự. |
| Quán đóng cửa nhưng quên tắt app, tôi vẫn nhận đơn thì sao? | Đây là trường hợp cơ chế được thiết kế để bảo vệ tài xế. Nếu hủy đúng thực tế và cung cấp bằng chứng đầy đủ, tài khoản sẽ không bị ảnh hưởng; đồng thời hệ thống sẽ ghi nhận để rà soát và hạn chế phát sinh đơn “ảo”. |
| Nhà hàng có bao lâu để xác nhận? | Nhà hàng có 15 phút để xác nhận thông tin. Nếu quá thời gian này không phản hồi, yêu cầu xác nhận sẽ hết hiệu lực; Green SM có thể hậu kiểm dựa trên hình ảnh, lịch sử đơn và dữ liệu hệ thống. |
| Nếu tôi báo cáo sai thì sao? | Hiện tại, Green SM ghi nhận vào hồ sơ vận doanh, xử lý theo Quy tắc ứng xử nếu lặp lại, và ảnh hưởng tỉ lệ hoàn thành + chương trình thưởng. Hãy cân nhắc hủy và lựa chọn lý do phù hợp. |
