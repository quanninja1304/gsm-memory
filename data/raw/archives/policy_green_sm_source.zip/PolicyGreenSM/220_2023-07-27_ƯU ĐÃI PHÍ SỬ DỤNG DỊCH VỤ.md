# ƯU ĐÃI PHÍ SỬ DỤNG DỊCH VỤ

- **Ngày đăng:** 2023-07-27
- **Chuyên mục:** Tài xế Green SM Bike
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/uu-dai-phi-su-dung-dich-vu](https://www.greensm.com/vn-vi/news/uu-dai-phi-su-dung-dich-vu)
- **Có bảng biểu:** Có
- **Có hình ảnh OCR:** Có

---

Kính gửi Quý Đối tác Tài xế Green SM Bike,

GSM xin thông báo về chính sách chia sẻ doanh thu cho tất cả Đối tác Tài xế Green SM Bike như sau:

![Hình ảnh minh họa](https://cdn.xanhsm.com/2023/07/0f5b4cd0-chinh-sach-su-dung-xanhsm-bike-1024x576.png)

> **[Nội dung trích xuất từ ảnh]:**
> # XANH SM BIKE
> ## PHÍ SỬ DỤNG DỊCH VỤ
> ## XANH SM BIKE
> # 15.5%
> 
> Lưu ý:
> Chỉ áp dụng trong giai đoạn ra mắt
> cho những Đối tác Tài xế đầu tiên.
> 
> **ỨNG TUYỂN NGAY**

Chính sách chia sẻ doanh thu cho tất cả Đối tác Tài xế Green SM Bike

Phí sử dụng dịch vụ được tính trên tổng thu mà Tài xế nhận được trên mỗi chuyến xe thực hiện thành công là 20% không bao gồm các khoản Thuế theo nghĩa vụ nhà nước. Trong giai đoạn ra mắt, phí sử dụng dịch vụ GSM chỉ còn 15.5% dành cho những Đối tác Tài xế tham gia đầu tiên.

Đồng thời, GSM sẽ phụ thu phí nền tảng từ Khách hàng để nghiên cứu và cải tiến nhằm mang lại sự an toàn, tin cậy cho Khách hàng và phát triển ứng dụng. Phí này sẽ được tính trực tiếp vào cước phí chuyến xe và KHÔNG ảnh hưởng đến thu nhập của Tài xế. GSM sẽ tự động khấu trừ khoản phí này sau khi chuyến xe hoàn thành.

Bảng tính doanh thu của Tài xế

Doanh thu tài xế thực nhận = Tổng thu Khách – Phí nền tảng – Phí dịch vụ GSM – Thuế và phí khác

| Tổng thu khách hàng | 50.000đ |
| --- | --- |
| Phí nền tảng | 3.350đ |
| Cước phí chuyến xe | 46.650đ |
| Doanh thu tài xế nhận | 35.000đ |

* Lưu ý dành cho ứng viên tham gia phỏng vấn:

- Yêu cầu mặc quần dài, áo có cổ, đi giày hoặc xăng-đan.

- Không mặc áo sát nách, quần ngắn/lửng, đi dép lê/dép tổ ong/dép trong nhà
