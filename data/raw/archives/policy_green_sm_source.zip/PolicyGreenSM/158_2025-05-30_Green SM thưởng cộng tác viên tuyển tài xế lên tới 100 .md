# Green SM thưởng cộng tác viên tuyển tài xế lên tới 100 triệu đồng

- **Ngày đăng:** 2025-05-30
- **Chuyên mục:** Tài xế Green SM Car
- **Nguồn bài viết:** [https://www.greensm.com/vn-vi/news/thuong-cong-tac-vien-tuyen-tai-xe](https://www.greensm.com/vn-vi/news/thuong-cong-tac-vien-tuyen-tai-xe)
- **Có bảng biểu:** Không
- **Có hình ảnh OCR:** Có

---

Để đẩy mạnh tuyển dụng·đội ngũ tài xế chất lượng năm 2025, Green SM triển khai chương trình tuyển cộng tác viên tuyển dụng với mức thưởng cực kỳ hấp dẫn. Khám phá ngay những thông tin nổi bật nhất về chính sáchthưởng cộng tác viên tuyển tài xếvà quy trình làm việc vị trícộng tác viên tuyển dụng Green SM.

![Gia nhập Green SM ngay hôm nay để bắt đầu hành trình gia tăng thu nhập chủ động, không rủi ro (Ảnh: Green SM)](https://cdn.xanhsm.com/2025/05/2f277f4f-chuong-trinh-thuong-xanh-sm-4.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> BÁC TÀI
> XANH
> TUYỂN CTV GIỚI THIỆU TÀI XẾ
> THƯỞNG THI ĐUA LÊN ĐẾN
> 100 TRIỆU VNĐ
> 
> **THƯỞNG**
> **1 TRIỆU**
> VNĐ/tài xế
> 
> **THƯỞNG LŨY TIẾN**
> LÊN ĐẾN
> **500K**
> VNĐ/tài xế
> 
> ĐĂNG KÝ NGAY
> ```

Gia nhập Green SM ngay hôm nay để bắt đầu hành trình gia tăng thu nhập chủ động, không rủi ro (Ảnh: Green SM)

## Đối tượng và thời gian áp dụng

Chính sách thưởng cộng tác viên tuyển tài xế Green SM áp dụng cho tất cả cá nhân/tổ chức không thuộc GSM và Tập đoàn Vingroup. Thời gian và khu vực áp dụng như sau:

- Thời gian áp dụng: từ 04/04/2025 – 31/06/2025.

- Khu vực áp dụng: Hà Nội và TP. Hồ Chí Minh.

## Mức thưởng cộng tác viên tuyển tài xế Green SM

Với mỗi tài xế tuyển dụng thành công theo yêu cầu, cộng tác viên tuyển dụng sẽ nhận được 1.000.000 VNĐ/tài xế.

Hơn nữa, Green SM còn áp dụng thưởng theo mốc tài xế tuyển được của cộng tác viên (thưởng thêm trên 1 tài xế tuyển dụng thành công). Cụ thể:

- Từ người thứ 10 đến 19: 150.000 VNĐ

- Từ người thứ 20 đến 29: 200.000 VNĐ

- Từ người thứ 30 đến 49: 300.000 VNĐ

- Từ người thứ 50: 500.000 VNĐ

Lưu ý: Tài xế tuyển dụng thành công là tài xế mới (không thuộc trường hợp tái tuyển), ký hợp đồng đào tạo và làm việc đủ 7 ngày kể từ ngày vào.

Đặc biệt, cộng tác viên tuyển tài xế Green SM nằm trong TOP tuyển dụng được nhiều tài xế nhất sẽ nhận thưởng lên đến 100 triệu đồng. Trong đó:

- Top 1 (1 giải): Tổng số lượng ứng viên đạt 500 trở lên: 100.000.000 VNĐ

- Top 2 (3 giải): Tổng số lượng ứng viên đạt tối thiểu 300: 50.000.000 VNĐ

- Top 3 (10 giải): Tổng số lượng ứng viên đạt tối thiểu 100: 20.000.000 VNĐ

Cộng tác viên cần đạt điều kiện số lượng ứng viên tối thiểu để xét thưởng. Bảng xếp hạng nhận thưởng cộng tác viên tuyển tài xế cho TOP tuyển dụng sẽ xếp hạng từ cao xuống thấp. Toàn bộ thưởng sẽ được chi trả một lần duy nhất sau khi kết thúc chương trình.

![Cộng tác viên tuyển được càng nhiều tài xế, mức thưởng càng cao (Ảnh: Green SM)](https://cdn.xanhsm.com/2025/05/f16d4fe4-thuong-cong-tac-vien-tuyen-tai-xe-2.jpg)

> **[Nội dung trích xuất từ ảnh]:**
> ```markdown
> XANH SM
> LUXURY
> XANH SM
> PLATFORM
> ```

Cộng tác viên tuyển được càng nhiều tài xế, mức thưởng càng cao (Ảnh: Green SM)

## Quy trình làm việc vị trí cộng tác viên tuyển tài xế Green SM

Để trở thành cộng tác viên tuyển tài xế Green SM và nhận thưởng, bạn cần thực hiện theo quy trình sau:

- Bước 1: Cộng tác viên ký hợp đồng với GSM và thực hiện tìm kiếm ứng viên và tư vấn sơ bộ về các tiêu chí tuyển.

- Bước 2: Cộng tác viên gửi danh sách ứng viên tới đầu mối GSM để thực hiện quy trình tuyển dụng.

- Bước 3: Phòng tuyển dụng thông báo danh sách hợp lệ (không trùng với data phòng tuyển dụng đã có) và kết quả phỏng vấn thành công đến cộng tác viên.

- Bước 4: Cộng tác viên tổng hợp danh sách ứng viên, gửi phòng tuyển dụng đối soát và kiểm tra các trường hợp hợp lệ vào ngày 25 hàng tháng.

- Bước 5: Cộng tác viên ký/xác nhận biên bản nghiệm thu sau khi đối soát.

- Bước 6: Phòng tuyển dụng thực hiện thanh toán vào ngày cuối cùng của tháng cho danh sách hợp lệ.

Lưu ý: Danh sách hợp lệ được chi trả là danh sách tài xế mới (không thuộc trường hợp tái tuyển), ký hợp đồng đào tạo và làm việc đủ 7 ngày kể từ ngày vào.

Nếu bạn yêu thích công việc tuyển dụng với thời gian linh hoạt, lương thưởng minh bạch thì hãy tham gia đội ngũcộng tác viên tuyển tài xế Green SMngay hôm nay! Đây là cơ hội để bạn có thể nâng cao thu nhập nhanh chóng cùng Green SM và chinh phục những mốcthưởng cộng tác viên tuyển tài xếhấp dẫn!
